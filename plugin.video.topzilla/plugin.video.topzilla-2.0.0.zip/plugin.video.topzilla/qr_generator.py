# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""Genera un QR en PNG con segno (paquete vendorizado en la raiz del addon).

cleanup() es responsabilidad del llamador: generate() solo crea el archivo
temporal y devuelve su ruta.
"""
import os
import tempfile

import xbmc
import xbmcvfs

_QR_SCALE = 8


def generate(url):
    """Genera un QR PNG en special://temp y devuelve su ruta, o None si falla."""
    if not url:
        return None

    try:
        import segno
    except ImportError as e:
        xbmc.log(f"[TopZilla/qr] segno no disponible: {e}", xbmc.LOGWARNING)
        return None

    # mkstemp evita colisiones entre invocaciones simultaneas; segno reabre el path.
    temp_dir = xbmcvfs.translatePath("special://temp/")
    fd, output_path = tempfile.mkstemp(prefix="topzilla_qr_", suffix=".png", dir=temp_dir)
    os.close(fd)
    try:
        qr = segno.make(url, micro=False, error="M")
        qr.save(
            output_path,
            kind="png",
            scale=_QR_SCALE,
            dark="#000000",
            light="#ffffff",
            border=2,
        )
        return output_path
    except (OSError, ValueError) as e:
        xbmc.log(f"[TopZilla/qr] segno error: {e}", xbmc.LOGWARNING)
        cleanup(output_path)
        return None


def cleanup(path):
    """Borra el PNG. Idempotente: ignora None o archivos inexistentes."""
    if not path:
        return
    try:
        os.remove(path)
    except OSError:
        pass
