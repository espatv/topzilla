# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
"""Índice de "visto" para pintar el ✔ en el catálogo.

Unión de dos fuentes: el historial local (watch_history) y lo visto en Trakt
(pull cacheado en disco con TTL). El resultado se cachea a nivel proceso para que
metadata_enricher.apply_to_listitem (llamado por cada item de cada lista) consulte
en O(1) sin tocar disco ni red por item.

Thread-safe: el Modo Cine construye filas en hilos concurrentes; la construcción
del set se serializa con un lock + doble-check.

Imports de watch_history/trakt_sync diferidos (dentro de funciones) para no crear
ciclos: watch_history.is_watched llama aquí, y aquí leemos watch_history.
"""
import threading
import time

import core_settings

_TRAKT_CACHE_FILE = 'trakt_watched_cache.json'
_TRAKT_TTL = 30 * 60  # 30 min: ventana entre pulls a Trakt

_lock = threading.Lock()
_mem = None  # frozenset de claves; caché de proceso (None = aún no construido)


def _keys_from_items(items, media_type):
    """Genera la clave ref_key por tmdb Y por imdb de cada item visto, para que un
    item del catálogo case aunque solo traiga uno de los dos identificadores."""
    keys = set()
    for it in items:
        tmdb = it.get('tmdb')
        imdb = it.get('imdb')
        if tmdb:
            try:  # un id raro de un título no debe tirar TODO el set de Trakt
                keys.add(f"tmdb:{media_type}:{int(tmdb)}")
            except (TypeError, ValueError):
                pass
        if imdb:
            keys.add(f"imdb:{media_type}:{imdb}")
    return keys


def _load_trakt_cache():
    data = core_settings.load_json(_TRAKT_CACHE_FILE, default=None)
    if not isinstance(data, dict):
        return None
    keys = data.get('keys')
    if not isinstance(keys, list):
        return None
    try:
        ts = int(data.get('ts', 0))
    except (TypeError, ValueError):
        ts = 0
    return ts, set(keys)


def _save_trakt_cache(keys):
    core_settings.save_json(_TRAKT_CACHE_FILE, {'ts': int(time.time()), 'keys': sorted(keys)})


def _trakt_keys():
    """Claves vistas en Trakt, desde la caché de disco o un pull si caducó.
    Si el pull no trae nada pero había caché (posible fallo de red), conserva la
    caché previa en vez de vaciar el ✔."""
    cached = _load_trakt_cache()
    if cached is not None and (time.time() - cached[0]) < _TRAKT_TTL:
        return cached[1]
    import trakt_sync
    if not trakt_sync.read_enabled():
        return set()
    keys = (_keys_from_items(trakt_sync.fetch_watched_movies(), 'movie')
            | _keys_from_items(trakt_sync.fetch_watched_shows(), 'show'))
    if not keys and cached is not None:
        return cached[1]  # fallback a caché caducada
    _save_trakt_cache(keys)
    return keys


def watched_keys():
    """Set (frozenset) de claves vistas: local + Trakt. Cacheado por proceso."""
    global _mem
    if _mem is not None:
        return _mem
    with _lock:
        if _mem is not None:  # otro hilo lo construyó mientras esperábamos el lock
            return _mem
        keys = set()
        try:
            import watch_history
            keys |= set(watch_history.watched_keys())
        except Exception:
            pass
        try:
            keys |= _trakt_keys()
        except Exception:
            pass
        _mem = frozenset(keys)
        return _mem


def is_watched_key(key):
    return bool(key) and key in watched_keys()


def invalidate():
    """Fuerza reconstruir el set de proceso (tras marcar/desmarcar local)."""
    global _mem
    with _lock:
        _mem = None
