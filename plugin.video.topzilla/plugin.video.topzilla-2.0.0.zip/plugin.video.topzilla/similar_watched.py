# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
"""Recomendaciones LOCALES: 'Similar a lo que has visto'.

Toma los títulos recientes del historial de visionado, junta las recomendaciones
de TMDB de cada uno (las que aparecen en varios suben), excluye lo ya visto y las
muestra como catálogo. Inspirado en el widget homónimo de Embuary, pero sobre el
historial propio de TopZilla.
"""
import sys

import context_menu
import core_settings
import movie_ref

_SEEDS = 6      # títulos recientes del historial de los que sacar recomendaciones
_LIMIT = 40     # recomendaciones a mostrar


def _u(**kwargs):
    return core_settings.make_url(**kwargs)


def _handle():
    return int(sys.argv[1])


def _canon_mt(mt):
    return 'show' if mt in ('show', 'tv') else 'movie'


def _aggregate(metas, watched_keys, limit=_LIMIT):
    """Pura (testeable): junta las 'recommendations' de varios metas, excluye lo
    visto, y ordena por frecuencia (aparece en varias semillas) y luego rating."""
    freq, cand = {}, {}
    for meta in metas:
        for rec in (meta.get('recommendations') or []):
            tid = rec.get('tmdb_id')
            if not tid:
                continue
            mt = _canon_mt(rec.get('media_type', 'movie'))
            key = f"tmdb:{mt}:{int(tid)}"
            if key in watched_keys:
                continue
            freq[key] = freq.get(key, 0) + 1
            cand[key] = rec
    ordered = sorted(cand.items(), key=lambda kv: (-freq[kv[0]], -(kv[1].get('rating') or 0)))
    return [item for _, item in ordered[:limit]]


def show_menu():
    import metadata_enricher as me
    import watch_history
    import xbmcgui
    import xbmcplugin

    h = _handle()
    af = core_settings.addon_fanart()
    bold  = core_settings.get_acc_force_bold()
    strip = core_settings.get_acc_strip_symbols()
    color = core_settings.get_acc_color_mode()

    refs = watch_history.watched_refs()
    seeds = [r for r in refs if r.get('tmdb_id')][:_SEEDS]
    if not seeds:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            "[COLOR gray]Marca alguna película como vista para tener recomendaciones[/COLOR]",
            bold=bold, strip=strip, color_mode=color))
        li.setArt({'icon': 'DefaultIconInfo.png', 'fanart': af})
        xbmcplugin.addDirectoryItem(handle=h, url='', listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
        return

    progress = xbmcgui.DialogProgressBG()
    progress.create('TopZilla', 'Buscando recomendaciones…')
    metas = []
    try:
        for s in seeds:
            tid = s.get('tmdb_id')
            if not tid:
                continue
            try:
                # las recomendaciones viven en los "extras" de TMDB, no en el meta base.
                extras = me.fetch_tmdb_extras(tid, _canon_mt(s.get('media_type', 'movie')))
            except Exception:
                continue  # una semilla fallida no debe tumbar toda la lista
            if extras and extras.get('recommendations'):
                metas.append(extras)
    finally:
        progress.close()

    watched = watch_history.watched_keys()
    items = _aggregate(metas, watched)

    if not items:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            "[COLOR gray]No hay recomendaciones nuevas por ahora[/COLOR]",
            bold=bold, strip=strip, color_mode=color))
        li.setArt({'icon': 'DefaultIconInfo.png', 'fanart': af})
        xbmcplugin.addDirectoryItem(handle=h, url='', listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
        return

    for item in items:
        mt = _canon_mt(item.get('media_type', 'movie'))
        year = item.get('year') or 0
        label = f"{item['title']} ({year})" if year else item['title']
        li = xbmcgui.ListItem(label=core_settings.apply_label(label, bold=bold, strip=strip, color_mode=color))

        meta = me.enrich(tmdb_id=item.get('tmdb_id'), media_type=mt, use_cache_only=True)
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
        else:
            poster = item.get('poster') or ''
            fanart = item.get('fanart') or af
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': poster, 'poster': poster, 'fanart': fanart})
            li.setInfo('video', {'title': item['title'], 'year': year or 0,
                                 'mediatype': 'tvshow' if mt == 'show' else 'movie'})

        ref = movie_ref.make_ref(title=item['title'], year=year or None,
                                 tmdb_id=item.get('tmdb_id'), media_type=mt,
                                 poster=item.get('poster', ''), source='similar')
        context_menu.attach(li, ref)
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(handle=h, url=context_menu.build_play_url(ref),
                                    listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h, cacheToDisc=core_settings.remember_list_position())
