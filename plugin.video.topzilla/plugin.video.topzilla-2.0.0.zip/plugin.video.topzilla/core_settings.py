# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
import base64
import hashlib
import json
import os
import re
import threading
import time

_TMDB_KEY_POOL_B64 = (
    "MjczZmZkMmY0MjhkZjNlMGVmNDc5ZWViOGQ2MzI1NDE=",
    "MjVjZGJiY2I0ZDk0ZTBkZWNlYTQxNzhhMjdjMzE1MmM=",
    "MjJjMTNmNWNlYzA3NDZkNDRlMjRiOWU4ZmVmZTRlNDU=",
    "YjY0YmRlYTM2OWQ4ODZlNWI3MzkyYmZiYjA5ZDRmOTU=",
)

_OMDB_KEY_POOL_B64 = (
    "NjVmMTVmM2Y=",
    "NDU4ODI0YWU=",
    "ZjVhNTM5NzI=",
)

_dead_pool_keys = set()
_dead_omdb_pool_keys = set()
_uid_cache = None
_decoded_pool = None
_decoded_omdb_pool = None


def _decode_one(b64):
    try:
        return base64.b64decode(b64).decode()
    except Exception:
        return ""


def _decoded():
    global _decoded_pool
    if _decoded_pool is None:
        _decoded_pool = tuple(_decode_one(b) for b in _TMDB_KEY_POOL_B64)
    return _decoded_pool


def _uid():
    global _uid_cache
    if _uid_cache is None:
        try:
            import stats
            _uid_cache = stats._get_uuid() or "x"
        except Exception:
            _uid_cache = "x"
    return _uid_cache


def _pool_index():
    h = hashlib.sha1(_uid().encode("utf-8")).hexdigest()
    return int(h[:8], 16) % len(_TMDB_KEY_POOL_B64)


def _pool_key():
    pool = _decoded()
    n = len(pool)
    start = _pool_index()
    for i in range(n):
        idx = (start + i) % n
        if idx in _dead_pool_keys:
            continue
        if pool[idx]:
            return pool[idx]
    _dead_pool_keys.clear()
    return pool[start]


def mark_tmdb_pool_key_dead(key):
    if not key:
        return
    pool = _decoded()
    for idx, k in enumerate(pool):
        if k == key:
            _dead_pool_keys.add(idx)
            return


def _decoded_omdb():
    global _decoded_omdb_pool
    if _decoded_omdb_pool is None:
        _decoded_omdb_pool = tuple(_decode_one(b) for b in _OMDB_KEY_POOL_B64)
    return _decoded_omdb_pool


def _omdb_pool_index():
    h = hashlib.sha1(_uid().encode("utf-8")).hexdigest()
    return int(h[8:16], 16) % len(_OMDB_KEY_POOL_B64)


def _omdb_pool_key():
    pool = _decoded_omdb()
    n = len(pool)
    if n == 0:
        return ""
    start = _omdb_pool_index()
    for i in range(n):
        idx = (start + i) % n
        if idx in _dead_omdb_pool_keys:
            continue
        if pool[idx]:
            return pool[idx]
    _dead_omdb_pool_keys.clear()
    return pool[start]


def mark_omdb_pool_key_dead(key):
    if not key:
        return
    pool = _decoded_omdb()
    for idx, k in enumerate(pool):
        if k == key:
            _dead_omdb_pool_keys.add(idx)
            return


def _auto_fetch_enabled():
    try:
        import xbmcaddon
        return xbmcaddon.Addon().getSetting('auto_fetch') == 'true'
    except Exception:
        return False


def set_auto_fetch_enabled(state):
    try:
        import xbmcaddon
        xbmcaddon.Addon().setSetting('auto_fetch', 'true' if state else 'false')
        return True
    except Exception:
        return False


def _show_context_menu_enabled():
    # Default true; userdata vacía o ausente cae al default.
    try:
        import xbmcaddon
        return xbmcaddon.Addon().getSetting('show_context_menu') != 'false'
    except Exception:
        return True


def _espadaily_integration_enabled():
    try:
        import xbmcaddon
        return xbmcaddon.Addon().getSetting('espadaily_integration_enabled') == 'true'
    except Exception:
        return False


def set_espadaily_integration_enabled(state):
    try:
        import xbmcaddon
        xbmcaddon.Addon().setSetting('espadaily_integration_enabled', 'true' if state else 'false')
        return True
    except Exception:
        return False


def _atresdaily_integration_enabled():
    try:
        import xbmcaddon
        return xbmcaddon.Addon().getSetting('atresdaily_integration_enabled') == 'true'
    except Exception:
        return False


def set_atresdaily_integration_enabled(state):
    try:
        import xbmcaddon
        xbmcaddon.Addon().setSetting('atresdaily_integration_enabled', 'true' if state else 'false')
        return True
    except Exception:
        return False


def _espatv_integration_enabled():
    try:
        import xbmcaddon
        return xbmcaddon.Addon().getSetting('espatv_integration_enabled') == 'true'
    except Exception:
        return False


def set_espatv_integration_enabled(state):
    try:
        import xbmcaddon
        xbmcaddon.Addon().setSetting('espatv_integration_enabled', 'true' if state else 'false')
        return True
    except Exception:
        return False


def set_show_context_menu_enabled(state):
    try:
        import xbmcaddon
        xbmcaddon.Addon().setSetting('show_context_menu', 'true' if state else 'false')
        return True
    except Exception:
        return False


def _show_context_menu_view_card_enabled():
    # Default true; userdata vacía o ausente cae al default.
    try:
        import xbmcaddon
        return xbmcaddon.Addon().getSetting('show_context_menu_view_card') != 'false'
    except Exception:
        return True


def set_show_context_menu_view_card_enabled(state):
    try:
        import xbmcaddon
        xbmcaddon.Addon().setSetting('show_context_menu_view_card', 'true' if state else 'false')
        return True
    except Exception:
        return False


def show_soundtrack_button_enabled():
    try:
        import xbmcaddon
        return xbmcaddon.Addon().getSetting('show_soundtrack_button') == 'true'
    except Exception:
        return False


def set_show_soundtrack_button_enabled(state):
    try:
        import xbmcaddon
        xbmcaddon.Addon().setSetting('show_soundtrack_button', 'true' if state else 'false')
        return True
    except Exception:
        return False


def show_omdb_button_enabled():
    try:
        import xbmcaddon
        return xbmcaddon.Addon().getSetting('show_omdb_button') == 'true'
    except Exception:
        return False


def set_show_omdb_button_enabled(state):
    try:
        import xbmcaddon
        xbmcaddon.Addon().setSetting('show_omdb_button', 'true' if state else 'false')
        return True
    except Exception:
        return False


def show_share_button_enabled():
    try:
        import xbmcaddon
        return xbmcaddon.Addon().getSetting('show_share_button') == 'true'
    except Exception:
        return False


def set_show_share_button_enabled(state):
    try:
        import xbmcaddon
        xbmcaddon.Addon().setSetting('show_share_button', 'true' if state else 'false')
        return True
    except Exception:
        return False


def show_megabuscador_button_enabled():
    try:
        import xbmcaddon
        return xbmcaddon.Addon().getSetting('show_megabuscador_button') == 'true'
    except Exception:
        return False


def set_show_megabuscador_button_enabled(state):
    try:
        import xbmcaddon
        xbmcaddon.Addon().setSetting('show_megabuscador_button', 'true' if state else 'false')
        return True
    except Exception:
        return False


def _all_setting_ids():
    """IDs de todos los <setting> de resources/settings.xml. Fuente única de verdad
    para el reset: leerlos del XML evita que una lista paralela se desincronice (y
    deje sin borrar ajustes nuevos, tokens Debrid o el PIN parental)."""
    import xml.etree.ElementTree as ET
    path = os.path.join(_addon().getAddonInfo('path'), 'resources', 'settings.xml')
    return [s.get('id') for s in ET.parse(path).iter('setting') if s.get('id')]


def reset_all_settings():
    try:
        addon = _addon()
        for sid in _all_setting_ids():
            addon.setSetting(sid, '')
        return True
    except Exception:
        return False


# --- Helpers genéricos de perfil/JSON (usados por favorites, watch_history,
#     navigation_history, search_history, category_manager, trakt_manager,
#     backup_manager) ---

def profile_dir():
    """Devuelve la ruta del perfil del addon, creándolo si no existe."""
    import xbmcaddon
    import xbmcvfs
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    os.makedirs(p, exist_ok=True)  # exist_ok: evita FileExistsError si dos hilos lo crean a la vez
    return p


def profile_file(name):
    return os.path.join(profile_dir(), name)


def load_json(name, default=None):
    """Devuelve `default` si el archivo no existe o está corrupto. Si el JSON está
    corrupto, loguea y mueve el archivo a `<name>.corrupt` para no perderlo en
    silencio (datos del usuario: favoritos, historial...) y poder diagnosticar."""
    if default is None:
        default = {}
    path = profile_file(name)
    if not os.path.exists(path):
        return default
    try:
        with open(path, 'r', encoding='utf-8') as fh:
            return json.load(fh)
    except ValueError as e:
        _log_warning("load_json {0} corrupto: {1}".format(name, e))
        _quarantine_corrupt(path)
        return default
    except OSError as e:
        _log_warning("load_json {0}: {1}".format(name, e))
        return default


def _log_warning(msg):
    try:
        import xbmc
        xbmc.log("[TopZilla] {0}".format(msg), xbmc.LOGWARNING)
    except Exception:
        pass


def _quarantine_corrupt(path):
    """Renombra un JSON corrupto a `<path>.corrupt` (con sufijo si ya existe) para
    no perder los datos del usuario y permitir recuperación manual."""
    try:
        dst = path + '.corrupt'
        if os.path.exists(dst):
            dst = "{0}.{1}".format(dst, threading.get_ident())
        os.replace(path, dst)
    except OSError:
        pass


def save_json(name, data):
    # Escritura atómica: tmp-por-hilo + os.replace. Un crash a media escritura deja
    # el .tmp parcial pero el destino intacto; el sufijo de hilo evita que dos
    # escritores del mismo fichero (p.ej. Modo Cine BG + menú contextual) colisionen
    # en el mismo tmp. Beneficia a favoritos/historiales, que pasan por aquí.
    path = profile_file(name)
    tmp = f"{path}.{threading.get_ident()}.tmp"
    try:
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        # En Windows os.replace lanza PermissionError si otro hilo tiene el destino
        # abierto para lectura (un lector de caché coincidiendo con la escritura).
        # La ventana es de microsegundos; reintentar un par de veces la salva sin
        # perder la escritura (favoritos/historial). Verificado en Win11/Python 3.x.
        for intento in range(3):
            try:
                os.replace(tmp, path)
                return True
            except PermissionError:
                if intento == 2:
                    raise
                time.sleep(0.05)
    except (OSError, TypeError, ValueError):
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except OSError:
            pass
        return False


# --- Personalización del menú principal (reordenar / ocultar entradas) ---
# Formato: {'order': [id, ...], 'hidden': [id, ...]}.

_MENU_LAYOUT_FILE = 'menu_layout.json'


def load_menu_layout():
    """Carga defensiva: siempre devuelve dict con 'order'/'hidden' como listas de str."""
    data = load_json(_MENU_LAYOUT_FILE, {'order': [], 'hidden': []})
    if not isinstance(data, dict):
        return {'order': [], 'hidden': []}
    order = data.get('order') if isinstance(data.get('order'), list) else []
    hidden = data.get('hidden') if isinstance(data.get('hidden'), list) else []
    return {
        'order': [k for k in order if isinstance(k, str)],
        'hidden': [k for k in hidden if isinstance(k, str)],
    }


def save_menu_layout(layout):
    # Escritura atómica: otra navegación del addon que lea a la vez ve el archivo
    # viejo completo o el nuevo completo, nunca uno truncado a medias.
    path = profile_file(_MENU_LAYOUT_FILE)
    tmp = path + '.tmp'
    try:
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(layout, fh, ensure_ascii=False)
        os.replace(tmp, path)
        return True
    except (OSError, TypeError, ValueError):
        return False


def reset_menu_layout():
    path = profile_file(_MENU_LAYOUT_FILE)
    if os.path.exists(path):
        try:
            os.remove(path)
        except OSError:
            return False
    return True


def make_url(**kwargs):
    """Construye la URL del plugin con los parámetros pasados.
    Helper único usado por los módulos del addon (sustituye al `_u` duplicado)."""
    import sys
    import urllib.parse
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)


# --- Accesibilidad (lee/escribe en settings.xml de Kodi) ---

_ACC_COLOR_MODES = ['none', 'white', 'daltonic_rg', 'daltonic_by', 'hc_dark', 'hc_light']


def _addon():
    import xbmcaddon
    return xbmcaddon.Addon()


def get_acc_color_mode():
    try:
        idx = int(_addon().getSetting('acc_color_mode') or '0')
        return _ACC_COLOR_MODES[idx] if 0 <= idx < len(_ACC_COLOR_MODES) else 'none'
    except Exception:
        return 'none'


def set_acc_color_mode(mode):
    try:
        idx = _ACC_COLOR_MODES.index(mode) if mode in _ACC_COLOR_MODES else 0
        _addon().setSetting('acc_color_mode', str(idx))
    except Exception:
        pass


def get_acc_force_bold():
    try:
        return _addon().getSetting('acc_force_bold') == 'true'
    except Exception:
        return True  # default del XML; coherente si getSetting fallara


def set_acc_force_bold(state):
    try:
        _addon().setSetting('acc_force_bold', 'true' if state else 'false')
    except Exception:
        pass


def get_acc_strip_symbols():
    try:
        return _addon().getSetting('acc_strip_symbols') == 'true'
    except Exception:
        return False


def set_acc_strip_symbols(state):
    try:
        _addon().setSetting('acc_strip_symbols', 'true' if state else 'false')
    except Exception:
        pass


def get_acc_font_size():
    try:
        return _addon().getSetting('acc_font_size') == 'true'
    except Exception:
        return False


def set_acc_font_size(state):
    try:
        _addon().setSetting('acc_font_size', 'true' if state else 'false')
    except Exception:
        pass


_SYMBOL_MAP = {
    '★': '*', '☆': '*', '●': '·', '•': '-',
    '▲': '^', '▼': 'v', '►': '>', '◄': '<',
    '➤': '>', '✓': 'OK', '✗': 'X', '✘': 'X',
    '→': '->', '←': '<-', '↑': '^', '↓': 'v',
    '…': '...', '«': '<<', '»': '>>',
}


_COLOR_TRANSFORM = {
    'white': {
        '__default__': 'white',
    },
    'daltonic_rg': {
        'red': 'darkorange', 'crimson': 'darkorange', 'darkred': 'darkorange',
        'tomato': 'darkorange', 'firebrick': 'darkorange',
        'green': 'deepskyblue', 'limegreen': 'deepskyblue', 'lime': 'deepskyblue',
        'darkgreen': 'deepskyblue', 'chartreuse': 'deepskyblue',
    },
    'daltonic_by': {
        'yellow': 'fuchsia', 'gold': 'fuchsia', 'orange': 'fuchsia',
        'darkorange': 'fuchsia', 'lightyellow': 'fuchsia',
        'blue': 'orangered', 'deepskyblue': 'orangered', 'cyan': 'orangered',
        'cornflowerblue': 'orangered', 'royalblue': 'orangered', 'aqua': 'orangered',
    },
    'hc_dark': {
        '__default__': 'yellow',
        'red': 'red',
    },
    'hc_light': {
        '__default__': 'black',
        'red': 'red',
    },
}

_COLOR_WRAP = {
    'white':    'white',
    'hc_dark':  'yellow',
    'hc_light': 'black',
}

_COLOR_TAG_RE = re.compile(r'\[COLOR ([^\]]+)\](.*?)\[/COLOR\]', re.DOTALL)


def _apply_color_transform(text, mode):
    transform = _COLOR_TRANSFORM.get(mode)
    if not transform:
        return text
    default = transform.get('__default__')

    def _replace(m):
        color = m.group(1).lower().strip()
        new = transform.get(color, default)
        if new is None:
            return m.group(0)
        return '[COLOR {0}]{1}[/COLOR]'.format(new, m.group(2))

    result = _COLOR_TAG_RE.sub(_replace, text)

    wrap = _COLOR_WRAP.get(mode)
    if wrap:
        result = '[COLOR {0}]{1}[/COLOR]'.format(wrap, result)
    return result


def apply_label(text, bold=None, strip=None, color_mode=None, font_size=None):
    """Devuelve el texto con todas las transformaciones de accesibilidad aplicadas.
    Recibe bold/strip/color_mode/font_size pre-leídos para evitar llamadas extra a getSetting() por ítem."""
    if not text:
        return text
    if strip is None:
        strip = get_acc_strip_symbols()
    if bold is None:
        bold = get_acc_force_bold()
    if color_mode is None:
        color_mode = get_acc_color_mode()
    if font_size is None:
        font_size = get_acc_font_size()
    if strip:
        for sym, rep in _SYMBOL_MAP.items():
            text = text.replace(sym, rep)
    if color_mode and color_mode != 'none':
        text = _apply_color_transform(text, color_mode)
    text = text.replace('[B]', '').replace('[/B]', '')
    if bold:
        text = '[B]' + text + '[/B]'
    if font_size:
        text = '[UPPERCASE]' + text + '[/UPPERCASE]'
    return text


def state_tag(enabled):
    """Etiqueta BBCode de estado (ACTIVADA / DESACTIVADA) para toggles del menú."""
    if enabled:
        return "[COLOR green]ACTIVADA[/COLOR]"
    return "[COLOR red]DESACTIVADA[/COLOR]"


# --- Trakt.tv ---

_TRAKT_SETTINGS_FILE = 'trakt_settings.json'
_TOPZILLA_TRAKT_CLIENT_ID = base64.b64decode("ZGY1MDZjZjQ4ZDY1ZGVlZDAyOTczOWY2Zjk3ZjcxYjA2NzE0YmI4ZGExZTgyMGRmMjVkOTMyYzk4M2EyYjNhZQ==").decode()

_DEFAULT_TRAKT_LIST_IDS = [
    "805405", "1282987", "2748259", "797798", "832943",
    "4737076", "4834057", "9429302", "851495", "1558961",
    "6544049", "3785062", "20579314", "11512456", "2142753",
    "2143363", "1211468", "11416887", "801239", "6652041",
    "20770365", "1326415", "1076107", "20492899", "20770267",
    "20772087", "21583416",
]


def get_trakt_settings():
    data = load_json(_TRAKT_SETTINGS_FILE, default={"api_key": "", "lists": []})
    if not isinstance(data, dict):
        return {"api_key": "", "lists": []}
    data.setdefault("api_key", "")
    data.setdefault("lists", [])
    return data


def save_trakt_settings(data):
    save_json(_TRAKT_SETTINGS_FILE, data)


# --- MDbList ---

_MDBLIST_SETTINGS_FILE = 'mdblist_settings.json'


def get_mdblist_api_key():
    data = load_json(_MDBLIST_SETTINGS_FILE, default={})
    if not isinstance(data, dict):
        return ''
    key = data.get('api_key', '')
    return key.strip() if isinstance(key, str) else ''


def set_mdblist_api_key(key):
    key = (key or '').strip() if isinstance(key, str) else ''
    save_json(_MDBLIST_SETTINGS_FILE, {'api_key': key})
    return True


# --- MyAnimeList ---

_MAL_SETTINGS_FILE = 'mal_settings.json'


def get_mal_client_id():
    data = load_json(_MAL_SETTINGS_FILE, default={})
    if not isinstance(data, dict):
        return ''
    cid = data.get('client_id', '')
    return cid.strip() if isinstance(cid, str) else ''


def set_mal_client_id(key):
    key = (key or '').strip() if isinstance(key, str) else ''
    save_json(_MAL_SETTINGS_FILE, {'client_id': key})
    return True


# --- Preferencias de listas / Modo Cine ---

def remember_list_position():
    """Si True, las listas de tops se cachean (cacheToDisc) para conservar la
    posición al volver con ATRÁS. A cambio, el contenido puede quedar algo viejo
    hasta refrescar. Default False."""
    try:
        import xbmcaddon
        return xbmcaddon.Addon().getSetting('remember_list_position') == 'true'
    except Exception:
        return False


def cinema_mode_auto_enabled():
    try:
        import xbmcaddon
        return xbmcaddon.Addon().getSetting('cinema_mode_auto') == 'true'
    except Exception:
        return False


_SNAPSHOT_TTL_OPTS = (3600, 3 * 3600, 6 * 3600, 12 * 3600, 24 * 3600)
_SNAPSHOT_TTL_LABELS = ('1 hora', '3 horas', '6 horas', '12 horas', '24 horas')


def get_snapshot_ttl():
    """TTL (segundos) del snapshot del Modo Cine. Por debajo de este margen,
    reabrir pinta la caché sin refrescar. Default índice 1 = 3 h (comportamiento
    histórico). Ante cualquier fallo de lectura, cae al default de 3 h."""
    return _SNAPSHOT_TTL_OPTS[get_snapshot_ttl_index()]


def get_snapshot_ttl_index():
    try:
        idx = int(_addon().getSetting('snapshot_ttl') or '1')
        return idx if 0 <= idx < len(_SNAPSHOT_TTL_OPTS) else 1
    except Exception:
        return 1


def set_snapshot_ttl_index(idx):
    try:
        _addon().setSetting('snapshot_ttl', str(int(idx)))
    except Exception:
        pass


# --- Ventana de bienvenida (gating una vez por versión) ---

_WELCOME_FILE = 'welcome_state.json'


def welcome_last_version():
    data = load_json(_WELCOME_FILE, default={})
    if not isinstance(data, dict):
        return ''
    v = data.get('version', '')
    return v if isinstance(v, str) else ''


def set_welcome_shown(version):
    return save_json(_WELCOME_FILE, {'version': version})


# --- Aviso de primer uso de atajos externos ("¿dónde buscar?") ---

def is_shortcut_first_use_shown():
    data = load_json('shortcut_first_use.json', default={})
    return isinstance(data, dict) and bool(data.get('shown'))


def mark_shortcut_first_use_shown():
    save_json('shortcut_first_use.json', {'shown': True})


# --- Control parental (PIN sobre el menú Opciones) ---

def get_parental_pin():
    try:
        return (_addon().getSetting('parental_pin') or '').strip()
    except Exception:
        return ''


def is_parental_options_protected():
    try:
        return _addon().getSetting('parental_protect_options') == 'true'
    except Exception:
        return False


def set_parental_protect_options(state):
    try:
        _addon().setSetting('parental_protect_options', 'true' if state else 'false')
    except Exception:
        pass


def set_parental_pin(pin):
    try:
        _addon().setSetting('parental_pin', (pin or '').strip())
    except Exception:
        pass


# --- Paridad panel↔botones: acceso genérico por id de setting ---
# 4 helpers parametrizados en vez de ~30 funciones de una línea (los menús de
# botones pasan el id de settings.xml). default respeta el de settings.xml: un
# setting sin tocar devuelve '' aquí, así que el caller fija su propio default.

def get_bool_setting(setting_id, default=False):
    try:
        v = _addon().getSetting(setting_id)
        return default if v == '' else v == 'true'
    except Exception:
        return default


def set_bool_setting(setting_id, state):
    try:
        _addon().setSetting(setting_id, 'true' if state else 'false')
        return True
    except Exception:
        return False


def get_text_setting(setting_id, default=''):
    try:
        v = _addon().getSetting(setting_id)
        return v if v != '' else default
    except Exception:
        return default


def set_text_setting(setting_id, value):
    try:
        _addon().setSetting(setting_id, value or '')
    except Exception:
        pass


def get_tmdb_user_key():
    try:
        return (_addon().getSetting('tmdb_api_key') or '').strip()
    except Exception:
        return ''


def get_tmdb_api_key():
    return get_tmdb_user_key() or _pool_key()


def set_tmdb_api_key(key):
    key = (key or '').strip() if isinstance(key, str) else ''
    try:
        _addon().setSetting('tmdb_api_key', key)
        return True
    except Exception:
        return False


def validate_tmdb_key(key, timeout=6):
    """Devuelve True si TMDB acepta la clave, False si la rechaza, None si no se pudo verificar."""
    if not isinstance(key, str) or not key.strip():
        return False
    try:
        import requests
        r = requests.get('https://api.themoviedb.org/3/configuration',
                         params={'api_key': key.strip()}, timeout=timeout)
        if 200 <= r.status_code < 300:
            return True
        if r.status_code in (401, 403):
            return False
    except Exception:
        pass
    return None


def validate_trakt_key(key, timeout=6):
    """Devuelve True si Trakt acepta el Client ID, False si lo rechaza, None si no se pudo verificar."""
    if not isinstance(key, str) or not key.strip():
        return False
    try:
        import requests
        r = requests.get('https://api.trakt.tv/movies/popular',
                         headers={'trakt-api-key': key.strip(),
                                  'trakt-api-version': '2'},
                         params={'limit': 1}, timeout=timeout)
        if 200 <= r.status_code < 300:
            return True
        if r.status_code in (401, 403):
            return False
    except Exception:
        pass
    return None


def get_trakt_user_key():
    try:
        addon = _addon()
        kodi_key = (addon.getSetting('trakt_api_key') or '').strip()
        if kodi_key:
            return kodi_key
        # Migra la key de trakt_settings.json (formato previo) al Kodi setting.
        # Solo ocurre una vez: tras migrar, limpia el campo JSON para que
        # borrar el Kodi setting no reactive la key antigua.
        settings = get_trakt_settings()
        json_key = settings.get('api_key', '')
        json_key = json_key.strip() if isinstance(json_key, str) else ''
        if json_key:
            try:
                addon.setSetting('trakt_api_key', json_key)
                settings['api_key'] = ''
                save_trakt_settings(settings)
            except Exception:
                pass
            return json_key
    except Exception:
        pass
    return ''


def get_trakt_api_key():
    return get_trakt_user_key() or _TOPZILLA_TRAKT_CLIENT_ID


def get_trakt_client_secret():
    # Client Secret de la app Trakt del usuario (necesario para el login OAuth
    # device-flow de "Mi Trakt"). No hay pool: es secreto y propio de cada app.
    try:
        return (_addon().getSetting('trakt_client_secret') or '').strip()
    except Exception:
        return ''


def set_trakt_client_secret(key):
    key = (key or '').strip() if isinstance(key, str) else ''
    try:
        _addon().setSetting('trakt_client_secret', key)
        return True
    except Exception:
        return False


def get_trakt_write_sync():
    """Escritura en Trakt (scrobble de vistas y espejo de watchlist). OFF por defecto:
    con la sesión Trakt en solo lectura no se envía nada a la cuenta del usuario."""
    try:
        return _addon().getSetting('trakt_write_sync') == 'true'
    except Exception:
        return False


def set_trakt_write_sync(state):
    try:
        _addon().setSetting('trakt_write_sync', 'true' if state else 'false')
    except Exception:
        pass


def get_omdb_user_key():
    try:
        return (_addon().getSetting('omdb_api_key') or '').strip()
    except Exception:
        return ''


def get_omdb_api_key():
    """User key first, fallback to hardcoded pool."""
    return get_omdb_user_key() or _omdb_pool_key()


def set_omdb_api_key(key):
    key = (key or '').strip() if isinstance(key, str) else ''
    try:
        _addon().setSetting('omdb_api_key', key)
        return True
    except Exception:
        return False


def set_trakt_api_key(key):
    key = (key or '').strip() if isinstance(key, str) else ''
    try:
        _addon().setSetting('trakt_api_key', key)
        return True
    except Exception:
        pass
    # setSetting falló (Kodi no disponible): guarda en JSON como fallback.
    try:
        data = get_trakt_settings()
        data['api_key'] = key
        save_trakt_settings(data)
        return True
    except Exception:
        return False


def get_trakt_lists():
    return get_trakt_settings().get("lists", [])


def add_trakt_list(list_id, name, user, item_count=0):
    data = get_trakt_settings()
    lists = data.get("lists", [])
    for l in lists:
        if l['id'] == list_id:
            l['name'] = name
            l['user'] = user
            l['item_count'] = item_count
            save_trakt_settings(data)
            return
    lists.append({"id": list_id, "name": name, "user": user, "item_count": item_count})
    data["lists"] = lists
    save_trakt_settings(data)
    order = load_trakt_lists_order()
    if order:
        new_order = [list_id] + [x for x in order if x != list_id]
        save_trakt_lists_order(new_order)


def seed_default_trakt_lists(api_key=''):
    """Añade las listas por defecto que aún no estén ni hayan sido eliminadas."""
    data = get_trakt_settings()
    lists = data.get("lists", [])
    removed_defaults = set(data.get("removed_defaults", []))
    existing_ids = {l['id'] for l in lists}
    new_ids = [lid for lid in _DEFAULT_TRAKT_LIST_IDS
               if lid not in existing_ids and lid not in removed_defaults]
    if not new_ids:
        return
    names = {lid: "Lista Trakt #{0}".format(lid) for lid in new_ids}
    if api_key:
        try:
            import requests
            from concurrent.futures import ThreadPoolExecutor
            headers = {'trakt-api-key': api_key, 'trakt-api-version': '2',
                       'Content-Type': 'application/json'}

            def fetch_name(lid):
                try:
                    r = requests.get("https://api.trakt.tv/lists/{0}".format(lid),
                                      headers=headers, timeout=5)
                    if r.status_code == 200:
                        return lid, r.json().get('name', names[lid])
                except Exception:
                    pass
                return lid, names[lid]

            with ThreadPoolExecutor(max_workers=8) as ex:
                for lid, name in ex.map(fetch_name, new_ids):
                    names[lid] = name
        except Exception:
            pass
    for lid in new_ids:
        lists.append({"id": lid, "name": names[lid], "user": "official", "item_count": 0})
    data["lists"] = lists
    save_trakt_settings(data)


def remove_trakt_list(list_id):
    data = get_trakt_settings()
    lists = data.get("lists", [])
    if list_id in _DEFAULT_TRAKT_LIST_IDS:
        removed = data.get("removed_defaults", [])
        if list_id not in removed:
            removed.append(list_id)
        data["removed_defaults"] = removed
    data["lists"] = [l for l in lists if l['id'] != list_id]
    save_trakt_settings(data)


def get_fanart_mode():
    try:
        return _addon().getSetting('fanart_mode') or 'addon'
    except Exception:
        return 'addon'


def set_fanart_mode(mode):
    try:
        _addon().setSetting('fanart_mode', mode)
    except Exception:
        pass


def get_custom_fanart_path():
    try:
        return _addon().getSetting('fanart_custom_path') or ''
    except Exception:
        return ''


def set_custom_fanart_path(path):
    try:
        _addon().setSetting('fanart_custom_path', path)
    except Exception:
        pass


def addon_media(filename):
    return os.path.join(_addon().getAddonInfo('path'), 'resources', 'media', filename)


def addon_fanart():
    try:
        mode = get_fanart_mode()
        if mode == 'disabled':
            return ''
        if mode == 'custom':
            path = get_custom_fanart_path()
            if path and os.path.exists(path):
                return path
        return os.path.join(_addon().getAddonInfo('path'), 'fanart.jpg')
    except Exception:
        return ''


# --- Atajos personalizados en "¿Dónde buscar?" ---

_SEARCH_SHORTCUTS_FILE = 'search_shortcuts.json'

# Tags BBCode admitidos por Kodi que no queremos en nombres de atajos
# (evita que un nombre rompa el [COLOR gold]...[/COLOR] del menú "¿Dónde buscar?").
_BBCODE_RE = re.compile(
    r'\[/?(?:B|I|UPPERCASE|LOWERCASE|CAPITALIZE|LIGHT|COLOR(?:\s+[^\]]*)?)\]',
    re.IGNORECASE,
)


def sanitize_shortcut_name(text):
    if not text:
        return ''
    return _BBCODE_RE.sub('', str(text)).strip()


def load_search_shortcuts():
    data = load_json(_SEARCH_SHORTCUTS_FILE, default=[])
    if not isinstance(data, list):
        return []
    out = []
    for item in data:
        if not isinstance(item, dict):
            continue
        cmd = item.get('command')
        if not isinstance(cmd, str) or not cmd.strip():
            continue
        out.append({
            'name':    sanitize_shortcut_name(item.get('name')) or cmd[:40],
            'icon':    item.get('icon') if isinstance(item.get('icon'), str) else '',
            'command': cmd.strip(),
            'type':    item.get('type') if item.get('type') in ('addon', 'manual') else 'manual',
            'addon_id': item.get('addon_id') if isinstance(item.get('addon_id'), str) else '',
        })
    return out


def save_search_shortcuts(shortcuts):
    return save_json(_SEARCH_SHORTCUTS_FILE, shortcuts)


# --- Orden personalizado de la ventana "¿Dónde buscar?" ---

_SEARCH_MENU_ORDER_FILE = 'search_menu_order.json'


def load_search_menu_order():
    data = load_json(_SEARCH_MENU_ORDER_FILE, default=[])
    if not isinstance(data, list):
        return []
    return [x for x in data if isinstance(x, str)]


def save_search_menu_order(order):
    return save_json(_SEARCH_MENU_ORDER_FILE, list(order))


def reset_search_menu_order():
    return save_json(_SEARCH_MENU_ORDER_FILE, [])


_SEARCH_MENU_HIDDEN_FILE = 'search_menu_hidden.json'


def load_search_hidden():
    """Set de ids de entradas ocultas del menú '¿Dónde buscar?'."""
    data = load_json(_SEARCH_MENU_HIDDEN_FILE, default=[])
    if not isinstance(data, list):
        return set()
    return {x for x in data if isinstance(x, str)}


def save_search_hidden(ids):
    return save_json(_SEARCH_MENU_HIDDEN_FILE, sorted(ids))


# --- Orden personalizado de las listas Trakt ---

_TRAKT_LISTS_ORDER_FILE = 'trakt_lists_order.json'


def load_trakt_lists_order():
    data = load_json(_TRAKT_LISTS_ORDER_FILE, default=[])
    if not isinstance(data, list):
        return []
    return [x for x in data if isinstance(x, str)]


def save_trakt_lists_order(order):
    return save_json(_TRAKT_LISTS_ORDER_FILE, list(order))


def reset_trakt_lists_order():
    return save_json(_TRAKT_LISTS_ORDER_FILE, [])


def shortcut_stable_id(sc):
    """ID estable para un atajo. Sobrevive a renombrados."""
    if not isinstance(sc, dict):
        return ''
    aid = sc.get('addon_id') or ''
    if aid:
        return 'custom:addon:{0}'.format(aid)
    cmd = (sc.get('command') or '').strip()
    if not cmd:
        return ''
    return 'custom:cmd:{0}'.format(hashlib.sha1(cmd.encode('utf-8')).hexdigest()[:8])


# ── Modo Cine (pelis_flix): filas configurables, tráiler y toggles de sesión ──

_FLIX_ROWS_FILE = 'flix_rows_config.json'
_FLIX_LAZY_FILE = 'flix_lazy_state.json'
_FLIX_REMEMBER_POS_FILE = 'flix_remember_pos_state.json'
_TRAILER_CFG_FILE = 'trailer_config.json'

_TRAILER_DEFAULTS = {'enabled': True, 'hide_busy': False, 'hover_s': 10, 'lang': 'es-ES', 'notify': True}
TRAILER_LANGS = ('en-US', 'es-ES')


def load_flix_rows(mode):
    """Lista de ids de filas activas del Modo Cine para 'movie'/'show', o None si el
    usuario no ha configurado nada (el llamador usa los defaults)."""
    data = load_json(_FLIX_ROWS_FILE, default={})
    if not isinstance(data, dict):
        return None
    v = data.get(mode)
    if not isinstance(v, list):
        return None
    return [x for x in v if isinstance(x, str)]


def save_flix_rows(mode, ids):
    # Fusiona con el otro modo ya guardado, sin pisarlo.
    data = load_json(_FLIX_ROWS_FILE, default={})
    if not isinstance(data, dict):
        data = {}
    data[mode] = [x for x in ids if isinstance(x, str)]
    return save_json(_FLIX_ROWS_FILE, data)


def reset_flix_rows():
    return save_json(_FLIX_ROWS_FILE, {})


def is_flix_lazy_enabled():
    data = load_json(_FLIX_LAZY_FILE, default={})
    return data.get('active', False) if isinstance(data, dict) else False


def set_flix_lazy_enabled(state):
    return save_json(_FLIX_LAZY_FILE, {'active': bool(state)})


def is_flix_remember_pos_enabled():
    data = load_json(_FLIX_REMEMBER_POS_FILE, default={})
    return data.get('active', True) if isinstance(data, dict) else True


def set_flix_remember_pos_enabled(state):
    return save_json(_FLIX_REMEMBER_POS_FILE, {'active': bool(state)})


def load_trailer_config():
    """Config del tráiler: {'enabled': bool, 'hide_busy': bool, 'hover_s': int, 'lang': str}.
    hover_s = segundos sobre un item antes de reproducir; lang = idioma del tráiler."""
    data = load_json(_TRAILER_CFG_FILE, default={})
    if not isinstance(data, dict):
        data = {}
    cfg = dict(_TRAILER_DEFAULTS)
    if isinstance(data.get('enabled'), bool):
        cfg['enabled'] = data['enabled']
    if isinstance(data.get('hide_busy'), bool):
        cfg['hide_busy'] = data['hide_busy']
    if isinstance(data.get('hover_s'), int) and 2 <= data['hover_s'] <= 30:
        cfg['hover_s'] = data['hover_s']
    if data.get('lang') in TRAILER_LANGS:
        cfg['lang'] = data['lang']
    if isinstance(data.get('notify'), bool):
        cfg['notify'] = data['notify']
    return cfg


def save_trailer_config(cfg):
    hover = cfg.get('hover_s')
    if not (isinstance(hover, int) and 2 <= hover <= 30):
        hover = _TRAILER_DEFAULTS['hover_s']
    return save_json(_TRAILER_CFG_FILE, {
        'enabled': bool(cfg.get('enabled')),
        'hide_busy': bool(cfg.get('hide_busy')),
        'hover_s': hover,
        'lang': cfg.get('lang') if cfg.get('lang') in TRAILER_LANGS else _TRAILER_DEFAULTS['lang'],
        'notify': bool(cfg.get('notify', _TRAILER_DEFAULTS['notify'])),
    })
