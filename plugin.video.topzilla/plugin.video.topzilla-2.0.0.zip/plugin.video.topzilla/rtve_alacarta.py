# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""RTVE Play: directos + catálogo (api.rtve.es y ztnr.rtve.es para DRM Widevine).

Canales en directo, catálogo de programas por categoría y búsqueda de RTVE Play.
La reproducción usa el MPD de ztnr.rtve.es servido vía inputstream.adaptive; el
DRM Widevine se resuelve pidiendo la licencia (widevineURL) al endpoint de token
de api.rtve.es. No hay descifrado de URL: RTVE entrega el manifest directo y la
URL de licencia por API.
"""
import hashlib
import json
import os
import sys
import threading
import time
from urllib.parse import quote

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import core_settings


_API_BASE = "https://www.rtve.es/api"
_LOG_TAG = "[TopZilla][rtve]"
_TTL = 6 * 3600

_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/138.0.0.0 Safari/537.36"
)
_HEADERS = {
    "User-Agent": _UA,
}

_RTVE_LIVE_CHANNELS = [
    {
        "name": "La 1",
        "video_id": "1688877",
        "logo": "https://img2.rtve.es/css/rtve.commons/rtve.header.footer/i/logoLa1.png",
        "plot": "Canal generalista de RTVE con informativos, series, entretenimiento y deportes.",
    },
    {
        "name": "La 2",
        "video_id": "1688885",
        "logo": "https://img2.rtve.es/css/rtve.commons/rtve.header.footer/i/logoLa2.png",
        "plot": "Canal cultural de RTVE con documentales, cine y programas de divulgación.",
    },
    {
        "name": "Canal 24 Horas",
        "video_id": "1694255",
        "logo": "https://img2.rtve.es/css/rtve.commons/rtve.header.footer/i/logo24h.png",
        "plot": "Canal de noticias 24 horas de RTVE.",
    },
    {
        "name": "Teledeporte",
        "video_id": "1712295",
        "logo": "https://img2.rtve.es/css/rtve.commons/rtve.header.footer/i/logoTdp.png",
        "plot": "Canal deportivo de RTVE.",
    },
    {
        "name": "Clan TVE",
        "video_id": "5466990",
        "logo": "https://img2.rtve.es/css/rtve.commons/rtve.header.footer/i/logoClan.png",
        "plot": "Canal infantil de RTVE.",
    },
]

# IDs de api.rtve.es/api/tematicas/
_RTVE_CATEGORIES = [
    {"name": "Series", "id": "864", "icon": "DefaultTVShows.png"},
    {"name": "Cine", "id": "866", "icon": "DefaultMovies.png"},
    {"name": "Documentales", "id": "863", "icon": "DefaultMovies.png"},
    {"name": "Informativos", "id": "862", "icon": "DefaultAddonPVRClient.png"},
    {"name": "Entretenimiento", "id": "102610", "icon": "DefaultAddonPVRClient.png"},
    {"name": "Deportes", "id": "867", "icon": "DefaultAddonPVRClient.png"},
    {"name": "Infantiles", "id": "865", "icon": "DefaultAddonPVRClient.png"},
    {"name": "Cultura", "id": "40270", "icon": "DefaultAddonPVRClient.png"},
    {"name": "Música", "id": "102614", "icon": "DefaultMusicSongs.png"},
    {"name": "Cocina", "id": "102611", "icon": "DefaultAddonPVRClient.png"},
    {"name": "Concursos", "id": "102613", "icon": "DefaultAddonPVRClient.png"},
    {"name": "Humor", "id": "102615", "icon": "DefaultAddonPVRClient.png"},
]


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"{_LOG_TAG} {msg}", level)


def _log_error(msg):
    xbmc.log(f"{_LOG_TAG} ERROR: {msg}", xbmc.LOGERROR)


def _handle():
    return int(sys.argv[1])


def _u(**kwargs):
    return core_settings.make_url(**kwargs)


def _media_icon(name, fallback='DefaultFolder.png'):
    if not name:
        return fallback
    p = os.path.join(
        xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path')),
        'resources', 'media', name,
    )
    return p if os.path.exists(p) else fallback


def _cache_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(profile, 'topzilla_rtve_cache.json')


def _load_cache():
    try:
        p = _cache_path()
        if not os.path.exists(p):
            return {}
        with open(p, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _save_cache(data):
    try:
        p = _cache_path()
        os.makedirs(os.path.dirname(p), exist_ok=True)
        # tmp por hilo: dos escrituras concurrentes con el mismo .tmp corromperían el JSON.
        tmp = f"{p}.{threading.get_ident()}.tmp"
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, p)
    except OSError as e:
        _log(f"cache save: {e}", xbmc.LOGWARNING)


def _fetch_json(url, timeout=15):
    cache = _load_cache()
    cache_key = hashlib.md5(url.encode("utf-8")).hexdigest()
    entry = cache.get(cache_key, {})
    if entry.get("content") and (time.time() - entry.get("ts", 0)) < _TTL:
        return entry["content"]

    try:
        r = requests.get(url, headers=_HEADERS, timeout=timeout)
        r.raise_for_status()
    except requests.RequestException as e:
        stale = entry.get("content")
        if stale:
            _log(f"fetch inaccesible, usando caché caducada: {e}", xbmc.LOGWARNING)
            return stale
        raise OSError(str(e)) from e

    try:
        data = r.json()
    except ValueError:
        return entry.get("content", {})

    if data:  # no cachear vacíos (un fallo transitorio envenenaría la query durante el TTL)
        cache[cache_key] = {"ts": time.time(), "content": data}
        _save_cache(cache)
    return data


def _play_drm_stream(video_id, title=""):
    """Reproduce un MPD de RTVE con Widevine vía inputstream.adaptive."""
    h = _handle()
    if not str(video_id).strip():
        # Sin id no hay nada que resolver: cerramos el item playable para que
        # Kodi no quede colgado esperando la resolución.
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        return
    stream_url = f"https://ztnr.rtve.es/ztnr/{video_id}.mpd"
    _log(f"DRM play: {title} -> {stream_url}")

    license_url = ""
    try:
        token_url = f"{_API_BASE}/token/{video_id}"
        token_data = _fetch_json(token_url)
        license_url = token_data.get("widevineURL", "")
        _log(f"Widevine URL: {license_url}")
    except (OSError, ValueError) as e:
        _log_error(f"Token error: {e}")

    headers = {
        "User-Agent": _HEADERS["User-Agent"],
        "Referer": "https://www.rtve.es/",
        "Origin": "https://www.rtve.es",
        "Accept": "*/*",
    }
    headers_string = "&".join(
        f"{k}={quote(v)}" for k, v in headers.items()
    )

    try:
        li = xbmcgui.ListItem(path=stream_url)
        if title:
            info_tag = li.getVideoInfoTag()
            info_tag.setMediaType("video")
            info_tag.setTitle(title)

        li.setProperty("inputstream", "inputstream.adaptive")
        li.setProperty("inputstream.adaptive.manifest_type", "mpd")
        li.setProperty("inputstream.adaptive.manifest_headers", headers_string)
        li.setProperty("inputstream.adaptive.stream_headers", headers_string)

        if license_url:
            li.setProperty("inputstream.adaptive.license_type",
                           "com.widevine.alpha")
            li.setProperty("inputstream.adaptive.license_key", license_url)

        li.setMimeType("application/dash+xml")
        li.setContentLookup(False)

        li.setProperty("inputstream.adaptive.stream_selection_type", "adaptive")

        xbmcplugin.setResolvedUrl(h, True, li)
        _log(f"DRM stream iniciado para: {title}")

    except Exception as e:
        # Handler de reproducción: cualquier fallo (construcción del ListItem,
        # propiedades de inputstream...) debe resolver False, o Kodi queda colgado
        # esperando la URL del item playable. Catch ancho + log (no silencioso).
        _log_error(f"DRM play error: {e}")
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        xbmcgui.Dialog().notification(
            "TopZilla", "Error al reproducir",
            xbmcgui.NOTIFICATION_ERROR, 3000)


def main_menu():
    h = _handle()
    bold = core_settings.get_acc_force_bold()
    strip = core_settings.get_acc_strip_symbols()
    color = core_settings.get_acc_color_mode()
    fanart = core_settings.addon_fanart()

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B][COLOR red]RTVE en Directo[/COLOR][/B]", bold=bold, strip=strip, color_mode=color))
    li.setArt({"icon": "DefaultAddonPVRClient.png", "fanart": fanart})
    li.setInfo("video", {"plot": "Canales de RTVE en directo:\n"
                                 "La 1, La 2, 24h, Teledeporte, Clan"})
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="rtve_live"), listitem=li, isFolder=True
    )

    for cat in _RTVE_CATEGORIES:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            cat["name"], bold=bold, strip=strip, color_mode=color))
        li.setArt({"icon": cat["icon"], "fanart": fanart})
        li.setInfo("video", {"plot": f"Programas de RTVE: {cat['name']}"})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="rtve_category", cat_id=cat["id"],
                   cat_name=cat["name"]),
            listitem=li,
            isFolder=True,
        )

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR dodgerblue][B]Buscar en RTVE[/B][/COLOR]", bold=bold, strip=strip, color_mode=color))
    li.setArt({"icon": _media_icon("busqueda.png", "DefaultAddonWebSkin.png"),
               "fanart": fanart})
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="rtve_search"), listitem=li, isFolder=True
    )

    xbmcplugin.endOfDirectory(h, cacheToDisc=True)


def live_channels():
    h = _handle()
    bold = core_settings.get_acc_force_bold()
    strip = core_settings.get_acc_strip_symbols()
    color = core_settings.get_acc_color_mode()
    fanart = core_settings.addon_fanart()
    xbmcplugin.setContent(h, "videos")
    for ch in _RTVE_LIVE_CHANNELS:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            f"[B]{ch['name']}[/B]", bold=bold, strip=strip, color_mode=color))
        li.setArt({"icon": ch["logo"], "thumb": ch["logo"], "fanart": fanart})
        li.setInfo("video", {"title": ch["name"], "plot": ch["plot"]})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="play_rtve_live", url=ch["video_id"],
                   title=ch["name"]),
            listitem=li,
            isFolder=False,
        )
    xbmcplugin.endOfDirectory(h, cacheToDisc=True)


def play_live(url, title=""):
    _play_drm_stream(url, title)


def category(cat_id, cat_name="", page=1, parent_id=""):
    h = _handle()
    bold = core_settings.get_acc_force_bold()
    strip = core_settings.get_acc_strip_symbols()
    color = core_settings.get_acc_color_mode()
    fanart = core_settings.addon_fanart()
    dp = xbmcgui.DialogProgress()
    dp.create("TopZilla", f"Cargando {cat_name or 'categoría'}...")
    try:
        dp.update(20, "Cargando subcategorías...")
        # Intentar hijos (subcarpetas de programas)
        hijos_url = f"https://api.rtve.es/api/tematicas/{cat_id}/hijos.json?page={page}"
        data = _fetch_json(hijos_url)
        hijos = data.get("page", {}).get("items", [])

        if hijos:
            dp.update(60, f"Procesando {len(hijos)} programas...")
            dp.close()
            xbmcplugin.setContent(h, "tvshows")

            for item in hijos:
                item_id = str(item.get("id", ""))
                name = item.get("title", item.get("name", "Sin título"))
                img = ""
                desc = item.get("shortDescription", item.get("description", "")) or ""
                try:
                    prog_url = f"https://www.rtve.es/api/programas/{item_id}"
                    prog_data = _fetch_json(prog_url)
                    prog_info = prog_data.get("page", {}).get("items", [{}])[0]
                    img = (prog_info.get("imgPoster", "") or
                           prog_info.get("imgCol", "") or
                           prog_info.get("thumbnail", "") or
                           prog_info.get("imgBackground", "") or "")
                    if not desc:
                        desc = prog_info.get("shortDescription", prog_info.get("description", "")) or ""
                except (OSError, ValueError):
                    pass

                li = xbmcgui.ListItem(label=core_settings.apply_label(
                    name, bold=bold, strip=strip, color_mode=color))
                li.setArt({"thumb": img, "icon": img, "poster": img, "fanart": fanart})
                li.setInfo("video", {"title": name, "plot": desc})
                xbmcplugin.addDirectoryItem(
                    handle=h,
                    url=_u(action="rtve_category", cat_id=item_id,
                           cat_name=name, parent_id=cat_id),
                    listitem=li,
                    isFolder=True,
                )

            total_pages = data.get("page", {}).get("totalPages", 1)
            current_page = data.get("page", {}).get("number", 1)

            if current_page > 1:
                li = xbmcgui.ListItem(label=core_settings.apply_label(
                    f"[COLOR yellow]← Página anterior ({current_page - 1}/{total_pages})[/COLOR]",
                    bold=bold, strip=strip, color_mode=color))
                li.setArt({"icon": "DefaultFolder.png"})
                xbmcplugin.addDirectoryItem(
                    handle=h,
                    url=_u(action="rtve_category", cat_id=cat_id,
                           cat_name=cat_name, page=current_page - 1,
                           parent_id=parent_id),
                    listitem=li, isFolder=True)

            if current_page < total_pages:
                li = xbmcgui.ListItem(label=core_settings.apply_label(
                    f"[COLOR limegreen]Página siguiente ({current_page + 1}/{total_pages})[/COLOR]",
                    bold=bold, strip=strip, color_mode=color))
                li.setArt({"icon": "DefaultFolder.png"})
                xbmcplugin.addDirectoryItem(
                    handle=h,
                    url=_u(action="rtve_category", cat_id=cat_id,
                           cat_name=cat_name, page=current_page + 1,
                           parent_id=parent_id),
                    listitem=li, isFolder=True)

            xbmcplugin.endOfDirectory(h, cacheToDisc=True)
            return

        # Si no hay hijos, intentar vídeos directos
        dp.update(40, "Buscando vídeos...")
        items = []

        # Si tenemos parent_id, usar API de programas/temporadas (series)
        if parent_id:
            try:
                season_url = (
                    f"https://www.rtve.es/api/programas/{parent_id}/temporadas/{cat_id}"
                    f"/videos.json?page={page}&size=20"
                )
                _log(f"Intentando temporada: {season_url}")
                data = _fetch_json(season_url)
                items = data.get("page", {}).get("items", [])
            except (OSError, ValueError) as e:
                _log(f"Temporada API falló: {e}, usando fallback")
                items = []

        # Fallback: API de tematicas (para categorías sin temporadas)
        if not items:
            videos_url = f"https://api.rtve.es/api/tematicas/{cat_id}/videos.json?page={page}"
            data = _fetch_json(videos_url)
            items = data.get("page", {}).get("items", [])

        dp.update(70, f"Procesando {len(items)} vídeos...")
        dp.close()

        if not items:
            xbmcgui.Dialog().notification(
                "TopZilla", "No se encontraron vídeos",
                xbmcgui.NOTIFICATION_INFO, 3000)
            xbmcplugin.endOfDirectory(h, cacheToDisc=True)
            return

        xbmcplugin.setContent(h, "videos")
        for item in items:
            _add_video_item(h, item, bold, strip, color, fanart)

        total_pages = data.get("page", {}).get("totalPages", 1)
        current_page = data.get("page", {}).get("number", 1)

        if current_page > 1:
            li = xbmcgui.ListItem(label=core_settings.apply_label(
                f"[COLOR yellow]← Página anterior ({current_page - 1}/{total_pages})[/COLOR]",
                bold=bold, strip=strip, color_mode=color))
            li.setArt({"icon": "DefaultFolder.png"})
            xbmcplugin.addDirectoryItem(
                handle=h,
                url=_u(action="rtve_category", cat_id=cat_id,
                       cat_name=cat_name, page=current_page - 1,
                       parent_id=parent_id),
                listitem=li, isFolder=True)

        if current_page < total_pages:
            li = xbmcgui.ListItem(label=core_settings.apply_label(
                f"[COLOR limegreen]Página siguiente ({current_page + 1}/{total_pages})[/COLOR]",
                bold=bold, strip=strip, color_mode=color))
            li.setArt({"icon": "DefaultFolder.png"})
            xbmcplugin.addDirectoryItem(
                handle=h,
                url=_u(action="rtve_category", cat_id=cat_id,
                       cat_name=cat_name, page=current_page + 1,
                       parent_id=parent_id),
                listitem=li, isFolder=True)

        xbmcplugin.endOfDirectory(h, cacheToDisc=True)

    except (OSError, ValueError, KeyError) as e:
        dp.close()
        _log_error(f"category: {e}")
        xbmcgui.Dialog().ok("TopZilla", f"Error al cargar:\n{e}")
        try:
            xbmcplugin.endOfDirectory(h, cacheToDisc=True)
        except RuntimeError:
            pass


def _add_video_item(h, item, bold, strip, color, fanart):
    title = item.get("title", item.get("name", "Sin título"))
    desc = item.get("shortDescription", item.get("description", "")) or ""
    thumb = item.get("thumbnail", item.get("imageSEO", "")) or ""
    try:
        duration = int(item.get("duration", 0) or 0)
    except (ValueError, TypeError):
        duration = 0
    pub_date = item.get("publicationDate", "") or ""
    video_id = str(item.get("id", ""))

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        title, bold=bold, strip=strip, color_mode=color))
    li.setArt({"thumb": thumb, "icon": thumb, "poster": thumb, "fanart": fanart})

    plot = desc
    if pub_date:
        plot += f"\n\nPublicado: {pub_date[:10]}"
    li.setInfo("video", {
        "title": title,
        "plot": plot,
        "duration": duration // 1000 if duration else 0,
    })
    li.setProperty("IsPlayable", "true")

    xbmcplugin.addDirectoryItem(
        handle=h,
        url=_u(action="play_rtve_video", video_id=video_id, title=title),
        listitem=li,
        isFolder=False,
    )


def play_video(video_id, title=""):
    _play_drm_stream(video_id, title)


def search():
    h = _handle()
    import remote_input
    query = remote_input.get_text_input("Buscar en RTVE Play").strip()
    if not query:
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    bold = core_settings.get_acc_force_bold()
    strip = core_settings.get_acc_strip_symbols()
    color = core_settings.get_acc_color_mode()
    fanart = core_settings.addon_fanart()
    dp = xbmcgui.DialogProgress()
    dp.create("TopZilla", f"Buscando '{query}'...")
    try:
        dp.update(30, "Consultando api.rtve.es...")
        url = ("https://api.rtve.es/api/search/contents"
               f"?search={quote(query)}&page=1&size=30&context=tve"
               "&type=completo&tipology=video"
               "&isExpanded=true&isChild=true"
               "&useOntology=false")
        data = _fetch_json(url)
        dp.update(70, "Procesando resultados...")
        dp.close()

        items = data.get("page", {}).get("items", [])
        if not items:
            xbmcgui.Dialog().notification(
                "TopZilla",
                f"Sin resultados para '{query}'",
                xbmcgui.NOTIFICATION_INFO, 3000)
            xbmcplugin.endOfDirectory(h, cacheToDisc=True)
            return

        xbmcplugin.setContent(h, "videos")
        for item in items:
            _add_video_item(h, item, bold, strip, color, fanart)
        xbmcplugin.endOfDirectory(h, cacheToDisc=True)

    except (OSError, ValueError, KeyError) as e:
        dp.close()
        _log_error(f"search: {e}")
        xbmcgui.Dialog().ok("TopZilla", f"Error en la búsqueda:\n{e}")
        try:
            xbmcplugin.endOfDirectory(h, cacheToDisc=True)
        except RuntimeError:
            pass
