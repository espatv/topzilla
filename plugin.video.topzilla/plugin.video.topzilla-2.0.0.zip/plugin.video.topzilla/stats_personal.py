# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""
Estadísticas personales de biblioteca: favoritos, historial, géneros, décadas.

Toda la lógica de cálculo vive en `compute()` (función pura sin xbmc) para que
sea testeable. `show_panel()` llama compute() y pinta el resultado.
"""
import collections

import xbmcgui

import movie_ref as mr

_DEFAULT_RUNTIME_MIN = 100  # minutos estimados cuando no hay dato en caché


def _prefetch_meta(refs):
    """Consulta metadatos cache-only (sin red) para cada ref único."""
    try:
        import metadata_enricher as me
    except Exception:
        return {}
    out = {}
    for ref in refs:
        key = mr.ref_key(ref)
        if not key or key in out:
            continue
        try:
            out[key] = me.enrich(
                tmdb_id=ref.get('tmdb_id'),
                imdb_id=ref.get('imdb_id'),
                title=ref.get('title', ''),
                year=ref.get('year') or None,
                media_type=ref.get('media_type', 'movie'),
                use_cache_only=True,
            ) or {}
        except Exception:
            out[key] = {}
    return out


def _format_time(minutes):
    minutes = max(0, int(minutes))
    if minutes < 60:
        return "{0} min".format(minutes)
    h = minutes // 60
    m = minutes % 60
    if h < 24:
        return "{0}h {1}m".format(h, m) if m else "{0}h".format(h)
    days = h // 24
    rh = h % 24
    parts = ["{0}d".format(days)]
    if rh:
        parts.append("{0}h".format(rh))
    if m:
        parts.append("{0}m".format(m))
    return " ".join(parts)


def compute():
    """
    Devuelve un dict con todas las estadísticas calculadas.
    Pura: no llama a xbmc, no muestra diálogos.
    """
    import favorites
    import watch_history

    fav_refs = favorites._load()
    watched_keys = watch_history.watched_keys()
    history_refs = watch_history.watched_refs()

    # Totales básicos (sin red)
    fav_movies = sum(1 for r in fav_refs if r.get('media_type', 'movie') != 'show')
    fav_shows  = len(fav_refs) - fav_movies
    fav_watched   = sum(1 for r in fav_refs if mr.ref_key(r) in watched_keys)
    fav_unwatched = len(fav_refs) - fav_watched

    hist_movies = sum(1 for r in history_refs if r.get('media_type', 'movie') != 'show')
    hist_shows  = len(history_refs) - hist_movies

    # Década favorita (year está en el ref, sin enrich)
    decade_counter = collections.Counter()
    for r in fav_refs + history_refs:
        y = r.get('year') or 0
        if y >= 1900:
            decade_counter[(y // 10) * 10] += 1

    # Metadatos cache-only para géneros, director y tiempo
    all_refs = list({mr.ref_key(r): r for r in fav_refs + history_refs if mr.ref_key(r)}.values())
    metas = _prefetch_meta(all_refs)

    genre_counter    = collections.Counter()
    director_counter = collections.Counter()
    total_min        = 0
    cached_count     = 0
    uncached_count   = 0

    for r in history_refs:
        if r.get('media_type', 'movie') == 'show':
            continue
        key = mr.ref_key(r)
        meta = metas.get(key) or {}
        for g in (meta.get('genres') or []):
            genre_counter[g] += 1
        d = meta.get('director') or ''
        if d:
            director_counter[d] += 1
        try:
            rt = int(meta.get('runtime') or 0)
        except (TypeError, ValueError):
            rt = 0
        if rt > 0:
            total_min += rt
            cached_count += 1
        else:
            total_min += _DEFAULT_RUNTIME_MIN
            uncached_count += 1

    # Puntuación media propia (solo favoritos con user_rating)
    rated = [(r.get('user_rating'), mr.display_label(r))
             for r in fav_refs if r.get('user_rating') is not None]
    avg_rating = None
    if rated:
        avg_rating = round(sum(v for v, _ in rated) / len(rated), 1)

    return {
        'fav_total':      len(fav_refs),
        'fav_movies':     fav_movies,
        'fav_shows':      fav_shows,
        'fav_watched':    fav_watched,
        'fav_unwatched':  fav_unwatched,
        'hist_total':     len(history_refs),
        'hist_movies':    hist_movies,
        'hist_shows':     hist_shows,
        'total_min':      total_min,
        'cached_count':   cached_count,
        'uncached_count': uncached_count,
        'decade_counter': decade_counter,
        'genre_counter':  genre_counter,
        'director_counter': director_counter,
        'rated':          rated,
        'avg_rating':     avg_rating,
        'meta_total':     len(all_refs),
    }


def show_panel():
    try:
        s = compute()
    except Exception as e:
        import xbmc
        xbmc.log("[TopZilla] stats_personal: {0}".format(e), xbmc.LOGWARNING)
        xbmcgui.Dialog().notification(
            "TopZilla", "No se pudieron calcular las estadísticas",
            xbmcgui.NOTIFICATION_WARNING, 3000)
        return

    lines = []

    # --- Favoritos ---
    lines.append("[B]Favoritos[/B]")
    if s['fav_total']:
        parts = []
        if s['fav_movies']:
            parts.append("{0} pelis".format(s['fav_movies']))
        if s['fav_shows']:
            parts.append("{0} series".format(s['fav_shows']))
        lines.append("  Total: {0}  ({1})".format(s['fav_total'], " · ".join(parts) if parts else ""))
        lines.append("  Vistos: {0}  ·  Sin ver: {1}".format(s['fav_watched'], s['fav_unwatched']))
    else:
        lines.append("  (sin favoritos)")

    if s['avg_rating'] is not None:
        lines.append("  Puntuación media propia: {0}/10 (sobre {1} títulos)".format(
            s['avg_rating'], len(s['rated'])))
        best = max(s['rated'], key=lambda x: x[0])
        lines.append("  Mejor valorado: {0} ({1}/10)".format(best[1], best[0]))

    lines.append("")

    # --- Historial ---
    lines.append("[B]Historial de visionado[/B]")
    if s['hist_total']:
        parts = []
        if s['hist_movies']:
            parts.append("{0} pelis".format(s['hist_movies']))
        if s['hist_shows']:
            parts.append("{0} series".format(s['hist_shows']))
        lines.append("  Total visto: {0}  ({1})".format(s['hist_total'], " · ".join(parts) if parts else ""))
        if s['hist_movies']:
            lines.append("  Tiempo total (pelis): ~{0}".format(_format_time(s['total_min'])))
            if s['uncached_count']:
                lines.append("    ({0} sin duración en caché, estimadas en {1} min)".format(
                    s['uncached_count'], _DEFAULT_RUNTIME_MIN))
    else:
        lines.append("  (sin historial)")

    lines.append("")

    # --- Décadas ---
    if s['decade_counter']:
        lines.append("[B]Décadas favoritas[/B]")
        for decade, cnt in s['decade_counter'].most_common(5):
            lines.append("  {0}s: {1} títulos".format(decade, cnt))
        lines.append("")

    # --- Géneros ---
    if s['genre_counter']:
        lines.append("[B]Géneros más frecuentes[/B]  (historial, con caché)")
        for genre, cnt in s['genre_counter'].most_common(6):
            lines.append("  {0}: {1}".format(genre, cnt))
        lines.append("")

    # --- Directores ---
    if s['director_counter']:
        lines.append("[B]Directores más vistos[/B]  (historial, con caché)")
        for director, cnt in s['director_counter'].most_common(5):
            lines.append("  {0}: {1} pelis".format(director, cnt))
        lines.append("")

    # Nota de cobertura
    if s['meta_total']:
        lines.append("[COLOR gray]Géneros/directores calculados sobre "
                     "{0} de {1} títulos únicos (metadatos en caché).".format(
                         s['cached_count'], s['meta_total']))
        lines.append("Abre tops o fichas para ampliar la cobertura.[/COLOR]")

    xbmcgui.Dialog().textviewer("Mis estadísticas", "\n".join(lines))
