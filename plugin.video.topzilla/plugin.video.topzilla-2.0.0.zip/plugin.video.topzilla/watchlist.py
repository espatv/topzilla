# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""
Watchlist ("Quiero ver"): lista de títulos pendientes de ver.

Distinto de Favoritos (lo que te ha gustado). Este almacén es para
pendientes. El flujo natural: añadir aquí → ver → mover a Favoritos o borrar.

Modelo de datos: lista de MovieRef en `watchlist.json`. Dedup por ref_key.
"""
import sys
import time

import xbmc
import xbmcgui
import xbmcplugin

import core_settings
import movie_ref


_FILE = 'watchlist.json'


def _u(**kwargs):
    return core_settings.make_url(**kwargs)


def _handle():
    return int(sys.argv[1])


def _load():
    data = core_settings.load_json(_FILE, default=[])
    return data if isinstance(data, list) else []


def _save(refs):
    core_settings.save_json(_FILE, refs)


def is_in_watchlist(key):
    if not key:
        return False
    return any(movie_ref.ref_key(r) == key for r in _load())


def add(ref):
    if not ref or not ref.get('title'):
        return False
    refs = _load()
    key = movie_ref.ref_key(ref)
    if not key:
        xbmcgui.Dialog().notification(
            'TopZilla', 'No se pudo guardar: título sin caracteres identificables',
            xbmcgui.NOTIFICATION_WARNING, 3000)
        return False
    if any(movie_ref.ref_key(r) == key for r in refs):
        xbmcgui.Dialog().notification('TopZilla', 'Ya estaba en Quiero ver',
                                       xbmcgui.NOTIFICATION_INFO, 2500)
        return False
    ref = dict(ref)
    ref['added_at'] = int(time.time())
    refs.insert(0, ref)
    _save(refs)
    xbmcgui.Dialog().notification('TopZilla',
                                   'Añadido a Quiero ver: {0}'.format(ref.get('title', '')),
                                   xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin('Container.Refresh')
    return True


def remove(key):
    if not key:
        return False
    refs = _load()
    new_refs = movie_ref.remove_by_key(refs, key)
    if len(new_refs) == len(refs):
        return False
    _save(new_refs)
    xbmcgui.Dialog().notification('TopZilla', 'Quitado de Quiero ver',
                                   xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin('Container.Refresh')
    return True


def move_to_favorites(key):
    """Quita de la watchlist y añade a Favoritos."""
    refs = _load()
    ref = movie_ref.find_ref(refs, key)
    if not ref:
        return False
    import favorites
    favorites.add(ref)  # muestra "ya estaba" si procede; no interrumpe la limpieza
    new_refs = movie_ref.remove_by_key(refs, key)
    _save(new_refs)
    xbmc.executebuiltin('Container.Refresh')
    return True


def clear_all():
    if not xbmcgui.Dialog().yesno('TopZilla - Quiero ver',
                                    '¿Borrar TODA la lista Quiero ver? Esta acción no se puede deshacer.'):
        return
    _save([])
    xbmcgui.Dialog().notification('TopZilla', 'Lista Quiero ver borrada',
                                   xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin('Container.Refresh')


def pick_action(key):
    if not key:
        return
    while True:
        ref = movie_ref.find_ref(_load(), key)
        if not ref:
            xbmcgui.Dialog().notification('TopZilla',
                'Título no encontrado', xbmcgui.NOTIFICATION_WARNING, 2500)
            return
        idx = xbmcgui.Dialog().select(
            'Acciones — {0}'.format(movie_ref.display_label(ref)),
            ['[COLOR green]Mover a Favoritos[/COLOR]',
             '[COLOR red]Quitar de Quiero ver[/COLOR]',
             'Ver datos guardados'])
        if idx < 0:
            return
        if idx == 0:
            move_to_favorites(key)
            return
        if idx == 1:
            if xbmcgui.Dialog().yesno('TopZilla',
                    '¿Quitar de Quiero ver?\n\n{0}'.format(movie_ref.display_label(ref))):
                remove(key)
            return
        if idx == 2:
            _view_info(ref)


def _view_info(ref):
    media = 'Serie' if ref.get('media_type') == 'show' else 'Película'
    year = ref.get('year') or 0
    added = ref.get('added_at')
    try:
        added_str = time.strftime('%d/%m/%Y %H:%M',
                                    time.localtime(int(added))) if added else '(desconocido)'
    except (ValueError, TypeError):
        added_str = '(desconocido)'
    text = (
        '[B]Título:[/B] {0}\n'
        '[B]Año:[/B] {1}\n'
        '[B]Tipo:[/B] {2}\n'
        '[B]TMDB ID:[/B] {3}\n'
        '[B]IMDb ID:[/B] {4}\n\n'
        '[B]Sinopsis:[/B]\n{5}\n\n'
        '[B]Añadido:[/B] {6}'
    ).format(
        ref.get('title') or '(sin título)',
        year if year else '(vacío)',
        media,
        ref.get('tmdb_id') or '(vacío)',
        ref.get('imdb_id') or '(vacío)',
        ref.get('plot') or '(vacía)',
        added_str,
    )
    xbmcgui.Dialog().textviewer('Datos guardados', text)


def show_menu():
    import metadata_enricher as me
    import context_menu

    h = _handle()
    refs = _load()
    af = core_settings.addon_fanart()

    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()

    if not refs:
        li = xbmcgui.ListItem(label=core_settings.apply_label('[COLOR gray]Tu lista Quiero ver está vacía[/COLOR]', bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': 'DefaultIconInfo.png', 'fanart': af})
        li.setInfo('video', {'plot':
            'Añade títulos desde el menú contextual (clic derecho) en cualquier sección del addon.'})
        xbmcplugin.addDirectoryItem(handle=h, url='', listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
        return

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        '[COLOR red][B]Borrar toda la lista[/B][/COLOR]',
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultIconError.png', 'fanart': af})
    li.setProperty('IsPlayable', 'false')
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='watchlist_clear_all'),
                                 listitem=li, isFolder=False)

    for ref in refs:
        title = ref.get('title') or ''
        year = ref.get('year') or 0
        media = ref.get('media_type', 'movie')
        label = '[B]{0}[/B]'.format(movie_ref.display_label(ref))
        src = movie_ref.format_source(ref.get('source', ''))
        if src:
            label = '{0}  [COLOR gray]{1}[/COLOR]'.format(label, src)
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            label, bold=_bold, strip=_strip, color_mode=_color))

        meta = me.enrich(
            tmdb_id=ref.get('tmdb_id'),
            imdb_id=ref.get('imdb_id'),
            title=title,
            year=year or None,
            media_type=media,
            use_cache_only=True,
        )
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
        else:
            poster = ref.get('poster') or ''
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': poster, 'poster': poster, 'fanart': af})
            li.setInfo('video', {
                'title': title,
                'year': year,
                'plot': ref.get('plot') or '',
                'mediatype': 'tvshow' if media == 'show' else 'movie',
            })

        context_menu.attach(li, ref)
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='watchlist_pick_action', key=movie_ref.ref_key(ref)),
            listitem=li,
            isFolder=False,
        )

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)
