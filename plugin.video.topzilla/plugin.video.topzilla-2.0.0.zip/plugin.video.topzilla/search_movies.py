# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""
Búsqueda local en todos los tops cargados (FilmAffinity, SensaCine,
Cinemeta, TMDB, Top Históricas). No hace ninguna llamada de red.
"""
import difflib
import json
import re
import sys
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcgui
import xbmcplugin

import core_settings
import movie_ref as mr
import yt_resolve

_HISTORY_FILE     = 'search_history.json'
_MAX_HISTORY      = 50
# Cache en RAM (window properties), no toca disco. Se pierde al cerrar Kodi.
_WP_PROP_TITLE    = 'topzilla.wp.title'
_WP_PROP_EXTRACT  = 'topzilla.wp.extract'
_WP_PROP_IMG_URLS = 'topzilla.wp.img_urls'

# TMDB extras: caché RAM por tmdb_id + listado de URLs cacheadas para limpiar.
_TMDB_PROP_IMG_URLS       = 'topzilla.tmdb.urls'
_TMDB_PROP_EXTRAS_PREFIX  = 'topzilla.tmdb.extras.'

# Endpoint TMDB → etiqueta legible
_TMDB_LABELS = {
    'movie/top_rated':      'TMDB: Top valoradas',
    'movie/popular':        'TMDB: Populares',
    'trending/movie/day':   'TMDB: Tendencias hoy',
    'trending/movie/week':  'TMDB: Tendencias semana',
    'movie/now_playing':    'TMDB: En cines',
    'movie/upcoming':       'TMDB: Próximos estrenos',
    'tv/top_rated':         'TMDB: Mejores series',
    'tv/popular':           'TMDB: Series populares',
    'trending/tv/week':     'TMDB: Tendencias series',
    'tv/on_the_air':        'TMDB: Series en emisión',
    'tv/airing_today':      'TMDB: Series hoy',
}


def _u(**kwargs):
    return core_settings.make_url(**kwargs)

def _handle():
    return int(sys.argv[1])


def _load_history():
    data = core_settings.load_json(_HISTORY_FILE, default=[])
    return data if isinstance(data, list) else []

def _save_history(history):
    core_settings.save_json(_HISTORY_FILE, history)

def _add_to_history(query):
    if not query:
        return
    history = _load_history()
    history = [h for h in history if h.get('query') != query]
    history.insert(0, {'query': query, 'ts': int(time.time())})
    _save_history(history[:_MAX_HISTORY])


# Recolección de todos los ítems locales

def _int_year(val):
    s = str(val) if val else ''
    return int(s) if s.isdigit() else 0


def _norm_key(title, media_type):
    """Clave de agrupación para dedup por título normalizado + tipo."""
    s = (title or '').lower().strip()
    s = re.sub(r'[^a-z0-9]+', '-', s).strip('-')
    return "{0}|{1}".format(s, media_type or 'movie')


# Búsqueda con tolerancia a erratas (fuzzy)

_FUZZY_MIN = 0.8     # umbral difflib para aceptar un match con erratas
_MIN_QUERY = 2       # nº mínimo de caracteres antes de activar fuzzy


def _norm_text(s):
    """Minúsculas + sin acentos + solo alfanumérico/espacios, para comparar títulos
    sin ruido. Normaliza los acentos (é→e, í→i, ñ→n) en vez de borrarlos, para que
    'espiritu' case 'El espíritu' aunque el usuario escriba sin tildes."""
    s = (s or '').lower()
    s = unicodedata.normalize('NFKD', s)
    s = ''.join(c for c in s if not unicodedata.combining(c))
    return re.sub(r'[^a-z0-9 ]+', ' ', s).strip()


def _fuzzy_match(q_norm, title_norm):
    """True si q casa el título por substring o por similitud (erratas) con
    alguna palabra. q_norm y title_norm deben venir ya normalizados (_norm_text)."""
    if not q_norm:
        return False
    if q_norm in title_norm:
        return True
    for w in title_norm.split():
        sm = difflib.SequenceMatcher(None, q_norm, w)
        if sm.real_quick_ratio() >= _FUZZY_MIN and sm.ratio() >= _FUZZY_MIN:
            return True
    return False


# Llamadas a TMDB en vivo (siempre con progreso de fondo, nunca lanzan)

def _bg_progress(label):
    """DialogProgressBG 'Buscando...'. Devuelve el diálogo o None si no se pudo
    crear. El llamante debe cerrarlo con _bg_close()."""
    try:
        dp = xbmcgui.DialogProgressBG()
        dp.create('TopZilla', label)
        dp.update(10)
        return dp
    except Exception:
        return None


def _bg_close(dp):
    if dp is None:
        return
    try:
        dp.close()
    except Exception:
        pass


def _search_tmdb_live(query):
    """me.search_multi con barra de progreso. Devuelve [] ante cualquier fallo
    (offline, sin clave, etc.) para que la búsqueda offline siga funcionando."""
    dp = _bg_progress('Buscando en TMDB...')
    try:
        import metadata_enricher as me
        return me.search_multi(query) or []
    except Exception as e:
        xbmc.log("[TopZilla-SR] search_multi: {0}".format(e), xbmc.LOGWARNING)
        return []
    finally:
        _bg_close(dp)


# Descubrimiento online (director / género / año) vía TMDB

# Géneros TMDB de película (IDs estándar de la API v3).
_GENRES = [
    ("Acción", "28"), ("Aventura", "12"), ("Animación", "16"), ("Comedia", "35"),
    ("Ciencia Ficción", "878"), ("Documental", "99"), ("Drama", "18"),
    ("Fantasía", "14"), ("Terror", "27"), ("Thriller", "53"),
    ("Musical", "10402"), ("Western", "37"), ("Bélica", "10752"),
]


def _pick_director(personas):
    """Elige el person_id más relevante, prefiriendo el departamento de dirección."""
    directores = [p for p in personas if p.get('department') == 'Directing']
    if directores:
        return directores[0]['id']
    return personas[0]['id'] if personas else None


def _merge_discover(*listas):
    """Fusiona listas de discover dedupeando por tmdb_id+tipo, ordena por popularidad."""
    out, seen = [], set()
    for lst in listas:
        for it in lst:
            k = (str(it.get('tmdb_id') or ''), it.get('media_type'))
            if k in seen:
                continue
            seen.add(k)
            out.append(it)
    out.sort(key=lambda x: x.get('popularity') or 0, reverse=True)
    return out


def _discover_live(label, media_type, params):
    """me.discover con progreso de fondo. Devuelve [] ante cualquier fallo."""
    dp = _bg_progress(label)
    try:
        import metadata_enricher as me
        return me.discover(media_type, params) or []
    except Exception as e:
        xbmc.log("[TopZilla-SR] discover: {0}".format(e), xbmc.LOGWARNING)
        return []
    finally:
        _bg_close(dp)


def _person_live(name):
    """me.search_person con progreso de fondo. Devuelve [] ante cualquier fallo."""
    dp = _bg_progress('Buscando director...')
    try:
        import metadata_enricher as me
        return me.search_person(name) or []
    except Exception as e:
        xbmc.log("[TopZilla-SR] search_person: {0}".format(e), xbmc.LOGWARNING)
        return []
    finally:
        _bg_close(dp)


def _render_online_results(results, empty_msg):
    """Pinta una lista de items normalizados de TMDB como un directorio Kodi.
    Cada item es clicable igual que un resultado de búsqueda local."""
    h = _handle()
    if not results:
        xbmcgui.Dialog().notification("TopZilla", empty_msg,
                                       xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
        return

    import metadata_enricher as me
    import context_menu

    af     = core_settings.addon_fanart()
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()

    for it in results:
        title = it.get('title') or ''
        if not title:
            continue
        year   = _int_year(it.get('year'))
        media  = it.get('media_type') or 'movie'
        tmdb   = str(it.get('tmdb_id') or '') or None

        base_label = "[B]{0}[/B]".format("{0} ({1})".format(title, year) if year else title)
        label = core_settings.apply_label(base_label, bold=_bold, strip=_strip, color_mode=_color)
        label += " [COLOR deepskyblue][TMDB online][/COLOR]"

        li = xbmcgui.ListItem(label=label)

        meta = None
        try:
            meta = me.enrich(tmdb_id=tmdb, title=title, year=year or None,
                             media_type=media, use_cache_only=True)
        except Exception as e:
            xbmc.log("[TopZilla-SR] enrich online: {0}".format(e), xbmc.LOGWARNING)

        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or it.get('poster') or ''
        else:
            poster = it.get('poster') or ''
            art = {'fanart': af}
            if poster:
                art.update({'thumb': poster, 'poster': poster})
            else:
                art['icon'] = 'DefaultVideo.png'
            li.setArt(art)
            info = {'title': title, 'mediatype': 'tvshow' if media == 'show' else 'movie'}
            if year:
                info['year'] = year
            if it.get('overview'):
                info['plot'] = it['overview']
            li.setInfo('video', info)

        plot = (meta.get('overview') if meta else '') or it.get('overview') or ''
        ref = mr.make_ref(title=title, year=year, tmdb_id=tmdb, imdb_id=None,
                          poster=poster, media_type=media, source='search', plot=plot)
        context_menu.attach(li, ref)
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(handle=h, url=context_menu.build_play_url(ref),
                                     listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def online_search_director(name=None):
    """Descubre películas de un director vía TMDB (search_person -> discover with_crew)."""
    if not name:
        import remote_input
        name = remote_input.get_text_input('Director (nombre completo)...')
        if not name:
            xbmcplugin.endOfDirectory(_handle(), succeeded=False, cacheToDisc=False)
            return
        name = name.strip()
    if not name:
        xbmcplugin.endOfDirectory(_handle(), succeeded=False, cacheToDisc=False)
        return

    _add_to_history(name)
    personas = _person_live(name)
    pid = _pick_director(personas)
    results = (_discover_live('Buscando películas...', 'movie',
                              {'with_crew': pid, 'sort_by': 'popularity.desc'})
               if pid else [])
    _render_online_results(results, "No se encontró '{0}' o sus películas".format(name))


def online_genres_menu():
    """Submenú con los géneros TMDB para descubrimiento online."""
    h = _handle()
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()
    af     = core_settings.addon_fanart()

    for label, gid in _GENRES:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            "[B]{0}[/B]".format(label), bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': 'DefaultGenre.png', 'fanart': af})
        li.setInfo('video', {'plot': 'Películas de {0} ordenadas por popularidad (TMDB).'.format(label)})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='search_online_genre', id=gid, label=label),
            listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def online_search_genre(genre_id, label):
    """Descubre películas de un género vía TMDB (discover with_genres)."""
    results = _discover_live('Cargando {0}...'.format(label or 'género'), 'movie',
                             {'with_genres': genre_id, 'vote_count.gte': 100,
                              'sort_by': 'popularity.desc'})
    _render_online_results(results, "Sin resultados para el género {0}".format(label))


def online_search_year(year=None):
    """Descubre estrenos (pelis + series) de un año vía TMDB, fusionados."""
    if not year:
        kb = xbmc.Keyboard('', 'Año (ej. 1999)...')
        kb.doModal()
        if not kb.isConfirmed():
            xbmcplugin.endOfDirectory(_handle(), succeeded=False, cacheToDisc=False)
            return
        year = kb.getText().strip()
    y = str(year or '').strip()
    if not (y.isdigit() and 1900 <= int(y) <= 2100):
        _render_online_results([], "Introduce un año válido (ej. 1999)")
        return

    _add_to_history(y)
    pelis  = _discover_live('Cargando estrenos de {0}...'.format(y), 'movie',
                            {'primary_release_year': y, 'vote_count.gte': 50,
                             'sort_by': 'popularity.desc'})
    series = _discover_live('Cargando series de {0}...'.format(y), 'show',
                            {'first_air_date_year': y, 'vote_count.gte': 50,
                             'sort_by': 'popularity.desc'})
    _render_online_results(_merge_discover(pelis, series), "Sin estrenos en {0}".format(y))


def _safe_dict(v):
    return v if isinstance(v, dict) else {}

def _safe_list(v):
    return v if isinstance(v, list) else []


def _collect_all_items():
    """Lee todas las cachés en disco y devuelve lista de dicts normalizados.
    Cualquier sección corrupta se ignora silenciosamente (log warning)."""
    items = []

    try:
        fa = _safe_dict(core_settings.load_json('topzilla_fa_cache.json', {}))
        for section, label in [('cartelera', 'FA: En Cines'),
                                ('top',     'FA: Top Valoradas'),
                                ('topfa',   'FA: Top Comunidad')]:
            for f in _safe_list(_safe_dict(fa.get(section)).get('films')):
                title = (f or {}).get('title', '')
                if title:
                    items.append({
                        'title':       title,
                        'year':        _int_year(f.get('year')),
                        'poster':      f.get('poster', ''),
                        'media_type':  'movie',
                        'source_label': label,
                        'tmdb_id':     None,
                        'imdb_id':     None,
                    })
    except Exception as e:
        xbmc.log("[TopZilla-SR] FA: {0}".format(e), xbmc.LOGWARNING)

    try:
        sc = _safe_dict(core_settings.load_json('topzilla_sc_cache.json', {}))
        for section, label in [('cartelera', 'SC: En Cines'),
                                ('estrenos', 'SC: Estrenos'),
                                ('mejores',  'SC: Mejores'),
                                ('taquilla', 'SC: Taquilla')]:
            for f in _safe_list(_safe_dict(sc.get(section)).get('films')):
                title = (f or {}).get('title', '')
                if title:
                    items.append({
                        'title':       title,
                        'year':        0,
                        'poster':      f.get('poster', ''),
                        'media_type':  'movie',
                        'source_label': label,
                        'tmdb_id':     None,
                        'imdb_id':     None,
                    })
    except Exception as e:
        xbmc.log("[TopZilla-SR] SC: {0}".format(e), xbmc.LOGWARNING)

    try:
        cm = _safe_dict(core_settings.load_json('topzilla_cinemeta_cache.json', {}))
        for f in _safe_list(_safe_dict(cm.get('top')).get('films')):
            title = (f or {}).get('title', '')
            if title:
                items.append({
                    'title':       title,
                    'year':        _int_year(f.get('year')),
                    'poster':      f.get('poster', ''),
                    'media_type':  'movie',
                    'source_label': 'Cinemeta Top',
                    'tmdb_id':     None,
                    'imdb_id':     f.get('id'),
                })
        for slug, entry in _safe_dict(cm.get('genres')).items():
            for f in _safe_list(_safe_dict(entry).get('films')):
                title = (f or {}).get('title', '')
                if title:
                    items.append({
                        'title':       title,
                        'year':        _int_year(f.get('year')),
                        'poster':      f.get('poster', ''),
                        'media_type':  'movie',
                        'source_label': 'Cinemeta {0}'.format(slug),
                        'tmdb_id':     None,
                        'imdb_id':     f.get('id'),
                    })
    except Exception as e:
        xbmc.log("[TopZilla-SR] CM: {0}".format(e), xbmc.LOGWARNING)

    try:
        tmdb = _safe_dict(core_settings.load_json('topzilla_tmdb_lists_cache.json', {}))
        for cache_key, entry in tmdb.items():
            endpoint = cache_key.split('|')[0] if isinstance(cache_key, str) else ''
            label = _TMDB_LABELS.get(endpoint, 'TMDB: ' + endpoint.replace('/', ' ').title()) if endpoint else 'TMDB'
            for it in _safe_list(_safe_dict(entry).get('items')):
                title = (it or {}).get('title', '')
                if title:
                    items.append({
                        'title':       title,
                        'year':        _int_year(it.get('year')),
                        'poster':      it.get('poster', ''),
                        'media_type':  _norm_mt(it.get('media_type')) or 'movie',
                        'source_label': label,
                        'tmdb_id':     it.get('tmdb_id'),
                        'imdb_id':     None,
                    })
    except Exception as e:
        xbmc.log("[TopZilla-SR] TMDB: {0}".format(e), xbmc.LOGWARNING)

    try:
        import movie_data
        thumbs = _safe_dict(core_settings.load_json('topzilla_top_movies_thumbs.json', {}))
        for title in movie_data._get_movies_list():
            if title:
                items.append({
                    'title':       title,
                    'year':        0,
                    'poster':      thumbs.get(title, ''),
                    'media_type':  'movie',
                    'source_label': 'Top Históricas',
                    'tmdb_id':     None,
                    'imdb_id':     None,
                })
    except Exception as e:
        xbmc.log("[TopZilla-SR] top_movies: {0}".format(e), xbmc.LOGWARNING)

    # Cachés nuevas (Trakt, Streaming, Anime, MDBList, Letterboxd). Su estructura
    # interna varía entre fuentes, así que las recorremos con un harvester genérico
    # tolerante. load_json ya devuelve {} si el fichero falta o está corrupto;
    # el harvester de un fichero defectuoso simplemente recoge menos sin afectar
    # al resto.
    for fname, label in _EXTRA_CACHES:
        try:
            _harvest_cache(core_settings.load_json(fname, {}), label, items)
        except (TypeError, ValueError, AttributeError) as e:
            xbmc.log("[TopZilla-SR] {0}: {1}".format(fname, e), xbmc.LOGWARNING)

    return items


# Cachés nuevas + harvester genérico

_EXTRA_CACHES = (
    ('topzilla_trakt_tops_cache.json',      'Trakt'),
    ('topzilla_streaming_tops_cache.json',  'Streaming'),
    ('topzilla_anime_cache.json',           'Anime'),
    ('topzilla_mdblist_cache.json',         'MDBList'),
    ('topzilla_letterboxd_cache.json',      'Letterboxd'),
)

_SHOW_TOKENS  = {'tv', 'show', 'shows', 'serie', 'series', 'tvshow', 'tvshows'}
_MOVIE_TOKENS = {'movie', 'movies', 'pelicula', 'peliculas', 'film', 'films'}


def _mt_from_key(key, parent):
    """Infiere movie/show por el nombre de la clave de caché (p.ej. trakt usa
    movies/ y shows/). Por tokens para no casar 'tv' dentro de otra palabra."""
    tokens = set(re.split(r'[^a-z]+', str(key).lower()))
    if tokens & _SHOW_TOKENS:
        return 'show'
    if tokens & _MOVIE_TOKENS:
        return 'movie'
    return parent


def _norm_mt(value):
    v = str(value or '').lower()
    if v in ('tv', 'show', 'tvshow', 'series', 'serie'):
        return 'show'
    if v in ('movie', 'film', 'pelicula'):
        return 'movie'
    return ''


def _harvest_cache(obj, label, items, mt_hint=''):
    """Recorre recursivamente un JSON de caché y añade a `items` los dicts con
    pinta de película/serie (title/name + al menos un campo de identidad)."""
    if isinstance(obj, dict):
        title = obj.get('title') or obj.get('name')
        ident = any(obj.get(k) for k in ('tmdb_id', 'poster', 'year', 'media_type', 'imdb_id', 'id'))
        if title and ident:
            mt = _norm_mt(obj.get('media_type')) or mt_hint or 'movie'
            imdb = obj.get('imdb_id')
            rawid = obj.get('id')
            if not imdb and isinstance(rawid, str) and rawid.startswith('tt'):
                imdb = rawid
            items.append({
                'title':        str(title),
                'year':         _int_year(obj.get('year')),
                'poster':       obj.get('poster') or '',
                'media_type':   mt,
                'source_label': label,
                'tmdb_id':      obj.get('tmdb_id') or None,
                'imdb_id':      imdb or None,
            })
            return  # no seguir bajando dentro de un item ya identificado
        for k, v in obj.items():
            _harvest_cache(v, label, items, _mt_from_key(k, mt_hint))
    elif isinstance(obj, list):
        for v in obj:
            _harvest_cache(v, label, items, mt_hint)


# Búsqueda y resultados

def perform_search(query=None):
    h = _handle()
    if not query:
        import remote_input
        query = remote_input.get_text_input('Buscar en los tops...')
        if not query:
            xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
            return
        query = query.strip()
    if not query:
        xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
        return

    _add_to_history(query)

    all_items = _collect_all_items()
    q_lower = query.lower()
    q_norm  = _norm_text(query)
    use_fuzzy = len(q_norm) >= _MIN_QUERY

    # Agrupar por título normalizado + media_type. Si la misma peli aparece
    # en varios tops, fusionamos: nos quedamos con el tmdb_id/imdb_id/poster
    # más rico y combinamos las etiquetas de fuente.
    groups = {}
    order  = []
    for item in all_items:
        title = item['title']
        # Substring (comportamiento original) + fuzzy por errata. El fuzzy solo
        # se evalúa si el substring falla y la query es lo bastante larga, para
        # no penalizar el rendimiento sobre el catálogo completo.
        if q_lower not in title.lower():
            if not (use_fuzzy and _fuzzy_match(q_norm, _norm_text(title))):
                continue
        k = _norm_key(item['title'], item['media_type'])
        if k not in groups:
            g = {
                'title':      item['title'],
                'year':       item['year'],
                'poster':     item['poster'],
                'media_type': item['media_type'],
                'tmdb_id':    item['tmdb_id'],
                'imdb_id':    item['imdb_id'],
                'sources':    [item['source_label']],
            }
            groups[k] = g
            order.append(k)
        else:
            g = groups[k]
            if not g['tmdb_id'] and item['tmdb_id']:
                g['tmdb_id'] = item['tmdb_id']
            if not g['imdb_id'] and item['imdb_id']:
                g['imdb_id'] = item['imdb_id']
            if not g['poster'] and item['poster']:
                g['poster'] = item['poster']
            if not g['year'] and item['year']:
                g['year'] = item['year']
            if item['source_label'] not in g['sources']:
                g['sources'].append(item['source_label'])

    results = [groups[k] for k in order]

    # Índices de lo local para detectar coincidencias con TMDB en vivo.
    local_by_tmdb = {str(groups[k]['tmdb_id']): groups[k]
                     for k in order if groups[k]['tmdb_id']}
    local_by_key  = {k: groups[k] for k in order}

    # Fusión con TMDB en vivo: añade títulos que TMDB devuelve y no estaban en
    # los tops cacheados, y marca con un badge los que sí están. Si TMDB no
    # responde ([]), el comportamiento offline se mantiene intacto.
    online = _search_tmdb_live(query)
    for it in online:
        otid = str(it.get('tmdb_id') or '')
        okey = _norm_key(it.get('title'), it.get('media_type'))
        local = local_by_tmdb.get(otid) if otid else None
        if local is None:
            local = local_by_key.get(okey)
        if local is not None:
            # Ya está en los tops: enriquecemos su tmdb_id si faltaba; no se
            # duplica la fila. (El badge de fuentes locales ya lo describe.)
            if not local['tmdb_id'] and otid:
                local['tmdb_id'] = otid
            continue
        results.append({
            'title':      it.get('title') or '',
            'year':       _int_year(it.get('year')),
            'poster':     it.get('poster') or '',
            'media_type': it.get('media_type') or 'movie',
            'tmdb_id':    otid or None,
            'imdb_id':    None,
            'sources':    ['TMDB online'],
            'online':     True,
        })

    if not results:
        xbmcgui.Dialog().notification(
            "TopZilla",
            "'{0}' no está en ningún top cargado".format(query),
            xbmcgui.NOTIFICATION_INFO, 3000,
        )
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
        return

    import metadata_enricher as me
    import context_menu

    af = core_settings.addon_fanart()
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()

    for g in results:
        title  = g['title']
        year   = g['year']
        media  = g['media_type']
        srcs   = ", ".join(g['sources']) if g['sources'] else ''

        base_label = "[B]{0}[/B]".format("{0} ({1})".format(title, year) if year else title)
        label = core_settings.apply_label(base_label, bold=_bold, strip=_strip, color_mode=_color)
        if g.get('online'):
            label += " [COLOR deepskyblue][TMDB online][/COLOR]"
        elif srcs:
            label += " [COLOR gray][En tus tops: {0}][/COLOR]".format(srcs)

        li = xbmcgui.ListItem(label=label)

        meta = None
        try:
            meta = me.enrich(
                tmdb_id=g['tmdb_id'],
                imdb_id=g['imdb_id'],
                title=title,
                year=year or None,
                media_type=media,
                use_cache_only=True,
            )
        except Exception as e:
            xbmc.log("[TopZilla-SR] enrich error: {0}".format(e), xbmc.LOGWARNING)

        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or g['poster']
        else:
            poster = g['poster']
            art = {'fanart': af}
            if poster:
                art.update({'thumb': poster, 'poster': poster})
            else:
                art['icon'] = 'DefaultVideo.png'
            li.setArt(art)
            info = {
                'title': title,
                'mediatype': 'tvshow' if media == 'show' else 'movie',
            }
            if year:
                info['year'] = year
            li.setInfo('video', info)

        plot = meta.get('overview', '') if meta else ''
        ref = mr.make_ref(
            title=title, year=year,
            tmdb_id=g['tmdb_id'], imdb_id=g['imdb_id'],
            poster=poster, media_type=media, source='search', plot=plot,
        )
        context_menu.attach(li, ref)
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=context_menu.build_play_url(ref),
            listitem=li,
            isFolder=False,
        )

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


_WP_UA      = {'User-Agent': 'TopZilla/2.x Kodi addon (+https://github.com/fullstackcurso)'}
_WP_BASE    = 'https://es.wikipedia.org/w/api.php'
_WP_TIMEOUT = 15
_WP_IMG_EXT = ('jpg', 'jpeg', 'png')


def _wp_remove_texture_for_url(url):
    """Borra del caché de texturas de Kodi (userdata/Thumbnails) la imagen
    correspondiente a la URL dada. Usa JSON-RPC, no toca disco directamente."""
    try:
        get_req = json.dumps({
            'jsonrpc': '2.0',
            'method':  'Textures.GetTextures',
            'params':  {'filter': {'field': 'url', 'operator': 'is', 'value': url}},
            'id':      1,
        })
        resp = xbmc.executeJSONRPC(get_req)
        data = json.loads(resp or '{}')
        for tex in (data.get('result') or {}).get('textures') or []:
            tid = tex.get('textureid')
            if tid is None:
                continue
            rm_req = json.dumps({
                'jsonrpc': '2.0',
                'method':  'Textures.RemoveTexture',
                'params':  {'textureid': int(tid)},
                'id':      1,
            })
            xbmc.executeJSONRPC(rm_req)
    except Exception as e:
        xbmc.log('[TopZilla-WP] tex remove: {0}'.format(e), xbmc.LOGWARNING)


def wp_exit():
    """Borra las texturas cacheadas y las propiedades en RAM de la sesión Wikipedia."""
    win = xbmcgui.Window(10000)
    urls_str = win.getProperty(_WP_PROP_IMG_URLS) or ''
    if urls_str:
        for u in urls_str.split('\n'):
            u = u.strip()
            if u:
                _wp_remove_texture_for_url(u)
    win.clearProperty(_WP_PROP_TITLE)
    win.clearProperty(_WP_PROP_EXTRACT)
    win.clearProperty(_WP_PROP_IMG_URLS)


def _wp_request(extra_params):
    """Ejecuta una petición a la API de Wikipedia. Devuelve dict (o lanza)."""
    qs = urllib.parse.urlencode(extra_params)
    req = urllib.request.Request(_WP_BASE + '?' + qs, headers=_WP_UA)
    with urllib.request.urlopen(req, timeout=_WP_TIMEOUT) as r:
        raw = r.read()
    try:
        return json.loads(raw.decode('utf-8'))
    except (ValueError, UnicodeDecodeError) as e:
        xbmc.log('[TopZilla-WP] respuesta no-JSON: {0}'.format(e), xbmc.LOGWARNING)
        return {}


def _wikipedia_search(query):
    q = (query or '').strip()
    if not q:
        return []
    data = _wp_request({
        'action': 'opensearch', 'search': q,
        'limit': '8', 'namespace': '0',
        'format': 'json', 'utf8': '1',
    })
    if isinstance(data, list) and len(data) >= 2 and isinstance(data[1], list):
        return [str(t) for t in data[1] if t]
    return []


def _wp_format_extract(extract):
    """Transforma el texto plano (explaintext) de MediaWiki en algo legible en
    el textviewer de Kodi: cabeceras de sección (== Título ==) en negrita y
    coloreadas, y párrafos separados por una línea en blanco."""
    if not extract:
        return ''
    out = []
    for raw_line in extract.split('\n'):
        line = raw_line.rstrip()
        m = re.match(r'^(={2,6})\s*(.+?)\s*\1\s*$', line)
        if m:
            depth = len(m.group(1))
            title = m.group(2).strip()
            if out and out[-1] != '':
                out.append('')
            if depth <= 2:
                out.append('[B][COLOR deepskyblue]{0}[/COLOR][/B]'.format(title))
            else:
                out.append('[B]{0}[/B]'.format(title))
            out.append('')
        else:
            out.append(line)
    text = '\n'.join(out)
    # Normaliza 3+ saltos consecutivos a exactamente 2 (un párrafo en blanco).
    text = re.sub(r'\n{3,}', '\n\n', text)
    return text.strip()


def _wikipedia_fetch_article(page_title):
    """Descarga extracto, imagen principal e imágenes del artículo.
    Si la descarga de imágenes falla parcialmente, se devuelven las que se hayan
    podido obtener junto con el texto del artículo."""
    pt = (page_title or '').strip()
    if not pt:
        return None

    # 1ª llamada: extracto + imagen principal + lista de imágenes (una sola petición).
    # redirects=1 → si el título es alias o redirección, salta al artículo destino.
    d1 = _wp_request({
        'action': 'query', 'titles': pt,
        'prop': 'extracts|pageimages|images',
        'explaintext': '1', 'pithumbsize': '600', 'imlimit': '30',
        'redirects': '1',
        'format': 'json', 'utf8': '1',
    })

    pages = ((d1 or {}).get('query') or {}).get('pages') or {}
    if not isinstance(pages, dict) or not pages:
        return None
    page = next(iter(pages.values()), {}) or {}
    if not isinstance(page, dict):
        return None
    if page.get('missing') is not None or page.get('invalid') is not None:
        return None

    extract = _wp_format_extract(page.get('extract') or '')
    thumb   = ((page.get('thumbnail') or {}).get('source')) or ''
    title   = page.get('title') or pt

    img_titles = []
    for i in (page.get('images') or []):
        t = (i or {}).get('title') or ''
        if t and t.lower().rsplit('.', 1)[-1] in _WP_IMG_EXT:
            img_titles.append(t)

    images = []
    if img_titles:
        try:
            d2 = _wp_request({
                'action': 'query', 'titles': '|'.join(img_titles[:20]),
                'prop': 'imageinfo', 'iiprop': 'url|dimensions',
                'format': 'json', 'utf8': '1',
            })
            for pg in (((d2 or {}).get('query') or {}).get('pages') or {}).values():
                if not isinstance(pg, dict):
                    continue
                info_list = pg.get('imageinfo') or []
                if not info_list:
                    continue
                ii = info_list[0] or {}
                iurl = ii.get('url') or ''
                if iurl and iurl.lower().rsplit('.', 1)[-1] in _WP_IMG_EXT:
                    name = (pg.get('title') or '')
                    for prefix in ('File:', 'Archivo:', 'Fichero:'):
                        if name.startswith(prefix):
                            name = name[len(prefix):]
                            break
                    images.append({
                        'name': name,
                        'url':  iurl,
                        'w':    int(ii.get('width') or 0),
                        'h':    int(ii.get('height') or 0),
                    })
        except (urllib.error.URLError, OSError, ValueError) as e:
            xbmc.log('[TopZilla-WP] imágenes parciales: {0}'.format(e), xbmc.LOGWARNING)

    return {'title': str(title), 'extract': extract, 'thumb': str(thumb), 'images': images}


def wikipedia_results(query):
    """Flujo de diálogos puro (select+textviewer): no abre ningún contenedor,
    así que el llamante debe cerrar su endOfDirectory antes de invocar.
    """
    q = (query or '').strip()
    if not q:
        return

    wp_exit()

    dp = xbmcgui.DialogProgress()
    dp.create('TopZilla — Wikipedia', 'Buscando en Wikipedia...')
    dp.update(10)

    try:
        titles = _wikipedia_search(q)
    except (urllib.error.URLError, OSError, ValueError) as exc:
        dp.close()
        xbmc.log('[TopZilla-WP] search: {0}'.format(exc), xbmc.LOGERROR)
        xbmcgui.Dialog().ok('TopZilla', 'Error al buscar en Wikipedia:\n{0}'.format(exc))
        return
    except Exception as exc:
        dp.close()
        xbmc.log('[TopZilla-WP] search inesperado: {0}'.format(exc), xbmc.LOGERROR)
        xbmcgui.Dialog().ok('TopZilla', 'Error inesperado en Wikipedia:\n{0}'.format(exc))
        return

    if dp.iscanceled():
        dp.close()
        return

    if not titles:
        dp.close()
        xbmcgui.Dialog().notification('TopZilla',
            "'{0}' no encontrado en Wikipedia".format(q),
            xbmcgui.NOTIFICATION_INFO, 3000)
        return

    page_title = titles[0]
    if len(titles) > 1:
        dp.close()
        idx = xbmcgui.Dialog().select('Wikipedia — ¿Qué artículo?', [str(t) for t in titles])
        if idx < 0:
            return
        page_title = titles[idx]
        dp = xbmcgui.DialogProgress()
        dp.create('TopZilla — Wikipedia', 'Cargando artículo...')

    dp.update(40, 'Descargando artículo e imágenes...')

    try:
        article = _wikipedia_fetch_article(page_title)
    except (urllib.error.URLError, OSError, ValueError) as exc:
        dp.close()
        xbmc.log('[TopZilla-WP] fetch: {0}'.format(exc), xbmc.LOGERROR)
        xbmcgui.Dialog().ok('TopZilla', 'Error al cargar el artículo:\n{0}'.format(exc))
        return
    except Exception as exc:
        dp.close()
        xbmc.log('[TopZilla-WP] fetch inesperado: {0}'.format(exc), xbmc.LOGERROR)
        xbmcgui.Dialog().ok('TopZilla', 'Error inesperado al cargar el artículo:\n{0}'.format(exc))
        return

    dp.close()

    if not article:
        xbmcgui.Dialog().notification('TopZilla', 'Artículo no encontrado',
                                       xbmcgui.NOTIFICATION_INFO, 3000)
        return

    art_title = str(article.get('title') or page_title)
    extract   = str(article.get('extract') or '(Sin descripción disponible)')
    thumb     = str(article.get('thumb') or '')
    images    = [img for img in (article.get('images') or []) if isinstance(img, dict)]

    items = []
    art_li = xbmcgui.ListItem(
        label='[COLOR deepskyblue][B]Ver artículo[/B][/COLOR]',
        label2='Texto completo del artículo de Wikipedia')
    if thumb:
        art_li.setArt({'thumb': thumb, 'icon': thumb, 'poster': thumb})
    else:
        art_li.setArt({'icon': 'DefaultAddonsSearch.png'})
    items.append(art_li)

    tracked_urls = []
    if thumb:
        tracked_urls.append(thumb)
    img_urls = []
    for img in images:
        iurl  = str(img.get('url') or '')
        iname = str(img.get('name') or 'Imagen')
        if not iurl:
            continue
        tracked_urls.append(iurl)
        img_urls.append(iurl)
        iw, ih = int(img.get('w') or 0), int(img.get('h') or 0)
        dims = '{0}x{1}'.format(iw, ih) if iw else ''
        li_img = xbmcgui.ListItem(label='[B]{0}[/B]'.format(iname),
                                   label2=dims or 'Imagen del artículo')
        li_img.setArt({'thumb': iurl, 'icon': iurl, 'poster': iurl})
        items.append(li_img)

    try:
        win = xbmcgui.Window(10000)
        win.setProperty(_WP_PROP_IMG_URLS, '\n'.join(u for u in tracked_urls if u))
    except Exception:
        pass

    try:
        while True:
            sel = xbmcgui.Dialog().select(
                '{0}  [Wikipedia]'.format(art_title),
                items, useDetails=True)
            if sel is None or sel < 0:
                break
            if sel == 0:
                xbmcgui.Dialog().textviewer(art_title, extract)
            else:
                i = sel - 1
                if 0 <= i < len(img_urls):
                    xbmc.executebuiltin('ShowPicture({0})'.format(img_urls[i]))
    finally:
        wp_exit()


# TMDB: más información (reparto, similares, recomendaciones, tráileres...)

def _tmdb_remove_texture_for_url(url):
    """Borra del caché de texturas (userdata/Thumbnails) la imagen indicada."""
    try:
        get_req = json.dumps({
            'jsonrpc': '2.0',
            'method':  'Textures.GetTextures',
            'params':  {'filter': {'field': 'url', 'operator': 'is', 'value': url}},
            'id':      1,
        })
        resp = xbmc.executeJSONRPC(get_req)
        data = json.loads(resp or '{}')
        for tex in (data.get('result') or {}).get('textures') or []:
            tid = tex.get('textureid')
            if tid is None:
                continue
            rm_req = json.dumps({
                'jsonrpc': '2.0',
                'method':  'Textures.RemoveTexture',
                'params':  {'textureid': int(tid)},
                'id':      1,
            })
            xbmc.executeJSONRPC(rm_req)
    except Exception as e:
        xbmc.log('[TopZilla-TMDB] tex remove: {0}'.format(e), xbmc.LOGWARNING)


def tmdb_exit():
    """Limpia texturas cacheadas y borra propiedades de extras de la sesión."""
    win = xbmcgui.Window(10000)
    urls_str = win.getProperty(_TMDB_PROP_IMG_URLS) or ''
    if urls_str:
        for u in urls_str.split('\n'):
            u = u.strip()
            if u:
                _tmdb_remove_texture_for_url(u)
    win.clearProperty(_TMDB_PROP_IMG_URLS)


def _tmdb_track_url(tracked, url):
    """Sólo registra URLs http(s). Los iconos internos de Kodi
    (Default*.png, etc.) no pasan por Texture Cache y no hay que limpiarlos."""
    if not url or not isinstance(url, str):
        return
    if not (url.startswith('http://') or url.startswith('https://')):
        return
    if url not in tracked:
        tracked.append(url)


def _tmdb_dump_tracked(urls):
    try:
        win = xbmcgui.Window(10000)
        win.setProperty(_TMDB_PROP_IMG_URLS, '\n'.join(u for u in urls if u))
    except Exception:
        pass


def _tmdb_cache_get(tmdb_id):
    try:
        win = xbmcgui.Window(10000)
        raw = win.getProperty(_TMDB_PROP_EXTRAS_PREFIX + str(tmdb_id)) or ''
        if raw:
            return json.loads(raw)
    except Exception:
        pass
    return None


def _tmdb_cache_set(tmdb_id, extras):
    try:
        win = xbmcgui.Window(10000)
        win.setProperty(_TMDB_PROP_EXTRAS_PREFIX + str(tmdb_id),
                         json.dumps(extras))
    except Exception:
        pass


def _tmdb_format_money(n):
    try:
        n = int(n or 0)
    except (TypeError, ValueError):
        return ''
    if n <= 0:
        return ''
    if n >= 1_000_000_000:
        return '{0:,.2f} B$'.format(n / 1_000_000_000).replace(',', '.')
    if n >= 1_000_000:
        return '{0:,.1f} M$'.format(n / 1_000_000).replace(',', '.')
    return '{0:,} $'.format(n).replace(',', '.')


def _tmdb_show_cast(cast, tracked):
    if not cast:
        return
    items = []
    for c in cast:
        thumb = c.get('thumb') or ''
        _tmdb_track_url(tracked, thumb)
        li = xbmcgui.ListItem(label='[B]{0}[/B]'.format(c.get('name') or ''),
                               label2=c.get('role') or '')
        if thumb:
            li.setArt({'thumb': thumb, 'icon': thumb, 'poster': thumb})
        else:
            li.setArt({'icon': 'DefaultActor.png'})
        items.append(li)
    _tmdb_dump_tracked(tracked)
    while True:
        idx = xbmcgui.Dialog().select('Reparto completo', items, useDetails=True)
        if idx < 0:
            return
        c = cast[idx]
        name = c.get('name') or 'Reparto'
        pid = c.get('id') or ''
        if not pid:
            # Cache antigua sin id de persona: degradación al detalle de texto.
            xbmcgui.Dialog().textviewer(
                name, 'Personaje: {0}'.format(c.get('role') or '(sin especificar)'))
            continue
        try:
            import metadata_enricher as me
            credits = me.get_person_credits(pid)
        except Exception as exc:
            xbmc.log('[TopZilla-TMDB] person credits: {0}'.format(exc), xbmc.LOGWARNING)
            credits = []
        if not credits:
            xbmcgui.Dialog().notification('TopZilla', 'Sin filmografía disponible',
                                           xbmcgui.NOTIFICATION_INFO, 2500)
            continue
        # Reutiliza el visor de "similares" (navegable, con drill-down a la ficha).
        if _tmdb_show_similar(credits, 'Filmografía de {0}'.format(name), '', tracked) == 'drill':
            return 'drill'


def _tmdb_show_crew(crew):
    if not crew:
        return
    label_map = [('director',       'Dirección'),
                 ('writers',        'Guion'),
                 ('composer',       'Música'),
                 ('cinematography', 'Fotografía'),
                 ('editor',         'Montaje')]
    lines = []
    for key, label in label_map:
        names = crew.get(key) or []
        if names:
            lines.append('[B]{0}[/B]: {1}'.format(label, ', '.join(names)))
    if not lines:
        return
    xbmcgui.Dialog().textviewer('Equipo técnico', '\n\n'.join(lines))


def _tmdb_show_similar(items, label, media_type, tracked):
    if not items:
        return
    li_items = []
    for it in items:
        poster = it.get('poster') or ''
        _tmdb_track_url(tracked, poster)
        title = it.get('title') or ''
        year  = it.get('year') or 0
        rate  = it.get('rating') or 0
        l1 = '[B]{0}[/B]{1}'.format(title, '  ({0})'.format(year) if year else '')
        l2 = 'Rating: {0:.1f}'.format(rate) if rate else (it.get('plot') or '')[:120]
        li = xbmcgui.ListItem(label=l1, label2=l2)
        if poster:
            li.setArt({'thumb': poster, 'icon': poster, 'poster': poster})
        else:
            li.setArt({'icon': 'DefaultVideo.png'})
        li_items.append(li)
    _tmdb_dump_tracked(tracked)
    while True:
        idx = xbmcgui.Dialog().select(label, li_items, useDetails=True)
        if idx < 0:
            return
        # Drill-down: re-abre el diálogo de alternativas para el título clicado.
        it = items[idx]
        clicked_title = it.get('title') or ''
        clicked_mode  = it.get('media_type') or media_type or 'movie'
        if not clicked_title:
            continue
        url = _u(action='search_alt_prompt', q=clicked_title, ot='', mode=clicked_mode)
        xbmc.executebuiltin('RunPlugin({0})'.format(url))
        return 'drill'


def _tmdb_show_videos(videos, art_title, tracked):
    if not videos:
        return
    has_youtube = xbmc.getCondVisibility('System.HasAddon(plugin.video.youtube)')
    items = []
    for v in videos:
        key = v.get('key') or ''
        thumb = 'https://i.ytimg.com/vi/{0}/hqdefault.jpg'.format(key) if key else ''
        _tmdb_track_url(tracked, thumb)
        li = xbmcgui.ListItem(label='[B]{0}[/B]'.format(v.get('name') or '(sin título)'),
                               label2=v.get('type') or '')
        if thumb:
            li.setArt({'thumb': thumb, 'icon': thumb, 'poster': thumb})
        else:
            li.setArt({'icon': 'DefaultAddonVideo.png'})
        items.append(li)
    _tmdb_dump_tracked(tracked)
    # Sin bucle: PlayMedia es asíncrono y entra en la cola de builtins de Kodi,
    # que NO se procesa mientras haya un Dialog().select abierto. Por eso si
    # tras el click volvemos al menú principal de secciones, el vídeo "se
    # cuela" detrás y parece que hay que cancelar la ventana para que arranque.
    # Solución: tras lanzar PlayMedia devolvemos un sentinel 'play' para que
    # tmdb_extras_dialog rompa también su bucle principal y libere la cola.
    idx = xbmcgui.Dialog().select('Tráileres — {0}'.format(art_title), items, useDetails=True)
    if idx < 0:
        return None
    key = videos[idx].get('key') or ''
    if not key:
        return None
    if has_youtube:
        xbmcgui.Dialog().notification('TopZilla',
            'Cargando tráiler...', xbmcgui.NOTIFICATION_INFO, 2000)
        if yt_resolve.ytdlp_enabled():
            yt_resolve.play_async(key)
            return 'play'
        xbmc.executebuiltin(
            'PlayMedia(plugin://plugin.video.youtube/play/?video_id={0})'.format(key))
        return 'play'
    if xbmcgui.Dialog().yesno(
            'TopZilla',
            'El addon "YouTube" no está instalado.\n\n'
            'Instálalo para reproducir el tráiler.\n\nURL: https://youtu.be/{0}'.format(key),
            yeslabel="Instalar", nolabel="Cancelar"):
        xbmc.executebuiltin("InstallAddon(plugin.video.youtube)")
    return None


def _tmdb_show_production(prod):
    if not prod:
        return
    lines = []
    if prod.get('budget'):
        lines.append('[B]Presupuesto[/B]: {0}'.format(_tmdb_format_money(prod['budget'])))
    if prod.get('revenue'):
        lines.append('[B]Recaudación[/B]: {0}'.format(_tmdb_format_money(prod['revenue'])))
    if prod.get('runtime'):
        lines.append('[B]Duración[/B]: {0} min'.format(prod['runtime']))
    if prod.get('certification'):
        lines.append('[B]Calificación[/B]: {0}'.format(prod['certification']))
    if prod.get('companies'):
        lines.append('[B]Productoras[/B]: {0}'.format(', '.join(prod['companies'])))
    if prod.get('countries'):
        lines.append('[B]Países[/B]: {0}'.format(', '.join(prod['countries'])))
    if prod.get('languages'):
        lines.append('[B]Idiomas[/B]: {0}'.format(', '.join(prod['languages'])))
    if not lines:
        return
    xbmcgui.Dialog().textviewer('Datos de producción', '\n\n'.join(lines))


def _tmdb_show_keywords(keywords, media_type='movie', tracked=None):
    if not keywords:
        return
    # Tolera cache antigua (lista de str) y nueva (lista de {id, name}).
    names = [k['name'] if isinstance(k, dict) else str(k) for k in keywords]
    ids   = [k.get('id', '') if isinstance(k, dict) else '' for k in keywords]
    if not any(ids):
        xbmcgui.Dialog().textviewer('Palabras clave', ', '.join(names))
        return
    items = []
    for n in names:
        li = xbmcgui.ListItem(label='[B]{0}[/B]'.format(n))
        li.setArt({'icon': 'DefaultTags.png'})
        items.append(li)
    mt = 'show' if media_type == 'show' else 'movie'
    while True:
        idx = xbmcgui.Dialog().select('Palabras clave', items, useDetails=True)
        if idx < 0:
            return
        kid = ids[idx]
        if not kid:
            continue
        try:
            import metadata_enricher as me
            results = me.discover(mt, {'with_keywords': kid})
        except Exception as exc:
            xbmc.log('[TopZilla-TMDB] keyword discover: {0}'.format(exc), xbmc.LOGWARNING)
            results = []
        if not results:
            xbmcgui.Dialog().notification('TopZilla', 'Sin resultados para esa etiqueta',
                                           xbmcgui.NOTIFICATION_INFO, 2500)
            continue
        if _tmdb_show_similar(results, 'Tema: {0}'.format(names[idx]), mt, tracked or []) == 'drill':
            return 'drill'


def _tmdb_show_externals(ext):
    if not ext:
        return
    parts = []
    if ext.get('imdb_id'):
        parts.append('IMDb:       https://www.imdb.com/title/{0}/'.format(ext['imdb_id']))
    if ext.get('homepage'):
        parts.append('Web oficial: {0}'.format(ext['homepage']))
    if ext.get('twitter_id'):
        parts.append('Twitter:    https://twitter.com/{0}'.format(ext['twitter_id'].lstrip('@')))
    if ext.get('instagram_id'):
        parts.append('Instagram:  https://instagram.com/{0}'.format(ext['instagram_id'].lstrip('@')))
    if ext.get('facebook_id'):
        parts.append('Facebook:   https://facebook.com/{0}'.format(ext['facebook_id'].lstrip('/')))
    if not parts:
        return
    xbmcgui.Dialog().textviewer('Enlaces externos', '\n\n'.join(parts))


def _tmdb_build_sections(ex, media_type):
    """Construye los ListItems del menú principal, sólo las secciones con
    contenido. Devuelve lista de tuplas (section_id, ListItem)."""
    sections = []
    cast = ex.get('cast') or []
    if cast:
        li = xbmcgui.ListItem(
            label='[B]Reparto completo[/B]',
            label2='{0} actores'.format(len(cast)))
        first_thumb = next((c.get('thumb') for c in cast if c.get('thumb')), '')
        li.setArt({'icon': first_thumb or 'DefaultActor.png',
                   'thumb': first_thumb or 'DefaultActor.png'})
        sections.append(('cast', li))

    crew = ex.get('crew') or {}
    if any(crew.get(k) for k in ('director', 'writers', 'composer', 'cinematography', 'editor')):
        li = xbmcgui.ListItem(label='[B]Equipo técnico[/B]',
                               label2='Dirección, guion, música...')
        li.setArt({'icon': 'DefaultStudios.png'})
        sections.append(('crew', li))

    label_sim = 'Series similares' if media_type == 'show' else 'Películas similares'
    similar = ex.get('similar') or []
    if similar:
        li = xbmcgui.ListItem(label='[B]{0}[/B]'.format(label_sim),
                               label2='{0} resultados'.format(len(similar)))
        first = next((s.get('poster') for s in similar if s.get('poster')), '')
        li.setArt({'icon': first or 'DefaultVideo.png',
                   'thumb': first or 'DefaultVideo.png',
                   'poster': first or 'DefaultVideo.png'})
        sections.append(('similar', li))

    recs = ex.get('recommendations') or []
    if recs:
        li = xbmcgui.ListItem(label='[B]Recomendaciones[/B]',
                               label2='{0} resultados'.format(len(recs)))
        first = next((s.get('poster') for s in recs if s.get('poster')), '')
        li.setArt({'icon': first or 'DefaultVideo.png',
                   'thumb': first or 'DefaultVideo.png',
                   'poster': first or 'DefaultVideo.png'})
        sections.append(('recommendations', li))

    videos = ex.get('videos') or []
    if videos:
        li = xbmcgui.ListItem(label='[B]Tráileres[/B]',
                               label2='{0} vídeos'.format(len(videos)))
        li.setArt({'icon': 'DefaultAddonVideo.png'})
        sections.append(('videos', li))

    prod = ex.get('production') or {}
    if any(prod.get(k) for k in ('budget', 'revenue', 'runtime', 'certification',
                                   'companies', 'countries', 'languages')):
        li = xbmcgui.ListItem(label='[B]Datos de producción[/B]',
                               label2='Presupuesto, países, productoras...')
        li.setArt({'icon': 'DefaultIconInfo.png'})
        sections.append(('production', li))

    keywords = ex.get('keywords') or []
    if keywords:
        li = xbmcgui.ListItem(label='[B]Palabras clave[/B]',
                               label2='{0} etiquetas'.format(len(keywords)))
        li.setArt({'icon': 'DefaultTags.png'})
        sections.append(('keywords', li))

    ext = ex.get('externals') or {}
    if any(ext.get(k) for k in ('imdb_id', 'homepage', 'twitter_id',
                                 'instagram_id', 'facebook_id')):
        li = xbmcgui.ListItem(label='[B]Enlaces externos[/B]',
                               label2='IMDb, web oficial, redes...')
        li.setArt({'icon': 'DefaultNetwork.png'})
        sections.append(('externals', li))

    return sections


def tmdb_extras_dialog(query, media_type='movie'):
    """Flujo de diálogos puro (select+textviewer): no abre ningún contenedor,
    así que el llamante debe cerrar su endOfDirectory antes de invocar.
    """
    q = (query or '').strip()
    if not q:
        return

    tmdb_exit()

    dp = xbmcgui.DialogProgress()
    dp.create('TopZilla — TMDB', 'Identificando título...')
    dp.update(10)

    try:
        import metadata_enricher as me
    except Exception as exc:
        dp.close()
        xbmc.log('[TopZilla-TMDB] import: {0}'.format(exc), xbmc.LOGERROR)
        xbmcgui.Dialog().notification('TopZilla', 'metadata_enricher no disponible',
                                       xbmcgui.NOTIFICATION_ERROR, 3000)
        return

    try:
        meta = me.enrich(title=q, media_type=media_type)
    except Exception as exc:
        dp.close()
        xbmc.log('[TopZilla-TMDB] enrich: {0}'.format(exc), xbmc.LOGERROR)
        xbmcgui.Dialog().notification('TopZilla', 'Error al identificar en TMDB',
                                       xbmcgui.NOTIFICATION_ERROR, 3000)
        return

    if dp.iscanceled():
        dp.close()
        return

    tmdb_id = ''
    if isinstance(meta, dict):
        tmdb_id = str((meta.get('ids') or {}).get('tmdb', '') or '')
    if not tmdb_id:
        dp.close()
        xbmcgui.Dialog().notification('TopZilla',
            "'{0}' no se pudo identificar en TMDB".format(q),
            xbmcgui.NOTIFICATION_INFO, 3000)
        return

    art_title = (meta.get('title') if isinstance(meta, dict) else '') or q
    mt        = (meta.get('media_type') if isinstance(meta, dict) else '') or media_type or 'movie'

    extras = _tmdb_cache_get(tmdb_id)
    if not extras:
        dp.update(50, 'Cargando información extra...')
        try:
            extras = me.fetch_tmdb_extras(tmdb_id, mt)
        except Exception as exc:
            dp.close()
            xbmc.log('[TopZilla-TMDB] fetch: {0}'.format(exc), xbmc.LOGERROR)
            xbmcgui.Dialog().notification('TopZilla',
                'Error al cargar datos de TMDB',
                xbmcgui.NOTIFICATION_ERROR, 3000)
            return
        if not extras:
            dp.close()
            xbmcgui.Dialog().notification('TopZilla',
                'Sin datos extra disponibles',
                xbmcgui.NOTIFICATION_INFO, 3000)
            return
        _tmdb_cache_set(tmdb_id, extras)

    dp.close()

    sections = _tmdb_build_sections(extras, mt)
    if not sections:
        xbmcgui.Dialog().notification('TopZilla',
            'Sin información extra disponible',
            xbmcgui.NOTIFICATION_INFO, 3000)
        return

    tracked = []  # URLs que pasarán por setArt, para limpieza al salir.

    try:
        section_items = [li for (_sid, li) in sections]
        section_ids   = [sid for (sid, _li) in sections]
        for (_sid, li) in sections:
            for k in ('thumb', 'poster'):
                u = li.getArt(k) if hasattr(li, 'getArt') else ''
                _tmdb_track_url(tracked, u)
        _tmdb_dump_tracked(tracked)

        while True:
            idx = xbmcgui.Dialog().select(
                '{0}  [TMDB]'.format(art_title),
                section_items, useDetails=True)
            if idx is None or idx < 0:
                break
            sid = section_ids[idx]
            if sid == 'cast':
                if _tmdb_show_cast(extras.get('cast') or [], tracked) == 'drill':
                    return
            elif sid == 'crew':
                _tmdb_show_crew(extras.get('crew') or {})
            elif sid == 'similar':
                if _tmdb_show_similar(extras.get('similar') or [],
                                       'Películas similares' if mt != 'show' else 'Series similares',
                                       mt, tracked) == 'drill':
                    return
            elif sid == 'recommendations':
                if _tmdb_show_similar(extras.get('recommendations') or [],
                                       'Recomendaciones', mt, tracked) == 'drill':
                    return
            elif sid == 'videos':
                if _tmdb_show_videos(extras.get('videos') or [], art_title, tracked) == 'play':
                    return
            elif sid == 'production':
                _tmdb_show_production(extras.get('production') or {})
            elif sid == 'keywords':
                if _tmdb_show_keywords(extras.get('keywords') or [], mt, tracked) == 'drill':
                    return
            elif sid == 'externals':
                _tmdb_show_externals(extras.get('externals') or {})
    finally:
        tmdb_exit()


# Menú principal de búsqueda

def show_search_menu():
    h = _handle()
    history = _load_history()

    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR limegreen][B]Nueva búsqueda...[/B][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultAddonsSearch.png', 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Busca por título en todos los tops cargados: FilmAffinity, SensaCine, Cinemeta, TMDB y Top Históricas.\nNo requiere conexión a internet."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='search_query'),
                                 listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR red][B]Buscar en YouTube[/B][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultAddonsSearch.png', 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Busca directamente en YouTube. Requiere el addon YouTube instalado."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='search_youtube_prompt'),
                                 listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR cyan][B]Buscar en Dailymotion[/B][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultAddonsSearch.png', 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Busca directamente en Dailymotion. Resolución nativa con cascada de reproducción."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='search_dailymotion_prompt'),
                                 listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR deeppink][B]Buscar vídeos en todas las plataformas[/B][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultAddonsSearch.png', 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Busca a la vez en Dailymotion, YouTube, Odysee, PeerTube y BitChute. Resultados ordenados por relevancia."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='bt_search'),
                                 listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR deepskyblue][B]Buscar en Wikipedia[/B][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultAddonsSearch.png', 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Busca información e imágenes de películas y series en Wikipedia en español."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='search_wikipedia_prompt'),
                                 listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR yellow][B]Explorar caché[/B][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultMovieTitle.png', 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Filtra todo lo cacheado por género, director, año o puntuación. No hace llamadas de red."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='explore_cache_menu'),
                                 listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR violet][B]Buscar online por director[/B][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultDirector.png', 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Descubre películas de un director vía TMDB. Requiere conexión a internet."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='search_online_director'),
                                 listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR violet][B]Buscar online por género[/B][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultGenre.png', 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Descubre películas por género vía TMDB, ordenadas por popularidad. Requiere conexión a internet."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='search_online_genres'),
                                 listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR violet][B]Buscar online por año[/B][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultYear.png', 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Descubre películas y series estrenadas en un año concreto vía TMDB. Requiere conexión a internet."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='search_online_year'),
                                 listitem=li, isFolder=True)

    if history:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            "[COLOR orange][B]Búsquedas recientes ({0})[/B][/COLOR]".format(len(history)),
            bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': core_settings.addon_media('adv_busqueda.png'), 'fanart': core_settings.addon_fanart()})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action='search_history_menu'),
                                     listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


# Explorar caché: filtrar por género, director, año o puntuación

import os                              # noqa: E402
import threading                       # noqa: E402

_EXPLORE_CACHE_FILE = 'topzilla_explore_cache.json'
_EXPLORE_BUILD_LOCK = threading.Lock()

# topzilla_metadata.db queda FUERA a propósito: cambia con cada enriquecimiento
# individual y dispararía rebuilds en ráfaga. Sólo nos importa cuándo cambia
# el catálogo de títulos.
_EXPLORE_SOURCE_FILES = (
    'topzilla_fa_cache.json',
    'topzilla_sc_cache.json',
    'topzilla_cinemeta_cache.json',
    'topzilla_tmdb_lists_cache.json',
)

# (min_inclusive, max_exclusive, etiqueta, id)
_RATING_BANDS = (
    (9.0, 10.01, '9 – 10 ★ (Excelente)', '9'),
    (8.0, 9.0,   '8 – 9 ★ (Muy buena)',  '8'),
    (7.0, 8.0,   '7 – 8 ★ (Buena)',      '7'),
    (6.0, 7.0,   '6 – 7 ★ (Aceptable)',  '6'),
    (0.01, 6.0,  'Menor que 6 ★',        '0'),
)


def _explore_source_signature():
    parts = []
    try:
        import xbmcaddon, xbmcvfs
        profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    except Exception:
        return ''
    if not profile:
        return ''
    for name in _EXPLORE_SOURCE_FILES:
        p = os.path.join(profile, name)
        try:
            st = os.stat(p)
            parts.append('{0}:{1}:{2}'.format(name, int(st.st_mtime), st.st_size))
        except OSError:
            parts.append('{0}:0:0'.format(name))
    return '|'.join(parts)


def _explore_load_disk_cache():
    try:
        data = core_settings.load_json(_EXPLORE_CACHE_FILE, default=None)
    except Exception as e:
        xbmc.log('[TopZilla-Explore] disk load: {0}'.format(e), xbmc.LOGWARNING)
        return None, None
    if not isinstance(data, dict):
        return None, None
    sig = data.get('signature')
    groups = data.get('groups')
    if not isinstance(sig, str) or not isinstance(groups, list):
        return None, None
    return sig, groups


def _explore_save_disk_cache(signature, groups):
    # Escritura atómica: tmp + os.replace. Un crash a media escritura deja el
    # .tmp parcial pero el destino intacto.
    payload = {
        'signature': signature,
        'built_at':  int(time.time()),
        'groups':    groups,
    }
    try:
        import xbmcaddon, xbmcvfs
        profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    except Exception as e:
        xbmc.log('[TopZilla-Explore] disk save (profile): {0}'.format(e), xbmc.LOGWARNING)
        return
    final_path = os.path.join(profile, _EXPLORE_CACHE_FILE)
    tmp_path   = final_path + '.tmp'
    try:
        with open(tmp_path, 'w', encoding='utf-8') as fh:
            json.dump(payload, fh, ensure_ascii=False)
        os.replace(tmp_path, final_path)
    except (OSError, TypeError, ValueError) as e:
        xbmc.log('[TopZilla-Explore] disk save: {0}'.format(e), xbmc.LOGWARNING)
        try:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
        except OSError:
            pass


def _explore_group_raw_items():
    raw = _collect_all_items()
    groups = {}
    order  = []
    for item in raw:
        k = _norm_key(item['title'], item['media_type'])
        if k not in groups:
            groups[k] = {
                'title':      item['title'],
                'year':       item['year'],
                'poster':     item['poster'],
                'media_type': item['media_type'],
                'tmdb_id':    item['tmdb_id'],
                'imdb_id':    item['imdb_id'],
                'sources':    [item['source_label']],
            }
            order.append(k)
        else:
            g = groups[k]
            if not g['tmdb_id'] and item['tmdb_id']:
                g['tmdb_id'] = item['tmdb_id']
            if not g['imdb_id'] and item['imdb_id']:
                g['imdb_id'] = item['imdb_id']
            if not g['poster'] and item['poster']:
                g['poster'] = item['poster']
            if not g['year'] and item['year']:
                g['year'] = item['year']
            if item['source_label'] not in g['sources']:
                g['sources'].append(item['source_label'])
    return [groups[k] for k in order]


def _explore_build_groups(show_progress=True):
    grouped = _explore_group_raw_items()
    total = len(grouped)
    if total == 0:
        return []

    dp = None
    if show_progress:
        try:
            dp = xbmcgui.DialogProgressBG()
            dp.create('TopZilla', 'Indexando metadatos locales...')
            dp.update(5)
        except Exception:
            dp = None

    try:
        import metadata_enricher as me
    except Exception as e:
        xbmc.log('[TopZilla-Explore] enricher import: {0}'.format(e), xbmc.LOGERROR)
        me = None

    if me is not None:
        try:
            metas = me.batch_enrich(
                [{
                    'tmdb_id':    g.get('tmdb_id'),
                    'imdb_id':    g.get('imdb_id'),
                    'title':      g.get('title'),
                    'year':       g.get('year') or None,
                    'media_type': g.get('media_type', 'movie'),
                } for g in grouped],
                use_cache_only=True,
                max_workers=8,
            )
        except Exception as e:
            xbmc.log('[TopZilla-Explore] batch_enrich: {0}'.format(e), xbmc.LOGWARNING)
            metas = [{} for _ in grouped]
    else:
        metas = [{} for _ in grouped]

    if dp is not None:
        try:
            dp.update(80, 'TopZilla', 'Procesando {0} títulos...'.format(total))
        except Exception:
            pass

    for g, meta in zip(grouped, metas):
        meta = meta if isinstance(meta, dict) else {}
        g['genres']   = list(meta.get('genres') or [])
        g['director'] = (meta.get('director') or '').strip()
        try:
            g['rating'] = float(meta.get('rating') or 0)
        except (TypeError, ValueError):
            g['rating'] = 0.0
        if not g.get('year') and meta.get('year'):
            try:
                g['year'] = int(meta.get('year') or 0)
            except (TypeError, ValueError):
                pass
        if not g.get('poster') and meta.get('poster'):
            g['poster'] = meta.get('poster')

    if dp is not None:
        try:
            dp.close()
        except Exception:
            pass

    return grouped


def _explore_get_groups():
    current_sig = _explore_source_signature()

    sig, groups = _explore_load_disk_cache()
    if sig and sig == current_sig and isinstance(groups, list):
        return groups

    # Double-checked locking: otro hilo puede haber reconstruido mientras esperábamos.
    with _EXPLORE_BUILD_LOCK:
        sig, groups = _explore_load_disk_cache()
        if sig and sig == current_sig and isinstance(groups, list):
            return groups

        groups = _explore_build_groups(show_progress=True)
        try:
            _explore_save_disk_cache(current_sig, groups)
        except Exception as e:
            xbmc.log('[TopZilla-Explore] save: {0}'.format(e), xbmc.LOGWARNING)
        return groups


_EXPLORE_FIELDS = [
    ('genre',    'Género',     'limegreen',   'DefaultGenre.png'),
    ('director', 'Director',   'orange',      'DefaultDirector.png'),
    ('year',     'Año',        'deepskyblue', 'DefaultYear.png'),
    ('rating',   'Puntuación', 'gold',        core_settings.addon_media('cat_pelis_top.png')),
]


def show_explore_menu():
    h = _handle()
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()
    af     = core_settings.addon_fanart()

    for field_id, label, color, icon in _EXPLORE_FIELDS:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            "[COLOR {0}][B]Por {1}[/B][/COLOR]".format(color, label.lower()),
            bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': icon, 'fanart': af})
        li.setInfo('video', {'plot': 'Listar todo el contenido cacheado agrupado por {0}.'.format(label.lower())})
        xbmcplugin.addDirectoryItem(handle=h,
                                     url=_u(action='explore_cache_by', field=field_id),
                                     listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def show_explore_values(field):
    h = _handle()
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()
    af     = core_settings.addon_fanart()

    groups = _explore_get_groups()

    entries = []  # lista de tuplas (label_value, count, url_value)

    if field == 'genre':
        counter = {}
        for g in groups:
            for gen in g.get('genres') or []:
                if gen:
                    counter[gen] = counter.get(gen, 0) + 1
        for name in sorted(counter, key=lambda x: (-counter[x], x.lower())):
            entries.append((name, counter[name], name))

    elif field == 'director':
        counter = {}
        for g in groups:
            d = g.get('director') or ''
            # Si vienen varios separados por ", " (showrunners), repartimos.
            for one in [x.strip() for x in d.split(',') if x.strip()]:
                counter[one] = counter.get(one, 0) + 1
        for name in sorted(counter, key=lambda x: (-counter[x], x.lower())):
            entries.append((name, counter[name], name))

    elif field == 'year':
        # Agrupamos por década para no acabar con 80 entradas.
        counter = {}
        for g in groups:
            y = g.get('year') or 0
            if y and y >= 1900:
                dec = (y // 10) * 10
                counter[dec] = counter.get(dec, 0) + 1
        for dec in sorted(counter, reverse=True):
            entries.append(('{0}s'.format(dec), counter[dec], str(dec)))

    elif field == 'rating':
        counts = [0] * len(_RATING_BANDS)
        unrated = 0
        for g in groups:
            r = g.get('rating') or 0.0
            if r <= 0:
                unrated += 1
                continue
            for i, (lo, hi, _lbl, _bid) in enumerate(_RATING_BANDS):
                if lo <= r < hi:
                    counts[i] += 1
                    break
        for i, (_lo, _hi, lbl, bid) in enumerate(_RATING_BANDS):
            if counts[i]:
                entries.append((lbl, counts[i], bid))
        if unrated:
            entries.append(('Sin puntuación', unrated, 'none'))

    if not entries:
        li = xbmcgui.ListItem(label=core_settings.apply_label("[COLOR gray]Sin datos cacheados para este filtro[/COLOR]", bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': 'DefaultIconInfo.png', 'fanart': af})
        xbmcplugin.addDirectoryItem(handle=h, url='', listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
        return

    field_label = next((lbl for fid, lbl, _c, _i in _EXPLORE_FIELDS if fid == field), field)
    icon_default = next((ic for fid, _l, _c, ic in _EXPLORE_FIELDS if fid == field), 'DefaultFolder.png')

    for label_value, count, url_value in entries:
        base = "[B]{0}[/B] [COLOR gray]({1})[/COLOR]".format(label_value, count)
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            base, bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': icon_default, 'fanart': af})
        li.setInfo('video', {'plot': '{0} cacheado en "{1}": {2} título(s).'.format(
            field_label, label_value, count)})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='explore_cache_filter', field=field, value=url_value),
            listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def show_explore_results(field, value):
    """Renderiza los items que pasan el filtro (field, value)."""
    h = _handle()
    groups = _explore_get_groups()

    if field == 'genre':
        filtered = [g for g in groups if value in (g.get('genres') or [])]
        header   = 'Género: {0}'.format(value)
    elif field == 'director':
        filtered = []
        for g in groups:
            d = g.get('director') or ''
            directors = [x.strip() for x in d.split(',') if x.strip()]
            if value in directors:
                filtered.append(g)
        header = 'Director: {0}'.format(value)
    elif field == 'year':
        try:
            dec = int(value)
        except ValueError:
            dec = -1
        filtered = [g for g in groups
                    if (g.get('year') or 0) and ((g['year'] // 10) * 10) == dec]
        header = 'Década: {0}s'.format(dec) if dec > 0 else 'Década'
    elif field == 'rating':
        if value == 'none':
            filtered = [g for g in groups if not (g.get('rating') or 0)]
            header = 'Sin puntuación'
        else:
            match = next((b for b in _RATING_BANDS if b[3] == str(value)), None)
            if not match:
                filtered = []
                header = 'Puntuación'
            else:
                lo, hi, lbl, _bid = match
                filtered = [g for g in groups
                            if lo <= (g.get('rating') or 0.0) < hi]
                header = lbl
    else:
        filtered = []
        header = ''

    if not filtered:
        xbmcgui.Dialog().notification(
            "TopZilla", "Sin resultados para '{0}'".format(header),
            xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
        return

    # Orden por defecto:
    # - rating/year: por puntuación desc (más útiles)
    # - genre/director: por año desc (más reciente arriba)
    if field in ('rating',):
        filtered.sort(key=lambda g: (-(g.get('rating') or 0.0),
                                       -(g.get('year') or 0),
                                       (g.get('title') or '').lower()))
    elif field == 'year':
        filtered.sort(key=lambda g: (-(g.get('year') or 0),
                                       -(g.get('rating') or 0.0),
                                       (g.get('title') or '').lower()))
    else:
        filtered.sort(key=lambda g: (-(g.get('year') or 0),
                                       -(g.get('rating') or 0.0),
                                       (g.get('title') or '').lower()))

    import metadata_enricher as me
    import context_menu

    af     = core_settings.addon_fanart()
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()

    for g in filtered:
        title = g['title']
        year  = g['year']
        media = g['media_type']
        srcs  = ", ".join(g.get('sources') or [])

        base_label = "[B]{0}[/B]".format("{0} ({1})".format(title, year) if year else title)
        label = core_settings.apply_label(base_label, bold=_bold, strip=_strip, color_mode=_color)
        if srcs:
            label += " [COLOR gray][{0}][/COLOR]".format(srcs)

        li = xbmcgui.ListItem(label=label)

        meta = None
        try:
            meta = me.enrich(
                tmdb_id=g.get('tmdb_id'),
                imdb_id=g.get('imdb_id'),
                title=title, year=year or None,
                media_type=media, use_cache_only=True,
            )
        except Exception as e:
            xbmc.log("[TopZilla-Explore] enrich: {0}".format(e), xbmc.LOGWARNING)

        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or g.get('poster') or ''
        else:
            poster = g.get('poster') or ''
            art = {'fanart': af}
            if poster:
                art.update({'thumb': poster, 'poster': poster})
            else:
                art['icon'] = 'DefaultVideo.png'
            li.setArt(art)
            info = {
                'title': title,
                'mediatype': 'tvshow' if media == 'show' else 'movie',
            }
            if year:
                info['year'] = year
            li.setInfo('video', info)

        plot = meta.get('overview', '') if meta else ''
        ref = mr.make_ref(
            title=title, year=year,
            tmdb_id=g.get('tmdb_id'), imdb_id=g.get('imdb_id'),
            poster=poster, media_type=media, source='explore', plot=plot,
        )
        context_menu.attach(li, ref)
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=context_menu.build_play_url(ref),
            listitem=li, isFolder=False,
        )

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def show_history():
    h = _handle()
    history = _load_history()

    if not history:
        li = xbmcgui.ListItem(label=core_settings.apply_label("[COLOR gray]Sin búsquedas recientes[/COLOR]"))
        li.setArt({'icon': 'DefaultIconInfo.png', 'fanart': core_settings.addon_fanart()})
        xbmcplugin.addDirectoryItem(handle=h, url='', listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
        return

    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR red][B]Borrar todo el historial[/B][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultIconError.png', 'fanart': core_settings.addon_fanart()})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='search_history_clear'),
                                 listitem=li, isFolder=False)
    for entry in history:
        q = entry.get('query', '')
        ts = entry.get('ts', 0)
        date_str = time.strftime("%d/%m/%Y", time.localtime(ts)) if ts else ''
        base_label = "[B]{0}[/B]".format(q)
        label = "{0} [COLOR gray]({1})[/COLOR]".format(base_label, date_str) if date_str else base_label
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            label, bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': 'DefaultAddonsSearch.png', 'fanart': core_settings.addon_fanart()})
        li.addContextMenuItems([
            ("Borrar de historial",
             "RunPlugin({0})".format(_u(action='search_history_delete', q=q))),
        ])
        xbmcplugin.addDirectoryItem(handle=h,
                                     url=_u(action='search_query', q=q),
                                     listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def delete_history_entry(q):
    if not q:
        return
    _save_history([h for h in _load_history() if h.get('query') != q])
    xbmc.executebuiltin("Container.Refresh")


def clear_history():
    if not xbmcgui.Dialog().yesno("TopZilla", "¿Borrar todo el historial de búsquedas?"):
        return
    _save_history([])
    xbmc.executebuiltin("Container.Refresh")
