# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""
Script invocado por kodi.context.item desde otros addons.
Añade el elemento actual a la Watchlist ("Quiero ver") de TopZilla.
Mismo patrón de enrich en tres capas que context_add_topzilla.py.
"""
import re
import urllib.parse

import xbmc
import xbmcgui

import movie_ref

_PLUGIN_URL = 'plugin://plugin.video.topzilla/'
_KODI_TAGS = re.compile(r'\[/?(?:COLOR(?:\s[^\]]*)?|B|I|UPPERCASE|LOWERCASE|CAPITALIZE|LIGHT|CR)\]',
                         re.IGNORECASE)


def _strip_markup(text):
    return _KODI_TAGS.sub('', text or '').strip()


def _to_int(v):
    if v is None or v == '':
        return None
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def _is_default_art(url):
    if not url:
        return True
    name = url.rsplit('/', 1)[-1].rsplit('\\', 1)[-1]
    return name.startswith('Default') and name.lower().endswith('.png')


def _get_container_addon():
    folder = (xbmc.getInfoLabel('Container.FolderPath') or '').strip()
    if not folder.startswith('plugin://'):
        return ''
    host = folder[len('plugin://'):]
    addon_id = host.split('/')[0].split('?')[0]
    return addon_id if '.' in addon_id else ''


def _capture_meta():
    title = ''
    for key in ('ListItem.Label', 'ListItem.Title', 'ListItem.OriginalTitle'):
        t = _strip_markup(xbmc.getInfoLabel(key))
        if t:
            title = t
            break
    poster = ''
    for key in ('ListItem.Art(poster)', 'ListItem.Thumb', 'ListItem.Icon'):
        p = (xbmc.getInfoLabel(key) or '').strip()
        if p and not _is_default_art(p):
            poster = p
            break
    plot = _strip_markup(xbmc.getInfoLabel('ListItem.Plot'))
    if not plot:
        plot = _strip_markup(xbmc.getInfoLabel('ListItem.PlotOutline'))
    year = _to_int(xbmc.getInfoLabel('ListItem.Year'))
    dbtype = (xbmc.getInfoLabel('ListItem.DBTYPE') or '').strip().lower()
    media_type = 'show' if dbtype in ('tvshow', 'episode', 'season') else 'movie'
    imdb_id = (xbmc.getInfoLabel('ListItem.IMDBNumber') or '').strip()
    if not imdb_id.startswith('tt'):
        imdb_id = None
    tmdb_id = _to_int(xbmc.getInfoLabel('ListItem.UniqueID(tmdb)') or
                       xbmc.getInfoLabel('ListItem.Property(tmdb_id)'))
    return {'title': title, 'poster': poster, 'plot': plot, 'year': year,
            'media_type': media_type, 'imdb_id': imdb_id, 'tmdb_id': tmdb_id}


def _try_enrich(meta):
    try:
        import core_settings
        import metadata_enricher as me
        auto_fetch = core_settings._auto_fetch_enabled()
        result = me.enrich(
            tmdb_id=meta.get('tmdb_id'),
            imdb_id=meta.get('imdb_id'),
            title=meta.get('title'),
            year=meta.get('year') or None,
            media_type=meta.get('media_type', 'movie'),
            use_cache_only=not auto_fetch,
        )
        return result or {}
    except Exception:
        return {}


def _merge(meta, cached):
    if not cached:
        return meta
    out = dict(meta)
    cached_ids = cached.get('ids') or {}
    if not out.get('tmdb_id') and cached_ids.get('tmdb'):
        out['tmdb_id'] = _to_int(cached_ids['tmdb'])
    if not out.get('imdb_id') and cached_ids.get('imdb'):
        out['imdb_id'] = cached_ids['imdb']
    if not out.get('poster') and cached.get('poster'):
        out['poster'] = cached['poster']
    if not out.get('plot') and cached.get('overview'):
        out['plot'] = cached['overview']
    if not out.get('year') and cached.get('year'):
        out['year'] = _to_int(cached['year'])
    if cached.get('media_type'):
        out['media_type'] = cached['media_type']
    return out


def _run():
    addon_id = _get_container_addon()
    meta = _capture_meta()
    if not meta['title']:
        xbmcgui.Dialog().notification(
            'TopZilla', 'No se encontró un título en este elemento.',
            xbmcgui.NOTIFICATION_WARNING, 3000)
        return

    original_title = meta['title']
    import remote_input
    text = remote_input.get_text_input('Añadir a Quiero ver (TopZilla)', original_title).strip()
    if not text:
        return
    meta['title'] = text

    if text.strip().lower() != original_title.strip().lower():
        meta['tmdb_id'] = None
        meta['imdb_id'] = None
        meta['year'] = None

    enriched = _try_enrich(meta)
    final = _merge(meta, enriched)

    ref = movie_ref.make_ref(
        title=final['title'],
        year=final.get('year'),
        tmdb_id=final.get('tmdb_id'),
        imdb_id=final.get('imdb_id'),
        media_type=final.get('media_type', 'movie'),
        poster=final.get('poster') or '',
        plot=final.get('plot') or '',
        source=addon_id or 'context_external',
    )
    ref_enc = movie_ref.dumps_ref(ref)
    url = _PLUGIN_URL + '?' + urllib.parse.urlencode({'action': 'add_watchlist', 'ref': ref_enc})
    xbmc.executebuiltin('RunPlugin({0})'.format(url))


if __name__ == '__main__':
    _run()
