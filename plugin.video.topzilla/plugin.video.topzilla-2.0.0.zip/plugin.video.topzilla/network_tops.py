# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
"""Catálogos por cadena de TV y por estudio de cine, vía TMDB discover.

Mismo patrón que streaming_tops (caché TTL, grid mode, enriquecido perezoso,
paginación), pero filtrando por with_networks (series) y with_companies (películas).
IDs de TMDB verificados contra themoviedb.org en el lote de junio 2026.
"""
import json
import os
import sys
import threading
import time

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import context_menu
import core_settings
import movie_ref

_TMDB_BASE = "https://api.themoviedb.org/3"
_IMG_W342  = "https://image.tmdb.org/t/p/w342"
_IMG_ORIG  = "https://image.tmdb.org/t/p/original"
_TTL       = 24 * 3600
_LOG_TAG   = "[TopZilla-NT]"

# (label, kind, tmdb_id, media_type, icon). kind: 'network' (with_networks, series) /
# 'company' (with_companies, películas). IDs verificados en themoviedb.org.
_CATS = [
    ("Cadena · HBO",                'network', 49,    'show',  'net_hbo.png'),
    ("Cadena · Netflix",            'network', 213,   'show',  'net_netflix.png'),
    ("Cadena · Apple TV+",          'network', 2552,  'show',  'net_appletv.png'),
    ("Cadena · AMC",                'network', 174,   'show',  'net_amc.png'),
    ("Cadena · Disney+",            'network', 2739,  'show',  'net_disney.png'),
    ("Cadena · FX",                 'network', 88,    'show',  'net_fx.png'),
    ("Cadena · Hulu",               'network', 453,   'show',  'net_hulu.png'),
    ("Estudio · A24",               'company', 41077, 'movie', 'stu_a24.png'),
    ("Estudio · Marvel Studios",    'company', 420,   'movie', 'stu_marvel.png'),
    ("Estudio · Pixar",             'company', 3,     'movie', 'stu_pixar.png'),
    ("Estudio · Studio Ghibli",     'company', 10342, 'movie', 'stu_ghibli.png'),
    ("Estudio · DreamWorks Animation", 'company', 521, 'movie', 'stu_dreamworks.png'),
    ("Estudio · Universal Pictures", 'company', 33,   'movie', 'stu_universal.png'),
    ("Estudio · Blumhouse",         'company', 3172,  'movie', 'stu_blumhouse.png'),
]

_GENRE_NAMES = {
    28: 'Acción', 12: 'Aventura', 16: 'Animación', 35: 'Comedia', 80: 'Crimen',
    99: 'Documental', 18: 'Drama', 10751: 'Familia', 14: 'Fantasía', 36: 'Historia',
    27: 'Terror', 10402: 'Música', 9648: 'Misterio', 10749: 'Romance',
    878: 'Ciencia ficción', 53: 'Suspense', 10752: 'Bélica', 37: 'Western',
    10759: 'Acción y aventura', 10765: 'Ciencia ficción y fantasía',
}


def _u(**kwargs):
    return core_settings.make_url(**kwargs)


def _handle():
    return int(sys.argv[1])


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"{_LOG_TAG} {msg}", level)


def _cache_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(profile, 'topzilla_network_tops_cache.json')


def _load_cache():
    try:
        p = _cache_path()
        if not os.path.exists(p):
            return {}
        with open(p, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _save_cache(data):
    try:
        p = _cache_path()
        os.makedirs(os.path.dirname(p), exist_ok=True)
        tmp = f"{p}.{threading.get_ident()}.tmp"
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, p)
    except OSError as e:
        _log(f"cache save: {e}", xbmc.LOGWARNING)


def _genres_from_ids(ids):
    return ' / '.join([_GENRE_NAMES[i] for i in (ids or []) if i in _GENRE_NAMES][:3])


def _tmdb_get(path, params):
    api_key = core_settings.get_tmdb_api_key()
    if not api_key:
        return None
    try:
        r = requests.get(f"{_TMDB_BASE}/{path}", params=dict(params, api_key=api_key), timeout=10)
        if r.status_code != 200:
            return None
        return r.json()
    except (requests.RequestException, ValueError) as e:
        _log(f"error {path}: {e}", xbmc.LOGERROR)
        return None


def _fetch_list(kind, tmdb_id, media_type, page):
    cache = _load_cache()
    cache_key = f"{kind}|{tmdb_id}|{media_type}|{page}"
    entry = cache.get(cache_key, {})
    if entry.get('items') and (time.time() - entry.get('ts', 0)) < _TTL:
        return entry['items'], entry.get('total_pages', 1)

    endpoint = 'discover/tv' if media_type == 'show' else 'discover/movie'
    filt = 'with_networks' if kind == 'network' else 'with_companies'
    params = {
        'language': 'es-ES', 'sort_by': 'popularity.desc',
        filt: str(tmdb_id), 'page': page,
    }
    data = _tmdb_get(endpoint, params)
    if not data:
        stale = entry.get('items')
        return (stale, entry.get('total_pages', 1)) if stale else ([], 1)

    total_pages = min(data.get('total_pages', 1), 10)
    items = []
    for r in data.get('results') or []:
        if media_type == 'show':
            title, date = r.get('name') or r.get('original_name', ''), (r.get('first_air_date') or '')
        else:
            title, date = r.get('title') or r.get('original_title', ''), (r.get('release_date') or '')
        if not title:
            continue
        pp, bp = r.get('poster_path') or '', r.get('backdrop_path') or ''
        items.append({
            'tmdb_id': str(r.get('id', '')), 'title': title, 'year': date[:4],
            'overview': r.get('overview', ''), 'rating': r.get('vote_average', 0),
            'genre': _genres_from_ids(r.get('genre_ids') or []),
            'poster': f"{_IMG_W342}{pp}" if pp else '',
            'fanart': f"{_IMG_ORIG}{bp}" if bp else '',
            'media_type': media_type,
        })

    if items:
        cache[cache_key] = {'ts': time.time(), 'items': items, 'total_pages': total_pages}
        _save_cache(cache)
    return items, total_pages


def show_menu():
    h = _handle()
    bold, strip, color = (core_settings.get_acc_force_bold(),
                          core_settings.get_acc_strip_symbols(), core_settings.get_acc_color_mode())
    af = core_settings.addon_fanart()
    for label, kind, tmdb_id, media_type, icon in _CATS:
        li = xbmcgui.ListItem(label=core_settings.apply_label(label, bold=bold, strip=strip, color_mode=color))
        li.setArt({'icon': core_settings.addon_media(icon), 'fanart': af})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='network_tops_list', kind=kind, tmdb_id=tmdb_id, media_type=media_type, page=1),
            listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def _trigger_bg_enrich(items):
    import metadata_enricher as me

    def _fetch():
        try:
            if any(me.batch_enrich(items, max_workers=2)):
                xbmc.executebuiltin("Container.Refresh")
        except Exception as e:
            _log(f"bg enrich: {e}", xbmc.LOGWARNING)

    threading.Thread(target=_fetch, daemon=True).start()


def show_list(kind, tmdb_id, media_type, page=1):
    import pelis_grid as _pg
    canon_mt = 'show' if media_type in ('tv', 'show') else 'movie'
    tipo = 'Series' if canon_mt == 'show' else 'Películas'
    if _pg.apply_grid_mode(_handle(), 'network', f'Catálogo · {tipo}',
                           kind=kind, tmdb_id=tmdb_id, media_type=media_type):
        return

    import metadata_enricher as me
    h = _handle()
    page = int(page)
    items, total_pages = _fetch_list(kind, tmdb_id, canon_mt, page)
    if not items:
        xbmcgui.Dialog().notification("TopZilla", "No se pudo cargar el catálogo", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(h)
        return

    af = core_settings.addon_fanart()
    bold, strip, color = (core_settings.get_acc_force_bold(),
                          core_settings.get_acc_strip_symbols(), core_settings.get_acc_color_mode())
    kodi_mt = 'tvshow' if canon_mt == 'show' else 'movie'
    missing = []

    for item in items:
        year_int = int(item['year']) if item.get('year', '').isdigit() else 0
        label = f"{item['title']} ({year_int})" if year_int else item['title']
        li = xbmcgui.ListItem(label=core_settings.apply_label(label, bold=bold, strip=strip, color_mode=color))

        meta = me.enrich(tmdb_id=item['tmdb_id'], title=item['title'],
                         year=year_int or None, media_type=canon_mt, use_cache_only=True)
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
        else:
            art = {'icon': 'DefaultVideo.png', 'fanart': item.get('fanart') or af}
            if item['poster']:
                art.update({'thumb': item['poster'], 'poster': item['poster']})
            li.setArt(art)
            info = {'title': item['title'], 'plot': item.get('overview', ''), 'mediatype': kodi_mt}
            if year_int:
                info['year'] = year_int
            if item.get('rating'):
                info['rating'] = item['rating']
            if item.get('genre'):
                info['genre'] = item['genre']
            li.setInfo('video', info)
            missing.append({'tmdb_id': item.get('tmdb_id'), 'imdb_id': '', 'title': item['title'],
                            'year': year_int or None, 'media_type': canon_mt})

        ref = movie_ref.make_ref(title=item['title'], year=year_int or None,
                                 tmdb_id=item['tmdb_id'], poster=item['poster'],
                                 media_type=canon_mt, source='network', plot=item.get('overview', ''))
        context_menu.attach(li, ref)
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(handle=h, url=context_menu.build_play_url(ref), listitem=li, isFolder=False)

    if missing:
        _trigger_bg_enrich(missing)

    if page < total_pages:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            f"[COLOR limegreen]Página siguiente ({page + 1}/{total_pages})[/COLOR]",
            bold=bold, strip=strip, color_mode=color))
        li.setArt({'icon': 'DefaultFolder.png', 'fanart': af})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='network_tops_list', kind=kind, tmdb_id=tmdb_id, media_type=media_type, page=page + 1),
            listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h, cacheToDisc=core_settings.remember_list_position())
