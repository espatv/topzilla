# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""Portapapeles interno persistente durante la sesion Kodi (Window 10000 prop).

set() tambien propaga al portapapeles del SO cuando es posible, asi el texto
copiado desde un item se puede pegar en cualquier sitio (otros addons, apps
externas), no solo dentro de TopZilla.

Setting `clipboard_sync_to_os` (bool, default true) controla el sync.
"""
import re

import xbmc
import xbmcaddon
import xbmcgui


PROPERTY_NAME = 'topzilla.clipboard'
WIN_HOME = 10000
SETTING_SYNC_TO_OS = 'clipboard_sync_to_os'

_CTRL_CHARS_RE = re.compile(r'[\x00-\x08\x0b-\x1f\x7f]')


def sanitize(text):
    """Limpia chars que rompen Input.SendText (control chars, saltos de linea)."""
    if not text:
        return ''
    cleaned = _CTRL_CHARS_RE.sub(
        '',
        text.replace('\r', ' ').replace('\n', ' ').replace('\t', ' '),
    )
    return cleaned.strip()


def get():
    raw = xbmcgui.Window(WIN_HOME).getProperty(PROPERTY_NAME) or ''
    return sanitize(raw)


def _sync_to_os_enabled():
    try:
        return xbmcaddon.Addon().getSettingBool(SETTING_SYNC_TO_OS)
    except RuntimeError:
        # Pre-init o setting ausente: default true conservador.
        return True


def set(text):
    clean = sanitize(text)
    xbmcgui.Window(WIN_HOME).setProperty(PROPERTY_NAME, clean)
    # Propagar al portapapeles del SO si esta activado. Catch ancho justificado:
    # handler de I/O del SO, no debe tumbar el flujo principal si falla en
    # Android sin JNI, Linux sin xclip, etc.
    if clean and _sync_to_os_enabled():
        try:
            import os_clipboard
            os_clipboard.set_system_clipboard(clean)
        except Exception as e:
            xbmc.log(f'[TopZilla] clipboard: sync_to_os fallo: {e}', xbmc.LOGDEBUG)


def clear():
    xbmcgui.Window(WIN_HOME).clearProperty(PROPERTY_NAME)
