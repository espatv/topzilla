# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""Letterboxd: listas curadas de películas para descubrimiento."""
import html as _html
import json
import os
import re
import ssl
import sys
import threading
import time

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import context_menu
import core_settings
import movie_ref

_TTL     = 24 * 3600
_LOG_TAG = "[TopZilla-LB]"

_LISTS = [
    ("Letterboxd Top 500",     "https://letterboxd.com/official/list/letterboxds-top-500-films/",            'top_letterboxd.png'),
    ("IMDb Top 250",           "https://letterboxd.com/dave/list/imdb-top-250/",                             'top_imdb.png'),
    ("1001 películas que ver", "https://letterboxd.com/peterstanley/list/1001-movies-you-must-see-before-you-die/", 'top_1001.png'),
]

_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "es-ES,es;q=0.9",
    "Referer": "https://letterboxd.com/",
}


class _Tls13Adapter(requests.adapters.HTTPAdapter):
    # Cloudflare reta el fingerprint TLS 1.2 del Python de Kodi con un 403; con
    # TLS 1.3 el handshake pasa. Mismo bloqueo de capa TLS que FilmAffinity.
    def init_poolmanager(self, *args, **kwargs):
        ctx = ssl.create_default_context()
        ctx.minimum_version = ssl.TLSVersion.TLSv1_3
        kwargs["ssl_context"] = ctx
        return super().init_poolmanager(*args, **kwargs)


def _lb_get(url, timeout=15):
    with requests.Session() as s:
        s.mount("https://", _Tls13Adapter())
        return s.get(url, headers=_HEADERS, timeout=timeout)


def _u(**kwargs):
    return core_settings.make_url(**kwargs)


def _handle():
    return int(sys.argv[1])


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"{_LOG_TAG} {msg}", level)


def _cache_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(profile, 'topzilla_letterboxd_cache.json')


def _load_cache():
    try:
        p = _cache_path()
        if not os.path.exists(p):
            return {}
        with open(p, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _save_cache(data):
    try:
        p = _cache_path()
        os.makedirs(os.path.dirname(p), exist_ok=True)
        # tmp por hilo: dos escrituras concurrentes con el mismo .tmp corromperían el JSON.
        tmp = f"{p}.{threading.get_ident()}.tmp"
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, p)
    except OSError as e:
        _log(f"cache save: {e}", xbmc.LOGWARNING)


def _parse_list_html(html_text):
    """Extrae pares {title, year} de una página de lista de Letterboxd.

    Cada película es un poster con data-item-name="Título (AAAA)".
    """
    films = []
    seen = set()
    for raw in re.findall(r'data-item-name="([^"]+)"', html_text):
        name = _html.unescape(raw).strip()
        m = re.match(r'^(.*?)\s*\((\d{4})\)\s*$', name)
        if m:
            title, year = m.group(1).strip(), m.group(2)
        else:
            title, year = name, ''

        key = title.lower()
        if title and key not in seen:
            seen.add(key)
            films.append({'title': title, 'year': year})

    return films


def _fetch_list(list_key, list_url):
    cache = _load_cache()
    entry = cache.get(list_key, {})
    if entry and (time.time() - entry.get('ts', 0)) < _TTL:
        return entry['films']

    films = []
    try:
        r = _lb_get(list_url)
        _log(f"list fetch {list_url[:60]} -> {r.status_code}")
        if r.status_code == 200:
            films = _parse_list_html(r.text)
        else:
            _log(f"list HTTP {r.status_code}", xbmc.LOGWARNING)
    except (requests.RequestException, ValueError) as e:
        _log(f"list request error: {e}", xbmc.LOGERROR)

    if films:
        cache[list_key] = {'ts': time.time(), 'films': films}
        _save_cache(cache)
    elif entry.get('films'):
        _log(f"usando caché caducada para '{list_key}'", xbmc.LOGWARNING)
        return entry['films']

    return films


def _media_icon(name, fallback='DefaultVideo.png'):
    p = os.path.join(
        xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path')),
        'resources', 'media', name,
    )
    return p if os.path.exists(p) else fallback


def show_menu():
    h = _handle()
    bold  = core_settings.get_acc_force_bold()
    strip = core_settings.get_acc_strip_symbols()
    color = core_settings.get_acc_color_mode()
    for label, url, icon in _LISTS:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            label, bold=bold, strip=strip, color_mode=color))
        li.setArt({'icon': _media_icon(icon),
                   'fanart': core_settings.addon_fanart()})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='letterboxd_list', list_key=label, list_url=url),
            listitem=li,
            isFolder=True,
        )
    xbmcplugin.endOfDirectory(h)


def _trigger_bg_enrich(items):
    import metadata_enricher as me

    def _fetch():
        try:
            results = me.batch_enrich(items, max_workers=2)
            if any(results):
                xbmc.executebuiltin("Container.Refresh")
        except Exception as e:  # hilo daemon: un fallo solo debe loguearse, no propagar
            _log(f"bg enrich: {e}", xbmc.LOGWARNING)

    threading.Thread(target=_fetch, daemon=True).start()


def show_list(list_key, list_url):
    import metadata_enricher as me

    h = _handle()
    films = _fetch_list(list_key, list_url)
    if not films:
        xbmcgui.Dialog().notification(
            "TopZilla",
            "No se pudo cargar la lista de Letterboxd",
            xbmcgui.NOTIFICATION_ERROR,
        )
        xbmcplugin.endOfDirectory(h)
        return

    af    = core_settings.addon_fanart()
    bold  = core_settings.get_acc_force_bold()
    strip = core_settings.get_acc_strip_symbols()
    color = core_settings.get_acc_color_mode()

    enrich_items = [
        {'title': f['title'], 'year': int(f['year']) if f.get('year', '').isdigit() else None,
         'media_type': 'movie'}
        for f in films
    ]
    metas = me.batch_enrich(enrich_items, use_cache_only=True)

    if any(metas):
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            "[COLOR red][B]Borrar metadatos de esta lista[/B][/COLOR]", bold=bold, strip=strip, color_mode=color))
        li.setArt({'icon': _media_icon('adv_borrar.png'), 'fanart': af})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='letterboxd_clear_meta', list_key=list_key, list_url=list_url),
            listitem=li,
            isFolder=False,
        )
    else:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            "[COLOR yellow][B]Descargar metadatos completos (actores, director...)[/B][/COLOR]",
            bold=bold, strip=strip, color_mode=color))
        li.setArt({'icon': _media_icon('adv_cache.png'), 'fanart': af})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='letterboxd_cache_meta', list_key=list_key, list_url=list_url),
            listitem=li,
            isFolder=False,
        )

    missing = []
    for f, meta, item in zip(films, metas, enrich_items):
        year_int = int(f['year']) if f.get('year', '').isdigit() else 0
        label = f"{f['title']} ({year_int})" if year_int else f['title']
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            label, bold=bold, strip=strip, color_mode=color))

        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or ''
        else:
            li.setArt({'icon': 'DefaultVideo.png', 'fanart': af})
            li.setInfo('video', {'title': f['title'], 'year': year_int, 'mediatype': 'movie'})
            poster = ''
            missing.append(item)

        tmdb_id = (meta.get('ids') or {}).get('tmdb', '') if meta else ''
        ref = movie_ref.make_ref(
            title=f['title'], year=year_int or None,
            tmdb_id=tmdb_id, imdb_id='',
            poster=poster, media_type='movie', source='letterboxd',
            plot=meta.get('overview', '') if meta else '',
        )
        context_menu.attach(li, ref)
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(
            handle=h, url=context_menu.build_play_url(ref), listitem=li, isFolder=False)

    if missing:
        _trigger_bg_enrich(missing)

    xbmcplugin.endOfDirectory(h, cacheToDisc=core_settings.remember_list_position())


def clear_list_meta(list_key, list_url):
    import metadata_enricher as me

    films = _fetch_list(list_key, list_url)
    items = [
        {'title': f['title'],
         'year': int(f['year']) if f.get('year', '').isdigit() else None,
         'media_type': 'movie'}
        for f in films
    ]
    me.delete_items(items)
    xbmcgui.Dialog().notification("TopZilla", "Metadatos de lista eliminados", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


def cache_list_meta(list_key, list_url):
    import metadata_enricher as me

    films = _fetch_list(list_key, list_url)
    if not films:
        xbmcgui.Dialog().notification("TopZilla", "No hay películas para descargar", xbmcgui.NOTIFICATION_ERROR)
        return

    items = [
        {'title': f['title'],
         'year': int(f['year']) if f.get('year', '').isdigit() else None,
         'media_type': 'movie'}
        for f in films
    ]
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("TopZilla", "Descargando metadatos Letterboxd...")
    try:
        count = me.batch_fetch_with_progress(items, pDialog)
    finally:
        pDialog.close()

    xbmcgui.Dialog().notification(
        "TopZilla", f"Metadatos guardados: {count}/{len(items)}", xbmcgui.NOTIFICATION_INFO,
    )
    xbmc.executebuiltin("Container.Refresh")
