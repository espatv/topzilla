# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
# Licencia: Consulta el archivo LICENSE.
"""Gestor de almacenamiento. Audita y limpia las cachés del addon.

Muestra cuánto ocupa el addon por tipo de dato (cachés de listas, metadatos
SQLite, snapshots/backups) y permite limpiar selectivamente (por categoría) o
todo, siempre con confirmación. Los datos del usuario (favoritos, historial,
categorías, atajos, sesión de Trakt, ajustes) NUNCA se tocan: solo se limpia
lo que se puede regenerar.

Seguridad: borra exclusivamente ficheros dentro del profile dir del addon
(special://profile/addon_data/plugin.video.topzilla), con rutas absolutas
validadas contra ese directorio. Para la base SQLite de metadatos delega en
metadata_enricher (clear/VACUUM), nunca borra el .db a mano.
"""

import os
import re
import sys
import shutil

import xbmc
import xbmcgui
import xbmcplugin

import core_settings

_LOG     = "[TopZilla-STORAGE]"
_PROFILE = core_settings.profile_dir()
_MEDIA   = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")

_META_DB = "topzilla_metadata.db"


def _icon(name, fallback="DefaultIconInfo.png"):
    p = os.path.join(_MEDIA, name)
    return p if os.path.isfile(p) else fallback


# Registro de cachés borrables.
# Cada entrada: clave, label, [archivos], [carpetas], [regex_dinamicos].
# Solo aparece en el menú lo que pesa > 0 bytes.

_CACHES = [
    ("meta_scrapers", "Metadatos de cine (Cinemeta / FA / SensaCine / TMDb)",
     ["topzilla_cinemeta_cache.json", "topzilla_fa_cache.json",
      "topzilla_sc_cache.json", "topzilla_tmdb_lists_cache.json"], [], []),
    ("trakt_tops", "Trakt — tops y descubrimiento",
     ["topzilla_trakt_tops_cache.json", "topzilla_trakt_discovery_cache.json"], [], []),
    ("trakt_thumbs", "Trakt — miniaturas de listas", [], [], [r"^trakt_thumbs_\d+\.json$"]),
    ("trakt_meta", "Trakt — metadatos descargados",
     ["trakt_meta_items.json", "trakt_meta_downloaded.flag"], [], []),
    ("streaming_tops", "Tops de plataformas de streaming",
     ["topzilla_streaming_tops_cache.json"], [], []),
    ("anime", "Tops de anime (AniList / MAL)", ["topzilla_anime_cache.json"], [], []),
    ("mdblist", "MDbList", ["topzilla_mdblist_cache.json"], [], []),
    ("letterboxd", "Letterboxd", ["topzilla_letterboxd_cache.json"], [], []),
    ("flix", "Modo Cine", ["topzilla_flix_cache.json"], [], []),
    ("archive", "Archive.org", ["topzilla_archive_cache.json"], [], []),
    ("omdb", "OMDb (notas IMDb / RT)", ["topzilla_omdb_cache.json"], [], []),
    ("wikipedia", "Wikipedia", ["topzilla_wikipedia_cache.json"], [], []),
    ("explore", "Explorar / filtros", ["topzilla_explore_cache.json"], [], []),
    ("yt_search", "Búsquedas de YouTube (caché)", ["topzilla_yt_search_cache.json"], [], []),
    ("on_air", "Calendario de emisión de series", ["topzilla_on_air_calendar.json"], [], []),
    ("covers", "Carátulas (Tops / Óscars)",
     ["topzilla_top_movies_thumbs.json", "topzilla_oscar_movies_thumbs.json"], [], []),
]

# Snapshots/backups generados por el addon. Son del usuario en cierto sentido
# (los crea él desde Backup), por eso van aparte con su propia confirmación y
# NO entran en 'Borrar TODAS las cachés'.
_BACKUPS_DIR = "backups"

# Datos del usuario (protegidos): se muestran como informativos, jamás se borran
# desde aquí. Coherente con _delete_metadata_db / _factory_reset de default.py.
_USER_DATA = [
    ("Biblioteca enriquecida (metadatos TMDB)", [_META_DB], []),
    ("Favoritos / Historiales",
     ["favorites.json", "watch_history.json", "navigation_history.json",
      "search_history.json"], []),
    ("Categorías personalizadas", ["custom_categories.json"], []),
    ("Atajos y orden de '¿Dónde buscar?'",
     ["search_shortcuts.json", "search_menu_order.json"], []),
    ("Trakt — sesión, listas y orden",
     ["trakt_settings.json", "trakt_lists_order.json", "trakt_auth.json"], []),
    ("Configuración (MDbList / MAL)",
     ["mdblist_settings.json", "mal_settings.json"], []),
    ("Preferencias del menú y Modo Cine",
     ["menu_layout.json", "trailer_config.json", "flix_rows_config.json",
      "flix_lazy_state.json", "flix_remember_pos_state.json"], []),
]

# Archivos protegidos contra borrado (cinturón y tirantes sobre la whitelist de
# _CACHES). Se derivan de _USER_DATA para que no se puedan desincronizar al añadir
# un fichero de usuario, más los que nunca se tocan aunque no salgan como sección.
_PROTECTED = {
    _META_DB, _META_DB + "-wal", _META_DB + "-shm", _META_DB + "-journal",
    "settings.xml",
    "welcome_state.json", "stats.json", "shortcut_first_use.json",
    "topzilla_acc_settings.json",
    "egg_count.txt", "tz.jpg", "ed.jpg",
}
for _label, _files, _dirs in _USER_DATA:
    _PROTECTED.update(_files)
    _PROTECTED.update(_dirs)


# Utilidades

def _path(name):
    return os.path.join(_PROFILE, name)


def _within_profile(path):
    """True si `path` está realmente dentro del profile dir del addon.

    Defensa contra rutas con .. o symlinks: nunca borramos fuera de addon_data.
    """
    try:
        base = os.path.realpath(_PROFILE)
        target = os.path.realpath(path)
    except OSError:
        return False
    return target == base or target.startswith(base + os.sep)


def _size_of(path):
    if not os.path.exists(path):
        return 0
    if os.path.isdir(path):
        total = 0
        for root, _, files in os.walk(path):
            for f in files:
                try:
                    total += os.path.getsize(os.path.join(root, f))
                except OSError:
                    pass
        return total
    try:
        return os.path.getsize(path)
    except OSError:
        return 0


def _delete_path(path):
    """Borra un archivo o carpeta dentro del profile. Devuelve los bytes liberados."""
    name = os.path.basename(path)
    if not _within_profile(path):
        xbmc.log(f"{_LOG} BLOQUEADO borrado fuera del addon_data: {path}", xbmc.LOGWARNING)
        return 0
    if name in _PROTECTED:
        xbmc.log(f"{_LOG} BLOQUEADO borrado de archivo protegido: {name}", xbmc.LOGWARNING)
        return 0
    sz = _size_of(path)
    try:
        if os.path.isdir(path):
            shutil.rmtree(path, ignore_errors=True)
            return sz if not os.path.exists(path) else 0
        if os.path.exists(path):
            os.remove(path)
            return sz
    except OSError as e:
        xbmc.log(f"{_LOG} Error borrando {path}: {e}", xbmc.LOGWARNING)
    return 0


def fmt_size(b):
    if b < 1024:
        return f"{b} B"
    if b < 1024 * 1024:
        return f"{b / 1024:.1f} KB"
    if b < 1024 * 1024 * 1024:
        return f"{b / 1024 / 1024:.2f} MB"
    return f"{b / 1024 / 1024 / 1024:.2f} GB"


def _u(**k):
    return core_settings.make_url(**k)


# Cálculo de uso de disco

def _list_profile():
    try:
        return os.listdir(_PROFILE)
    except OSError:
        return []


def _resolver_paths(files, dirs, regex_list, profile_entries):
    """Devuelve la lista de rutas existentes para una entrada de caché."""
    rutas = []
    for f in files:
        p = _path(f)
        if os.path.exists(p):
            rutas.append(p)
    for d in dirs:
        p = _path(d)
        if os.path.exists(p):
            rutas.append(p)
    if regex_list:
        compiled = [re.compile(rx) for rx in regex_list]
        for entry in profile_entries:
            if any(c.match(entry) for c in compiled):
                rutas.append(_path(entry))
    return rutas


def auditar_cache():
    """[(key, label, bytes, rutas), ...] solo categorías con bytes > 0."""
    entries = _list_profile()
    out = []
    for key, label, files, dirs, regex_list in _CACHES:
        rutas = _resolver_paths(files, dirs, regex_list, entries)
        total = sum(_size_of(p) for p in rutas)
        if total > 0:
            out.append((key, label, total, rutas))
    return out


def auditar_user_data():
    """[(label, bytes), ...] de las categorías de datos del usuario con bytes > 0."""
    out = []
    for label, files, dirs in _USER_DATA:
        total = sum(_size_of(_path(f)) for f in files)
        total += sum(_size_of(_path(d)) for d in dirs)
        if total > 0:
            out.append((label, total))
    return out


def _backups_size():
    return _size_of(_path(_BACKUPS_DIR))


def _metadata_size():
    """Tamaño total de la BD SQLite incluyendo sidecars WAL/SHM."""
    return sum(_size_of(_path(_META_DB + sfx)) for sfx in ("", "-wal", "-shm"))


# Acciones de borrado

def _borrar_rutas(rutas):
    return sum(_delete_path(p) for p in rutas)


def purgar_todas():
    """Borra todas las cachés conocidas (_CACHES) sin diálogos. Devuelve bytes liberados.

    Whitelist pura: nunca toca config, datos del usuario, backups ni la BD de
    metadatos. Pensada para reutilizarse desde un limpiador rápido si hiciera falta.
    """
    entries = _list_profile()
    return sum(
        _borrar_rutas(_resolver_paths(files, dirs, regex_list, entries))
        for _key, _label, files, dirs, regex_list in _CACHES
    )


def borrar_categoria(key):
    """Borra una categoría concreta tras confirmación del usuario."""
    entry = next((c for c in _CACHES if c[0] == key), None)
    if entry is None:
        return
    _, label, files, dirs, regex_list = entry
    rutas = _resolver_paths(files, dirs, regex_list, _list_profile())
    total = sum(_size_of(p) for p in rutas)

    if total == 0:
        xbmcgui.Dialog().notification("TopZilla", "Esta caché ya está vacía",
                                      xbmcgui.NOTIFICATION_INFO, 2000)
        return

    if not xbmcgui.Dialog().yesno(
        "Borrar caché",
        f"{label}\n\nSe liberarán [B]{fmt_size(total)}[/B].\n\n"
        "Los datos se volverán a descargar la próxima vez que abras esta sección.",
    ):
        return

    liberado = _borrar_rutas(rutas)
    xbmcgui.Dialog().notification("TopZilla", f"Liberados {fmt_size(liberado)}",
                                  xbmcgui.NOTIFICATION_INFO, 3000)
    xbmc.executebuiltin("Container.Refresh")


def borrar_todas():
    """Borra TODAS las cachés conocidas tras confirmación."""
    audit = auditar_cache()
    total = sum(b for _, _, b, _ in audit)

    if total == 0:
        xbmcgui.Dialog().notification("TopZilla", "No hay cachés que borrar",
                                      xbmcgui.NOTIFICATION_INFO, 2000)
        return

    if not xbmcgui.Dialog().yesno(
        "Borrar TODAS las cachés",
        f"Se borrarán todas las cachés del addon ([B]{fmt_size(total)}[/B] en total).\n\n"
        "[COLOR lightgreen]Tus favoritos, historiales, categorías, atajos, sesión de "
        "Trakt y la biblioteca de metadatos NO se tocan.[/COLOR]\n\n"
        "¿Continuar?",
    ):
        return

    liberado = purgar_todas()
    xbmcgui.Dialog().notification("TopZilla", f"Liberados {fmt_size(liberado)}",
                                  xbmcgui.NOTIFICATION_INFO, 3500)
    xbmc.executebuiltin("Container.Refresh")


def borrar_backups():
    """Borra los backups generados por el addon tras confirmación."""
    total = _backups_size()
    if total == 0:
        xbmcgui.Dialog().notification("TopZilla", "No hay backups guardados",
                                      xbmcgui.NOTIFICATION_INFO, 2000)
        return

    if not xbmcgui.Dialog().yesno(
        "Borrar backups",
        f"Se borrarán todos los backups guardados en el addon ([B]{fmt_size(total)}[/B]).\n\n"
        "[COLOR orange]Son copias de seguridad de tus datos que creaste tú. "
        "Una vez borradas no se pueden recuperar.[/COLOR]\n\n¿Continuar?",
    ):
        return

    liberado = _delete_path(_path(_BACKUPS_DIR))
    xbmcgui.Dialog().notification("TopZilla", f"Liberados {fmt_size(liberado)}",
                                  xbmcgui.NOTIFICATION_INFO, 3000)
    xbmc.executebuiltin("Container.Refresh")


def borrar_metadata():
    """Vacía la biblioteca de metadatos (topzilla_metadata.db) tras confirmación.

    Caso especial fuera de _CACHES: rehidratarla cuesta muchas llamadas a TMDB,
    así que 'Borrar TODAS' no la toca. Delega en metadata_enricher.prune_and_vacuum()
    (purga caducados + VACUUM); no se borra el .db a mano para no dejar sidecars
    WAL/SHM ni romper conexiones abiertas.
    """
    antes = _metadata_size()
    if antes == 0:
        xbmcgui.Dialog().notification("TopZilla", "La biblioteca ya está vacía",
                                      xbmcgui.NOTIFICATION_INFO, 2000)
        return

    if not xbmcgui.Dialog().yesno(
        "Compactar biblioteca de metadatos",
        f"Se purgarán los metadatos de TMDB caducados y se compactará la base de "
        f"datos ([B]{fmt_size(antes)}[/B] ocupados ahora).\n\n"
        "[COLOR orange]Se reconstruye sola con el uso; la primera vez que ojees "
        "cada lista volverá a pedir a TMDB (irá algo más lento ese rato).[/COLOR]\n\n"
        "¿Continuar?",
    ):
        return

    import metadata_enricher
    prog = xbmcgui.DialogProgressBG()
    prog.create("TopZilla", "Compactando biblioteca de metadatos...")
    try:
        _deleted, freed = metadata_enricher.prune_and_vacuum()
    finally:
        prog.close()

    xbmcgui.Dialog().notification("TopZilla", f"Liberados {fmt_size(freed)}",
                                  xbmcgui.NOTIFICATION_INFO, 3000)
    xbmc.executebuiltin("Container.Refresh")


# Menú

_USER_DATA_PLOT_DEFAULT = (
    "Esta categoría contiene datos personales y NO se borra desde el gestor de "
    "almacenamiento.\nPara borrarlos, ve a la sección correspondiente del addon."
)

_USER_DATA_PLOTS = {
    "Biblioteca enriquecida (metadatos TMDB)":
        "Caché unificada de metadatos de TMDB (topzilla_metadata.db) compartida por "
        "todas las listas del addon.\n\n"
        "No se borra con 'Borrar TODAS' porque rehidratarla cuesta muchas llamadas "
        "a TMDB. Si necesitas el espacio, usa el botón naranja 'Compactar biblioteca "
        "de metadatos' de más abajo.",
    "Favoritos / Historiales":
        "Tus favoritos y los historiales de visionado, navegación y búsqueda.\n\n"
        "No se borra desde aquí. Límpialo desde la sección correspondiente del addon.",
    "Trakt — sesión, listas y orden":
        "Tu sesión de Trakt, las listas importadas y su orden.\n\n"
        "No se borra desde aquí. Gestiónalo desde la sección de Trakt.",
}


def _user_data_plot(label):
    return _USER_DATA_PLOTS.get(label, _USER_DATA_PLOT_DEFAULT)


def _add_item(h, label, url, plot=None, icon="DefaultIconInfo.png", folder=False):
    li = xbmcgui.ListItem(label=core_settings.apply_label(label))
    li.setArt({"icon": icon, "fanart": core_settings.addon_fanart()})
    if plot:
        li.setInfo("video", {"plot": plot})
    li.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=url or "", listitem=li, isFolder=folder)


def info_almacenamiento():
    """Diálogo de texto que explica qué se borra y qué no."""
    sep = "─" * 44
    lines = [
        "GESTOR DE ALMACENAMIENTO",
        sep,
        "",
        "El addon guarda dos tipos de información:",
        "",
        "  1) CACHÉS — datos descargados de internet que",
        "     se pueden volver a bajar (tops, metadatos de",
        "     listas, miniaturas, etc.).",
        "",
        "  2) DATOS DEL USUARIO — favoritos, historiales,",
        "     categorías, atajos, sesión de Trakt, ajustes",
        "     y la biblioteca de metadatos. Solo existen aquí.",
        "",
        sep,
        "QUÉ SE PUEDE BORRAR DESDE AQUÍ",
        sep,
        "",
        "Solo las cachés del grupo (1) y, aparte, los backups",
        "que hayas creado tú. Al volver a abrir cada sección,",
        "las cachés se descargan otra vez. No pierdes nada.",
        "",
        sep,
        "QUÉ NO SE TOCA NUNCA",
        sep,
        "",
        "  • Favoritos e historiales",
        "  • Categorías personalizadas",
        "  • Atajos de '¿Dónde buscar?'",
        "  • Sesión y listas de Trakt / MDbList / MAL",
        "  • Ajustes (accesibilidad, claves API, menú)",
        "",
        "La biblioteca de metadatos no se borra: se compacta",
        "con su propio botón (purga caducados + VACUUM).",
        "",
        sep,
        "SEGURIDAD",
        sep,
        "",
        "El gestor solo borra ficheros dentro de la carpeta",
        "del addon (addon_data/plugin.video.topzilla).",
        "Nunca toca nada fuera de ahí.",
    ]
    xbmcgui.Dialog().textviewer("Gestor de almacenamiento — ayuda", "\n".join(lines))


def menu_almacenamiento():
    """Submenú principal: muestra el uso por categoría y permite borrar."""
    h = int(sys.argv[1])

    cache = sorted(auditar_cache(), key=lambda x: -x[2])
    user  = sorted(auditar_user_data(), key=lambda x: -x[1])

    total_cache  = sum(b for _, _, b, _ in cache)
    total_user   = sum(b for _, b in user)
    backups_size = _backups_size()
    total_all    = total_cache + total_user + backups_size

    icon_cache  = _icon("adv_cache.png")
    icon_borrar = _icon("adv_limpieza.png")

    _add_item(
        h,
        f"[B][COLOR aqua]Uso del addon: {fmt_size(total_all)}[/COLOR][/B]    "
        f"[COLOR grey]({fmt_size(total_cache)} en cachés)[/COLOR]",
        url="",
        plot="Resumen del espacio que ocupa el addon en este dispositivo.\n"
             "El menú muestra solo lo borrable. Tus datos personales aparecen al "
             "final pero no se pueden borrar desde aquí.",
        icon=icon_cache,
    )

    if cache:
        _add_item(h, "[COLOR yellow]── CACHÉS (se pueden borrar sin perder datos) ──[/COLOR]", url="")
        for key, label, b, _rutas in cache:
            _add_item(
                h,
                f"  {label}    [COLOR grey]{fmt_size(b)}[/COLOR]",
                url=_u(action="storage_clear_category", key=key),
                plot=f"Pulsa para borrar esta caché ({fmt_size(b)}).\n\n"
                     "Los datos se volverán a descargar la próxima vez que abras "
                     "la sección correspondiente.",
                icon=icon_cache,
            )
        _add_item(
            h,
            f"[B][COLOR red][ Borrar TODAS las cachés ({fmt_size(total_cache)}) ][/COLOR][/B]",
            url=_u(action="storage_clear_all"),
            plot="Borra todas las cachés del addon. Tus datos personales y la "
                 "biblioteca de metadatos NO se tocan.",
            icon=icon_borrar,
        )
    else:
        _add_item(h, "[COLOR lightgreen]No hay cachés que borrar[/COLOR]", url="")

    meta_size = _metadata_size()
    if meta_size > 0:
        _add_item(
            h,
            f"[COLOR orange]Compactar biblioteca de metadatos ({fmt_size(meta_size)})[/COLOR]",
            url=_u(action="storage_clear_metadata"),
            plot="Purga los metadatos de TMDB caducados y compacta la base de datos "
                 "(topzilla_metadata.db) para liberar espacio.\n\n"
                 "Se reconstruye sola con el uso.",
            icon=icon_borrar,
        )

    if backups_size > 0:
        _add_item(
            h,
            f"[COLOR orange]Borrar backups guardados ({fmt_size(backups_size)})[/COLOR]",
            url=_u(action="storage_clear_backups"),
            plot="Borra las copias de seguridad que creaste desde la sección de "
                 "Backup.\n\n[COLOR orange]No se pueden recuperar una vez borradas.[/COLOR]",
            icon=icon_borrar,
        )

    if user:
        _add_item(h, "[COLOR yellow]── DATOS DEL USUARIO (no se borran desde aquí) ──[/COLOR]", url="")
        for label, b in user:
            _add_item(
                h,
                f"  {label}    [COLOR grey]{fmt_size(b)}[/COLOR]",
                url="",
                plot=_user_data_plot(label),
            )

    _add_item(
        h,
        "[COLOR grey]¿Qué se borra y qué no?[/COLOR]",
        url=_u(action="storage_info"),
        plot="Explica qué cachés se pueden borrar y qué datos del usuario nunca se tocan.",
        icon=_icon("adv_limpieza.png"),
    )

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)
