# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""Escritura en Trakt: scrobble de vistas y espejo de watchlist.

Opt-in y best-effort. Solo actúa si el usuario activó la sincronización de
escritura (ajuste trakt_write_sync, OFF por defecto) Y tiene cuenta vinculada.
Cualquier fallo de red/Trakt se loguea y se ignora: nunca rompe la operación
local (marcar visto / añadir favorito) que lo dispara.

History solo para películas: Trakt registra el historial a nivel episodio, así
que añadir una serie entera marcaría todos sus episodios como vistos (efecto
desproporcionado). Las series sí se reflejan en la watchlist (es a nivel título).
"""
import time

import xbmc

import core_settings
import trakt_auth

_LOG = "[TopZilla-TS]"


def _enabled():
    return (core_settings.get_trakt_write_sync()
            and trakt_auth.has_credentials()
            and trakt_auth.is_authorized())


def _ids(ref):
    """{'tmdb': int, 'imdb': str} con las claves que existan en el ref."""
    ids = {}
    try:
        tmdb = int(ref.get('tmdb_id'))
    except (TypeError, ValueError):
        tmdb = 0
    if tmdb:
        ids['tmdb'] = tmdb
    imdb = (ref.get('imdb_id') or '').strip()
    if imdb:
        ids['imdb'] = imdb
    return ids


def _bucket(ref):
    return 'shows' if ref.get('media_type') == 'show' else 'movies'


def _post(path, body):
    try:
        r = trakt_auth.authed_post(path, body)
    except Exception as e:  # red/Trakt: best-effort, no propagar al flujo local
        xbmc.log(f"{_LOG} {path}: {e}", xbmc.LOGWARNING)
        return False
    ok = r is not None and r.status_code in (200, 201)
    if not ok and r is not None:
        xbmc.log(f"{_LOG} {path} -> {r.status_code}", xbmc.LOGWARNING)
    return ok


def mark_watched(ref):
    """Marca la película como vista en el historial de Trakt. No-op para series.
    Si el envío falla (red caída), encola para reintentar al arrancar Kodi."""
    if not ref or not _enabled() or ref.get('media_type') == 'show':
        return False
    ids = _ids(ref)
    if not ids:
        return False
    watched_at = time.strftime('%Y-%m-%dT%H:%M:%S.000Z', time.gmtime())
    body = {'movies': [{'watched_at': watched_at, 'ids': ids}]}
    if _post('sync/history', body):
        return True
    _queue_pending('sync/history', body)
    return False


_PENDING_FILE = 'trakt_pending.json'
_PENDING_CAP = 200


def _queue_pending(path, body):
    """Guarda un envío fallido para reintentarlo más tarde. Cap FIFO."""
    try:
        q = core_settings.load_json(_PENDING_FILE, default=[])
        if not isinstance(q, list):
            q = []
        q.append({'path': path, 'body': body})
        if len(q) > _PENDING_CAP:
            q = q[-_PENDING_CAP:]
        core_settings.save_json(_PENDING_FILE, q)
    except Exception as e:
        xbmc.log(f"{_LOG} queue: {e}", xbmc.LOGWARNING)


def flush_pending():
    """Reintenta los envíos encolados. Solo si hay sesión Trakt. Conserva los que
    sigan fallando, descarta los corruptos. Llamado al arrancar Kodi (service.py)."""
    if not _enabled():
        return
    try:
        q = core_settings.load_json(_PENDING_FILE, default=[])
    except Exception:
        return
    if not isinstance(q, list) or not q:
        return
    remaining = []
    for item in q:
        if not isinstance(item, dict) or 'path' not in item or 'body' not in item:
            continue  # entrada corrupta: descartar
        if not _post(item['path'], item['body']):
            remaining.append(item)  # sigue fallando: conservar para el próximo arranque
    try:
        core_settings.save_json(_PENDING_FILE, remaining)
    except Exception as e:
        xbmc.log(f"{_LOG} flush save: {e}", xbmc.LOGWARNING)


def read_enabled():
    """La LECTURA (pull de vistos) solo necesita sesión vinculada, no el opt-in de
    escritura: el ✔ del catálogo debe verse aunque trakt_write_sync esté OFF."""
    return trakt_auth.has_credentials() and trakt_auth.is_authorized()


def _fetch_watched(path, container):
    """Lista de {'tmdb': int|None, 'imdb': str|None} de lo visto en Trakt.
    [] si no hay sesión, falla la red o la respuesta no es 200. Nunca lanza."""
    if not read_enabled():
        return []
    try:
        r = trakt_auth.authed_get(path)
    except Exception as e:  # red/Trakt: best-effort
        xbmc.log(f"{_LOG} {path}: {e}", xbmc.LOGWARNING)
        return []
    if r is None or getattr(r, 'status_code', 0) != 200:
        return []
    try:
        data = r.json()
    except Exception:
        return []
    if not isinstance(data, list):  # estos endpoints devuelven array; defensa
        return []
    out = []
    for entry in data:
        if not isinstance(entry, dict):
            continue
        ids = (entry.get(container) or {}).get('ids') or {}
        tmdb, imdb = ids.get('tmdb'), ids.get('imdb')
        if tmdb or imdb:
            out.append({'tmdb': tmdb, 'imdb': imdb})
    return out


def fetch_watched_movies():
    return _fetch_watched('sync/watched/movies', 'movie')


def fetch_watched_shows():
    return _fetch_watched('sync/watched/shows', 'show')


def add_watchlist(ref):
    if not ref or not _enabled():
        return False
    ids = _ids(ref)
    if not ids:
        return False
    return _post('sync/watchlist', {_bucket(ref): [{'ids': ids}]})


def remove_watchlist(ref):
    if not ref or not _enabled():
        return False
    ids = _ids(ref)
    if not ids:
        return False
    return _post('sync/watchlist/remove', {_bucket(ref): [{'ids': ids}]})
