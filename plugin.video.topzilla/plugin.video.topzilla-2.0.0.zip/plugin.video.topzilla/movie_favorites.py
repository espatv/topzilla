# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""Adaptador de favoritos para el Modo Cine/Grid.

Expone la API que esperan pelis_flix/pelis_grid (get/is/toggle/remove por
media_type) PERO respaldada por el almacén único de favoritos de topzilla
(favorites.json vía favorites.py). Así la fila "Mis Favoritos" del Modo Cine y
el menú contextual global de Kodi comparten los mismos favoritos.

MovieRef no guarda rating/género/director/reparto/runtime/fanart, así que
get_movie_favorites los rellena desde la caché de metadatos (sin red); lo que no
esté en caché se completa luego con el enriquecido en segundo plano del Modo Cine.
"""
import time

import xbmc

import favorites
import movie_ref


def _mirror_watchlist(method, ref):
    """Espejo opt-in a la watchlist de Trakt; nunca debe romper el toggle local."""
    try:
        import trakt_sync
        getattr(trakt_sync, method)(ref)
    except Exception as e:
        xbmc.log(f"[TopZilla] watchlist {method}: {e}", xbmc.LOGWARNING)


def _ref_from(m, media_type):
    """Construye un MovieRef a partir de un dict de película del grid/cine."""
    return movie_ref.make_ref(
        title=m.get('title', ''),
        year=m.get('year') or None,
        tmdb_id=m.get('tmdb_id') or None,
        imdb_id=m.get('imdb_id') or None,
        poster=m.get('poster', ''),
        media_type=media_type,
        source=m.get('source') or 'fav',
        plot=m.get('plot') or m.get('overview') or '',
    )


def is_movie_favorited(m, media_type='movie'):
    return favorites.is_favorite(movie_ref.ref_key(_ref_from(m, media_type)))


def toggle_movie_favorite(m, media_type='movie'):
    """Añade o quita el favorito sin notificación ni Container.Refresh (el Modo
    Cine recarga su fila volátil). Devuelve True si quedó añadido, False si quitado."""
    ref = _ref_from(m, media_type)
    key = movie_ref.ref_key(ref)
    refs = favorites._load()
    if any(movie_ref.ref_key(r) == key for r in refs):
        favorites._save(movie_ref.remove_by_key(refs, key))
        _mirror_watchlist('remove_watchlist', ref)
        return False
    ref = dict(ref)
    ref['added_at'] = int(time.time())
    refs.insert(0, ref)
    favorites._save(refs)
    _mirror_watchlist('add_watchlist', ref)
    return True


def remove_movie_favorite(m, media_type='movie'):
    ref = _ref_from(m, media_type)
    favorites._save(movie_ref.remove_by_key(favorites._load(), movie_ref.ref_key(ref)))
    _mirror_watchlist('remove_watchlist', ref)


def get_movie_favorites(media_type='movie'):
    """Favoritos del tipo pedido, enriquecidos desde la caché de metadatos (sin red).
    Devuelve dicts con los campos que consume el Modo Cine/Grid."""
    import metadata_enricher as me

    out = []
    for r in favorites._load():
        if r.get('media_type', 'movie') != media_type:
            continue
        rec = {
            'title':      r.get('title', ''),
            'year':       r.get('year') or '',
            'poster':     r.get('poster', ''),
            'fanart':     '',
            'rating':     0,
            'genre':      '',
            'director':   '',
            'cast_str':   '',
            'plot':       r.get('plot') or '',
            'runtime':    0,
            'imdb_id':    r.get('imdb_id') or '',
            'tmdb_id':    str(r.get('tmdb_id') or ''),
            'media_type': media_type,
        }
        meta = me.enrich(
            tmdb_id=r.get('tmdb_id'), imdb_id=r.get('imdb_id'),
            title=r.get('title'), year=r.get('year') or None,
            media_type=media_type, use_cache_only=True,
        )
        if meta:
            genres = meta.get('genres') or []
            cast = meta.get('cast') or []
            rec['poster']   = meta.get('poster') or rec['poster']
            rec['fanart']   = meta.get('fanart') or ''
            rec['rating']   = meta.get('rating') or 0
            rec['genre']    = ' / '.join(genres[:2]) if genres else ''
            rec['director'] = meta.get('director') or ''
            rec['cast_str'] = ', '.join(
                c.get('name', '') if isinstance(c, dict) else str(c) for c in cast[:3])
            rec['plot']     = meta.get('overview') or rec['plot']
            rec['runtime']  = meta.get('runtime') or 0
            rec['tmdb_id']  = str((meta.get('ids') or {}).get('tmdb') or rec['tmdb_id'])
        out.append(rec)
    return out
