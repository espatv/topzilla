# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""Login OAuth de la cuenta personal del usuario en Trakt.tv (device-code flow).

Maneja la obtención, almacenamiento y refresco del token, y expone authed_get()
para llamadas autenticadas a api.trakt.tv. La UI de menús vive en trakt_personal.py.

El token se guarda en trakt_auth.json del perfil del addon (escritura atómica vía
core_settings.save_json). NO contiene la peli/serie del usuario, solo las claves de
sesión OAuth; aun así es dato sensible y nunca se loguea su contenido.
"""
import threading
import time

import requests
import xbmc
import xbmcgui

import core_settings
import qr_dialog

_TRAKT_BASE = "https://api.trakt.tv"
_TOKEN_FILE = "trakt_auth.json"
_OOB_REDIRECT = "urn:ietf:wg:oauth:2.0:oob"
_LOG_TAG = "[TopZilla-TA]"

# Refrescamos si el token caduca en menos de esto. Trakt da tokens de varios
# meses, pero refrescar con margen evita un 401 a mitad de navegación.
_REFRESH_MARGIN_S = 24 * 3600

# Serializa el refresh del token: el Modo Cine lanza llamadas en hilos paralelos, así
# que un GET (p.ej. "Continuar viendo") y un POST (scrobble) pueden caducar el token a la
# vez. Sin esto, ambos refrescarían y, como Trakt rota el refresh_token, el segundo
# fallaría. El lock + double-check dentro de _refresh evita el doble refresh.
_refresh_lock = threading.Lock()


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"{_LOG_TAG} {msg}", level)


def _client_id():
    return (core_settings.get_trakt_user_key() or '').strip()


def _client_secret():
    # get_trakt_client_secret la añade el integrador en core_settings (ver reporte).
    # getattr defensivo: si aún no existe, el flujo cae al onboarding sin reventar.
    fn = getattr(core_settings, 'get_trakt_client_secret', None)
    if not callable(fn):
        return ''
    try:
        return (fn() or '').strip()
    except Exception as e:
        _log(f"client_secret lookup: {e}", xbmc.LOGWARNING)
        return ''


def has_credentials():
    """True si el usuario ha configurado Client ID y Client Secret propios.
    El device-flow OAuth los exige ambos; sin secret no se puede autenticar."""
    return bool(_client_id() and _client_secret())


def _load_token():
    data = core_settings.load_json(_TOKEN_FILE, default={})
    return data if isinstance(data, dict) else {}


def _save_token(data):
    return core_settings.save_json(_TOKEN_FILE, data)


def is_authorized():
    return bool(_load_token().get('access_token'))


def sign_out():
    """Borra el token local. No revoca en Trakt (innecesario: el usuario puede
    revocar la app desde trakt.tv si quiere)."""
    return _save_token({})


def _post(path, body, timeout=12):
    """POST JSON sin auth a oauth/*. Devuelve el objeto Response o None si la red falla."""
    try:
        return requests.post(f"{_TRAKT_BASE}/{path}",
                             json=body,
                             headers={'Content-Type': 'application/json'},
                             timeout=timeout)
    except requests.RequestException as e:
        _log(f"POST {path}: {e}", xbmc.LOGWARNING)
        return None


def _request_device_code():
    r = _post('oauth/device/code', {'client_id': _client_id()})
    if r is None or r.status_code != 200:
        if r is not None:
            _log(f"device/code -> {r.status_code}", xbmc.LOGWARNING)
        return None
    try:
        return r.json()
    except ValueError:
        return None


def _poll_token(device_code):
    """Intercambia el device_code por un token. Devuelve (token_dict, status):
    status 'ok' | 'pending' | 'slow_down' | 'stop'."""
    r = _post('oauth/device/token', {
        'code': device_code,
        'client_id': _client_id(),
        'client_secret': _client_secret(),
    })
    if r is None:
        return None, 'pending'  # red caída transitoria: seguir intentando
    code = r.status_code
    if code == 200:
        try:
            return r.json(), 'ok'
        except ValueError:
            return None, 'stop'
    if code == 400:
        return None, 'pending'      # el usuario aún no ha autorizado
    if code == 429:
        return None, 'slow_down'    # rate limit: esperar más
    # 404 device_code inválido / 409 ya aprobado / 410 expirado / 418 denegado
    _log(f"device/token -> {code} (parar)", xbmc.LOGWARNING)
    return None, 'stop'


def _store_token(tok):
    created = int(tok.get('created_at') or time.time())
    expires_in = int(tok.get('expires_in') or 0)
    _save_token({
        'access_token':  tok.get('access_token', ''),
        'refresh_token': tok.get('refresh_token', ''),
        'expires_at':    created + expires_in,
    })


def authorize():
    """Lanza el device-code flow con QR del verification_url + user_code visible y
    polling cancelable. Devuelve True si el usuario autorizó correctamente."""
    if not has_credentials():
        return False

    code_data = _request_device_code()
    if not code_data or not code_data.get('device_code'):
        xbmcgui.Dialog().notification(
            "TopZilla", "No se pudo iniciar el login de Trakt",
            xbmcgui.NOTIFICATION_ERROR)
        return False

    device_code = code_data['device_code']
    user_code = code_data.get('user_code', '')
    verify_url = code_data.get('verification_url', 'https://trakt.tv/activate')
    interval = max(int(code_data.get('interval') or 5), 1)
    expires_in = int(code_data.get('expires_in') or 600)

    # QR del verification_url para escanear con el móvil; el código a teclear se
    # muestra en el título del QR y luego en el diálogo de progreso.
    qr_dialog.show(f"Escanea y entra en Trakt — Código: {user_code}", verify_url)

    pd = xbmcgui.DialogProgress()
    pd.create("TopZilla — Conectar Trakt",
              f"Entra en [B]{verify_url}[/B]\n"
              f"e introduce el código:  [B][COLOR yellow]{user_code}[/COLOR][/B]")
    deadline = time.time() + expires_in
    try:
        while time.time() < deadline:
            if pd.iscanceled():
                return False
            remaining = int(deadline - time.time())
            pct = int(100 * (1 - remaining / max(expires_in, 1)))
            pd.update(pct,
                      f"Entra en [B]{verify_url}[/B]\n"
                      f"Código:  [B][COLOR yellow]{user_code}[/COLOR][/B]\n"
                      f"Esperando autorización… ({remaining}s)")

            tok, status = _poll_token(device_code)
            if status == 'ok' and tok and tok.get('access_token'):
                _store_token(tok)
                xbmcgui.Dialog().notification(
                    "TopZilla", "Cuenta de Trakt conectada",
                    xbmcgui.NOTIFICATION_INFO)
                return True
            if status == 'stop':
                xbmcgui.Dialog().notification(
                    "TopZilla", "Login cancelado o caducado",
                    xbmcgui.NOTIFICATION_ERROR)
                return False
            if status == 'slow_down':
                interval += 1

            # iscanceled() no se cubre durante un sleep largo: trocear el wait.
            waited = 0
            while waited < interval:
                if pd.iscanceled():
                    return False
                xbmc.sleep(1000)
                waited += 1
    finally:
        pd.close()

    xbmcgui.Dialog().notification(
        "TopZilla", "El código de login expiró", xbmcgui.NOTIFICATION_ERROR)
    return False


def _refresh(refresh_token):
    """Canjea el refresh_token por un token nuevo. Devuelve True si tuvo éxito.

    Serializado: si al entrar al lock otro hilo ya refrescó (el refresh_token guardado
    cambió porque Trakt lo rota), no repetimos el canje; el token actual ya es válido."""
    with _refresh_lock:
        stored = _load_token().get('refresh_token', '')
        if stored and stored != refresh_token:
            return True
        r = _post('oauth/token', {
            'refresh_token': refresh_token,
            'client_id':     _client_id(),
            'client_secret': _client_secret(),
            'redirect_uri':  _OOB_REDIRECT,
            'grant_type':    'refresh_token',
        })
        if r is None or r.status_code != 200:
            if r is not None:
                _log(f"refresh -> {r.status_code}", xbmc.LOGWARNING)
            return False
        try:
            tok = r.json()
        except ValueError:
            return False
        if not tok.get('access_token'):
            return False
        _store_token(tok)
        return True


def get_access_token():
    """Devuelve un access_token válido (refrescando si caduca pronto) o '' si no hay
    sesión o el refresh falla."""
    tok = _load_token()
    access = tok.get('access_token', '')
    if not access:
        return ''
    expires_at = tok.get('expires_at') or 0
    if expires_at and (expires_at - time.time()) < _REFRESH_MARGIN_S:
        refresh = tok.get('refresh_token', '')
        if refresh and _refresh(refresh):
            return _load_token().get('access_token', '')
        if not refresh:
            return access  # sin refresh_token, usamos el actual hasta que falle
    return access


def _auth_headers(access_token):
    return {
        'Content-Type':      'application/json',
        'Authorization':     f'Bearer {access_token}',
        'trakt-api-version': '2',
        'trakt-api-key':     _client_id(),
    }


def authed_get(path, params=None):
    """GET autenticado a api.trakt.tv. Devuelve el Response (status_code/json()) o None
    si no hay sesión o la red falla. Ante 401 intenta un refresh y reintenta una vez."""
    access = get_access_token()
    if not access:
        return None
    url = f"{_TRAKT_BASE}/{path}"
    try:
        r = requests.get(url, params=params, headers=_auth_headers(access), timeout=15)
    except requests.RequestException as e:
        _log(f"authed_get {path}: {e}", xbmc.LOGWARNING)
        return None

    if r.status_code == 401:
        refresh = _load_token().get('refresh_token', '')
        if refresh and _refresh(refresh):
            access = _load_token().get('access_token', '')
            try:
                r = requests.get(url, params=params, headers=_auth_headers(access), timeout=15)
            except requests.RequestException as e:
                _log(f"authed_get retry {path}: {e}", xbmc.LOGWARNING)
                return None
        else:
            _log(f"authed_get {path}: 401 y refresh falló, sesión inválida", xbmc.LOGWARNING)
            sign_out()
            return r
    return r


def authed_post(path, body):
    """POST JSON autenticado a api.trakt.tv (escritura: sync/history, watchlist…).
    Mismo manejo de 401 que authed_get: refresca y reintenta una vez. Devuelve el
    Response o None si no hay sesión o la red falla."""
    access = get_access_token()
    if not access:
        return None
    url = f"{_TRAKT_BASE}/{path}"
    try:
        r = requests.post(url, json=body, headers=_auth_headers(access), timeout=15)
    except requests.RequestException as e:
        _log(f"authed_post {path}: {e}", xbmc.LOGWARNING)
        return None

    if r.status_code == 401:
        refresh = _load_token().get('refresh_token', '')
        if refresh and _refresh(refresh):
            access = _load_token().get('access_token', '')
            try:
                r = requests.post(url, json=body, headers=_auth_headers(access), timeout=15)
            except requests.RequestException as e:
                _log(f"authed_post retry {path}: {e}", xbmc.LOGWARNING)
                return None
        else:
            _log(f"authed_post {path}: 401 y refresh falló, sesión inválida", xbmc.LOGWARNING)
            sign_out()
            return r
    return r
