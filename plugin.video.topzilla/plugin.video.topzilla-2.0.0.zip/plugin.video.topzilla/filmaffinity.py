# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
import sys
import re
import html
import json
import os
import ssl
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
import requests
import core_settings

_TMDB_IMG = "https://image.tmdb.org/t/p/w342"

_TMDB_GENRE_NAMES = {
    28: "Acción", 12: "Aventura", 16: "Animación", 35: "Comedia", 80: "Crimen",
    99: "Documental", 18: "Drama", 10751: "Familia", 14: "Fantasía",
    36: "Historia", 27: "Terror", 10402: "Música", 9648: "Misterio",
    10749: "Romance", 878: "Ciencia ficción", 10770: "TV", 53: "Suspense",
    10752: "Bélica", 37: "Western",
    10759: "Acción y aventura", 10762: "Infantil", 10763: "Noticias",
    10764: "Reality", 10765: "Ciencia ficción y fantasía",
    10766: "Telenovela", 10767: "Talk show", 10768: "Bélica y política",
}


def _tmdb_genres_to_names(genre_ids):
    if not genre_ids:
        return ""
    names = [_TMDB_GENRE_NAMES.get(gid) for gid in genre_ids[:3]]
    return ", ".join([n for n in names if n])


_GENRES = [
    ("Top General",     "movie", ""),
    ("Accion",          "movie", "28"),
    ("Animacion",       "movie", "16"),
    ("Aventura",        "movie", "12"),
    ("Comedia",         "movie", "35"),
    ("Ciencia Ficcion", "movie", "878"),
    ("Documental",      "movie", "99"),
    ("Drama",           "movie", "18"),
    ("Fantasia",        "movie", "14"),
    ("Terror",          "movie", "27"),
    ("Thriller",        "movie", "53"),
    ("Musical",         "movie", "10402"),
    ("Western",         "movie", "37"),
    ("Belica",          "movie", "10752"),
    ("Series TV",       "tv",    ""),
]

_TZ_MEDIA = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')

_GENRE_ICON = {
    "28":    "top_accion.png",
    "12":    "top_aventura.png",
    "16":    "top_animacion.png",
    "35":    "top_comedia.png",
    "878":   "top_scifi.png",
    "99":    "top_genero.png",
    "18":    "top_drama.png",
    "14":    "top_fantasia.png",
    "27":    "top_terror.png",
    "53":    "top_thriller.png",
    "10402": "top_genero.png",
    "37":    "top_western.png",
    "10752": "top_belica.png",
}


def _genre_icon(media_type, genre_id):
    if not genre_id:
        fname = "top_mejores.png" if media_type == "movie" else "top_series_air.png"
    else:
        fname = _GENRE_ICON.get(genre_id, "top_genero.png")
    return os.path.join(_TZ_MEDIA, fname)


def _u(**kwargs):
    return core_settings.make_url(**kwargs)

def _handle():
    return int(sys.argv[1])

def _fetch(media_type, genre_id):
    params = {
        "language": "es-ES",
        "region": "ES",
        "sort_by": "vote_average.desc",
        "vote_count.gte": 1000,
        "page": 1,
    }
    if genre_id:
        params["with_genres"] = genre_id
    try:
        import metadata_enricher as me
        data = me.tmdb_get(f"discover/{media_type}", params)
        if not data:
            return []
        movies = []
        for item in data.get("results", []) or []:
            title  = item.get("title") or item.get("name", "")
            date   = item.get("release_date") or item.get("first_air_date", "")
            year   = int(date[:4]) if date and len(date) >= 4 else 0
            path   = item.get("poster_path", "")
            poster = f"{_TMDB_IMG}{path}" if path else ""
            rating = item.get("vote_average", 0) or 0
            genre  = _tmdb_genres_to_names(item.get("genre_ids") or [])
            plot   = item.get("overview", "") or ""
            movies.append({"title": title, "year": year, "poster": poster,
                        "tmdb_id": item.get("id"), "media_type": media_type,
                        "rating": rating, "genre": genre, "plot": plot})
        return movies
    except Exception as e:
        xbmc.log(f"[TopZilla] filmaffinity Error: {e}", xbmc.LOGERROR)
        return []

def menu():
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()
    for label, media_type, genre_id in _GENRES:
        li = xbmcgui.ListItem(label=core_settings.apply_label("[B]{0}[/B]".format(label), bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': _genre_icon(media_type, genre_id), 'fanart': core_settings.addon_fanart()})
        url = _u(action="filmaffinity_list", genre=f"{media_type}:{genre_id}")
        xbmcplugin.addDirectoryItem(handle=_handle(), url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(_handle())

def show_list(genre):
    import pelis_grid as _pg
    if _pg.apply_grid_mode(_handle(), 'filmaffinity_list', "FilmAffinity · Género", genre=genre):
        return

    import metadata_enricher as me

    media_type, genre_id = genre.split(":", 1) if ":" in genre else ("movie", genre)
    movies = _fetch(media_type, genre_id)
    if not movies:
        xbmcgui.Dialog().notification("TopZilla", "No se pudieron cargar los titulos", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle())
        return

    af = core_settings.addon_fanart()
    canon_type = 'show' if media_type == 'tv' else 'movie'
    enrich_items = [{'tmdb_id': m.get('tmdb_id'), 'title': m['title'], 'year': m['year'],
                     'media_type': canon_type} for m in movies]
    metas = me.batch_enrich(enrich_items, use_cache_only=False, max_workers=4)

    import context_menu, movie_ref
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()
    for m, meta in zip(movies, metas):
        label = "[B]{0}[/B]".format("{0} ({1})".format(m['title'], m['year']) if m['year'] else m['title'])
        li = xbmcgui.ListItem(label=core_settings.apply_label(label, bold=_bold, strip=_strip, color_mode=_color))
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or m['poster']
        else:
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': m['poster'], 'poster': m['poster'], 'fanart': core_settings.addon_fanart()})
            header = me.build_plot_header(m.get('rating'), m.get('genre'))
            li.setInfo('video', {'title': m['title'], 'year': m['year'],
                                  'genre': m.get('genre', ''),
                                  'plot': header + m.get('plot', ''),
                                  'mediatype': 'movie'})
            poster = m['poster']
        plot = meta.get('overview', '') if meta else m.get('plot', '')
        ref = movie_ref.make_ref(
            title=m['title'], year=m.get('year'),
            tmdb_id=m.get('tmdb_id'), poster=poster,
            media_type=canon_type, source='filmaffinity', plot=plot,
        )
        context_menu.attach(li, ref)
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(handle=_handle(), url=context_menu.build_play_url(ref), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(_handle())


_FA_BASE = "https://www.filmaffinity.com/es"
_FA_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Accept-Language": "es-ES,es;q=0.9",
    "Referer": "https://www.filmaffinity.com/es/",
}
_CARTELERA_TTL = 6 * 3600
_TOPFA_TTL = 7 * 24 * 3600

_FA_MIN_FILMS = 3


class _Tls13Adapter(requests.adapters.HTTPAdapter):
    # filmaffinity/#20297-equivalente: Cloudflare reta el fingerprint TLS 1.2 del
    # Python de Kodi con un 403 (managed challenge); con TLS 1.3 el handshake pasa.
    # Es un bloqueo de capa TLS, previo al envío HTTP (las cabeceras no influyen).
    def init_poolmanager(self, *args, **kwargs):
        ctx = ssl.create_default_context()
        ctx.minimum_version = ssl.TLSVersion.TLSv1_3
        kwargs['ssl_context'] = ctx
        return super().init_poolmanager(*args, **kwargs)


def _fa_get(page, timeout=12):
    url = f"{_FA_BASE}/{page}"
    with requests.Session() as s:
        s.mount("https://", _Tls13Adapter())
        return s.get(url, headers=_FA_HEADERS, timeout=timeout)


def _cache_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(profile, 'topzilla_fa_cache.json')


def _load_cache():
    empty = {"cartelera": {}, "posters": {}, "top": {}, "topfa": {}, "cat": {}}
    try:
        path = _cache_path()
        if not os.path.exists(path):
            return empty
        with open(path, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        for key in empty:
            if not isinstance(data.get(key), dict):
                data[key] = {}
        return data
    except Exception as e:
        xbmc.log(f"[TopZilla] filmaffinity cache load error: {e}", xbmc.LOGWARNING)
        return empty


def _save_cache(data):
    try:
        path = _cache_path()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        # tmp ÚNICO por hilo: dos escrituras concurrentes con el mismo .tmp se
        # pisaban y dejaban el JSON corrupto ("Extra data"), vaciando la caché.
        tmp = '{0}.{1}.tmp'.format(path, threading.get_ident())
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, path)
    except Exception as e:
        xbmc.log(f"[TopZilla] filmaffinity cache save error: {e}", xbmc.LOGWARNING)


def _cartelera_fresh(cache):
    c = cache.get("cartelera", {})
    return bool(c.get("films")) and (time.time() - c.get("fetched_at", 0)) < _CARTELERA_TTL


def _scrape_filmaffinity():
    try:
        r = _fa_get("cat_new_th_es.html")
        xbmc.log(f"[TopZilla] filmaffinity cat_new_th_es -> {r.status_code}", xbmc.LOGINFO)
        if r.status_code != 200:
            return None
        films = []
        seen = set()
        for block in re.split(r'(?=<div[^>]+data-movie-id=")', r.text):
            id_m = re.search(r'data-movie-id="(\d+)"', block)
            if not id_m:
                continue
            fid = id_m.group(1)
            if fid in seen:
                continue
            title_m = re.search(r'class="[^"]*movie-title[^"]*"[^>]*title="([^"]+)"', block)
            if not title_m:
                title_m = re.search(r'class="poster-wrap"[^>]*title="([^"]+)"', block)
            if not title_m:
                continue
            seen.add(fid)
            poster_m = re.search(r'(https://pics\.filmaffinity\.com/[^"\s]+\.jpg)', block)
            poster = (poster_m.group(1).replace("-msmall.jpg", "-large.jpg").replace("-mmed.jpg", "-large.jpg")
                      if poster_m else "")
            films.append({'id': fid, 'title': html.unescape(title_m.group(1).strip()), 'poster': poster})
        if len(films) < _FA_MIN_FILMS:
            xbmc.log(f"[TopZilla] filmaffinity resultado sospechoso ({len(films)} films), ignorando", xbmc.LOGWARNING)
            return None
        xbmc.log(f"[TopZilla] filmaffinity scrapeadas {len(films)} películas", xbmc.LOGINFO)
        return films
    except Exception as e:
        xbmc.log(f"[TopZilla] filmaffinity scrape error: {e}", xbmc.LOGERROR)
        return None


def _tmdb_poster(title):
    try:
        import metadata_enricher as me
        data = me.tmdb_get("search/movie", {"query": title, "language": "es-ES"})
        if not data:
            return ""
        results = data.get("results", []) or []
        if not results:
            return ""
        path = results[0].get("poster_path", "")
        return f"{_TMDB_IMG}{path}" if path else ""
    except Exception:
        return ""


def _resolve_posters(films, poster_cache):
    _key = lambda t: t.lower().strip()
    # Los títulos que ya traen póster directo de FilmAffinity no consultan TMDB;
    # TMDB queda solo como respaldo para los que el scrape no resolvió.
    misses = [f for f in films if not f.get('poster') and _key(f['title']) not in poster_cache]
    if misses:
        xbmc.log(f"[TopZilla] filmaffinity TMDB: {len(misses)} posters nuevos a resolver", xbmc.LOGINFO)
        with ThreadPoolExecutor(max_workers=8) as ex:
            future_map = {ex.submit(_tmdb_poster, f['title']): f['title'] for f in misses}
            for future in as_completed(future_map):
                title = future_map[future]
                poster_cache[_key(title)] = future.result()
    return [dict(f, poster=(f.get('poster') or poster_cache.get(_key(f['title']), ''))) for f in films]


def _fetch_en_cines():
    cache = _load_cache()

    if _cartelera_fresh(cache):
        films = cache["cartelera"]["films"]
        xbmc.log(f"[TopZilla] filmaffinity cartelera desde caché ({len(films)} títulos)", xbmc.LOGINFO)
    else:
        scraped = _scrape_filmaffinity()
        if scraped is not None:
            films = scraped
            cache["cartelera"] = {"fetched_at": time.time(), "films": films}
        elif cache.get("cartelera", {}).get("films"):
            films = cache["cartelera"]["films"]
            xbmc.log("[TopZilla] filmaffinity inaccesible, usando caché caducada", xbmc.LOGWARNING)
        else:
            return []

    poster_cache = cache.setdefault("posters", {})
    films_with_posters = _resolve_posters(films, poster_cache)
    _save_cache(cache)
    return films_with_posters


def show_cartelera():
    import pelis_grid as _pg
    if _pg.apply_grid_mode(_handle(), 'filmaffinity_cartelera', "En Cines · FilmAffinity"):
        return

    import metadata_enricher as me

    films = _fetch_en_cines()
    if not films:
        xbmcgui.Dialog().notification("TopZilla", "No se pudo cargar FilmAffinity", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle())
        return

    af = core_settings.addon_fanart()
    auto_fetch = core_settings._auto_fetch_enabled()
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()

    if not auto_fetch:
        first_title = films[0]['title'] if films else None
        has_meta = bool(me.enrich(title=first_title, media_type='movie', use_cache_only=True)) if first_title else False
        if not has_meta:
            li = xbmcgui.ListItem(label=core_settings.apply_label("[COLOR yellow][B]Descargar metadatos completos[/B][/COLOR]", bold=_bold, strip=_strip, color_mode=_color))
            li.setArt({'icon': 'DefaultAddonService.png', 'fanart': core_settings.addon_fanart()})
            li.setInfo('video', {'plot': "Descarga sinopsis en español, actores y director de las películas en cartelera."})
            xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="filmaffinity_cache_cartelera_meta"), listitem=li, isFolder=False)
        else:
            li = xbmcgui.ListItem(label=core_settings.apply_label("[COLOR red][B]Borrar metadatos de cartelera[/B][/COLOR]", bold=_bold, strip=_strip, color_mode=_color))
            li.setArt({'icon': 'DefaultIconError.png', 'fanart': core_settings.addon_fanart()})
            li.setInfo('video', {'plot': "Elimina los metadatos guardados de la cartelera actual."})
            xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="filmaffinity_clear_cartelera_meta"), listitem=li, isFolder=False)

    import context_menu, movie_ref
    for f in films:
        li = xbmcgui.ListItem(label=core_settings.apply_label("[B]{0}[/B]".format(f['title']), bold=_bold, strip=_strip, color_mode=_color))
        meta = me.enrich(title=f['title'], media_type='movie', use_cache_only=not auto_fetch)
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or f['poster']
        else:
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': f['poster'], 'poster': f['poster'], 'fanart': af})
            li.setInfo('video', {'title': f['title'], 'mediatype': 'movie'})
            poster = f['poster']
        tmdb_id = (meta or {}).get('ids', {}).get('tmdb') if meta else None
        plot = meta.get('overview', '') if meta else ''
        ref = movie_ref.make_ref(
            title=f['title'], year=(meta or {}).get('year') if meta else None,
            tmdb_id=tmdb_id, poster=poster,
            media_type='movie', source='filmaffinity', plot=plot,
        )
        context_menu.attach(li, ref)
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(handle=_handle(), url=context_menu.build_play_url(ref), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(_handle())


def _top_fresh(cache):
    c = cache.get("top", {})
    return bool(c.get("films")) and (time.time() - c.get("fetched_at", 0)) < _CARTELERA_TTL


def _fetch_tmdb_top_rated():
    try:
        import metadata_enricher as me
        data = me.tmdb_get("movie/top_rated", {"language": "es-ES", "page": 1})
        if not data:
            return None
        films = []
        for m in data.get("results", []) or []:
            title = m.get("title", "").strip()
            if not title:
                continue
            poster_path = m.get("poster_path", "")
            poster = f"{_TMDB_IMG}{poster_path}" if poster_path else ""
            year = str(m.get("release_date", ""))[:4]
            rating = f"{m.get('vote_average', 0):.1f}"
            genre = _tmdb_genres_to_names(m.get("genre_ids") or [])
            plot = m.get("overview", "") or ""
            films.append({"id": str(m.get("id", "")), "title": title,
                          "year": year, "rating": rating, "poster": poster,
                          "genre": genre, "plot": plot})
        if len(films) < _FA_MIN_FILMS:
            xbmc.log(f"[TopZilla] filmaffinity top_rated sospechoso ({len(films)} films), ignorando", xbmc.LOGWARNING)
            return None
        xbmc.log(f"[TopZilla] filmaffinity top_rated: {len(films)} películas", xbmc.LOGINFO)
        return films
    except Exception as e:
        xbmc.log(f"[TopZilla] filmaffinity top_rated error: {e}", xbmc.LOGERROR)
        return None


def _fetch_top():
    cache = _load_cache()
    if _top_fresh(cache):
        films = cache["top"]["films"]
        xbmc.log(f"[TopZilla] filmaffinity top desde caché ({len(films)} títulos)", xbmc.LOGINFO)
        return films
    fetched = _fetch_tmdb_top_rated()
    if fetched is not None:
        films = fetched
        cache["top"] = {"fetched_at": time.time(), "films": films}
    elif cache.get("top", {}).get("films"):
        films = cache["top"]["films"]
        xbmc.log("[TopZilla] filmaffinity TMDB inaccesible, usando caché top caducada", xbmc.LOGWARNING)
    else:
        return []
    _save_cache(cache)
    return films


def show_top():
    import pelis_grid as _pg
    if _pg.apply_grid_mode(_handle(), 'filmaffinity_top', "Top Valoradas · FilmAffinity"):
        return

    import metadata_enricher as me

    films = _fetch_top()
    if not films:
        xbmcgui.Dialog().notification("TopZilla", "No se pudo cargar FilmAffinity Top", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle())
        return

    af = core_settings.addon_fanart()
    enrich_items = [{'tmdb_id': f.get('tmdb_id') or f.get('id'), 'title': f['title'],
                     'year': int(f['year']) if f.get('year', '').isdigit() else None,
                     'media_type': 'movie'} for f in films]
    metas = me.batch_enrich(enrich_items, use_cache_only=False, max_workers=4)

    import context_menu, movie_ref
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()
    for f, meta in zip(films, metas):
        year_int = int(f['year']) if f.get('year', '').isdigit() else 0
        label = "[B]{0}[/B]".format("{0} ({1})".format(f['title'], year_int) if year_int else f['title'])
        li = xbmcgui.ListItem(label=core_settings.apply_label(label, bold=_bold, strip=_strip, color_mode=_color))
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or f['poster']
        else:
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': f['poster'], 'poster': f['poster'], 'fanart': af})
            header = me.build_plot_header(f.get('rating'), f.get('genre'))
            li.setInfo('video', {'title': f['title'], 'year': year_int,
                                  'genre': f.get('genre', ''),
                                  'plot': header + f.get('plot', ''),
                                  'mediatype': 'movie'})
            poster = f['poster']
        tmdb_id = (meta or {}).get('ids', {}).get('tmdb') if meta else (f.get('tmdb_id') or f.get('id'))
        plot = meta.get('overview', '') if meta else f.get('plot', '')
        ref = movie_ref.make_ref(
            title=f['title'], year=year_int,
            tmdb_id=tmdb_id, poster=poster,
            media_type='movie', source='filmaffinity', plot=plot,
        )
        context_menu.attach(li, ref)
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(handle=_handle(), url=context_menu.build_play_url(ref), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(_handle())


def cache_cartelera_meta():
    import metadata_enricher as me

    films = _fetch_en_cines()
    if not films:
        xbmcgui.Dialog().notification("TopZilla", "No hay películas en cartelera", xbmcgui.NOTIFICATION_ERROR)
        return

    items = [{'title': f['title'], 'media_type': 'movie'} for f in films]
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("TopZilla", "Descargando metadatos cartelera...")
    try:
        count = me.batch_fetch_with_progress(items, pDialog)
    finally:
        pDialog.close()

    xbmcgui.Dialog().notification(
        "TopZilla",
        "Metadatos guardados: {0}/{1}".format(count, len(items)),
        xbmcgui.NOTIFICATION_INFO,
    )
    xbmc.executebuiltin("Container.Refresh")


def clear_cartelera_meta():
    import metadata_enricher as me

    films = _fetch_en_cines()
    items = [{'title': f['title'], 'media_type': 'movie'} for f in films]
    me.delete_items(items)
    xbmcgui.Dialog().notification("TopZilla", "Metadatos de cartelera eliminados", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


# Secciones cat_*.html: novedades por plataforma, cines por país y alquiler/venta.
# Comparten parser (_scrape_cat) y se sirven por show_cat(src). La cartelera
# (cat_new_th_es) NO está aquí: tiene su propio flujo por retro-compatibilidad.
_FA_TV_SUFFIX = re.compile(r'\s*\((?:Mini)?[Ss]erie de TV[^)]*\)\s*$')


def _split_type(title):
    # 'Rick y Morty (Serie de TV)' -> ('Rick y Morty', 'show')
    if _FA_TV_SUFFIX.search(title):
        return _FA_TV_SUFFIX.sub('', title).strip(), 'show'
    return title, 'movie'


def _scrape_cat(path):
    """Scrapea una página cat_*.html. Extrae el póster -large.jpg directo de FA
    (evita ~900 búsquedas TMDB) y detecta el tipo por ítem. Devuelve dicts
    {id, title, poster, media_type} o None si falla/sospechoso."""
    try:
        r = _fa_get(path)
        xbmc.log(f"[TopZilla] filmaffinity {path} -> {r.status_code}", xbmc.LOGINFO)
        if r.status_code != 200:
            return None
        films = []
        seen = set()
        for block in re.split(r'(?=<div[^>]+data-movie-id=")', r.text):
            id_m = re.search(r'data-movie-id="(\d+)"', block)
            if not id_m:
                continue
            fid = id_m.group(1)
            if fid in seen:
                continue
            title_m = re.search(r'class="[^"]*movie-title[^"]*"[^>]*title="([^"]+)"', block)
            if not title_m:
                title_m = re.search(r'class="poster-wrap"[^>]*title="([^"]+)"', block)
            if not title_m:
                continue
            seen.add(fid)
            title, media_type = _split_type(html.unescape(title_m.group(1).strip()))
            poster_m = re.search(r'(https://pics\.filmaffinity\.com/[^"\s]+\.jpg)', block)
            poster = poster_m.group(1).replace("-msmall.jpg", "-large.jpg").replace("-mmed.jpg", "-large.jpg") if poster_m else ""
            films.append({'id': fid, 'title': title, 'poster': poster, 'media_type': media_type})
        if len(films) < _FA_MIN_FILMS:
            xbmc.log(f"[TopZilla] filmaffinity {path}: resultado sospechoso ({len(films)} films), ignorando", xbmc.LOGWARNING)
            return None
        xbmc.log(f"[TopZilla] filmaffinity {path}: scrapeadas {len(films)} películas", xbmc.LOGINFO)
        return films
    except (requests.RequestException, ValueError) as e:
        xbmc.log(f"[TopZilla] filmaffinity {path} scrape error: {e}", xbmc.LOGERROR)
        return None


_CAT_SECTIONS = [
    {"src": "netflix",      "label": "Novedades Netflix",          "path": "cat_new_netflix.html",   "icon": "top_netflix.png",    "group": "streaming", "ttl": 12 * 3600},
    {"src": "hbo",          "label": "Novedades HBO Max",          "path": "cat_new_hbo_es.html",    "icon": "top_max.png",        "group": "streaming", "ttl": 12 * 3600},
    {"src": "amazon",       "label": "Novedades Prime Video",      "path": "cat_new_amazon_es.html", "icon": "top_amazon.png",     "group": "streaming", "ttl": 12 * 3600},
    {"src": "disney",       "label": "Novedades Disney+",          "path": "cat_disneyplus.html",    "icon": "top_disney.png",     "group": "streaming", "ttl": 12 * 3600},
    {"src": "movistar",     "label": "Novedades Movistar Plus+",   "path": "cat_new_movistar_f.html","icon": "top_movistar.png",   "group": "streaming", "ttl": 12 * 3600},
    {"src": "filmin",       "label": "Novedades Filmin",           "path": "cat_new_filmin.html",    "icon": "fa_filmin.png",      "group": "streaming", "ttl": 12 * 3600},
    {"src": "apple",        "label": "Novedades Apple TV+",        "path": "cat_apple_tv_plus.html", "icon": "top_appletv.png",    "group": "streaming", "ttl": 12 * 3600},
    {"src": "skyshowtime",  "label": "Novedades SkyShowtime",      "path": "cat_skyshowtime.html",   "icon": "fa_skyshowtime.png", "group": "streaming", "ttl": 12 * 3600},
    {"src": "th_us",        "label": "En cines (USA)",             "path": "cat_new_th_us.html",     "icon": "fa_cines_intl.png",  "group": "cines",     "ttl": 12 * 3600},
    {"src": "th_uk",        "label": "En cines (Reino Unido)",     "path": "cat_new_th_uk.html",     "icon": "fa_cines_intl.png",  "group": "cines",     "ttl": 12 * 3600},
    {"src": "th_fr",        "label": "En cines (Francia)",         "path": "cat_new_th_fr.html",     "icon": "fa_cines_intl.png",  "group": "cines",     "ttl": 12 * 3600},
    {"src": "rent",         "label": "Novedades en alquiler",      "path": "cat_new_re_es.html",     "icon": "fa_alquiler.png",    "group": "rent",      "ttl": 12 * 3600},
    {"src": "buy",          "label": "Novedades en venta",         "path": "cat_new_sa_es.html",     "icon": "fa_venta.png",       "group": "rent",      "ttl": 12 * 3600},
    {"src": "upc_movistar", "label": "Próximos en Movistar Plus+", "path": "cat_upc_movistar_f.html","icon": "top_movistar.png",   "group": "otros",     "ttl": _CARTELERA_TTL},
    {"src": "current_tv",   "label": "Actualidad TV",              "path": "cat_current_tv.html",    "icon": "top_encines_tv.png", "group": "otros",     "ttl": _CARTELERA_TTL},
]


def _cat_section(src):
    return next((s for s in _CAT_SECTIONS if s["src"] == src), None)


def cat_sections_for(group):
    """Secciones de un grupo, para construir los submenús en default.py."""
    return [s for s in _CAT_SECTIONS if s["group"] == group]


def _cat_fresh(cache, src, ttl):
    c = cache.get("cat", {}).get(src, {})
    return bool(c.get("films")) and (time.time() - c.get("fetched_at", 0)) < ttl


def _fetch_cat(src):
    section = _cat_section(src)
    if not section:
        return []
    cache = _load_cache()
    catcache = cache.setdefault("cat", {})
    if _cat_fresh(cache, src, section["ttl"]):
        films = catcache[src]["films"]
        xbmc.log(f"[TopZilla] filmaffinity {src} desde caché ({len(films)} títulos)", xbmc.LOGINFO)
        return films
    scraped = _scrape_cat(section["path"])
    if scraped is not None:
        films = scraped
        catcache[src] = {"fetched_at": time.time(), "films": films}
    elif catcache.get(src, {}).get("films"):
        films = catcache[src]["films"]
        xbmc.log(f"[TopZilla] filmaffinity {src} inaccesible, usando caché caducada", xbmc.LOGWARNING)
    else:
        return []
    _save_cache(cache)
    return films


def _trigger_bg_enrich_cat(films):
    import metadata_enricher as me

    def _fetch():
        try:
            items = [{'title': f['title'], 'media_type': f.get('media_type', 'movie')} for f in films]
            results = me.batch_enrich(items, max_workers=2)
            if any(results):
                xbmc.executebuiltin("Container.Refresh")
        except Exception as e:  # hilo daemon: loguear, no propagar
            xbmc.log(f"[TopZilla] filmaffinity cat bg enrich: {e}", xbmc.LOGWARNING)

    threading.Thread(target=_fetch, daemon=True).start()


def show_cat(src):
    section = _cat_section(src)
    if not section:
        xbmcplugin.endOfDirectory(_handle())
        return

    import pelis_grid as _pg
    if _pg.apply_grid_mode(_handle(), 'filmaffinity_cat', section["label"], src=src):
        return

    import context_menu
    import metadata_enricher as me
    import movie_ref

    films = _fetch_cat(src)
    if not films:
        xbmcgui.Dialog().notification("TopZilla", "No se pudo cargar FilmAffinity", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle())
        return

    af    = core_settings.addon_fanart()
    bold  = core_settings.get_acc_force_bold()
    strip = core_settings.get_acc_strip_symbols()
    color = core_settings.get_acc_color_mode()

    first = films[0]
    has_meta = bool(me.enrich(title=first['title'], media_type=first.get('media_type', 'movie'), use_cache_only=True))
    if not has_meta:
        _trigger_bg_enrich_cat(films)

    h = _handle()
    for f in films:
        media_type = f.get('media_type', 'movie')
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            f['title'], bold=bold, strip=strip, color_mode=color))
        meta = me.enrich(title=f['title'], media_type=media_type, use_cache_only=True)
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or f.get('poster', '')
        else:
            poster = f.get('poster', '')
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': poster, 'poster': poster, 'fanart': af})
            li.setInfo('video', {'title': f['title'],
                                 'mediatype': 'tvshow' if media_type == 'show' else 'movie'})
        tmdb_id = (meta.get('ids') or {}).get('tmdb') if meta else None
        ref = movie_ref.make_ref(
            title=f['title'], tmdb_id=tmdb_id, poster=poster,
            media_type=media_type, source='filmaffinity',
        )
        context_menu.attach(li, ref)
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(handle=h, url=context_menu.build_play_url(ref), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h, cacheToDisc=core_settings.remember_list_position())


def _scrape_topgen():
    try:
        r = _fa_get("topgen.php")
        xbmc.log(f"[TopZilla] filmaffinity topgen -> {r.status_code}", xbmc.LOGINFO)
        if r.status_code != 200:
            return None
        films = []
        seen = set()
        for block in re.split(r'(?=<div[^>]+data-movie-id=")', r.text):
            id_m = re.search(r'data-movie-id="(\d+)"', block)
            if not id_m:
                continue
            fid = id_m.group(1)
            if fid in seen:
                continue
            title_m = re.search(r'class="mc-title"[^>]*>\s*<a[^>]*title="([^"]+)"', block)
            if not title_m:
                title_m = re.search(r'class="mc-title"[^>]*>\s*<a[^>]*>([^<]+)</a>', block)
            if not title_m:
                continue
            seen.add(fid)
            title = html.unescape(title_m.group(1).strip())
            year_m = re.search(r'class="mc-year">(\d{4})', block)
            year = year_m.group(1) if year_m else ""
            poster_m = re.search(r'<img[^>]+(?:data-src|src)="(https://pics\.filmaffinity\.com/[^"]+)"', block)
            poster = poster_m.group(1) if poster_m else ""
            if poster:
                poster = poster.replace("-msmall.jpg", "-large.jpg").replace("-mmed.jpg", "-large.jpg")
            rating_m = re.search(r'class="avg-rating">([\d,\.]+)', block)
            rating = rating_m.group(1).replace(",", ".") if rating_m else ""
            director_m = re.search(r'class="mc-director"[^>]*>.*?<a[^>]*title="([^"]+)"', block, re.DOTALL)
            if not director_m:
                director_m = re.search(r'class="mc-director"[^>]*>.*?<a[^>]*>([^<]+)</a>', block, re.DOTALL)
            director = html.unescape(director_m.group(1).strip()) if director_m else ""
            films.append({'id': fid, 'title': title, 'year': year, 'poster': poster,
                          'rating': rating, 'director': director})
        if len(films) < _FA_MIN_FILMS:
            xbmc.log(f"[TopZilla] filmaffinity topgen sospechoso ({len(films)} films), ignorando", xbmc.LOGWARNING)
            return None
        xbmc.log(f"[TopZilla] filmaffinity topgen: {len(films)} películas", xbmc.LOGINFO)
        return films
    except Exception as e:
        xbmc.log(f"[TopZilla] filmaffinity topgen error: {e}", xbmc.LOGERROR)
        return None


def _topfa_fresh(cache):
    c = cache.get("topfa", {})
    return bool(c.get("films")) and (time.time() - c.get("fetched_at", 0)) < _TOPFA_TTL


def _fetch_topfa():
    cache = _load_cache()
    if _topfa_fresh(cache):
        films = cache["topfa"]["films"]
        xbmc.log(f"[TopZilla] filmaffinity topfa desde caché ({len(films)} títulos)", xbmc.LOGINFO)
        return films
    fetched = _scrape_topgen()
    if fetched is not None:
        films = fetched
        cache["topfa"] = {"fetched_at": time.time(), "films": films}
    elif cache.get("topfa", {}).get("films"):
        films = cache["topfa"]["films"]
        xbmc.log("[TopZilla] filmaffinity topgen inaccesible, usando caché caducada", xbmc.LOGWARNING)
    else:
        return []
    _save_cache(cache)
    return films


def show_topfa():
    import pelis_grid as _pg
    if _pg.apply_grid_mode(_handle(), 'filmaffinity_topfa', "Top Comunidad · FilmAffinity"):
        return

    import metadata_enricher as me

    films = _fetch_topfa()
    if not films:
        xbmcgui.Dialog().notification("TopZilla", "No se pudo cargar Top FilmAffinity", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle())
        return

    af = core_settings.addon_fanart()
    enrich_items = [{'title': f['title'],
                     'year': int(f['year']) if f.get('year', '').isdigit() else None,
                     'media_type': 'movie'} for f in films]
    metas = me.batch_enrich(enrich_items, use_cache_only=False, max_workers=4)

    import context_menu, movie_ref
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()
    for f, meta in zip(films, metas):
        year_int = int(f['year']) if f.get('year', '').isdigit() else 0
        rating = f.get('rating', '')
        title_label = "{0} ({1})".format(f['title'], year_int) if year_int else f['title']
        if rating:
            title_label = "{0}  [COLOR yellow]FA {1}[/COLOR]".format(title_label, rating)
        label = "[B]{0}[/B]".format(title_label)
        li = xbmcgui.ListItem(label=core_settings.apply_label(label, bold=_bold, strip=_strip, color_mode=_color))
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or f['poster']
        else:
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': f['poster'], 'poster': f['poster'], 'fanart': af})
            header = me.build_plot_header(rating, None, director=f.get('director'))
            li.setInfo('video', {'title': f['title'], 'year': year_int,
                                  'plot': header, 'mediatype': 'movie'})
            poster = f['poster']
        tmdb_id = (meta or {}).get('ids', {}).get('tmdb') if meta else None
        plot = meta.get('overview', '') if meta else ''
        ref = movie_ref.make_ref(
            title=f['title'], year=year_int,
            tmdb_id=tmdb_id, poster=poster,
            media_type='movie', source='filmaffinity', plot=plot,
        )
        context_menu.attach(li, ref)
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(handle=_handle(), url=context_menu.build_play_url(ref), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(_handle())
