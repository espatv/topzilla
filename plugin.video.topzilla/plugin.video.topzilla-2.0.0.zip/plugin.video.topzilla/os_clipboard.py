# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""Lectura y escritura del portapapeles del SO. Multiplataforma sin dependencias.

Estrategias por SO:
- Windows: ctypes + Win32 (OpenClipboard / GetClipboardData / SetClipboardData).
  Evitamos tkinter (crea ventana root oculta + arrastra _tkinter entero) y
  pywin32 (dependencia externa). ctypes es stdlib pura.
- macOS: subprocess /usr/bin/pbpaste y /usr/bin/pbcopy.
- Linux: wl-paste/wl-copy (Wayland) o xclip/xsel (X11), detectados con
  shutil.which.
- Android: no soportado (Kodi no expone ClipboardManager sin JNI).
  Devuelve None en get; set lanza NotSupportedError.

API:
- get_system_clipboard() -> str | None
- set_system_clipboard(text) -> bool (True si OK, False si fallo)
"""
import os
import shutil
import subprocess
import sys


class NotSupportedError(Exception):
    """Plataforma no soporta operacion (ej: Android sin JNI)."""


def _is_android():
    # Heuristica estandar en addons Kodi: env vars que Android Kodi setea.
    return 'ANDROID_ROOT' in os.environ or 'ANDROID_DATA' in os.environ


def _win_load():
    """Carga referencias Win32 una sola vez. Devuelve (u32, k32) o (None, None)."""
    try:
        import ctypes
        from ctypes import wintypes
    except (ImportError, OSError):
        return None, None
    u32 = ctypes.windll.user32
    k32 = ctypes.windll.kernel32
    u32.OpenClipboard.argtypes = [wintypes.HWND]
    u32.OpenClipboard.restype = wintypes.BOOL
    u32.GetClipboardData.argtypes = [wintypes.UINT]
    u32.GetClipboardData.restype = wintypes.HANDLE
    u32.EmptyClipboard.restype = wintypes.BOOL
    u32.SetClipboardData.argtypes = [wintypes.UINT, wintypes.HANDLE]
    u32.SetClipboardData.restype = wintypes.HANDLE
    u32.CloseClipboard.restype = wintypes.BOOL
    k32.GlobalLock.argtypes = [wintypes.HGLOBAL]
    k32.GlobalLock.restype = ctypes.c_void_p
    k32.GlobalUnlock.argtypes = [wintypes.HGLOBAL]
    k32.GlobalAlloc.argtypes = [wintypes.UINT, ctypes.c_size_t]
    k32.GlobalAlloc.restype = wintypes.HGLOBAL
    k32.GlobalFree.argtypes = [wintypes.HGLOBAL]
    k32.GlobalFree.restype = wintypes.HGLOBAL
    return u32, k32


def _clipboard_windows_get():
    import ctypes
    u32, k32 = _win_load()
    if u32 is None:
        return None
    CF_UNICODETEXT = 13
    if not u32.OpenClipboard(0):
        return None
    try:
        handle = u32.GetClipboardData(CF_UNICODETEXT)
        if not handle:
            return None
        ptr = k32.GlobalLock(handle)
        if not ptr:
            return None
        try:
            return ctypes.wstring_at(ptr)
        finally:
            k32.GlobalUnlock(handle)
    finally:
        u32.CloseClipboard()


def _clipboard_windows_set(text):
    import ctypes
    u32, k32 = _win_load()
    if u32 is None:
        return False
    CF_UNICODETEXT = 13
    GMEM_MOVEABLE = 0x0002
    data = text.encode('utf-16-le') + b'\x00\x00'
    h = k32.GlobalAlloc(GMEM_MOVEABLE, len(data))
    if not h:
        return False
    # El OS toma ownership de h solo si SetClipboardData devuelve un handle
    # no nulo. En cualquier otro camino de salida hay que GlobalFree(h).
    os_owns_h = False
    try:
        ptr = k32.GlobalLock(h)
        if not ptr:
            return False
        ctypes.memmove(ptr, data, len(data))
        k32.GlobalUnlock(h)

        if not u32.OpenClipboard(0):
            return False
        try:
            u32.EmptyClipboard()
            if u32.SetClipboardData(CF_UNICODETEXT, h):
                os_owns_h = True
                return True
            return False
        finally:
            u32.CloseClipboard()
    finally:
        if not os_owns_h:
            k32.GlobalFree(h)


def _run(cmd, input_bytes=None):
    """Wrapper de subprocess.run con timeout corto. Devuelve stdout o None si falla."""
    try:
        out = subprocess.run(
            cmd, capture_output=True, timeout=2,
            input=input_bytes, check=False,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return None
    if out.returncode != 0:
        return None
    return out.stdout


def _clipboard_macos_get():
    res = _run(['/usr/bin/pbpaste'])
    return res.decode('utf-8', errors='replace') if res is not None else None


def _clipboard_macos_set(text):
    res = _run(['/usr/bin/pbcopy'], input_bytes=text.encode('utf-8'))
    return res is not None


def _clipboard_linux_get():
    if os.environ.get('WAYLAND_DISPLAY') and shutil.which('wl-paste'):
        res = _run(['wl-paste', '--no-newline'])
    elif shutil.which('xclip'):
        res = _run(['xclip', '-selection', 'clipboard', '-o'])
    elif shutil.which('xsel'):
        res = _run(['xsel', '--clipboard', '--output'])
    else:
        return None
    return res.decode('utf-8', errors='replace') if res is not None else None


def _clipboard_linux_set(text):
    data = text.encode('utf-8')
    if os.environ.get('WAYLAND_DISPLAY') and shutil.which('wl-copy'):
        res = _run(['wl-copy'], input_bytes=data)
    elif shutil.which('xclip'):
        res = _run(['xclip', '-selection', 'clipboard', '-i'], input_bytes=data)
    elif shutil.which('xsel'):
        res = _run(['xsel', '--clipboard', '--input'], input_bytes=data)
    else:
        return False
    return res is not None


def get_system_clipboard():
    """Devuelve el contenido del portapapeles del SO o None si falla/no soportado."""
    try:
        if sys.platform == 'win32':
            return _clipboard_windows_get()
        if sys.platform == 'darwin':
            return _clipboard_macos_get()
        if sys.platform.startswith('linux'):
            if _is_android():
                return None
            return _clipboard_linux_get()
    except Exception:
        # Handler de UI: cualquier fallo del portapapeles no debe tumbar el addon.
        return None
    return None


def set_system_clipboard(text):
    """Escribe text al portapapeles del SO. Devuelve True si OK, False si fallo."""
    if not isinstance(text, str):
        return False
    try:
        if sys.platform == 'win32':
            return _clipboard_windows_set(text)
        if sys.platform == 'darwin':
            return _clipboard_macos_set(text)
        if sys.platform.startswith('linux'):
            if _is_android():
                raise NotSupportedError('Android no soportado')
            return _clipboard_linux_set(text)
    except NotSupportedError:
        raise
    except Exception:
        return False
    return False
