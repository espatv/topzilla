# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""
Item de menu contextual: pega el portapapeles en el teclado virtual / cuadro
de busqueda enfocado via Input.SendText (JSON-RPC).

Origen del texto: el portapapeles interno de TopZilla y, si esta vacio, el
portapapeles del SO (asi el usuario puede pegar algo copiado fuera de Kodi).

Lógica anti-race (origen: bug kodi/kodi#20297 en Android):
1. Detectar Window.IsActive(virtualkeyboard).
2. Esperar POST_KB_DETECT_DELAY_MS (250ms minimo observado).
3. Esperar a que busydialog cierre (BUSY_WAIT_MAX_MS max).
4. Revalidar que el teclado sigue abierto.
5. Input.SendText con done=True en UNA sola llamada.

El send se hace con done=True atomico: la variante two-phase
(SendText(done=False) + delay + done=True) dispara un bug en Kodi 21+ con
addons cuyo teclado abre con foco en "Aceptar" (el done=False cierra el
dialogo prematuramente con buffer vacio). Un unico done=True evita el bug
porque set+commit es atomico.
"""
import json
import sys
import threading

import xbmc
import xbmcgui

import clipboard

_LOG_PREFIX = '[TopZilla.context_paste]'

_WAIT_INTERVAL_MS = 100
_WAIT_APPEAR_MS = 8000
_POST_KB_DETECT_DELAY_MS = 500   # minimo observado para evitar kodi/kodi#20297
_BUSY_WAIT_MAX_MS = 3000


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log(f'{_LOG_PREFIX} {msg}', level)


def _is_keyboard_active():
    return bool(xbmc.getCondVisibility('Window.IsActive(virtualkeyboard)'))


def _is_busy_dialog_active():
    return (
        xbmc.getCondVisibility('Window.IsActive(busydialog)')
        or xbmc.getCondVisibility('Window.IsActive(busydialognocancel)')
    )


def _wait_for_busy_clear(monitor, max_ms=_BUSY_WAIT_MAX_MS):
    elapsed = 0
    while _is_busy_dialog_active() and elapsed < max_ms:
        if monitor.abortRequested():
            return False
        xbmc.sleep(_WAIT_INTERVAL_MS)
        elapsed += _WAIT_INTERVAL_MS
    return not _is_busy_dialog_active()


def _send_text(text):
    payload = {
        'jsonrpc': '2.0',
        'method': 'Input.SendText',
        'params': {'text': str(text), 'done': True},
        'id': 1,
    }
    raw = xbmc.executeJSONRPC(json.dumps(payload))
    try:
        resp = json.loads(raw or '{}')
    except (ValueError, TypeError):
        return False
    return 'error' not in resp


def _get_listitem_url():
    """Cadena de fallback: sys.listitem.getPath() -> getProperty('Path') -> infolabel."""
    url = ''
    if hasattr(sys, 'listitem') and sys.listitem:
        try:
            url = sys.listitem.getPath() or ''
        except (AttributeError, RuntimeError) as e:
            _log(f'getPath error: {e}', xbmc.LOGDEBUG)
        if not url:
            try:
                url = sys.listitem.getProperty('Path') or ''
            except (AttributeError, RuntimeError) as e:
                _log(f'getProperty error: {e}', xbmc.LOGDEBUG)
    if not url:
        url = xbmc.getInfoLabel('ListItem.FileNameAndPath')
    return url


def _is_folder_item():
    """Determina si el item es folder para elegir Container.Update vs RunPlugin.

    `xbmc.getInfoLabel('ListItem.IsFolder')` desde un context menu handler suele
    devolver '' (no 'true'/'false'), comprobado en Kodi 21+. Los items de
    busqueda son folders (devuelven resultados): asumimos True salvo que IsFolder
    sea EXPLICITAMENTE 'false' o '0'.
    """
    val = (xbmc.getInfoLabel('ListItem.IsFolder') or '').strip().lower()
    return val not in ('false', '0')


def _wait_keyboard_and_send(text):
    """Espera al teclado virtual e inyecta el texto (patron anti-race)."""
    monitor = xbmc.Monitor()

    elapsed = 0
    while not _is_keyboard_active() and elapsed < _WAIT_APPEAR_MS:
        if monitor.abortRequested():
            return
        xbmc.sleep(_WAIT_INTERVAL_MS)
        elapsed += _WAIT_INTERVAL_MS

    if not _is_keyboard_active():
        _log('el teclado no aparecio', xbmc.LOGWARNING)
        if not monitor.abortRequested():
            xbmcgui.Dialog().notification(
                'TopZilla', 'No se abrio teclado. Es un item de busqueda?',
                xbmcgui.NOTIFICATION_WARNING, 3500,
            )
        return

    xbmc.sleep(_POST_KB_DETECT_DELAY_MS)

    # El busy puede quedarse abierto si el plugin de directorio espera el texto
    # (chicken-and-egg): enviamos igual si el teclado sigue activo.
    if not _wait_for_busy_clear(monitor, max_ms=1000) and not _is_keyboard_active():
        _log('busy no cierra y teclado no activo', xbmc.LOGWARNING)
        return

    if not _is_keyboard_active():
        _log('el teclado se cerro durante la espera', xbmc.LOGWARNING)
        return

    if _send_text(text):
        xbmcgui.Dialog().notification(
            'TopZilla', f'Pegado: {text[:60]}',
            xbmcgui.NOTIFICATION_INFO, 2500,
        )
    elif not monitor.abortRequested():
        _log('Input.SendText rechazado por Kodi', xbmc.LOGWARNING)
        xbmcgui.Dialog().notification(
            'TopZilla', 'No se pudo pegar el texto',
            xbmcgui.NOTIFICATION_WARNING, 2500,
        )


def _run():
    text = clipboard.get()
    if not text:
        import os_clipboard
        text = clipboard.sanitize(os_clipboard.get_system_clipboard() or '')
    if not text:
        xbmcgui.Dialog().notification(
            'TopZilla', 'No hay nada en el portapapeles',
            xbmcgui.NOTIFICATION_WARNING, 2500,
        )
        return

    url = _get_listitem_url()
    if not url or not url.startswith('plugin://'):
        _log(f'item no ejecutable como plugin: {url[:120]!r}', xbmc.LOGWARNING)
        xbmcgui.Dialog().notification(
            'TopZilla', 'Item no ejecutable como plugin',
            xbmcgui.NOTIFICATION_WARNING, 2500,
        )
        return

    # Container.Update para folders (busquedas): RunPlugin ejecuta el plugin pero
    # los resultados de endOfDirectory no actualizan ningun container visible.
    builtin = f'Container.Update({url})' if _is_folder_item() else f'RunPlugin({url})'
    _log(f'lanzando {builtin[:100]!r} + inject thread, text_preview={text[:40]!r}')

    threading.Thread(
        target=_wait_keyboard_and_send,
        args=(text,),
        daemon=True,
        name='topzilla-paste',
    ).start()
    xbmc.executebuiltin(builtin)


if __name__ == '__main__':
    try:
        _run()
    except Exception as e:
        xbmc.log(f'{_LOG_PREFIX} error inesperado: {e}', xbmc.LOGERROR)
        xbmcgui.Dialog().notification(
            'TopZilla', 'Error al pegar',
            xbmcgui.NOTIFICATION_ERROR, 2000,
        )
