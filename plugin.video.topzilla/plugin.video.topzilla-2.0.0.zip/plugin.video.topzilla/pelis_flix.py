# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""Modo Cine: ventana hero + filas estilo Netflix, con toggle Cine/Series."""
import json
import os
import random
import sys
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

import core_settings
import movie_favorites
import pelis_grid  # capa de datos: reutilizamos _LOADERS y _normalize
import yt_resolve

_ADDON_PATH = xbmcaddon.Addon().getAddonInfo('path')
_LOG = '[TopZilla-Flix]'

_ID_HERO = 200
_ID_LOADING = 500
_ID_BTN_CLOSE = 100
_ID_BTN_MODE = 110
_ID_BTN_SEARCH = 111
_ID_BTN_SURPRISE = 112
_ID_ROW_BASE = 310  # filas 310..(310+MAX_ROWS-1)

MAX_ROWS = 34
MAX_CONCURRENCY = 5
_MAX_PER_ROW = 14
_MAX_HERO = 5
_LAZY_INITIAL = 6      # filas que carga al abrir en modo lazy (el resto, al hacer scroll)
_LAZY_SKELETON = 5     # cards placeholder por fila diferida (para que sea enfocable)
_FOCUS_POLL_MS = 200
_TRAILER_OPEN_TIMEOUT = 8  # si el stream no reproduce de verdad en este tiempo, se descarta
_TRAILER_ORPHAN_WINDOW = 120  # margen para parar un trailer que arranca tarde tras navegar
_TRAILER_PAUSE_SETTLE = 1.5  # segundos en pausa antes del stop real de un trailer (ver _stop_trailer):
                             # parar en seco un stream ISA joven cuelga ~20s (deja un fetch de segmento
                             # al proxy de plugin.video.youtube); pausar primero deja que ISA estabilice
                             # y entonces el stop cierra limpio (~0.1s).
_ENRICH_BATCH = 8
_STATE_PROP = 'topzilla_flix_state'  # window prop (sesión): modo + fila + película enfocada

MODE_CINE = 'movie'
MODE_SERIES = 'show'

_MOVE_ACTIONS = (
    xbmcgui.ACTION_MOVE_LEFT, xbmcgui.ACTION_MOVE_RIGHT,
    xbmcgui.ACTION_MOVE_UP, xbmcgui.ACTION_MOVE_DOWN,
    xbmcgui.ACTION_PAGE_UP, xbmcgui.ACTION_PAGE_DOWN,
)

# Catálogo maestro de filas. Cada entrada: id (estable, para persistir la selección),
# title, key (clave de pelis_grid._LOADERS), params, rank?, hero?, default (on por defecto).
# default=True solo en las filas que cambian con frecuencia; las casi estáticas (géneros,
# Oscar, "mejor valoradas") quedan disponibles pero apagadas, configurables desde Ajustes.
_CATALOG_CINE = [
    {'id': 'mis_favs',  'title': 'Mis Favoritos',       'key': 'movie_favorites', 'params': {'media_type': 'movie'}, 'default': True, 'volatile': True},
    {'id': 'continuar', 'title': 'Continuar viendo',    'key': 'continue_watching', 'params': {'media_type': 'movie'}, 'default': True, 'volatile': True},
    {'id': 'top10',     'title': 'Top 10 hoy',          'key': 'trakt', 'params': {'path': 'movies/watched/daily', 'media_type': 'movie'}, 'rank': True, 'hero': True, 'default': True},
    {'id': 'cartelera', 'title': 'En cartelera',        'key': 'filmaffinity_cartelera', 'params': {}, 'hero': True, 'default': True},
    {'id': 'estrenos',  'title': 'Próximos estrenos',   'key': 'sensacine_estrenos', 'params': {}, 'default': True},
    {'id': 'populares', 'title': 'Populares ahora',     'key': 'cinemeta_top', 'params': {}, 'hero': True, 'default': True},
    {'id': 'tendencia', 'title': 'Tendencia',           'key': 'trakt', 'params': {'path': 'movies/trending', 'media_type': 'movie'}, 'hero': True, 'default': True},
    {'id': 'taquilla',  'title': 'Taquilla USA',        'key': 'trakt', 'params': {'path': 'movies/boxoffice', 'media_type': 'movie'}, 'default': False},
    {'id': 'netflix',   'title': 'En Netflix',          'key': 'streaming', 'params': {'provider_id': '8', 'media_type': 'movie'}, 'default': True},
    {'id': 'prime',     'title': 'En Prime Video',      'key': 'streaming', 'params': {'provider_id': '119', 'media_type': 'movie'}, 'default': True},
    {'id': 'disney',    'title': 'En Disney+',          'key': 'streaming', 'params': {'provider_id': '337', 'media_type': 'movie'}, 'default': True},
    {'id': 'max',       'title': 'En Max',              'key': 'streaming', 'params': {'provider_id': '1899', 'media_type': 'movie'}, 'default': True},
    {'id': 'movistar',  'title': 'En Movistar Plus+',   'key': 'streaming', 'params': {'provider_id': '149', 'media_type': 'movie'}, 'default': True},
    {'id': 'apple',     'title': 'En Apple TV+',        'key': 'streaming', 'params': {'provider_id': '350', 'media_type': 'movie'}, 'default': True},
    {'id': 'valoradas', 'title': 'Mejor valoradas',     'key': 'filmaffinity_top', 'params': {}, 'default': False},
    {'id': 'g_accion',  'title': 'Acción',              'key': 'filmaffinity_list', 'params': {'genre': 'movie:28'}, 'default': False},
    {'id': 'g_terror',  'title': 'Terror',              'key': 'filmaffinity_list', 'params': {'genre': 'movie:27'}, 'default': False},
    {'id': 'g_comedia', 'title': 'Comedia',             'key': 'filmaffinity_list', 'params': {'genre': 'movie:35'}, 'default': False},
    {'id': 'g_scifi',   'title': 'Ciencia ficción',     'key': 'filmaffinity_list', 'params': {'genre': 'movie:878'}, 'default': False},
    {'id': 'g_drama',   'title': 'Drama',               'key': 'filmaffinity_list', 'params': {'genre': 'movie:18'}, 'default': False},
    {'id': 'g_thriller','title': 'Thriller',            'key': 'filmaffinity_list', 'params': {'genre': 'movie:53'}, 'default': False},
    {'id': 'g_animacion','title': 'Animación',          'key': 'filmaffinity_list', 'params': {'genre': 'movie:16'}, 'default': False},
    {'id': 'g_aventura','title': 'Aventura',            'key': 'filmaffinity_list', 'params': {'genre': 'movie:12'}, 'default': False},
    {'id': 'g_fantasia','title': 'Fantasía',            'key': 'filmaffinity_list', 'params': {'genre': 'movie:14'}, 'default': False},
    {'id': 'g_documental','title': 'Documental',        'key': 'filmaffinity_list', 'params': {'genre': 'movie:99'}, 'default': False},
    {'id': 'g_musical', 'title': 'Musical',             'key': 'filmaffinity_list', 'params': {'genre': 'movie:10402'}, 'default': False},
    {'id': 'g_western',  'title': 'Western',            'key': 'filmaffinity_list', 'params': {'genre': 'movie:37'}, 'default': False},
    {'id': 'anticipadas','title': 'Más esperadas',      'key': 'trakt', 'params': {'path': 'movies/anticipated', 'media_type': 'movie'}, 'default': False},
    {'id': 'favoritas', 'title': 'Más favoritas',       'key': 'trakt', 'params': {'path': 'movies/favorited/daily', 'media_type': 'movie'}, 'default': False},
    {'id': 'tendencia_sem','title': 'Tendencia semanal','key': 'tmdb_list', 'params': {'endpoint': 'trending/movie/week', 'media_type': 'movie'}, 'default': False},
    {'id': 'populares_tmdb','title': 'Populares (TMDB)', 'key': 'tmdb_list', 'params': {'endpoint': 'movie/popular', 'media_type': 'movie'}, 'default': False},
    {'id': 'anime_trend','title': 'Anime en tendencia', 'key': 'anime_anilist', 'params': {'sort_key': 'anilist_trending'}, 'default': False},
    {'id': 'anime_pop', 'title': 'Anime más popular',   'key': 'anime_anilist', 'params': {'sort_key': 'anilist_popular'}, 'default': False},
    {'id': 'anime_top', 'title': 'Anime mejor valorado','key': 'anime_anilist', 'params': {'sort_key': 'anilist_top'}, 'default': False},
    {'id': 'anime_temp','title': 'Anime de temporada',  'key': 'anime_anilist', 'params': {'sort_key': 'anilist_seasonal'}, 'default': False},
    {'id': 'oscar',     'title': 'Ganadoras del Oscar', 'key': 'oscar', 'params': {}, 'default': False},
]

_CATALOG_SERIES = [
    {'id': 'mis_favs',       'title': 'Mis Favoritos',     'key': 'movie_favorites', 'params': {'media_type': 'show'}, 'default': True, 'volatile': True},
    {'id': 'continuar',      'title': 'Continuar viendo',  'key': 'continue_watching', 'params': {'media_type': 'show'}, 'default': True, 'volatile': True},
    {'id': 'top10',          'title': 'Top 10 hoy',        'key': 'trakt', 'params': {'path': 'shows/watched/daily', 'media_type': 'show'}, 'rank': True, 'hero': True, 'default': True},
    {'id': 'tendencia',      'title': 'Tendencia',         'key': 'trakt', 'params': {'path': 'shows/trending', 'media_type': 'show'}, 'hero': True, 'default': True},
    {'id': 'populares',      'title': 'Populares',         'key': 'trakt', 'params': {'path': 'shows/popular', 'media_type': 'show', 'wrapped': 'false'}, 'hero': True, 'default': False},
    {'id': 'tendencia_tmdb', 'title': 'Tendencia (TMDB)',  'key': 'tmdb_list', 'params': {'endpoint': 'trending/tv/day', 'media_type': 'show'}, 'default': True},
    {'id': 'netflix',        'title': 'En Netflix',        'key': 'streaming', 'params': {'provider_id': '8', 'media_type': 'show'}, 'default': True},
    {'id': 'prime',          'title': 'En Prime Video',    'key': 'streaming', 'params': {'provider_id': '119', 'media_type': 'show'}, 'default': True},
    {'id': 'disney',         'title': 'En Disney+',        'key': 'streaming', 'params': {'provider_id': '337', 'media_type': 'show'}, 'default': True},
    {'id': 'max',            'title': 'En Max',            'key': 'streaming', 'params': {'provider_id': '1899', 'media_type': 'show'}, 'default': True},
    {'id': 'movistar',       'title': 'En Movistar Plus+', 'key': 'streaming', 'params': {'provider_id': '149', 'media_type': 'show'}, 'default': True},
    {'id': 'apple',          'title': 'En Apple TV+',      'key': 'streaming', 'params': {'provider_id': '350', 'media_type': 'show'}, 'default': True},
    {'id': 'valoradas',      'title': 'Top valoradas',     'key': 'tmdb_list', 'params': {'endpoint': 'tv/top_rated', 'media_type': 'show'}, 'default': False},
    {'id': 'populares_tmdb', 'title': 'Series populares',  'key': 'tmdb_list', 'params': {'endpoint': 'tv/popular', 'media_type': 'show'}, 'default': False},
    {'id': 'en_emision',     'title': 'En emisión',        'key': 'tmdb_list', 'params': {'endpoint': 'tv/on_the_air', 'media_type': 'show'}, 'default': False},
    {'id': 'emiten_hoy',     'title': 'Emiten hoy',        'key': 'tmdb_list', 'params': {'endpoint': 'tv/airing_today', 'media_type': 'show'}, 'default': False},
    {'id': 'tendencia_sem',  'title': 'Tendencia semanal', 'key': 'tmdb_list', 'params': {'endpoint': 'trending/tv/week', 'media_type': 'show'}, 'default': False},
    {'id': 'anticipadas',    'title': 'Más esperadas',     'key': 'trakt', 'params': {'path': 'shows/anticipated', 'media_type': 'show'}, 'default': False},
    {'id': 'favoritas',      'title': 'Más favoritas',     'key': 'trakt', 'params': {'path': 'shows/favorited/daily', 'media_type': 'show'}, 'default': False},
    {'id': 'sg_drama',       'title': 'Drama',             'key': 'filmaffinity_list', 'params': {'genre': 'tv:18'}, 'default': False},
    {'id': 'sg_comedia',     'title': 'Comedia',           'key': 'filmaffinity_list', 'params': {'genre': 'tv:35'}, 'default': False},
    {'id': 'sg_crimen',      'title': 'Crimen',            'key': 'filmaffinity_list', 'params': {'genre': 'tv:80'}, 'default': False},
    {'id': 'sg_accion',      'title': 'Acción y aventura', 'key': 'filmaffinity_list', 'params': {'genre': 'tv:10759'}, 'default': False},
    {'id': 'sg_scifi',       'title': 'Ciencia ficción y fantasía', 'key': 'filmaffinity_list', 'params': {'genre': 'tv:10765'}, 'default': False},
    {'id': 'sg_animacion',   'title': 'Animación',         'key': 'filmaffinity_list', 'params': {'genre': 'tv:16'}, 'default': False},
    {'id': 'sg_misterio',    'title': 'Misterio',          'key': 'filmaffinity_list', 'params': {'genre': 'tv:9648'}, 'default': False},
    {'id': 'sg_documental',  'title': 'Documental',        'key': 'filmaffinity_list', 'params': {'genre': 'tv:99'}, 'default': False},
    {'id': 'anime_trend',    'title': 'Anime en tendencia','key': 'anime_anilist', 'params': {'sort_key': 'anilist_trending'}, 'default': False},
    {'id': 'anime_pop',      'title': 'Anime más popular', 'key': 'anime_anilist', 'params': {'sort_key': 'anilist_popular'}, 'default': False},
    {'id': 'anime_top',      'title': 'Anime mejor valorado', 'key': 'anime_anilist', 'params': {'sort_key': 'anilist_top'}, 'default': False},
    {'id': 'anime_temp',     'title': 'Anime de temporada','key': 'anime_anilist', 'params': {'sort_key': 'anilist_seasonal'}, 'default': False},
]


def catalog_for(mode):
    import category_manager
    base = _CATALOG_CINE if mode == MODE_CINE else _CATALOG_SERIES
    media_type = 'movie' if mode == MODE_CINE else 'show'
    cats = category_manager.load_cats()
    extra = []
    for name in sorted(cats.keys()):
        if not any(r.get('media_type', 'movie') == media_type for r in cats[name]):
            continue
        extra.append({
            'id': f'cat__{name}',
            'title': name,
            'key': 'custom_category',
            'params': {'cat_name': name, 'media_type': media_type},
            'default': False,
            'volatile': True,
        })
    return base[:1] + extra + base[1:]


def default_ids(catalog):
    return [r['id'] for r in catalog if r.get('default')]


def build_rows(mode):
    """Lista efectiva de filas para el modo: selección guardada por el usuario, o los
    defaults. Filtra ids inválidos, capa a MAX_ROWS y nunca devuelve vacío."""
    catalog = catalog_for(mode)
    by_id = {r['id']: r for r in catalog}
    has_favs = bool(movie_favorites.get_movie_favorites(mode))
    import continue_watching
    has_cw = continue_watching.has_sources(mode)

    def _pick(ids):
        # "Mis Favoritos" y "Continuar viendo" son filas normales (activables desde
        # Ajustes), pero solo se muestran si tienen fuente: no enseñamos una fila vacía.
        def _ok(i):
            if i == 'mis_favs':
                return has_favs
            if i == 'continuar':
                return has_cw
            return True
        return [by_id[i] for i in ids if i in by_id and _ok(i)]

    rows = _pick(core_settings.load_flix_rows(mode) or default_ids(catalog))
    if not rows:  # p.ej. el usuario dejó solo "Mis Favoritos" y no tiene ninguno: no atascar
        rows = _pick(default_ids(catalog))
    return rows[:MAX_ROWS]


def _hero_indices(cfg):
    return [i for i, r in enumerate(cfg) if r.get('hero')]


def _rating_val(m):
    try:
        return float(m.get('rating') or 0)
    except (TypeError, ValueError):
        return 0.0


def _sub_line(m):
    parts = []
    if m.get('year'):
        parts.append(str(m['year']))
    r = _rating_val(m)
    if r > 0:
        parts.append(f'★ {r:.1f}')
    return ' · '.join(parts)


def _meta_line(m):
    parts = []
    if m.get('year'):
        parts.append(str(m['year']))
    r = _rating_val(m)
    if r > 0:
        parts.append(f'★ {r:.1f}')
    rt = int(m.get('runtime') or 0)
    if rt > 0:
        parts.append(f'{rt} min')
    return ' · '.join(parts)


def _apply_props(li, m, hero=False, rank=''):
    poster = m.get('poster', '')
    fanart = m.get('fanart') or poster
    r = _rating_val(m)
    li.setProperty('f_poster', poster)
    li.setProperty('f_title', m.get('title', ''))
    li.setProperty('f_sub', _sub_line(m))
    li.setProperty('f_meta', _meta_line(m))
    li.setProperty('f_plot', m.get('plot', ''))
    li.setProperty('f_genre', m.get('genre', ''))
    li.setProperty('f_director', m.get('director', ''))
    li.setProperty('f_cast', m.get('cast_str', ''))
    li.setProperty('f_year', str(m.get('year') or ''))
    li.setProperty('f_rating', f'{r:.1f}' if r > 0 else '')
    li.setProperty('f_rank', rank)
    li.setProperty('f_fanart', fanart)
    li.setProperty('f_tmdb_id', str(m.get('tmdb_id') or ''))
    li.setProperty('f_imdb_id', str(m.get('imdb_id') or ''))
    li.setProperty('f_runtime', str(int(m.get('runtime') or 0)))
    li.setProperty('f_media_type', m.get('media_type') or '')
    if hero:
        li.setProperty('f_landscape', fanart)


def _make_item(m, hero=False, rank=''):
    li = xbmcgui.ListItem(label=m.get('title', ''))
    _apply_props(li, m, hero=hero, rank=rank)
    return li


# ── snapshot en disco: filas ya enriquecidas por modo, para reabrir al instante ──
_snapshot_lock = threading.Lock()


def _snapshot_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(profile, 'topzilla_flix_cache.json')


def _load_snapshot(mode, current_ids):
    """Devuelve (rows_data, edad_segundos) del snapshot, o (None, None) si no hay/
    está corrupto/cambió la selección de filas. rows_data: dict {idx_fila: [dicts]}.
    El idx depende del orden de las filas activas, así que el snapshot solo vale si los
    ids guardados coinciden con los actuales (snapshots viejos sin 'ids' → se descartan)."""
    try:
        with open(_snapshot_path(), 'r', encoding='utf-8') as fh:
            data = json.load(fh)
    except (OSError, ValueError):
        return None, None
    entry = data.get(mode) or {}
    if entry.get('ids') != list(current_ids):
        return None, None
    rows = entry.get('rows')
    if not rows:
        return None, None
    try:
        rows_data = {int(k): v for k, v in rows.items()}
    except (TypeError, ValueError):
        return None, None
    return rows_data, time.time() - entry.get('ts', 0)


def _save_snapshot(mode, rows_data, ids):
    rows = {str(k): v for k, v in rows_data.items() if v}
    if not rows:
        return
    with _snapshot_lock:
        try:
            with open(_snapshot_path(), 'r', encoding='utf-8') as fh:
                data = json.load(fh)
        except (OSError, ValueError):
            data = {}
        data[mode] = {'ts': time.time(), 'ids': list(ids), 'rows': rows}
        path = _snapshot_path()
        tmp = path + '.tmp'
        try:
            with open(tmp, 'w', encoding='utf-8') as fh:
                json.dump(data, fh, ensure_ascii=False)
            os.replace(tmp, path)  # atómico: la lectura nunca ve un archivo a medias
        except (OSError, TypeError, ValueError) as e:
            xbmc.log(f'{_LOG} snapshot save: {e}', xbmc.LOGWARNING)
            try:
                os.remove(tmp)
            except OSError:
                pass


class PelisFlix(xbmcgui.WindowXMLDialog):

    def __init__(self, xml, addon_path, skin, res, addon_url='', search_fn=None, initial_mode=None):
        super().__init__(xml, addon_path, skin, res)
        self._addon_url = addon_url or sys.argv[0]
        self._search_fn = search_fn
        self._pending_trailer_key = ''  # tráiler a reproducir tras cerrar (ver show())
        # Estado de la última sesión (modo/fila/película) para restaurar el foco al reabrir.
        # Toggle leído una vez: si está off, ni guardamos ni restauramos (abre en hero/Cine).
        self._remember_pos = core_settings.is_flix_remember_pos_enabled()
        saved = self._load_state() if self._remember_pos else None
        self._restore_state = saved
        if initial_mode in (MODE_CINE, MODE_SERIES):
            # El botón "Modo Cine"/"Modo Series" manda en el modo; la posición guardada
            # solo se restaura si es de ese mismo modo (si no, abre en el hero).
            self._mode = initial_mode
            if not (saved and saved.get('mode') == initial_mode):
                self._restore_state = None
        else:
            self._mode = saved['mode'] if saved and saved.get('mode') in (MODE_CINE, MODE_SERIES) else MODE_CINE
        self._mode_token = 0
        self._cache = {}          # mode -> {idx: [dicts normalizados]}
        self._loaded_modes = set()
        self._loaded_ids = {}     # mode -> tuple(ids) cacheados: el caché indexa por posición,
                                  # así que solo es reusable si las filas activas no cambiaron
        self._rows_data = {}      # alias al dict del modo actual
        self._pending = 0         # filas que faltan por cargar en la carga en curso
        self._hero_pos = {}       # (idx_fila, pos) -> índice de card en el hero
        self._hero_seeded = False
        self._loaded = False
        self._user_moved = False
        self._closing = False
        self._lock = threading.Lock()
        self._active_rows = []    # filas efectivas del modo actual (calculadas 1 vez/carga)
        self._lazy = False        # carga perezosa por scroll (opt-in en Opciones)
        self._row_loaded = set()  # idx de filas ya cargadas (modo lazy)
        self._row_loading = set() # idx de filas cargándose ahora (modo lazy)
        self._trailer_active = False
        self._trailer_started = 0.0    # time.time() del último _start_trailer
        self._pending_stop_at = 0.0    # time.time() de una pausa pendiente de stop diferido (anti-cuelgue ISA)
        self._trailer_gen = 0          # se incrementa al parar: invalida resoluciones yt-dlp en curso
        self._trailer_pending_key = None  # foco para el que ya hay resolver en curso
        self._trailer_resolved = {}    # foco -> youtube_key ('' = sin trailer)
        _tcfg = core_settings.load_trailer_config()
        self._trailers_enabled = _tcfg['enabled']
        self._hide_busy = _tcfg['hide_busy']
        self._trailer_hover_s = _tcfg['hover_s']
        self._trailer_lang = _tcfg['lang']
        self._trailer_notify = _tcfg['notify']
        self._trailer_notice_shown = False  # el aviso de tráiler se muestra 1 vez por sesión

    def _cfg(self):
        return self._active_rows

    def _active_ids(self):
        return [r['id'] for r in self._active_rows]

    # ── ciclo de vida ──────────────────────────────────────────────────────
    def onInit(self):
        self.setProperty('focused_title', 'Cargando catálogo…')
        self.setProperty('focus_zone', 'hero')
        for p in ('focused_meta', 'focused_plot', 'focused_genre', 'focused_fanart', 'flix_loading'):
            self.setProperty(p, '')
        threading.Thread(target=self._focus_poll_loop, daemon=True).start()
        self._start_mode_load(self._mode)

    # ── carga por modo ─────────────────────────────────────────────────────
    def _start_mode_load(self, mode):
        # Filas efectivas del modo (selección del usuario o defaults). Se calcula ANTES de
        # decidir si reusar el caché: la presencia de "Mis Favoritos" puede cambiar entre
        # cargas (al añadir el primer / quitar el último favorito), y el caché en memoria
        # indexa por posición; reusarlo con otras filas pintaría datos desalineados (la fila
        # Mis Favoritos mostraría el Top 10, etc.). El resto del ciclo usa _cfg().
        active_rows = build_rows(mode)
        active_ids = tuple(r['id'] for r in active_rows)
        with self._lock:
            self._mode_token += 1
            token = self._mode_token
            self._mode = mode
            self._hero_pos = {}
            self._hero_seeded = False
            self._loaded = False
            self._lazy = core_settings.is_flix_lazy_enabled()
            self._row_loaded = set()
            self._row_loading = set()
            self._active_rows = active_rows
            in_memory = (mode in self._loaded_modes
                         and self._loaded_ids.get(mode) == active_ids)
            if in_memory:
                self._rows_data = self._cache[mode]
        cfg = self._active_rows
        self.setProperty('cur_mode_label', 'Modo Cine' if mode == MODE_CINE else 'Modo Series')
        self.setProperty('mode_label', 'Ver Series' if mode == MODE_CINE else 'Ver Cine')
        for k in range(MAX_ROWS):
            self.setProperty(f'row_title_{k}', cfg[k]['title'] if k < len(cfg) else '')

        # Ya cargado en esta sesión: pinta desde memoria, sin tocar disco ni red.
        if in_memory:
            threading.Thread(target=self._populate_from_cache, args=(token,), daemon=True).start()
            return

        # Snapshot en disco: pinta al instante; si está viejo, refresca en 2º plano
        # (tras pintar). Si no hay snapshot o falla, cae a la carga normal. En modo lazy
        # se omite: cargamos bajo demanda y dejamos que las cachés por-fuente eviten red.
        if not self._lazy:
            snap_rows, snap_age = _load_snapshot(mode, self._active_ids())
            if snap_rows:
                with self._lock:
                    if token != self._mode_token:
                        return
                    self._rows_data = snap_rows
                    self._cache[mode] = snap_rows
                fresh = snap_age is not None and snap_age < core_settings.get_snapshot_ttl()
                if fresh:
                    with self._lock:
                        self._loaded_modes.add(mode)
                        self._loaded_ids[mode] = tuple(self._active_ids())
                threading.Thread(target=self._populate_from_cache,
                                 args=(token, not fresh), daemon=True).start()
                return

        self._start_loaders(token, mode, cfg, background=False)

    def _start_loaders(self, token, mode, cfg, background):
        """Lanza los workers de carga. background=True actualiza sin tapar lo ya
        pintado (snapshot viejo); False muestra la pantalla 'Cargando catálogo…'.
        En modo lazy (solo foreground) carga las primeras filas; el resto bajo demanda."""
        lazy = self._lazy and not background
        initial = self._lazy_initial_count(cfg) if lazy else len(cfg)
        with self._lock:
            if token != self._mode_token:
                return
            if not background:
                self._rows_data = {}
                self._cache[mode] = self._rows_data
            # En background conservamos las filas del snapshot ya pintadas; cada worker
            # solo sustituye la suya si trae datos (un fallo transitorio no las borra).
            self._pending = initial
            if lazy:
                # Marca las iniciales como cargando: evita que _ensure_row (al enfocar
                # una fila inicial aún en vuelo) lance un segundo worker para la misma.
                self._row_loading.update(range(initial))
            if background:
                # las filas top pueden cambiar: re-sembrar el hero con datos frescos
                self._hero_seeded = False
                self._hero_pos = {}
        if background:
            self.setProperty('flix_loading', 'Actualizando…')
        else:
            self._set_loading('Cargando catálogo…')
        # Filas diferidas: placeholders enfocables (una lista vacía no recibe foco, así
        # que sin esto no se podría hacer scroll hasta ellas para dispararlas).
        if lazy:
            for idx in range(initial, len(cfg)):
                self._populate_skeleton(idx)
        sem = threading.Semaphore(MAX_CONCURRENCY)
        for idx in range(initial):
            threading.Thread(target=self._row_worker, args=(token, idx, cfg[idx], sem), daemon=True).start()

    def _row_worker(self, token, idx, row, sem):
        with sem:
            if self._closing or token != self._mode_token:
                return
            movies = []
            loader = pelis_grid._LOADERS.get(row['key'])
            if loader is None:
                xbmc.log(f"{_LOG} loader desconocido: {row['key']}", xbmc.LOGWARNING)
            else:
                try:
                    movies = loader(row.get('params') or {}) or []
                except Exception as e:
                    xbmc.log(f"{_LOG} fila {idx} ({row['key']}) error: {e}", xbmc.LOGWARNING)
            movies = movies[:_MAX_PER_ROW]

        if self._closing or token != self._mode_token:
            return
        with self._lock:
            if token != self._mode_token:
                return
            if movies or idx not in self._rows_data:
                self._rows_data[idx] = movies
            else:
                # refresco en background que vino vacío: conserva lo que ya había
                movies = self._rows_data.get(idx) or []
            self._row_loaded.add(idx)
            self._row_loading.discard(idx)
            self._pending -= 1
            done = self._pending <= 0
        xbmc.log(f"{_LOG} fila {idx} ({row['key']}): {len(movies)} items", xbmc.LOGINFO)
        self._populate_row(token, idx, row, movies)
        self._maybe_seed_hero(token)
        if done:
            self._on_mode_loaded(token)

    # ── carga perezosa por scroll (opt-in) ─────────────────────────────────
    def _lazy_initial_count(self, cfg):
        # al menos _LAZY_INITIAL; nunca cortar antes de la última fila hero
        last_hero = max((i for i, r in enumerate(cfg) if r.get('hero')), default=-1)
        return min(len(cfg), max(_LAZY_INITIAL, last_hero + 1))

    def _populate_skeleton(self, idx):
        """Pinta cards vacías en una fila diferida para que sea enfocable hasta que
        se cargue de verdad. Sin items reales: no descarga imágenes."""
        if idx >= MAX_ROWS:
            return
        items = [xbmcgui.ListItem(label='') for _ in range(_LAZY_SKELETON)]
        try:
            ctrl = self.getControl(_ID_ROW_BASE + idx)
            ctrl.reset()
            ctrl.addItems(items)
        except Exception as e:
            xbmc.log(f'{_LOG} skeleton fila {idx}: {e}', xbmc.LOGWARNING)

    def _ensure_row(self, token, idx):
        """Carga una fila diferida bajo demanda (al enfocarla). No-op si no es lazy,
        si ya está cargada/cargándose, o si ya tiene datos (p.ej. del caché en memoria)."""
        if not self._lazy or self._closing or token != self._mode_token:
            return
        cfg = self._cfg()
        if not (0 <= idx < len(cfg)):
            return
        with self._lock:
            if idx in self._row_loaded or idx in self._row_loading:
                return
            if self._rows_data.get(idx):
                self._row_loaded.add(idx)
                return
            self._row_loading.add(idx)
        threading.Thread(target=self._lazy_row_worker,
                         args=(token, idx, cfg[idx]), daemon=True).start()

    def _lazy_row_worker(self, token, idx, row):
        movies = []
        loader = pelis_grid._LOADERS.get(row['key'])
        if loader is None:
            xbmc.log(f"{_LOG} loader desconocido: {row['key']}", xbmc.LOGWARNING)
        else:
            try:
                movies = loader(row.get('params') or {}) or []
            except Exception as e:
                xbmc.log(f"{_LOG} fila {idx} ({row['key']}) lazy error: {e}", xbmc.LOGWARNING)
        movies = movies[:_MAX_PER_ROW]
        if self._closing or token != self._mode_token:
            return
        with self._lock:
            if token != self._mode_token:
                return
            self._rows_data[idx] = movies
            self._row_loading.discard(idx)
            self._row_loaded.add(idx)
        xbmc.log(f"{_LOG} fila {idx} ({row['key']}) lazy: {len(movies)} items", xbmc.LOGINFO)
        self._populate_row(token, idx, row, movies)
        self._maybe_seed_hero(token)
        self._enrich_rows(token, [idx])

    def _on_mode_loaded(self, token):
        if token != self._mode_token:
            return
        with self._lock:
            self._loaded_modes.add(self._mode)
            self._loaded_ids[self._mode] = tuple(self._active_ids())
            any_data = any(self._rows_data.get(i) for i in range(len(self._active_rows)))
        self._loaded = True
        if any_data:
            try:
                self.getControl(_ID_LOADING).setVisible(False)
            except Exception:
                pass
        else:
            self._set_loading('[COLOR orange]No hay contenido disponible. Revisa tu conexión.[/COLOR]')
        self.setProperty('flix_loading', '')
        self._maybe_seed_hero(token, force=True)
        self._refresh_focus_props()
        # El snapshot lo escribe _lazy_enrich_all al terminar (única vía: evita la carrera
        # de que el guardado base pisara al enriquecido). Guarda aunque no haya nada que
        # enriquecer, así que el snapshot queda siempre actualizado.
        threading.Thread(target=self._lazy_enrich_all, args=(token,), daemon=True).start()

    def _populate_from_cache(self, token, then_refresh=False):
        cfg = self._cfg()
        rows = self._rows_data  # referencia estable: el refresco posterior reasigna self._rows_data
        for idx in range(len(cfg)):
            if self._closing or token != self._mode_token:
                return
            data = rows.get(idx)
            # Lazy: una fila NUNCA cargada (diferida pendiente, p.ej. al volver de otro
            # modo) necesita placeholder para seguir enfocable y recargable por scroll.
            # Una que cargó vacía ([]) se deja vacía, igual que en no-lazy.
            if data is None and self._lazy:
                self._populate_skeleton(idx)
            else:
                self._populate_row(token, idx, cfg[idx], data or [])
        self._loaded = True
        try:
            self.getControl(_ID_LOADING).setVisible(False)
        except Exception:
            pass
        self._maybe_seed_hero(token, force=True)
        self._refresh_focus_props()
        if then_refresh and not self._closing and token == self._mode_token:
            # Snapshot viejo (caducado): se refresca entero en 2º plano sin pisar lo pintado.
            self._start_loaders(token, self._mode, cfg, background=True)
        else:
            # Snapshot reciente o repintado en memoria: el grueso ya está pintado al
            # instante; solo reintentamos las filas que quedaron vacías (un fallo
            # transitorio), sin recargar todo y sin perder el pintado instantáneo.
            self._retry_empty_rows(token)

    def _retry_empty_rows(self, token):
        """Recarga en 2º plano SOLO las filas sin datos (p.ej. una que falló al guardarse
        el snapshot, o cartelera con un 403 puntual). No toca las que ya tienen contenido,
        así el repintado sigue siendo instantáneo. No-op en lazy (ahí van por scroll)."""
        if self._lazy or self._closing or token != self._mode_token:
            return
        cfg = self._cfg()
        with self._lock:
            empty = [i for i in range(len(cfg))
                     if not self._rows_data.get(i) and i not in self._row_loading]
            self._row_loading.update(empty)
        for idx in empty:
            threading.Thread(target=self._lazy_row_worker,
                             args=(token, idx, cfg[idx]), daemon=True).start()

    def _populate_row(self, token, idx, row, movies):
        if self._closing or token != self._mode_token or idx >= MAX_ROWS:
            return
        is_rank = bool(row.get('rank'))
        items = [_make_item(m, rank=(str(pos + 1) if is_rank else ''))
                 for pos, m in enumerate(movies)]
        try:
            ctrl = self.getControl(_ID_ROW_BASE + idx)
            ctrl.reset()
            if items:
                ctrl.addItems(items)
                self._loaded = True
            # Colapsa la fila si cargó sin items (mismo contrato de skin que
            # _reload_volatile_row): row_title vacío oculta el grupo, así no queda una
            # franja con título y sin cards. Caso real: "Continuar viendo" con Trakt
            # vinculado pero nada en progreso ni marcado. Si trae items, (re)pone título.
            self.setProperty(f'row_title_{idx}', row.get('title', '') if movies else '')
        except Exception as e:
            xbmc.log(f'{_LOG} fila {idx} populate: {e}', xbmc.LOGWARNING)

    def _maybe_seed_hero(self, token, force=False):
        if self._closing or token != self._mode_token:
            return
        with self._lock:
            if self._hero_seeded:
                return
            cfg = self._cfg()
            ready = [i for i in _hero_indices(cfg) if self._rows_data.get(i)]
            if not force and len(ready) < 2:
                return
            if not ready:
                ready = [i for i in range(len(cfg)) if self._rows_data.get(i)]
                if not ready:
                    return
            # Hero = los títulos distintos más destacados. Las filas top (más visto,
            # tendencia, populares) suelen compartir el #1, así que en vez de repetirlo
            # recorremos por posición (0 de cada fila, luego 1 de cada fila…) y vamos
            # cogiendo títulos no vistos hasta llenar el hero. Guardamos (fila, pos) para
            # poder enriquecer luego la card correcta.
            seen = set()
            hero_src = []  # (idx_fila, pos)
            maxlen = max((len(self._rows_data.get(i) or []) for i in ready), default=0)
            for pos in range(maxlen):
                for i in ready:
                    row = self._rows_data.get(i) or []
                    if pos >= len(row):
                        continue
                    m = row[pos]
                    key = m.get('tmdb_id') or m.get('imdb_id') or m.get('title') or ''
                    if key and key in seen:
                        continue
                    if key:
                        seen.add(key)
                    hero_src.append((i, pos))
                    if len(hero_src) >= _MAX_HERO:
                        break
                if len(hero_src) >= _MAX_HERO:
                    break
            self._hero_seeded = True
            self._hero_pos = {src: k for k, src in enumerate(hero_src)}
            snapshot = [self._rows_data[i][pos] for i, pos in hero_src]

        hero_items = [_make_item(m, hero=True) for m in snapshot]
        try:
            hctrl = self.getControl(_ID_HERO)
            hctrl.reset()
            hctrl.addItems(hero_items)
        except Exception as e:
            xbmc.log(f'{_LOG} hero populate: {e}', xbmc.LOGWARNING)

        if not self._user_moved:
            if not (self._restore_state and self._try_restore_focus()):
                try:
                    self.setFocusId(_ID_HERO)
                except Exception:
                    pass
            # Consumir: solo restauramos en la primera siembra; tras un toggle de
            # modo el foco va al hero como siempre.
            self._restore_state = None
        self._refresh_focus_props()

    def _enrich_rows(self, token, indices):
        """Rellena en segundo plano póster/fanart/datos de los items incompletos de las
        filas indicadas (las fuentes traen use_cache_only=True). Solo muta propiedades de
        ListItems ya creados. Abandona si el modo cambió (token)."""
        import metadata_enricher as me
        monitor = xbmc.Monitor()
        cfg = self._cfg()
        pending = []
        for idx in indices:
            for pos, m in enumerate(self._rows_data.get(idx, [])):
                if m.get('skip_enrich'):
                    continue
                if not m.get('poster') or not m.get('director'):
                    pending.append((idx, pos, m))
        if pending:
            self.setProperty('flix_loading', 'Cargando carátulas…')
        try:
            for i in range(0, len(pending), _ENRICH_BATCH):
                if self._closing or token != self._mode_token or monitor.abortRequested():
                    return
                batch = pending[i:i + _ENRICH_BATCH]
                items = [{
                    'imdb_id': m.get('imdb_id') or None,
                    'tmdb_id': m.get('tmdb_id') or None,
                    'title': m.get('title'),
                    'year': int(m['year']) if str(m.get('year', '')).isdigit() else None,
                    'media_type': m.get('media_type', 'movie'),
                } for _, _, m in batch]
                try:
                    results = me.batch_enrich(items, use_cache_only=False, max_workers=4)
                except Exception:
                    results = [None] * len(batch)
                if self._closing or token != self._mode_token:
                    return
                for (idx, pos, m), meta in zip(batch, results):
                    if not meta:
                        continue
                    # La fila pudo recargarse mientras enriquecíamos (p.ej. una volátil
                    # como "Mis Favoritos" tras un alta/baja): si el item ya no es el mismo
                    # objeto en su sitio, pintarlo cruzaría datos sobre otra película.
                    current = self._rows_data.get(idx)
                    if not current or pos >= len(current) or current[pos] is not m:
                        continue
                    m.update(pelis_grid._normalize(m, meta))
                    if self._closing or token != self._mode_token:
                        return
                    rank = str(pos + 1) if (idx < len(cfg) and cfg[idx].get('rank')) else ''
                    try:
                        li = self.getControl(_ID_ROW_BASE + idx).getListItem(pos)
                        _apply_props(li, m, rank=rank)
                    except Exception:
                        pass
                    hc = self._hero_pos.get((idx, pos))
                    if hc is not None:
                        try:
                            hli = self.getControl(_ID_HERO).getListItem(hc)
                            _apply_props(hli, m, hero=True)
                        except Exception:
                            pass
                self._refresh_focus_props()
                if monitor.waitForAbort(0.3):
                    return
        finally:
            try:
                self.setProperty('flix_loading', '')
            except Exception:
                pass

    def _lazy_enrich_all(self, token):
        """Enriquece todas las filas cargadas y persiste el snapshot al terminar (única
        vía de guardado: evita que el guardado base pise al enriquecido). En modo lazy no
        se persiste el snapshot (estado parcial); las cachés por-fuente ya evitan red."""
        self._enrich_rows(token, range(len(self._cfg())))
        if self._lazy or self._closing or token != self._mode_token:
            return
        with self._lock:
            # Las filas volátiles (p.ej. "Mis Favoritos") no se cachean: deben reflejar
            # las altas/bajas al instante, así que se recargan del loader al reabrir.
            volatile = {i for i, r in enumerate(self._active_rows) if r.get('volatile')}
            rows_copy = {i: v for i, v in self._rows_data.items() if i not in volatile}
            ids = self._active_ids()
        _save_snapshot(self._mode, rows_copy, ids)

    # ── toggle Cine/Series ─────────────────────────────────────────────────
    def _clear_rows(self):
        """Vacía el hero y todas las filas (antes de recargar/reconstruir el modo)."""
        try:
            self.getControl(_ID_HERO).reset()
        except Exception:
            pass
        for k in range(MAX_ROWS):
            try:
                self.getControl(_ID_ROW_BASE + k).reset()
            except Exception:
                pass

    def _reload_mode(self, new_mode):
        """Limpia la pantalla y recarga el modo desde cero (cambio de modo, o alta/baja
        que hace aparecer/desaparecer la fila 'Mis Favoritos')."""
        self._stop_trailer()
        self._trailer_resolved.clear()
        self._trailer_pending_key = None
        self._clear_rows()
        self.setProperty('focused_title', 'Cargando catálogo…')
        self.setProperty('focus_zone', 'hero')
        for p in ('focused_plot', 'focused_metagenre', 'focused_credits', 'focused_fanart'):
            self.setProperty(p, '')
        self._start_mode_load(new_mode)

    def _toggle_mode(self):
        self._reload_mode(MODE_SERIES if self._mode == MODE_CINE else MODE_CINE)

    # ── interacción ────────────────────────────────────────────────────────
    def _focus_poll_loop(self):
        monitor = xbmc.Monitor()
        last = None
        hover_since = 0.0
        _cd_shown = ''
        while not self._closing and not monitor.abortRequested():
            try:
                key = self._focus_key()
                if key != last:
                    if self._trailer_active:
                        self._stop_trailer()
                    else:
                        # active=False pero un worker yt-dlp puede seguir resolviendo: en la
                        # ventana entre el revert por timeout y el re-anchor del worker, sin
                        # invalidar su gen reproduciría el tráiler anterior bajo el nuevo foco.
                        self._trailer_gen += 1
                    if key is not None:
                        self._refresh_focus_props()
                        if self._lazy and key[0] != _ID_HERO:
                            # Al enfocar una fila, carga esa y la siguiente (prefetch).
                            base = key[0] - _ID_ROW_BASE
                            self._ensure_row(self._mode_token, base)
                            self._ensure_row(self._mode_token, base + 1)
                    last = key
                    hover_since = time.time() if key is not None else 0.0
                    if _cd_shown:
                        self.setProperty('trailer_countdown', '')
                        _cd_shown = ''
                elif (self._trailers_enabled and key is not None and key[0] != _ID_HERO
                        and not self._trailer_active and hover_since
                        and time.time() - hover_since >= self._trailer_hover_s):
                    # Quieto Xs sobre un item de las filas (el videowindow solo es
                    # visible ahí): una sola comprobación, fuera de la ruta de
                    # navegación. El trailer se resuelve bajo demanda.
                    if _cd_shown:
                        self.setProperty('trailer_countdown', '')
                        _cd_shown = ''
                    resolved = self._trailer_resolved.get(key)
                    if resolved is not None:
                        if resolved:
                            self._start_trailer(resolved)
                        hover_since = 0.0  # resuelto (con o sin trailer): no reintentar
                    elif self._trailer_pending_key != key:
                        self._spawn_trailer_resolver(key)
                else:
                    if (self._trailers_enabled and key is not None
                            and not self._trailer_active and hover_since):
                        elapsed = time.time() - hover_since
                        if elapsed < self._trailer_hover_s:
                            remaining = int(self._trailer_hover_s - elapsed)
                            cd = f'{remaining + 1}s'
                            if cd != _cd_shown:
                                self.setProperty('trailer_countdown', cd)
                                _cd_shown = cd
                        elif _cd_shown:
                            self.setProperty('trailer_countdown', '')
                            _cd_shown = ''
                    elif _cd_shown:
                        self.setProperty('trailer_countdown', '')
                        _cd_shown = ''
                # Stop diferido tras pausa (ver _stop_trailer): el trailer joven se pausó para que
                # ISA estabilice su descarga; pasado el settle, lo paramos de verdad (teardown limpio).
                if self._pending_stop_at:
                    if time.time() - self._pending_stop_at >= _TRAILER_PAUSE_SETTLE:
                        xbmc.executebuiltin('PlayerControl(Stop)')
                        self._pending_stop_at = 0.0
                        # Limpia el marcador de arranque: si no, en la iteración siguiente el
                        # stream aún puede figurar como isPlayingVideo() (stop asíncrono) y el
                        # orphan-kill de abajo lo re-pausaría, encadenando otro settle.
                        self._trailer_started = 0.0
                else:
                    # Gestión del trailer en curso. Clave: NO parar mientras el stream solo se
                    # está "abriendo" (parar ahí bloquea el hilo de GUI de Kodi).
                    playing_video = xbmc.Player().isPlayingVideo()
                    if self._trailer_active:
                        if playing_video:
                            # Arrancó de verdad: ahora sí mostramos el vídeo (oculta el fanart).
                            if self.getProperty('trailer_playing') != 'true':
                                self.setProperty('trailer_playing', 'true')
                        elif time.time() - self._trailer_started >= _TRAILER_OPEN_TIMEOUT:
                            # No arrancó (stream atascado) o terminó: volver al fanart sin
                            # llamar a stop() (si solo está abriendo, stop congela la GUI;
                            # si terminó, ya está parado). ISA fallará solo en 2º plano.
                            self._revert_trailer_ui()
                    elif (self._trailer_started
                            and time.time() - self._trailer_started < _TRAILER_ORPHAN_WINDOW
                            and playing_video):
                        # Trailer huérfano que arrancó tarde tras navegar: ya reproduce de
                        # verdad, así que pararlo es seguro. La ventana temporal evita parar
                        # un vídeo que el usuario tuviera reproduciéndose antes de entrar.
                        self._stop_trailer()
            except Exception:
                pass
            if monitor.waitForAbort(_FOCUS_POLL_MS / 1000):
                break

    def _spawn_trailer_resolver(self, want_key):
        """Lanza un hilo que resuelve el trailer del item enfocado (solo red, sin
        tocar GUI). El resultado se consume en el poll loop, que sí reproduce."""
        li = self._focused_item()
        if li is None:
            return
        tmdb_id = li.getProperty('f_tmdb_id')
        if not tmdb_id:
            return  # aún sin enriquecer: reintentar cuando llegue el tmdb_id
        media_type = li.getProperty('f_media_type') or self._mode
        self._trailer_pending_key = want_key
        threading.Thread(target=self._trailer_resolver_worker,
                         args=(want_key, tmdb_id, media_type), daemon=True).start()

    def _trailer_resolver_worker(self, want_key, tmdb_id, media_type):
        import metadata_enricher as me
        yt = ''
        try:
            yt = me.get_trailer_key(tmdb_id, media_type, lang=self._trailer_lang) or ''
        except Exception as e:
            xbmc.log(f'{_LOG} trailer resolver: {e}', xbmc.LOGWARNING)
            yt = ''
        finally:
            self._trailer_resolved[want_key] = yt
            if self._trailer_pending_key == want_key:
                self._trailer_pending_key = None

    def _focused_row_control(self):
        """(cid, control) del hero o la fila enfocada, o (0, None) si no hay foco válido.
        Usa getFocusId() (devuelve 0 sin lanzar) en vez de getFocus(), que sí lanza
        (y Kodi loguea 'Non-Existent Control 0' a 5Hz) cuando el diálogo se queda sin
        foco (p.ej. al reproducir un tráiler; ver kodi/kodi#21593)."""
        cid = self.getFocusId()
        if cid != _ID_HERO and not (_ID_ROW_BASE <= cid < _ID_ROW_BASE + MAX_ROWS):
            return 0, None
        try:
            return cid, self.getControl(cid)
        except Exception:
            return 0, None

    def _focus_key(self):
        cid, ctrl = self._focused_row_control()
        if ctrl is None:
            return None
        try:
            return (cid, ctrl.getSelectedPosition())
        except Exception:
            return None

    def _refresh_focus_props(self):
        cid, ctrl = self._focused_row_control()
        if ctrl is None:
            return
        try:
            pos = ctrl.getSelectedPosition()
            if pos < 0:
                return
            li = ctrl.getListItem(pos)
            if li is None:
                return
            # Zona de foco: en filas se tapa el carrusel del hero con el fanart grande.
            self.setProperty('focus_zone', 'hero' if cid == _ID_HERO else 'row')
            self.setProperty('focused_title', li.getProperty('f_title') or li.getLabel() or '')
            self.setProperty('focused_plot', li.getProperty('f_plot') or '')
            # Meta (año·★·min, ámbar) + género (cian) en una sola línea del pie, con
            # colores embebidos para no perder la distinción al juntarlos.
            meta = li.getProperty('f_meta')
            genre = li.getProperty('f_genre')
            mg = []
            if meta:
                mg.append('[COLOR FFFBBF24]' + meta + '[/COLOR]')
            if genre:
                mg.append('[COLOR FF38BDF8]' + genre + '[/COLOR]')
            self.setProperty('focused_metagenre', '    ·    '.join(mg))
            director = li.getProperty('f_director')
            cast = li.getProperty('f_cast')
            credits = ' · '.join(p for p in (('Dir. ' + director) if director else '', cast) if p)
            self.setProperty('focused_credits', credits)
            self.setProperty('focused_fanart', li.getProperty('f_fanart') or li.getProperty('f_poster') or '')
        except Exception:
            pass

    def _set_loading(self, msg):
        try:
            ctrl = self.getControl(_ID_LOADING)
            ctrl.setLabel(msg)
            ctrl.setVisible(True)
        except Exception:
            pass

    def _start_trailer(self, key):
        # Si la ventana se está cerrando no arrancamos nada: el poll loop puede
        # llegar aquí en la misma iteración en que se pulsa Atrás (la ruta no-ytdlp
        # lanza PlayMedia de inmediato y quedaría reproduciendo a pantalla completa).
        if self._closing:
            return
        # No apilar reproducciones: si algo sigue reproduciéndose o abriéndose
        # (p.ej. un stream anterior atascado), no lanzamos otro.
        if xbmc.Player().isPlaying():
            return
        # Aviso al expirar el contador, antes de reproducir: informa de lo que va a pasar y
        # recuerda cómo apagarlo. Una vez por sesión (no en cada ficha que se sobrevuela) para
        # no spamear el browse; interruptor 'notify' en Opciones para silenciarlo del todo.
        if self._trailer_notify and not self._trailer_notice_shown:
            self._trailer_notice_shown = True
            xbmcgui.Dialog().notification(
                'Reproduciendo tráiler',
                'Si Kodi se bloquea, desactívalos en Opciones',
                xbmcgui.NOTIFICATION_INFO, 4000)
        # Flag windowed (,1) de PlayMedia: reproduce sin saltar a pantalla completa,
        # así el vídeo se queda dentro del control videowindow de la ventana.
        # trailer_playing NO se pone aquí: se pone en el poll loop cuando el vídeo
        # reproduce de verdad, para no enseñar una caja negra mientras "abre".
        self._trailer_active = True
        self._trailer_started = time.time()
        if yt_resolve.ytdlp_enabled():
            threading.Thread(target=self._ytdlp_trailer_worker,
                             args=(key, self._trailer_gen), daemon=True).start()
        else:
            url = f'plugin://plugin.video.youtube/play/?video_id={key}'
            xbmc.executebuiltin(f'PlayMedia({url},1)')
        if self._hide_busy:
            threading.Thread(target=self._suppress_busy_loop, daemon=True).start()

    def _ytdlp_trailer_worker(self, key, gen):
        # Resuelve la URL con yt-dlp (lento) fuera del hilo de GUI. Si el foco cambió
        # o la ventana se cerró durante la resolución (gen distinta), no reproduce: así
        # no se cuela un tráiler del item anterior (race) ni el error de bot en pantalla.
        # timeout = window del preview y sin impersonate: si yt-dlp no entrega a tiempo,
        # plugin.video.youtube es un respaldo más rápido que un segundo intento.
        url = yt_resolve.resolve_url(key, timeout=_TRAILER_OPEN_TIMEOUT,
                                     allow_impersonate=False)
        if self._closing or gen != self._trailer_gen:
            return
        if not url:
            # yt-dlp no resolvió: respaldo a plugin.video.youtube (windowed). Reanclamos
            # ambos flags porque el poll loop pudo poner _trailer_active=False al superar
            # _TRAILER_OPEN_TIMEOUT mientras yt-dlp trabajaba; sin ello, la orphan-logic
            # del poll loop mataría esta reproducción al verla con _trailer_active=False.
            self._trailer_active = True
            self._trailer_started = time.time()
            if self._closing or gen != self._trailer_gen:   # race re-anchor / PlayMedia
                return
            xbmc.executebuiltin(f'PlayMedia(plugin://plugin.video.youtube/play/?video_id={key},1)')
            if self._hide_busy:
                threading.Thread(target=self._suppress_busy_loop, daemon=True).start()
            return
        li = xbmcgui.ListItem(path=url)
        li.setContentLookup(False)
        if yt_resolve.is_hls(url):
            li.setMimeType('application/x-mpegURL')
        # Re-chequeo y reancla: la resolución pudo superar _TRAILER_OPEN_TIMEOUT y el
        # poll loop habría revertido la UI; reanclamos para que el orphan-logic no lo mate.
        if self._closing or gen != self._trailer_gen:
            return
        self._trailer_active = True
        self._trailer_started = time.time()
        if self._closing or gen != self._trailer_gen:   # race entre re-anchor y play()
            return
        xbmc.Player().play(url, li, True)  # windowed: dentro del videowindow, no fullscreen

    def _suppress_busy_loop(self):
        # "Truco" opcional: el plugin de YouTube tarda 1-3s en resolver el stream y
        # Kodi muestra su busy dialog (oscurece la pantalla). Lo cerramos en cuanto
        # aparece, hasta que el vídeo arranca. No es garantía: puede parpadear.
        monitor = xbmc.Monitor()
        deadline = time.time() + 10
        while not self._closing and time.time() < deadline:
            if (xbmc.getCondVisibility('Window.IsVisible(busydialognocancel)')
                    or xbmc.getCondVisibility('Window.IsVisible(busydialog)')):
                xbmc.executebuiltin('Dialog.Close(busydialognocancel,true)')
                xbmc.executebuiltin('Dialog.Close(busydialog,true)')
            if xbmc.Player().isPlaying():
                break
            if monitor.waitForAbort(0.1):
                break

    def _stop_trailer(self):
        # Invalida cualquier resolución yt-dlp en curso (cambio de foco / cierre): su
        # worker capturó la gen anterior y al terminar verá que cambió y no reproducirá.
        self._trailer_gen += 1
        if self._pending_stop_at:
            return  # ya pausado y esperando el stop diferido: no re-togglear la pausa
        # PAUSAR, no parar en seco: un stream ISA recién arrancado parado de golpe deja un fetch de
        # segmento al proxy de plugin.video.youtube colgado ~20s (cuelga la GUI). Al pausar, ISA deja
        # de pedir segmentos y se estabiliza; el poll loop hace el stop real tras _TRAILER_PAUSE_SETTLE
        # (teardown limpio ~0.1s). Revertimos la UI ya: el vídeo pausado queda oculto tras el fanart y
        # sin audio. Guard isPlayingVideo(): no togglear la pausa de un vídeo que solo se está abriendo.
        if xbmc.Player().isPlayingVideo():
            xbmc.Player().pause()
            self._pending_stop_at = time.time()
        self._revert_trailer_ui()

    def _revert_trailer_ui(self):
        self.setProperty('trailer_playing', '')
        self._trailer_active = False

    def _finish_pending_stop(self):
        """Completa de forma síncrona el stop diferido que dejó _stop_trailer (pausa +
        _pending_stop_at). Lo usan las rutas que matan el poll loop (cierre del modal,
        salto a tráiler fullscreen): el poll loop ya no va a rematar el stop, así que
        esperamos aquí el settle de la pausa (que ISA termine su fetch en vuelo) y
        paramos limpio (~0.1s) en vez de colgar la GUI ~20s al pararlo en seco. Bombea
        el event loop con xbmc.sleep hasta que el player se detiene de verdad."""
        if not self._pending_stop_at:
            return
        settle = self._pending_stop_at + _TRAILER_PAUSE_SETTLE
        while time.time() < settle:
            xbmc.sleep(50)
        xbmc.executebuiltin('PlayerControl(Stop)')
        self._pending_stop_at = 0.0
        self._trailer_started = 0.0
        deadline = time.time() + 0.5
        while xbmc.Player().isPlayingVideo() and time.time() < deadline:
            xbmc.sleep(20)

    def _open_item(self, title, poster, tmdb_id=''):
        if not title:
            return
        mode = 'movie' if self._mode == MODE_CINE else 'tv'
        if self._search_fn is not None:
            # Menú síncrono: cierra el Modo Cine vía _close_now solo si se navega
            # a resultados (no al cancelar ni en opciones que son meros diálogos).
            # El menú corre ahora en el hilo de GUI; antes lo aislaba el RunPlugin
            # (con catch-all en el router), así que aquí restauramos esa red.
            try:
                self._search_fn(title, poster, mode, tmdb_id=tmdb_id, on_navigate=self._close_now)
            except Exception as e:
                xbmc.log(f'{_LOG} _open_item search_fn error: {e}', xbmc.LOGERROR)
        else:
            url = core_settings.make_url(action='search_alt_prompt', q=title, ot=poster, mode=mode, tmdb_id=tmdb_id)
            xbmc.executebuiltin(f'RunPlugin({url})')

    def _focused_item(self):
        cid, ctrl = self._focused_row_control()
        if ctrl is None:
            return None
        try:
            pos = ctrl.getSelectedPosition()
            if pos < 0:
                return None
            return ctrl.getListItem(pos)
        except Exception:
            return None

    def _do_search(self):
        import remote_input
        text = remote_input.get_text_input('Buscar película o serie')
        if text:
            self._open_item(text, '')

    def _do_surprise(self):
        with self._lock:
            pool = [m for movies in self._rows_data.values() for m in movies]
        if not pool:
            xbmcgui.Dialog().notification('TopZilla', 'Aún cargando, prueba en un momento…',
                                          xbmcgui.NOTIFICATION_INFO, 2500)
            return
        m = random.choice(pool)
        self._open_item(m.get('title', ''), m.get('poster', ''), str(m.get('tmdb_id') or ''))

    def _close_now(self):
        if self._closing:   # idempotente: doble Back o re-entrada durante xbmc.sleep
            return
        self._closing = True
        self._save_state()
        self._stop_trailer()       # pausa el trailer en curso (si hay) y marca el stop diferido
        self._finish_pending_stop()  # remata el stop aquí: el poll loop ya no va a hacerlo
        self.close()

    def _load_state(self):
        try:
            raw = xbmcgui.Window(10000).getProperty(_STATE_PROP)
            data = json.loads(raw) if raw else None
        except (ValueError, TypeError):
            return None
        # La property puede traer JSON no-dict (corrupción / otra versión): no fiarse.
        return data if isinstance(data, dict) else None

    def _save_state(self):
        """Persiste modo + fila + película enfocada en una window property (sesión).
        Best-effort: se llama desde los puntos de cierre, así que un fallo aquí nunca
        debe impedir que el modal se cierre."""
        if not self._remember_pos:
            return
        try:
            state = {'mode': self._mode, 'row_id': 'hero', 'key': ''}
            cid = self.getFocusId()
            if _ID_ROW_BASE <= cid < _ID_ROW_BASE + MAX_ROWS:
                idx = cid - _ID_ROW_BASE
                cfg = self._cfg()
                data = self._rows_data.get(idx)
                if 0 <= idx < len(cfg) and data:
                    state['row_id'] = cfg[idx].get('id') or 'hero'
                    pos = self.getControl(cid).getSelectedPosition()
                    if 0 <= pos < len(data):
                        m = data[pos]
                        state['key'] = m.get('tmdb_id') or m.get('imdb_id') or m.get('title') or ''
            xbmcgui.Window(10000).setProperty(_STATE_PROP, json.dumps(state))
        except Exception as e:
            xbmc.log(f'{_LOG} _save_state: {e}', xbmc.LOGWARNING)

    def _try_restore_focus(self):
        """Pone el foco en la fila/película guardadas. Devuelve False si no se puede
        (fila inexistente, aún sin datos, o cualquier fallo): el llamador cae al hero.
        Corre en hilo daemon, así que captura todo para no abortar la carga."""
        try:
            st = self._restore_state or {}
            row_id = st.get('row_id')
            if not row_id or row_id == 'hero':
                return False
            cfg = self._cfg()
            idx = next((i for i, r in enumerate(cfg) if r.get('id') == row_id), None)
            if idx is None:
                return False
            data = self._rows_data.get(idx)
            if not data:
                return False
            key = st.get('key') or ''
            pos = 0
            if key:
                pos = next((p for p, m in enumerate(data)
                            if (m.get('tmdb_id') or m.get('imdb_id') or m.get('title') or '') == key), 0)
            cid = _ID_ROW_BASE + idx
            self.getControl(cid).selectItem(pos)
            self.setFocusId(cid)
            return True
        except Exception as e:
            xbmc.log(f'{_LOG} _try_restore_focus: {e}', xbmc.LOGWARNING)
            return False

    def _show_info_menu(self):
        if not self._loaded:
            return
        li = self._focused_item()
        if li is None:
            return
        title = li.getProperty('f_title') or li.getLabel() or ''
        if not title:
            return
        poster = li.getProperty('f_poster') or ''
        tmdb_id = li.getProperty('f_tmdb_id') or ''
        media_type = li.getProperty('f_media_type') or self._mode
        m = {
            'title': title, 'poster': poster, 'tmdb_id': tmdb_id,
            'imdb_id': li.getProperty('f_imdb_id'), 'media_type': media_type,
            'year': li.getProperty('f_year'), 'rating': li.getProperty('f_rating'),
            'genre': li.getProperty('f_genre'), 'director': li.getProperty('f_director'),
            'cast_str': li.getProperty('f_cast'), 'plot': li.getProperty('f_plot'),
            'fanart': li.getProperty('f_fanart'), 'runtime': li.getProperty('f_runtime'),
        }
        in_fav = movie_favorites.is_movie_favorited(m, self._mode)
        opts = [
            ('synopsis',     'Ver sinopsis'),
            ('trailer',      'Ver tráiler'),
            ('search',       'Buscar / ¿Dónde ver?'),
            ('fav_topzilla', 'Quitar de Mis Favoritos' if in_fav else 'Añadir a Mis Favoritos'),
            ('fav_kodi',     'Añadir a favoritos de Kodi'),
        ]
        sel = xbmcgui.Dialog().select(title, [label for _, label in opts])
        if sel < 0:
            return
        action = opts[sel][0]
        if action == 'synopsis':
            line = ' · '.join(x for x in (li.getProperty('f_meta'), li.getProperty('f_genre')) if x)
            body = title
            if line:
                body += '\n' + line
            credits = ' · '.join(p for p in (
                f"Dir. {li.getProperty('f_director')}" if li.getProperty('f_director') else '',
                f"Con: {li.getProperty('f_cast')}" if li.getProperty('f_cast') else '') if p)
            if credits:
                body += '\n' + credits
            plot = li.getProperty('f_plot')
            if plot:
                body += '\n\n' + plot
            xbmcgui.Dialog().textviewer(title, body)
        elif action == 'trailer':
            self._play_trailer_fullscreen(tmdb_id, media_type)
        elif action == 'search':
            self._open_item(title, poster, tmdb_id)
        elif action == 'fav_topzilla':
            added = movie_favorites.toggle_movie_favorite(m, self._mode)
            xbmcgui.Dialog().notification(
                'TopZilla', 'Añadida a Mis Favoritos' if added else 'Quitada de Mis Favoritos',
                xbmcgui.NOTIFICATION_INFO, 2000)
            # Si la fila "Mis Favoritos" debe aparecer (primer alta) o desaparecer (última
            # baja), reconstruye el modo para que se vea en vivo; si ya estaba, recarga solo
            # esa fila. (build_rows encapsula también el respeto a la config del usuario.)
            if tuple(r['id'] for r in build_rows(self._mode)) != tuple(self._active_ids()):
                self._reload_mode(self._mode)
            else:
                self._reload_volatile_row('mis_favs')
        elif action == 'fav_kodi':
            ok = pelis_grid.add_to_kodi_favorites(self._addon_url, title, poster, tmdb_id, media_type)
            xbmcgui.Dialog().notification(
                'TopZilla', 'Añadida a favoritos de Kodi' if ok else 'No se pudo añadir',
                xbmcgui.NOTIFICATION_INFO, 2500)

    def _play_trailer_fullscreen(self, tmdb_id, media_type):
        self._stop_trailer()  # pausa el tráiler "hover" en ventana (deja stop diferido)
        if not tmdb_id:
            xbmcgui.Dialog().notification('TopZilla', 'Sin datos del título para el tráiler',
                                          xbmcgui.NOTIFICATION_INFO, 2500)
            return  # poll loop sigue vivo: remata el stop diferido por su cuenta
        xbmcgui.Dialog().notification('TopZilla', 'Cargando tráiler…',
                                      xbmcgui.NOTIFICATION_INFO, 1500)
        key = pelis_grid.resolve_trailer_key(tmdb_id, media_type, self._trailer_lang)
        if not key:
            xbmcgui.Dialog().notification('TopZilla', 'No hay tráiler disponible',
                                          xbmcgui.NOTIFICATION_INFO, 2500)
            return  # ídem: el poll loop remata el stop diferido
        # Remata aquí el stop del tráiler hover antes de soltar el modal: si cerrásemos con el
        # vídeo aún vivo (pausado), Kodi lo sacaría a pantalla completa, y un stop en seco de un
        # ISA joven colgaría la GUI. La resolución de red de arriba ya consumió casi todo el settle.
        self._finish_pending_stop()
        # Cerramos el Modo Cine y reproducimos a pantalla completa: el modal tapaba el vídeo.
        # show() lanza el PlayMedia una vez cerrado, y el busy dialog de Kodi da el feedback
        # de carga (antes quedaba oculto tras el modal). La posición se restaura al reabrir.
        self._pending_trailer_key = key
        self._save_state()
        self._closing = True
        self.close()

    def _reload_volatile_row(self, row_id):
        """Recarga en vivo una fila volátil (p.ej. 'Mis Favoritos' tras un alta/baja).
        Su loader es local e instantáneo, así que no bloquea."""
        token = self._mode_token
        cfg = self._cfg()
        idx = next((i for i, r in enumerate(cfg) if r.get('id') == row_id), None)
        if idx is None:
            return
        row = cfg[idx]
        loader = pelis_grid._LOADERS.get(row['key'])
        movies = (loader(row.get('params') or {}) or []) if loader else []
        movies = movies[:_MAX_PER_ROW]
        if token != self._mode_token:
            return
        with self._lock:
            self._rows_data[idx] = movies
        self._populate_row(token, idx, row, movies)
        # El grupo de la fila se muestra solo si su row_title no está vacío (grouplist):
        # al quedar sin items (último favorito quitado) lo ocultamos para no dejar una
        # franja con título y sin cards, y sacamos el foco de ahí. Al re-añadir, se restaura.
        self.setProperty(f'row_title_{idx}', row.get('title', '') if movies else '')
        if not movies:
            try:
                if self.getFocusId() == _ID_ROW_BASE + idx:
                    self.setFocusId(_ID_HERO)
            except Exception:
                pass

    def onClick(self, controlId):
        if controlId == _ID_BTN_CLOSE:
            self._close_now()
            return
        if controlId == _ID_BTN_MODE:
            self._toggle_mode()
            return
        if controlId == _ID_BTN_SEARCH:
            self._do_search()
            return
        if controlId == _ID_BTN_SURPRISE:
            self._do_surprise()
            return
        if not self._loaded:
            return
        if controlId != _ID_HERO and not (_ID_ROW_BASE <= controlId < _ID_ROW_BASE + MAX_ROWS):
            return
        try:
            ctrl = self.getControl(controlId)
            pos = ctrl.getSelectedPosition()
            if pos < 0:
                return
            li = ctrl.getListItem(pos)
            title = li.getProperty('f_title') or li.getLabel() or ''
            poster = li.getProperty('f_poster') or ''
            tmdb_id = li.getProperty('f_tmdb_id') or ''
        except Exception as e:
            xbmc.log(f'{_LOG} onClick error: {e}', xbmc.LOGERROR)
            return
        self._open_item(title, poster, tmdb_id)

    def onAction(self, action):
        aid = action.getId()
        if aid in (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK):
            self._close_now()
            return
        if aid in (xbmcgui.ACTION_SHOW_INFO, xbmcgui.ACTION_CONTEXT_MENU):
            self._show_info_menu()
            return
        if aid in _MOVE_ACTIONS:
            self._user_moved = True


def show(search_fn=None, initial_mode=None):
    win = PelisFlix('pelis_flix.xml', _ADDON_PATH, 'Default', '1080i',
                    addon_url=sys.argv[0], search_fn=search_fn, initial_mode=initial_mode)
    key = ''
    try:
        win.doModal()
        key = win._pending_trailer_key
    finally:
        trailer_was_started = win._trailer_started > 0
        del win
    if not key and trailer_was_started:
        # Capa 1: PlayerControl(Stop) se encola DESPUÉS de cualquier PlayMedia windowed
        # pendiente en executebuiltin (ruta YouTube plugin); los cancela antes de que
        # salgan del modal y abran pantalla completa.
        xbmc.executebuiltin('PlayerControl(Stop)')
        # Capa 2: para lo que ya esté reproduciéndose (stream tardío o race yt-dlp).
        # Aquí es seguro parar incluso streams "abriéndose": el modal ya está cerrado.
        if xbmc.Player().isPlaying():
            xbmc.Player().stop()
    pelis_grid.play_trailer_key(key)  # tras cerrar: el tráiler fullscreen ya no queda tapado
