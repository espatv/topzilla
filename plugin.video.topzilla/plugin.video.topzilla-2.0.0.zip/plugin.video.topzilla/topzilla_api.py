# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""API de consulta de películas para otros addons.

Otro addon obtiene el catálogo de cine de TopZilla (sin duplicar scraping ni
claves) consultando el plugin vía JSON-RPC Files.GetDirectory, que es síncrono
y bloquea hasta recibir el listado completo:

    import json, xbmc
    req = {"jsonrpc": "2.0", "id": 1, "method": "Files.GetDirectory", "params": {
        "directory": "plugin://plugin.video.topzilla/?action=api_consulta_pelis&categoria=top&limit=20",
        "media": "video",
        "properties": ["title", "year", "plot", "genre", "director",
                       "cast", "rating", "art", "uniqueid", "mediatype"]}}
    resp  = json.loads(xbmc.executeJSONRPC(json.dumps(req)))
    items = resp.get("result", {}).get("files", [])
    # cada item: label, year, plot, art["poster"], uniqueid["tmdb"] / uniqueid["imdb"] ...

Categorías (solo películas):
    top          Top global de Cinemeta
    cartelera    En cines España (FilmAffinity); solo título + póster
    tmdb_top     Top valoradas de TMDB
    tmdb_search  Búsqueda en TMDB; requiere &q=titulo
"""
import re
import sys
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin

_LIMIT_CAP = 100


def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)


def _to_year(value):
    s = str(value or "")[:4]
    return int(s) if s.isdigit() else 0


def _to_int(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


def _to_rating(value):
    try:
        return round(float(str(value).replace(",", ".")), 1)
    except (TypeError, ValueError):
        return 0.0


def _split_genres(value):
    # las fuentes mezclan separadores: cinemeta une con ", "; FilmAffinity/TMDB con " / ".
    if isinstance(value, (list, tuple)):
        return [str(g).strip() for g in value if str(g).strip()]
    return [g.strip() for g in re.split(r"[/,]", str(value or "")) if g.strip()]


# Cada fuente de TopZilla devuelve sus propias claves; estos normalizadores las
# llevan al formato común que consume el addon cliente (ver docstring del módulo).

def _normalize_cinemeta(f):
    return {
        "tmdb_id":    "",
        "imdb_id":    f.get("id", ""),
        "title":      f.get("title", ""),
        "year":       _to_year(f.get("year")),
        "poster":     f.get("poster", ""),
        "overview":   f.get("plot", ""),
        "genres":     _split_genres(f.get("genre")),
        "rating":     _to_rating(f.get("rating")),
        "runtime":    _to_int(f.get("runtime")),
        "director":   f.get("director", "") or "",
        "cast":       [],
        "media_type": "movie",
    }


def _normalize_fa_cartelera(f):
    # La cartelera trae solo id de FilmAffinity (no usable como tmdb/imdb), título y
    # póster. El cliente desambigua por título+año contra su propia fuente si lo necesita.
    return {
        "tmdb_id":    "",
        "imdb_id":    "",
        "title":      f.get("title", ""),
        "year":       0,
        "poster":     f.get("poster", ""),
        "overview":   "",
        "genres":     [],
        "rating":     0.0,
        "runtime":    0,
        "director":   "",
        "cast":       [],
        "media_type": "movie",
    }


def _normalize_fa_top(f):
    # _fetch_top trae el id de TMDB en 'id' y la sinopsis en 'plot' (no 'tmdb_id'/'overview').
    return {
        "tmdb_id":    str(f.get("id") or ""),
        "imdb_id":    "",
        "title":      f.get("title", ""),
        "year":       _to_year(f.get("year")),
        "poster":     f.get("poster", ""),
        "overview":   f.get("plot", ""),
        "genres":     _split_genres(f.get("genre")),
        "rating":     _to_rating(f.get("rating")),
        "runtime":    0,
        "director":   "",
        "cast":       [],
        "media_type": "movie",
    }


def _normalize_tmdb_search(it):
    return {
        "tmdb_id":    str(it.get("tmdb_id") or ""),
        "imdb_id":    "",
        "title":      it.get("title", ""),
        "year":       _to_year(it.get("year")),
        "poster":     it.get("poster", ""),
        "overview":   it.get("overview", ""),
        "genres":     [],
        "rating":     0.0,
        "runtime":    0,
        "director":   "",
        "cast":       [],
        "media_type": "movie",
    }


def _source_top(q):
    import cinemeta
    return [_normalize_cinemeta(f) for f in (cinemeta._get_top_films() or [])]


def _source_cartelera(q):
    import filmaffinity
    return [_normalize_fa_cartelera(f) for f in (filmaffinity._fetch_en_cines() or [])]


def _source_tmdb_top(q):
    import filmaffinity
    return [_normalize_fa_top(f) for f in (filmaffinity._fetch_top() or [])]


def _source_tmdb_search(q):
    if not q:
        return []
    import metadata_enricher
    items = metadata_enricher.search_multi(q, limit=_LIMIT_CAP) or []
    # search_multi devuelve películas y series; esta API es solo de cine.
    return [_normalize_tmdb_search(it) for it in items if it.get("media_type") == "movie"]


_SOURCES = {
    "top":         _source_top,
    "cartelera":   _source_cartelera,
    "tmdb_top":    _source_tmdb_top,
    "tmdb_search": _source_tmdb_search,
}


def query_movies(categoria="top", q="", limit=20, offset=0):
    """Lista de películas normalizadas. Ver docstring del módulo para el formato."""
    q = str(q or "").strip()  # q llega como str desde la URL, pero es API pública: coerce
    try:
        limit = min(max(int(limit), 1), _LIMIT_CAP)
    except (TypeError, ValueError):
        limit = 20
    try:
        offset = max(int(offset), 0)
    except (TypeError, ValueError):
        offset = 0

    try:
        items = _SOURCES.get(categoria, _source_top)(q)
    except Exception as e:
        xbmc.log(f"[TopZilla-API] query_movies error (categoria={categoria}): {e}", xbmc.LOGERROR)
        return []

    if q and categoria != "tmdb_search":
        ql = q.lower()
        items = [it for it in items if ql in (it.get("title") or "").lower()]

    return items[offset:offset + limit]


def render_directory(params):
    """Genera el directorio Kodi que consume otro addon vía Files.GetDirectory."""
    try:
        handle = int(sys.argv[1])
    except (IndexError, ValueError):
        xbmc.log("[TopZilla-API] render_directory sin handle de plugin válido", xbmc.LOGERROR)
        return
    try:
        items = query_movies(
            categoria=params.get("categoria", "top"),
            q=params.get("q", ""),
            limit=params.get("limit", 20),
            offset=params.get("offset", 0),
        )
        xbmcplugin.setContent(handle, "movies")
        for it in items:
            li = xbmcgui.ListItem(label=it["title"])
            info = {
                "title":     it["title"],
                "year":      it["year"],
                "plot":      it["overview"],
                "genre":     " / ".join(it["genres"]),
                "mediatype": "movie",
            }
            if it["rating"]:
                info["rating"] = it["rating"]
            if it["director"]:
                info["director"] = it["director"]
            li.setInfo("video", info)
            li.setArt({"icon": "DefaultVideo.png", "thumb": it["poster"], "poster": it["poster"]})
            ids = {k: v for k, v in (("tmdb", it["tmdb_id"]), ("imdb", it["imdb_id"])) if v}
            if ids:
                li.setUniqueIDs(ids)
            li.setProperty("IsPlayable", "false")
            url = _u(action="search_alt_prompt", q=it["title"], ot=it["poster"], mode="movie")
            xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(handle)
        xbmc.log(f"[TopZilla-API] {len(items)} pelis servidas (categoria={params.get('categoria', 'top')})",
                 xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[TopZilla-API] render_directory error: {e}", xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(handle, succeeded=False)
