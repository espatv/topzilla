# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""Reproducción opcional de YouTube vía yt-dlp.

Modo OFF (por defecto): nada de esto se usa; los tráileres van a
plugin.video.youtube como siempre. Modo ON: se resuelve la URL directa con
yt-dlp del sistema y, si falla, se cae a plugin.video.youtube como respaldo.
Funciona en Windows, Linux y macOS; en Android no (no hay subprocess de Python).
"""
import xbmc

_PLUGIN_PLAY = 'plugin://plugin.video.youtube/play/?video_id={0}'

# Etiqueta del ajuste -> nombre de navegador que entiende yt-dlp.
_COOKIE_BROWSERS = {
    'Chrome': 'chrome', 'Edge': 'edge', 'Firefox': 'firefox',
    'Brave': 'brave', 'Opera': 'opera', 'Vivaldi': 'vivaldi',
}


def ytdlp_enabled():
    """True con el ajuste activado, salvo en Android (sin subprocess de Python).

    No comprueba si yt-dlp está realmente instalado: hacerlo aquí implicaría un
    subprocess que congelaría la GUI (esta función se llama en el hilo de UI del
    Modo Cine). Si yt-dlp falta, resolve_url cae a plugin.video.youtube."""
    try:
        import xbmcaddon
        if xbmc.getCondVisibility('System.Platform.Android'):
            return False
        return xbmcaddon.Addon().getSetting('youtube_ytdlp_enabled') == 'true'
    except Exception:
        return False


def _cookies_browser():
    try:
        import xbmcaddon
        raw = (xbmcaddon.Addon().getSetting('youtube_ytdlp_cookies') or '').strip()
        return _COOKIE_BROWSERS.get(raw, '')
    except Exception:
        return ''


def _cookie_file():
    """Ruta a un cookies.txt (Netscape). Más fiable que el navegador en
    Chrome/Edge en Windows: desde Chrome 127 el App-Bound Encryption impide
    que yt-dlp descifre sus cookies.

    Anti-fuga: si el fichero está DENTRO de la carpeta del addon se ignora (se
    empaquetaría al distribuirlo y filtraría tus credenciales). Debe vivir fuera."""
    try:
        import os.path
        import xbmcaddon
        addon = xbmcaddon.Addon()
        path = (addon.getSetting('youtube_ytdlp_cookiefile') or '').strip()
        if not path or not os.path.isfile(path):
            return ''
        # normcase: en Windows las rutas no distinguen mayúsculas; sin esto el guard
        # se saltaría por diferencias de capitalización.
        addon_dir = os.path.normcase(os.path.realpath(addon.getAddonInfo('path')))
        real = os.path.normcase(os.path.realpath(path))
        if real == addon_dir or real.startswith(addon_dir + os.sep):
            xbmc.log('[TopZilla-YT] cookies.txt dentro del addon: IGNORADO por seguridad. '
                     'Muévelo fuera de la carpeta del addon.', xbmc.LOGWARNING)
            return ''
        return path
    except Exception:
        return ''


_BOT_SIGNALS = ('sign in to confirm', 'not a bot')


def _is_bot_block(stderr):
    s = (stderr or '').lower()
    return any(sig in s for sig in _BOT_SIGNALS)


def _interpreters():
    """Binarios de Python a probar, en orden. Windows: el py launcher expone 'python'.
    POSIX: 'python3' primero (macOS 12.3+ ya no trae 'python', y muchas distros tampoco),
    con 'python' como respaldo para sistemas que solo tengan ese alias."""
    if xbmc.getCondVisibility('System.Platform.Windows'):
        return ('python',)
    return ('python3', 'python')


def _run_ytdlp(extra_args, video_id, timeout):
    """Lanza yt-dlp y devuelve el CompletedProcess, o None si Python/yt-dlp no está en
    PATH o hay timeout/OSError (fallos que no merecen reintento)."""
    import subprocess
    # --ignore-config: no heredar el yt_dlp.conf del usuario (podría cambiar formato/salida).
    # --no-warnings + -J: stdout limpio (solo JSON). --socket-timeout: corta cuelgues de red
    # antes que el timeout del proceso.
    # player_client tv/web_safari/mweb/tv_simply: el cliente 'web' por defecto cada vez lo
    # bloquea más YouTube ("confirm you're not a bot"); estos clientes lo evitan casi siempre.
    # Formato: progresivo https (URL directa que Kodi reproduce sin inputstream.adaptive);
    # YouTube suele dar 360p (itag 18) o 720p (22). Solo cae a HLS/otro si no hay progresivo.
    args = ['-m', 'yt_dlp', '--ignore-config', '--no-warnings',
            '--socket-timeout', '15', '--dump-single-json', '--no-download',
            '--no-playlist', '--extractor-args',
            'youtube:player_client=tv,web_safari,mweb,tv_simply',
            '-f', 'best[protocol=https][ext=mp4]/best[protocol=https]/best']
    cookiefile = _cookie_file()
    if cookiefile:
        args += ['--cookies', cookiefile]
    else:
        browser = _cookies_browser()
        if browser:
            args += ['--cookies-from-browser', browser]
    args += extra_args + ['https://www.youtube.com/watch?v=' + video_id]
    # CREATE_NO_WINDOW oculta la consola del subprocess en Windows; en POSIX no aplica.
    flags = 0x08000000 if xbmc.getCondVisibility('System.Platform.Windows') else 0
    interps = _interpreters()
    for i, py in enumerate(interps):
        try:
            return subprocess.run([py] + args, capture_output=True, text=True,
                                  timeout=timeout, creationflags=flags)
        except FileNotFoundError:
            # Solo este intérprete falta: prueba el siguiente. Si yt_dlp no está instalado
            # el proceso SÍ arranca (returncode!=0), así que no caemos aquí y no probamos otro.
            if i == len(interps) - 1:
                xbmc.log('[TopZilla-YT] Python/yt-dlp no encontrado en PATH (probado: {0})'.format(
                    ', '.join(interps)), xbmc.LOGWARNING)
        except (subprocess.TimeoutExpired, OSError) as e:
            xbmc.log('[TopZilla-YT] yt-dlp error: {0}'.format(e), xbmc.LOGWARNING)
            return None
    return None


def resolve_url(video_id, timeout=35, allow_impersonate=True):
    """Resuelve un video de YouTube a URL directa con yt-dlp. '' si falla.

    allow_impersonate: ante bloqueo de bot, reintenta con --impersonate chrome (requiere
    curl_cffi). El preview windowed del Modo Cine lo desactiva: allí plugin.video.youtube
    es un respaldo más rápido que un segundo intento de yt-dlp."""
    if not video_id:
        return ''
    import json
    proc = _run_ytdlp([], video_id, timeout)
    # Reintento SOLO ante bloqueo de bot. Un error real (video privado/borrado, sin red) no se
    # reintenta: impersonate no lo arreglaría y solo dobla la espera.
    if (allow_impersonate and proc is not None
            and proc.returncode != 0 and _is_bot_block(proc.stderr)):
        xbmc.log('[TopZilla-YT] bot block; reintento con --impersonate chrome', xbmc.LOGINFO)
        retry = _run_ytdlp(['--impersonate', 'chrome'], video_id, timeout)
        if retry is not None:
            if retry.returncode != 0 and 'curl_cffi' in (retry.stderr or '').lower():
                xbmc.log("[TopZilla-YT] --impersonate requiere 'pip install curl_cffi'",
                         xbmc.LOGWARNING)
            proc = retry
    if proc is None:
        return ''
    if proc.returncode != 0 or not proc.stdout.strip():
        xbmc.log('[TopZilla-YT] yt-dlp rc={0} err={1}'.format(
            proc.returncode, (proc.stderr or '')[:200]), xbmc.LOGWARNING)
        return ''
    try:
        data = json.loads(proc.stdout)
    except (ValueError, TypeError):
        return ''
    url = data.get('url')
    if not url:
        rf = data.get('requested_formats') or []
        if rf:
            url = rf[0].get('url')
    return url or ''


def is_hls(url):
    """True si la URL parece un manifiesto HLS (el formato progresivo lo evita, pero
    el fallback /best podría darlo). YouTube usa .../api/manifest/hls_playlist/... (sin
    '.m3u8'). Marcadores específicos, NO un 'hls' suelto: el nombre aleatorio de servidor
    de googlevideo (sn-...) podría contener 'hls' por azar y romper un mp4 progresivo."""
    u = (url or '').lower()
    return 'm3u8' in u or 'hls_playlist' in u or '/manifest/hls' in u


def _resolve_and_play(video_id, notify):
    import xbmcgui
    if notify:
        xbmcgui.Dialog().notification(
            'TopZilla', 'Resolviendo tráiler con yt-dlp…',
            xbmcgui.NOTIFICATION_INFO, 2500)
    url = resolve_url(video_id)
    if url:
        li = xbmcgui.ListItem(path=url)
        li.setContentLookup(False)
        if is_hls(url):
            li.setMimeType('application/x-mpegURL')
        xbmc.Player().play(url, li)
        return
    xbmc.log('[TopZilla-YT] yt-dlp sin URL, respaldo a plugin.video.youtube', xbmc.LOGINFO)
    xbmc.executebuiltin('PlayMedia({0})'.format(_PLUGIN_PLAY.format(video_id)))


def play_async(video_id, notify=False):
    """Resuelve y reproduce a pantalla completa en un hilo (no bloquea la GUI).
    El preview windowed del Modo Cine NO usa esto: pelis_flix tiene su propio
    worker integrado con su máquina de estados (gen-guard contra cambios de foco)."""
    import threading
    threading.Thread(target=_resolve_and_play,
                     args=(video_id, notify), daemon=True).start()
