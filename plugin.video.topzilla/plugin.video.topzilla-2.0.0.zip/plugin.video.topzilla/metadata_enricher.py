# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""Enriquecimiento centralizado de metadatos de películas y series vía TMDB."""
import json
import os
import sqlite3
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests
import xbmc
import xbmcaddon
import xbmcvfs

import core_settings

_TMDB_BASE = "https://api.themoviedb.org/3"
_IMG_W342  = "https://image.tmdb.org/t/p/w342"
_IMG_W185  = "https://image.tmdb.org/t/p/w185"
_IMG_ORIG  = "https://image.tmdb.org/t/p/original"
_TTL_SEC   = 30 * 86400
_LOG_TAG   = "[TopZilla-ME]"

_KODI_MEDIATYPE = {'movie': 'movie', 'show': 'tvshow'}

_write_lock   = threading.Lock()
_thread_local = threading.local()
_session      = requests.Session()

# Limitador global de concurrencia para TMDB. El umbral actual de TMDB es
# ~40 req/s (https://developer.themoviedb.org/docs/rate-limiting). Con ~300ms
# de respuesta media, 12 workers ≈ 40 req/s, justo en el techo. Las puntas
# que excedan el umbral se manejan con el backoff de 429 más abajo, así que
# el usuario nunca ve un error: como mucho una pausa de 1-2s puntual.
_TMDB_CONCURRENCY = 12
_tmdb_sem = threading.Semaphore(_TMDB_CONCURRENCY)

# Caché en memoria (por sesión) de keys de tráiler de YouTube; get_trailer_key
# no toca la caché SQLite de metadatos.
_trailer_cache = {}
_trailer_lock  = threading.Lock()


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log("{0} {1}".format(_LOG_TAG, msg), level)


def _api_key():
    return core_settings.get_tmdb_api_key()


def _profile_dir():
    return xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))


def _db_path():
    return os.path.join(_profile_dir(), 'topzilla_metadata.db')


def _connection():
    conn = getattr(_thread_local, 'conn', None)
    if conn is not None:
        return conn
    path = _db_path()
    parent = os.path.dirname(path)
    if parent and not os.path.exists(parent):
        os.makedirs(parent, exist_ok=True)
    conn = sqlite3.connect(path, timeout=10)
    try:
        conn.execute("PRAGMA journal_mode=WAL")
    except sqlite3.OperationalError as e:
        # WAL necesita memoria compartida (.shm), no disponible si el perfil está en
        # un sistema de archivos de red (SMB/NFS). El modo por defecto sirve igual.
        _log("WAL no disponible, modo por defecto: {0}".format(e), xbmc.LOGWARNING)
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute(
        "CREATE TABLE IF NOT EXISTS meta ("
        " key TEXT PRIMARY KEY,"
        " data TEXT NOT NULL,"
        " fetched_at INTEGER NOT NULL"
        ")"
    )
    conn.commit()
    _thread_local.conn = conn
    return conn


def _reset_thread_state():
    conn = getattr(_thread_local, 'conn', None)
    if conn is not None:
        try:
            conn.close()
        except sqlite3.Error:
            pass
        del _thread_local.conn


def _cache_get(key):
    if not key:
        return None
    try:
        row = _connection().execute(
            "SELECT data, fetched_at FROM meta WHERE key=?", (key,)
        ).fetchone()
    except sqlite3.Error as e:
        _log("cache_get: {0}".format(e), xbmc.LOGWARNING)
        return None
    if not row:
        return None
    # delta < 0 = reloj del sistema retrocedido (Android TV sin RTC, apagón): tratamos
    # la entrada como caducada en vez de fiarnos de un reloj que sabemos roto.
    delta = time.time() - row[1]
    if delta < 0 or delta >= _TTL_SEC:
        return None
    try:
        return json.loads(row[0])
    except ValueError:
        return None


def _cache_set(key, meta):
    if not key:
        return
    try:
        payload = json.dumps(meta, ensure_ascii=False)
    except (TypeError, ValueError) as e:
        _log("cache_set encode: {0}".format(e), xbmc.LOGWARNING)
        return
    now = int(time.time())
    try:
        with _write_lock:
            conn = _connection()
            conn.execute(
                "INSERT OR REPLACE INTO meta(key, data, fetched_at) VALUES(?,?,?)",
                (key, payload, now),
            )
            conn.commit()
    except sqlite3.Error as e:
        _log("cache_set: {0}".format(e), xbmc.LOGWARNING)


def _delete_keys(keys):
    rows = [(k,) for k in keys if k]
    if not rows:
        return
    try:
        with _write_lock:
            conn = _connection()
            conn.executemany("DELETE FROM meta WHERE key=?", rows)
            conn.commit()
    except sqlite3.Error as e:
        _log("delete_keys: {0}".format(e), xbmc.LOGWARNING)


def delete_by_imdb_ids(imdb_ids):
    _delete_keys(["imdb:{0}".format(i) for i in imdb_ids if i])


def delete_items(items):
    keys = [
        _canon_key(i.get('tmdb_id'), i.get('imdb_id'), i.get('title'),
                   i.get('year'), i.get('media_type', 'movie'))
        for i in items
    ]
    _delete_keys(keys)


def clear_all():
    try:
        with _write_lock:
            conn = _connection()
            conn.execute("DELETE FROM meta")
            conn.commit()
    except sqlite3.Error as e:
        _log("clear_all: {0}".format(e), xbmc.LOGWARNING)


def delete_db():
    """Cierra la conexión y elimina la BD completa, incluidos los sidecars WAL/SHM.
    Devuelve bytes liberados."""
    # Checkpoint truncando el WAL antes de cerrar: evita que el .db-wal conserve datos
    # huérfanos que SQLite pudiera recuperar al recrear la BD.
    try:
        _connection().execute("PRAGMA wal_checkpoint(TRUNCATE)")
    except sqlite3.Error:
        pass
    _reset_thread_state()
    path = _db_path()
    try:
        freed = 0
        for suffix in ('', '-wal', '-shm', '-journal'):
            p = path + suffix
            if os.path.exists(p):
                freed += os.path.getsize(p)
                os.remove(p)
        return freed
    except OSError as e:
        _log("delete_db: {0}".format(e), xbmc.LOGWARNING)
        raise


def prune_and_vacuum():
    path = _db_path()
    if not os.path.exists(path):
        return 0, 0
    try:
        size_before = os.path.getsize(path)
    except OSError:
        size_before = 0
    cutoff = int(time.time()) - _TTL_SEC
    deleted = 0
    with _write_lock:
        _reset_thread_state()
        try:
            conn = sqlite3.connect(path, timeout=10)
        except sqlite3.Error as e:
            _log("prune_and_vacuum connect: {0}".format(e), xbmc.LOGWARNING)
            return 0, 0
        try:
            try:
                cur = conn.execute("DELETE FROM meta WHERE fetched_at < ?", (cutoff,))
                deleted = cur.rowcount or 0
                conn.commit()
            except sqlite3.Error as e:
                _log("prune_and_vacuum delete: {0}".format(e), xbmc.LOGWARNING)
            try:
                conn.execute("VACUUM")
                conn.commit()
            except sqlite3.Error as e:
                _log("prune_and_vacuum vacuum: {0}".format(e), xbmc.LOGWARNING)
        finally:
            try:
                conn.close()
            except sqlite3.Error:
                pass
    try:
        size_after = os.path.getsize(path) if os.path.exists(path) else 0
    except OSError:
        size_after = size_before
    return deleted, max(0, size_before - size_after)


def _to_int(value):
    if value is None or value == '' or isinstance(value, bool):
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _canon_key(tmdb_id, imdb_id, title, year, media_type):
    tmdb_int = _to_int(tmdb_id)
    if tmdb_int:
        return "tmdb:{0}:{1}".format(media_type, tmdb_int)
    if imdb_id:
        return "imdb:{0}".format(imdb_id)
    if title:
        normalized = title.lower().strip()
        if normalized:
            return "title:{0}:{1}:{2}".format(media_type, normalized, year or '')
    return None


def _build_cast(credits):
    return [
        {
            'name':      a.get('name', ''),
            'role':      a.get('character', ''),
            'thumbnail': "{0}{1}".format(_IMG_W185, a['profile_path']) if a.get('profile_path') else '',
        }
        for a in (credits.get('cast') or [])[:10]
    ]


def _build_director(media_type, payload):
    crew = (payload.get('credits') or {}).get('crew') or []
    director_from_crew = next(
        (p.get('name', '') for p in crew if p.get('job') == 'Director'),
        '',
    )
    if media_type == 'show':
        creators = ', '.join(
            c.get('name', '') for c in (payload.get('created_by') or []) if c.get('name')
        )
        return creators or director_from_crew
    return director_from_crew


def _parse(d, media_type):
    poster_path   = d.get('poster_path')
    backdrop_path = d.get('backdrop_path')
    credits       = d.get('credits') or {}
    genres        = [g.get('name', '') for g in (d.get('genres') or [])]
    ext_ids       = d.get('external_ids') or {}
    imdb_id       = d.get('imdb_id') or ext_ids.get('imdb_id', '')

    raw_date = d.get('release_date') or d.get('first_air_date') or ''
    year = int(raw_date[:4]) if raw_date[:4].isdigit() else 0

    runtime = d.get('runtime') or 0
    if not runtime and media_type == 'show':
        rt_list = d.get('episode_run_time') or []
        runtime = rt_list[0] if rt_list else 0

    try:
        rating = float(d.get('vote_average') or 0)
    except (TypeError, ValueError):
        rating = 0.0

    return {
        'ids':            {'tmdb': d.get('id'), 'imdb': imdb_id,
                           'tvdb': str(ext_ids.get('tvdb_id') or '')},
        'media_type':     media_type,
        'title':          d.get('title') or d.get('name') or '',
        'original_title': d.get('original_title') or d.get('original_name') or '',
        'year':           year,
        'overview':       d.get('overview') or '',
        'tagline':        d.get('tagline') or '',
        'genres':         genres,
        'rating':         rating,
        'votes':          int(d.get('vote_count') or 0),
        'runtime':        runtime,
        'certification':  '',
        'director':       _build_director(media_type, d),
        'cast':           _build_cast(credits),
        'poster':         "{0}{1}".format(_IMG_W342, poster_path) if poster_path else '',
        'fanart':         "{0}{1}".format(_IMG_ORIG, backdrop_path) if backdrop_path else '',
    }


def _tmdb_get(path, params):
    api_key = _api_key()
    if not api_key:
        return None
    full = dict(params, api_key=api_key)
    url = "{0}/{1}".format(_TMDB_BASE, path)

    with _tmdb_sem:
        try:
            r = _session.get(url, params=full, timeout=8)
        except requests.RequestException as e:
            _log("request error ({0}): {1}".format(path, e), xbmc.LOGWARNING)
            return None

        # Si TMDB devuelve 429 (Too Many Requests) respetamos Retry-After
        # con un solo reintento. Más reintentos sólo amplificarían el problema.
        if r.status_code == 429:
            try:
                wait = int(r.headers.get('Retry-After', '1'))
            except (TypeError, ValueError):
                wait = 1
            time.sleep(min(max(wait, 1), 5))
            try:
                r = _session.get(url, params=full, timeout=8)
            except requests.RequestException as e:
                _log("retry error ({0}): {1}".format(path, e), xbmc.LOGWARNING)
                return None

        if r.status_code in (401, 403) and not core_settings.get_tmdb_user_key():
            core_settings.mark_tmdb_pool_key_dead(api_key)
            next_key = core_settings.get_tmdb_api_key()
            if next_key and next_key != api_key:
                full["api_key"] = next_key
                try:
                    r = _session.get(url, params=full, timeout=8)
                except requests.RequestException as e:
                    _log("failover error ({0}): {1}".format(path, e), xbmc.LOGWARNING)
                    return None

    if r.status_code != 200:
        return None
    try:
        return r.json()
    except ValueError:
        return None


_inflight_lock = threading.Lock()
_inflight = {}


def _tmdb_get_dedup(path, params):
    cache_key = (path, tuple(sorted((params or {}).items())))

    with _inflight_lock:
        slot = _inflight.get(cache_key)
        if slot is None:
            slot = (threading.Event(), [None])
            _inflight[cache_key] = slot
            owner = True
        else:
            owner = False

    ev, container = slot

    if not owner:
        ev.wait(timeout=10)
        return container[0]

    try:
        container[0] = _tmdb_get(path, params)
        return container[0]
    finally:
        with _inflight_lock:
            _inflight.pop(cache_key, None)
        ev.set()


def tmdb_get(path, params=None):
    """Facade de _tmdb_get con el mismo semáforo de concurrencia. Devuelve JSON o None."""
    return _tmdb_get_dedup(path, dict(params or {}))


def _norm_tmdb_item(r, is_tv):
    """Normaliza un result de TMDB (movie/tv) al formato ligero del buscador/grid,
    o None si no tiene título. Para items de listas/búsqueda (sin credits)."""
    title = (r.get('name') if is_tv else r.get('title')) or ''
    if not title:
        return None
    date = (r.get('first_air_date') if is_tv else r.get('release_date')) or ''
    pp = r.get('poster_path') or ''
    return {
        'tmdb_id':    str(r.get('id') or ''),
        'title':      title,
        'year':       date[:4] if len(date) >= 4 else '',
        'poster':     f"{_IMG_W342}{pp}" if pp else '',
        'overview':   r.get('overview') or '',
        'media_type': 'show' if is_tv else 'movie',
        'popularity': r.get('popularity') or 0,
    }


def search_multi(query, limit=40):
    """Busca películas y series en TMDB (/search/multi). Devuelve lista normalizada
    ordenada por popularidad, o [] si no hay query/red/clave."""
    q = (query or '').strip()
    if not q:
        return []
    data = tmdb_get('search/multi', {'query': q, 'language': 'es-ES', 'include_adult': 'false'})
    out = []
    for r in (data or {}).get('results', []):
        if r.get('media_type') not in ('movie', 'tv'):
            continue
        item = _norm_tmdb_item(r, r.get('media_type') == 'tv')
        if item:
            out.append(item)
    out.sort(key=lambda x: x['popularity'], reverse=True)
    return out[:limit]


def search_person(name, limit=8):
    """Busca personas (directores/actores) en TMDB. Devuelve lista de
    {id, name, department, popularity, known_for} ordenada por popularidad, o []."""
    q = (name or '').strip()
    if not q:
        return []
    data = tmdb_get('search/person', {'query': q, 'language': 'es-ES', 'include_adult': 'false'})
    out = []
    for p in (data or {}).get('results', []):
        pid = p.get('id')
        if not pid:
            continue
        known = [k.get('title') or k.get('name') for k in (p.get('known_for') or [])]
        out.append({
            'id':         str(pid),
            'name':       p.get('name') or '',
            'department': p.get('known_for_department') or '',
            'popularity': p.get('popularity') or 0,
            'known_for':  [k for k in known if k][:3],
        })
    out.sort(key=lambda x: x['popularity'], reverse=True)
    return out[:limit]


def discover(media_type, params, limit=40, with_pages=False):
    """Descubre películas o series vía /discover. media_type es 'movie' o 'show'.
    params son filtros TMDB (with_crew, with_genres, primary_release_year, ...).
    Con with_pages=True devuelve (items, total_pages) para paginar."""
    is_tv = media_type == 'show'
    endpoint = 'discover/tv' if is_tv else 'discover/movie'
    base = {'language': 'es-ES', 'region': 'ES', 'include_adult': 'false',
            'sort_by': 'popularity.desc', 'page': 1}
    data = tmdb_get(endpoint, dict(base, **params))
    out = []
    for r in (data or {}).get('results', []):
        item = _norm_tmdb_item(r, is_tv)
        if item:
            out.append(item)
    items = out[:limit]
    if with_pages:
        return items, (data or {}).get('total_pages', 1)
    return items


# Géneros TV de ruido en filmografías (telediario, reality, late shows).
_PERSON_NOISE_GENRES = {10763, 10764, 10767}


def get_person_credits(person_id, limit=60):
    """Filmografía combinada (cine + TV) de una persona vía
    /person/{id}/combined_credits. Devuelve lista normalizada (con 'role' del
    personaje), deduplicada por (media_type, id) y ordenada por popularidad."""
    pid = _to_int(person_id)
    if not pid:
        return []
    data = tmdb_get(f'person/{pid}/combined_credits', {'language': 'es-ES'})
    seen, out = set(), []
    for r in (data or {}).get('cast', []):
        mt = r.get('media_type')
        if mt not in ('movie', 'tv'):
            continue
        if set(r.get('genre_ids') or []) & _PERSON_NOISE_GENRES:
            continue
        item = _norm_tmdb_item(r, mt == 'tv')
        if not item:
            continue
        key = (item['media_type'], item['tmdb_id'])
        if key in seen:
            continue
        seen.add(key)
        item['role'] = r.get('character') or ''
        out.append(item)
    out.sort(key=lambda x: x['popularity'], reverse=True)
    return out[:limit]


def _find_trailer_key(endpoint, tmdb_int, language):
    payload = tmdb_get(f'{endpoint}/{tmdb_int}/videos', {'language': language})
    for v in (payload or {}).get('results', []):
        if v.get('site') == 'YouTube' and v.get('type') == 'Trailer' and v.get('key'):
            return v['key']
    return ''


def get_trailer_key(tmdb_id, media_type='movie', lang='es-ES'):
    """Key de YouTube del primer tráiler del título, o ''. Consulta /videos en el
    idioma pedido y reintenta en en-US (donde TMDB suele tener el oficial). Cachea
    en memoria por sesión."""
    tmdb_int = _to_int(tmdb_id)
    if not tmdb_int:
        return ''
    ck = (media_type, tmdb_int, lang)
    with _trailer_lock:
        if ck in _trailer_cache:
            return _trailer_cache[ck]
    endpoint = 'tv' if media_type == 'show' else 'movie'
    key = _find_trailer_key(endpoint, tmdb_int, lang)
    if not key and lang != 'en-US':
        key = _find_trailer_key(endpoint, tmdb_int, 'en-US')
    with _trailer_lock:
        _trailer_cache[ck] = key
    return key


def _fetch_by_tmdb_id(tmdb_id, media_type):
    endpoint = 'tv' if media_type == 'show' else 'movie'
    # 8 recursos appended (límite TMDB = 20). _parse() ignora claves desconocidas,
    # así que no hay cambios de comportamiento; los datos extra los consume
    # fetch_tmdb_extras() bajo demanda.
    base = {'append_to_response': ('credits,external_ids,similar,recommendations,'
                                    'keywords,videos,release_dates,content_ratings'),
            'language': 'es-ES'}
    payload = _tmdb_get("{0}/{1}".format(endpoint, tmdb_id), base)
    if not payload:
        return None
    if not payload.get('overview'):
        en = _tmdb_get("{0}/{1}".format(endpoint, tmdb_id), dict(base, language='en-US'))
        if en and en.get('overview'):
            payload['overview'] = en['overview']
    return _parse(payload, media_type)


def _find_by_imdb(imdb_id, media_type):
    payload = _tmdb_get("find/{0}".format(imdb_id), {'external_source': 'imdb_id'})
    if not payload:
        return None
    movies = payload.get('movie_results') or []
    shows  = payload.get('tv_results') or []
    if media_type == 'show' and shows:
        return _fetch_by_tmdb_id(shows[0].get('id'), 'show')
    if media_type == 'movie' and movies:
        return _fetch_by_tmdb_id(movies[0].get('id'), 'movie')
    if movies:
        return _fetch_by_tmdb_id(movies[0].get('id'), 'movie')
    if shows:
        return _fetch_by_tmdb_id(shows[0].get('id'), 'show')
    return None


def _pick_search_match(results, year, media_type):
    if not results:
        return None
    target = _to_int(year)
    if not target:
        return results[0]
    date_field = 'first_air_date' if media_type == 'show' else 'release_date'
    same_year = [
        r for r in results
        if (r.get(date_field) or '')[:4].isdigit()
        and int((r.get(date_field) or '')[:4]) == target
    ]
    if same_year:
        return max(same_year, key=lambda r: r.get('vote_count') or 0)
    return results[0]


def _search_by_title(title, year, media_type):
    endpoint = 'tv' if media_type == 'show' else 'movie'
    year_key = 'first_air_date_year' if media_type == 'show' else 'year'
    params   = {'query': title, 'language': 'es-ES'}
    if year:
        params[year_key] = year
    payload = _tmdb_get("search/{0}".format(endpoint), params)
    if not payload:
        return None
    pick = _pick_search_match(payload.get('results') or [], year, media_type)
    if not pick:
        return None
    return _fetch_by_tmdb_id(pick.get('id'), media_type)


def enrich(tmdb_id=None, imdb_id=None, title=None, year=None,
           media_type='movie', use_cache_only=False):
    tmdb_int = _to_int(tmdb_id)
    key = _canon_key(tmdb_int, imdb_id, title, year, media_type)
    if not key:
        return {}

    cached = _cache_get(key)
    if cached is not None:
        return cached
    if use_cache_only:
        return {}

    if tmdb_int:
        meta = _fetch_by_tmdb_id(tmdb_int, media_type)
    elif imdb_id:
        meta = _find_by_imdb(imdb_id, media_type)
    elif title:
        meta = _search_by_title(title, year, media_type)
    else:
        meta = None

    if not meta:
        return {}

    _cache_set(key, meta)
    fetched_tmdb = (meta.get('ids') or {}).get('tmdb')
    fetched_imdb = (meta.get('ids') or {}).get('imdb')
    if fetched_tmdb:
        alt = "tmdb:{0}:{1}".format(media_type, fetched_tmdb)
        if alt != key:
            _cache_set(alt, meta)
    if fetched_imdb:
        alt = "imdb:{0}".format(fetched_imdb)
        if alt != key:
            _cache_set(alt, meta)
    return meta


def batch_enrich(items, use_cache_only=False, max_workers=12):
    results = [{} for _ in items]

    def _one(idx, item):
        return idx, enrich(
            tmdb_id=item.get('tmdb_id'),
            imdb_id=item.get('imdb_id'),
            title=item.get('title'),
            year=item.get('year'),
            media_type=item.get('media_type', 'movie'),
            use_cache_only=use_cache_only,
        )

    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futures = [ex.submit(_one, i, item) for i, item in enumerate(items)]
        for future in as_completed(futures):
            try:
                idx, meta = future.result()
                results[idx] = meta or {}
            except Exception as e:
                _log("batch_enrich item: {0}".format(e), xbmc.LOGWARNING)
    return results


def batch_fetch_with_progress(items, progress_dialog, max_workers=12):
    total = len(items)
    if total == 0:
        return 0

    def _fetch(item):
        return enrich(
            tmdb_id=item.get('tmdb_id'),
            imdb_id=item.get('imdb_id'),
            title=item.get('title'),
            year=item.get('year'),
            media_type=item.get('media_type', 'movie'),
        )

    completed = 0
    success   = 0
    ex = ThreadPoolExecutor(max_workers=max_workers)
    futures = {}
    try:
        futures = {ex.submit(_fetch, item): item for item in items}
        for future in as_completed(futures):
            if progress_dialog.iscanceled():
                break
            item = futures[future]
            completed += 1
            label = item.get('title') or '...'
            progress_dialog.update(
                int(completed * 100 / total),
                "({0}/{1}) {2}".format(completed, total, label),
            )
            try:
                if future.result():
                    success += 1
            except Exception as e:
                _log("batch_fetch item: {0}".format(e), xbmc.LOGWARNING)
    finally:
        # Cancelar debe responder al instante: cancelamos lo que no empezó y NO
        # esperamos a lo en vuelo (el `with` haría shutdown(wait=True) y congelaría
        # la GUI). Lo en vuelo (a lo sumo max_workers, cada uno con timeout) termina
        # solo en segundo plano. cancel_futures no existe en Python 3.8 (Kodi 19).
        for f in futures:
            f.cancel()
        ex.shutdown(wait=False)
    return success


def _build_plot_header(rating, genres, runtime=None, director=None):
    line1 = []
    try:
        r = float(rating or 0)
        if r > 0:
            line1.append("[COLOR yellow]★ {0:.1f}[/COLOR]".format(r))
    except (TypeError, ValueError):
        pass
    if runtime:
        try:
            rt = int(runtime)
            if rt > 0:
                line1.append("{0} min".format(rt))
        except (TypeError, ValueError):
            pass
    if genres:
        if isinstance(genres, str):
            g = genres.strip()
        else:
            g = ", ".join([str(x) for x in genres[:3] if x])
        if g:
            line1.append(g)

    lines = []
    if line1:
        lines.append("[B]" + "  ·  ".join(line1) + "[/B]")
    if director:
        d = director.strip() if isinstance(director, str) else ""
        if d:
            lines.append("[I]Dir: {0}[/I]".format(d))
    if not lines:
        return ""
    return "\n".join(lines) + "\n\n"


def build_plot_header(rating, genres, runtime=None, director=None):
    return _build_plot_header(rating, genres, runtime, director)


def _build_plot(meta):
    tagline  = meta.get('tagline') or ''
    overview = meta.get('overview') or ''
    header   = _build_plot_header(
        meta.get('rating'),
        meta.get('genres'),
        runtime=meta.get('runtime'),
        director=meta.get('director'),
    )
    body     = "[B]{0}[/B]\n\n{1}".format(tagline, overview) if tagline else overview
    return header + body


def _kodi_mediatype(media_type):
    return _KODI_MEDIATYPE.get(media_type, 'movie')


def fetch_watch_providers(tmdb_id, media_type='movie'):
    tid = _to_int(tmdb_id)
    if not tid:
        return {}
    cache_key = 'providers:{0}:{1}'.format(media_type, tid)
    cached = _cache_get(cache_key)
    if cached is not None:
        return cached
    if not _api_key():
        return {}
    endpoint = 'tv' if media_type == 'show' else 'movie'
    data = _tmdb_get('{0}/{1}/watch/providers'.format(endpoint, tid), {})
    if not data:
        return {}
    es = data.get('results', {}).get('ES', {})
    result = {
        'flatrate': [p['provider_name'] for p in es.get('flatrate', [])],
        'free':     [p['provider_name'] for p in es.get('free', [])],
        'buy':      [p['provider_name'] for p in es.get('buy', [])],
        'rent':     [p['provider_name'] for p in es.get('rent', [])],
        'link':     es.get('link', ''),
    }
    _cache_set(cache_key, result)
    return result


_TMDB_EXTRA_CREW_JOBS = {
    'Director':                 'director',
    'Writer':                   'writers',
    'Screenplay':               'writers',
    'Original Music Composer':  'composer',
    'Director of Photography':  'cinematography',
    'Editor':                   'editor',
}


def _pick_certification(payload, media_type):
    """ES preferido, US fallback. Devuelve cadena vacía si no hay nada útil."""
    try:
        if media_type == 'show':
            results = (payload.get('content_ratings') or {}).get('results') or []
            by_cc = {(r or {}).get('iso_3166_1', ''): (r or {}).get('rating', '') for r in results}
            return by_cc.get('ES') or by_cc.get('US') or ''
        results = (payload.get('release_dates') or {}).get('results') or []
        for cc in ('ES', 'US'):
            for r in results:
                if (r or {}).get('iso_3166_1') == cc:
                    for entry in (r.get('release_dates') or []):
                        cert = (entry or {}).get('certification') or ''
                        if cert:
                            return cert
        return ''
    except Exception:
        return ''


def _parse_extras_cast(payload):
    cast = ((payload.get('credits') or {}).get('cast') or [])
    out = []
    for c in cast:
        if not isinstance(c, dict):
            continue
        name = c.get('name') or ''
        role = c.get('character') or ''
        prof = c.get('profile_path') or ''
        if not name:
            continue
        thumb = (_IMG_W185 + prof) if prof else ''
        out.append({'id': str(c.get('id') or ''), 'name': str(name),
                    'role': str(role), 'thumb': thumb})
    return out


def _parse_extras_crew(payload):
    crew = ((payload.get('credits') or {}).get('crew') or [])
    grouped = {v: [] for v in set(_TMDB_EXTRA_CREW_JOBS.values())}
    for c in crew:
        if not isinstance(c, dict):
            continue
        job = c.get('job') or ''
        target = _TMDB_EXTRA_CREW_JOBS.get(job)
        if not target:
            continue
        name = c.get('name') or ''
        if name and name not in grouped[target]:
            grouped[target].append(str(name))
    return grouped


def _parse_extras_videos(payload):
    out = []
    for v in (payload.get('videos') or {}).get('results') or []:
        if not isinstance(v, dict):
            continue
        if (v.get('site') or '').lower() != 'youtube':
            continue
        if (v.get('type') or '') not in ('Trailer', 'Teaser'):
            continue
        key = v.get('key') or ''
        if not key:
            continue
        out.append({
            'name': str(v.get('name') or ''),
            'key':  str(key),
            'type': str(v.get('type') or ''),
        })
    return out


def _parse_extras_similar_like(items, media_type):
    """Parsea entradas de 'similar' o 'recommendations' (mismo schema).
    Omite entradas sin título (la UI no podría hacer drill-down sobre ellas)."""
    out = []
    for it in items or []:
        if not isinstance(it, dict):
            continue
        is_show = (it.get('first_air_date') is not None) or (it.get('name') is not None and not it.get('title'))
        title = it.get('title') if not is_show else it.get('name')
        title = str(title or '').strip()
        if not title:
            continue
        date  = it.get('release_date') if not is_show else it.get('first_air_date')
        year  = 0
        if isinstance(date, str) and len(date) >= 4 and date[:4].isdigit():
            year = int(date[:4])
        poster_path   = it.get('poster_path') or ''
        backdrop_path = it.get('backdrop_path') or ''
        try:
            rating = float(it.get('vote_average') or 0)
        except (TypeError, ValueError):
            rating = 0.0
        try:
            tid = int(it.get('id') or 0)
        except (TypeError, ValueError):
            tid = 0
        out.append({
            'tmdb_id':    tid,
            'title':      title,
            'year':       year,
            'poster':     (_IMG_W342 + poster_path) if poster_path else '',
            'fanart':     (_IMG_ORIG + backdrop_path) if backdrop_path else '',
            'rating':     rating,
            'plot':       str(it.get('overview') or ''),
            'media_type': 'show' if is_show or media_type == 'show' else 'movie',
        })
    return out


def _parse_extras_keywords(payload, media_type):
    kw = payload.get('keywords') or {}
    seq = kw.get('keywords') if media_type != 'show' else kw.get('results')
    out = []
    for k in seq or []:
        if isinstance(k, dict):
            n = k.get('name') or ''
            if n:
                out.append({'id': str(k.get('id') or ''), 'name': str(n)})
    return out


def _parse_extras_externals(payload):
    ext = payload.get('external_ids') or {}
    return {
        'imdb_id':       str(ext.get('imdb_id') or ''),
        'tvdb_id':       str(ext.get('tvdb_id') or ''),  # series: lo usa Fanart.tv
        'twitter_id':    str(ext.get('twitter_id') or ''),
        'instagram_id':  str(ext.get('instagram_id') or ''),
        'facebook_id':   str(ext.get('facebook_id') or ''),
        'homepage':      str(payload.get('homepage') or ''),
    }


def _parse_extras_production(payload, media_type):
    runtime = 0
    if media_type == 'show':
        eprt = payload.get('episode_run_time') or []
        if isinstance(eprt, list) and eprt:
            try:
                runtime = int(eprt[0] or 0)
            except (TypeError, ValueError):
                runtime = 0
    else:
        try:
            runtime = int(payload.get('runtime') or 0)
        except (TypeError, ValueError):
            runtime = 0
    companies = [str(c.get('name') or '') for c in (payload.get('production_companies') or []) if isinstance(c, dict) and c.get('name')]
    countries = [str(c.get('name') or '') for c in (payload.get('production_countries') or []) if isinstance(c, dict) and c.get('name')]
    languages = [str(l.get('english_name') or l.get('name') or '') for l in (payload.get('spoken_languages') or []) if isinstance(l, dict)]
    languages = [x for x in languages if x]
    try:
        budget = int(payload.get('budget') or 0)
    except (TypeError, ValueError):
        budget = 0
    try:
        revenue = int(payload.get('revenue') or 0)
    except (TypeError, ValueError):
        revenue = 0
    return {
        'budget':        budget,
        'revenue':       revenue,
        'runtime':       runtime,
        'companies':     companies,
        'countries':     countries,
        'languages':     languages,
        'certification': _pick_certification(payload, media_type),
    }


def fetch_tmdb_extras(tmdb_id, media_type='movie'):
    """Devuelve datos extra de TMDB no incluidos en el plot estándar:
    reparto completo, equipo técnico, similares, recomendaciones, tráileres,
    palabras clave, IDs externos y datos de producción.
    No cachea: el llamante puede guardar en RAM si quiere reutilizar.
    Devuelve {} si no se puede obtener (id inválido, sin api_key o error de red)."""
    tid = _to_int(tmdb_id)
    if not tid or not _api_key():
        return {}
    endpoint = 'tv' if media_type == 'show' else 'movie'
    append   = ('credits,external_ids,similar,recommendations,'
                'keywords,videos,release_dates,content_ratings')
    payload  = _tmdb_get('{0}/{1}'.format(endpoint, tid),
                          {'append_to_response': append, 'language': 'es-ES'})
    if not payload:
        return {}
    similar_items         = (payload.get('similar') or {}).get('results') or []
    recommendations_items = (payload.get('recommendations') or {}).get('results') or []
    return {
        'cast':            _parse_extras_cast(payload),
        'crew':            _parse_extras_crew(payload),
        'similar':         _parse_extras_similar_like(similar_items, media_type),
        'recommendations': _parse_extras_similar_like(recommendations_items, media_type),
        'videos':          _parse_extras_videos(payload),
        'keywords':        _parse_extras_keywords(payload, media_type),
        'externals':       _parse_extras_externals(payload),
        'production':      _parse_extras_production(payload, media_type),
    }


def apply_to_listitem(li, meta, addon_fanart=''):
    if not meta:
        return
    poster = meta.get('poster') or ''
    li.setArt({
        'icon':   'DefaultVideo.png',
        'thumb':  poster,
        'poster': poster,
        'fanart': meta.get('fanart') or addon_fanart,
    })
    info = {
        'title':     meta.get('title') or '',
        'year':      meta.get('year') or 0,
        'plot':      _build_plot(meta),
        'mediatype': _kodi_mediatype(meta.get('media_type')),
        'genre':     ' / '.join(meta.get('genres') or []),
        'rating':    meta.get('rating') or 0,
        'votes':     str(meta.get('votes') or 0),
        'duration':  (meta.get('runtime') or 0) * 60,
    }
    original = meta.get('original_title') or ''
    if original:
        info['originaltitle'] = original
    director = meta.get('director') or ''
    if director:
        info['director'] = director
    certification = meta.get('certification') or ''
    if certification:
        info['mpaa'] = certification
    # Arte HD de Fanart.tv (opt-in). Lee SOLO de caché aquí (no bloquea el pintado)
    # y encola un prefetch en segundo plano para llenar lo que falte.
    try:
        import fanart_tv
        if fanart_tv.enabled():
            _ftv_ids = meta.get('ids') or {}
            _ftv_tvdb = _ftv_ids.get('tvdb') or (meta.get('externals') or {}).get('tvdb_id')
            _ftv_art = fanart_tv.cached_art(tmdb_id=_ftv_ids.get('tmdb'), tvdb_id=_ftv_tvdb,
                                            media_type=meta.get('media_type'))
            if _ftv_art:
                li.setArt(_ftv_art)
            fanart_tv.request_async(tmdb_id=_ftv_ids.get('tmdb'), tvdb_id=_ftv_tvdb,
                                    media_type=meta.get('media_type'))
    except Exception:
        pass
    # ✔ de visto (local + Trakt) vía el índice en memoria. Best-effort: cualquier
    # fallo aquí no debe impedir pintar el item. import diferido para no crear ciclos.
    try:
        import watched_index
        import movie_ref
        _ids = meta.get('ids') or {}
        _mt = 'show' if meta.get('media_type') in ('show', 'tv') else 'movie'
        _key = movie_ref.ref_key({'tmdb_id': _ids.get('tmdb'), 'imdb_id': _ids.get('imdb'),
                                  'title': meta.get('title'), 'year': meta.get('year'),
                                  'media_type': _mt})
        if watched_index.is_watched_key(_key):
            info['playcount'] = 1
    except Exception:
        pass
    li.setInfo('video', info)
    cast = meta.get('cast') or []
    if cast:
        li.setCast(cast)
