# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
import difflib
import json
import os
import re
import sys
import urllib.error
import urllib.parse
import xml.etree.ElementTree as ET

import requests

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import core_settings
import stats


def _u(**kwargs):
    return core_settings.make_url(**kwargs)


def _mi(filename):
    return os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media', filename)


def _human_size(b):
    for unit in ('B', 'KB', 'MB', 'GB'):
        if b < 1024:
            return "{0:.1f} {1}".format(b, unit)
        b /= 1024
    return "{0:.1f} TB".format(b)


_ACC_COLOR_NAMES = {
    'none':        'Sin modificar (colores originales)',
    'white':       'Texto blanco (todos los colores → blanco)',
    'daltonic_rg': 'Daltónico rojo-verde (deuteranopia/protanopia)',
    'daltonic_by': 'Daltónico azul-amarillo (tritanopia)',
    'hc_dark':     'Alto contraste — fondo oscuro (amarillo)',
    'hc_light':    'Alto contraste — fondo claro (negro)',
}
_ACC_COLOR_PLOTS = {
    'none':        "Los textos aparecen con los colores originales del addon.",
    'white':       "Todos los textos de color se muestran en blanco.\nMáxima legibilidad sobre fondos oscuros.",
    'daltonic_rg': "Optimizado para daltonismo rojo-verde (deuteranopia o protanopia).\nLos rojos pasan a naranja y los verdes a cian.",
    'daltonic_by': "Optimizado para daltonismo azul-amarillo (tritanopia).\nLos amarillos pasan a magenta y los azules/cian a rojo.",
    'hc_dark':     "Alto contraste para skins con fondo oscuro.\nTodo el texto de color se muestra en amarillo, excepto las acciones destructivas (rojo).",
    'hc_light':    "Alto contraste para skins con fondo claro.\nTodo el texto de color se muestra en negro, excepto las acciones destructivas (rojo).",
}


# Menú principal

def _runplugin(**k):
    return "RunPlugin(" + _u(**k) + ")"


# Definición declarativa de todas las entradas del menú principal.
# El ORDEN de inserción de este dict es el orden por defecto del menú.
# Cada entrada: label, icon (+ fallback opcional Default*), action, params, is_folder,
# plot, hideable. hideable=False protege el acceso a Opciones/Información: nunca se
# ocultan aunque aparezcan en la lista 'hidden' del layout guardado.
_MENU_ITEMS_MASTER = {
    'modo_cine': {
        'label': "Modo Cine", 'icon': 'modo_grid.png',
        'action': 'pelis_flix', 'params': {'mode': 'movie'}, 'is_folder': False, 'hideable': True,
        'plot': "Explora películas en una interfaz tipo Netflix, con filas de tops, géneros y plataformas, tráiler al pasar el foco y tu fila de favoritos.",
    },
    'modo_series': {
        'label': "Modo Series", 'icon': 'modo_grid.png',
        'action': 'pelis_flix', 'params': {'mode': 'show'}, 'is_folder': False, 'hideable': True,
        'plot': "Explora series en una interfaz tipo Netflix, con filas de tops, géneros y plataformas, tráiler al pasar el foco y tu fila de favoritos.",
    },
    'search_menu': {
        'label': "Buscar", 'icon': 'busqueda.png', 'action': 'search_menu', 'is_folder': True, 'hideable': True,
        'plot': "Busca por título en los tops cargados (FilmAffinity, SensaCine, Cinemeta, TMDB, Históricas) o directamente en YouTube y Dailymotion.",
    },
    'my_library_menu': {
        'label': "Mi Biblioteca", 'icon': 'mi_biblioteca.png', 'action': 'my_library_menu', 'is_folder': True, 'hideable': True,
        'plot': "Tus favoritos, categorías personales e historiales de visionado y navegación.",
    },
    'trakt_root': {
        'label': "Trakt.tv", 'icon': 'cat_trakt.png', 'action': 'trakt_root', 'is_folder': True, 'hideable': True,
        'plot': "Listas públicas importadas desde Trakt.tv.",
    },
    'filmaffinity_menu': {
        'label': "Mejores Películas", 'icon': 'cat_pelis_top.png', 'action': 'filmaffinity_menu', 'is_folder': True, 'hideable': True,
        'plot': "Top de películas y series por género, con portadas y títulos en español.",
    },
    'filmaffinity_submenu': {
        'label': "FilmAffinity", 'icon': 'cat_filmaffinity.png', 'action': 'filmaffinity_submenu', 'is_folder': True, 'hideable': True,
        'plot': "En cines y top valoradas según FilmAffinity.",
    },
    'sensacine_submenu': {
        'label': "SensaCine", 'icon': 'cat_sensacine.png', 'action': 'sensacine_submenu', 'is_folder': True, 'hideable': True,
        'plot': "Cartelera y estrenos en cines según SensaCine.",
    },
    'cinemeta_submenu': {
        'label': "Cinemeta", 'icon': 'cat_cinemeta.png', 'action': 'cinemeta_submenu', 'is_folder': True, 'hideable': True,
        'plot': "Top y géneros según Cinemeta/Stremio.",
    },
    'trakt_tops_menu': {
        'label': "Trakt — Tops en tiempo real", 'icon': 'top_trakt_real.png', 'action': 'trakt_tops_menu', 'is_folder': True, 'hideable': True,
        'plot': "Tops de Trakt en tiempo real: tendencias, más vistas, taquilla y más esperadas.",
    },
    'streaming_tops_menu': {
        'label': "Por plataforma de streaming", 'icon': 'top_streaming.png', 'action': 'streaming_tops_menu', 'is_folder': True, 'hideable': True,
        'plot': "Lo más popular por plataforma de streaming en España (Netflix, Prime, Disney+, Max...).",
    },
    'mdblist_menu': {
        'label': "MDbList — Listas populares", 'icon': 'top_mdblist.png', 'action': 'mdblist_menu', 'is_folder': True, 'hideable': True,
        'plot': "Listas curadas de MDbList combinando IMDb, Letterboxd, Metacritic, Rotten Tomatoes y Trakt.",
    },
    'anime_menu': {
        'label': "Anime — AniList y MyAnimeList", 'icon': 'top_anime.png', 'action': 'anime_menu', 'is_folder': True, 'hideable': True,
        'plot': "Tops de anime según AniList y MyAnimeList: tendencias, populares y mejor valorados.",
    },
    'letterboxd_menu': {
        'label': "Letterboxd — Listas curadas", 'icon': 'top_lists_popular.png', 'action': 'letterboxd_menu', 'is_folder': True, 'hideable': True,
        'plot': "Listas curadas de la comunidad de Letterboxd.",
    },
    'tmdb_lists_menu': {
        'label': "Rankings de TMDB", 'icon': 'cat_pelis_top.png', 'action': 'tmdb_lists_menu', 'is_folder': True, 'hideable': True,
        'plot': "Rankings oficiales de TMDB: populares, tendencias, mejor valoradas y más.",
    },
    'top_movies': {
        'label': "Top Películas de la Historia", 'icon': 'cat_peliculas.png', 'action': 'top_movies', 'is_folder': True, 'hideable': True,
        'plot': "Las ~130 mejores películas de todos los tiempos con sinopsis, director y nota IMDb.",
    },
    'oscar_movies': {
        'label': "Ganadoras del Oscar", 'icon': 'oscar.png', 'action': 'oscar_movies', 'is_folder': True, 'hideable': True,
        'plot': "Todas las ganadoras del Oscar a Mejor Película desde 1939 hasta hoy, ordenadas por año de ceremonia con sinopsis, director y nota IMDb.",
    },
    'awards': {
        'label': "Otros Premios de Cine y TV", 'icon': 'oscar.png', 'action': 'awards_menu', 'is_folder': True, 'hideable': True,
        'plot': "Ganadores de los Emmy (Drama y Comedia), Globos de Oro (Drama y Comedia/Musical) y BAFTA (Mejor Película), con carátula y reparto desde TMDB.",
    },
    'on_air_calendar': {
        'label': "Calendario de Emisión de Series", 'icon': 'top_series_air.png', 'action': 'on_air_calendar', 'is_folder': True, 'hideable': True,
        'plot': "Próximos episodios de las series en emisión, con día, hora local y sinopsis.",
    },
    'similar_watched': {
        'label': "Recomendado para ti (según tu historial)", 'icon': 'top_similar.png', 'action': 'similar_watched', 'is_folder': True, 'hideable': True,
        'plot': "Películas y series similares a las que has marcado como vistas, combinando las recomendaciones de TMDB de tu historial.",
    },
    'collections_tops': {
        'label': "Sagas y Colecciones", 'icon': 'top_sagas.png', 'action': 'collections_menu', 'is_folder': True, 'hideable': True,
        'plot': "Las películas de cada saga juntas y en orden: Star Wars, El Señor de los Anillos, Harry Potter, James Bond, Fast & Furious y más.",
    },
    'network_tops': {
        'label': "Por Cadena y Estudio", 'icon': 'top_cadena.png', 'action': 'network_tops_menu', 'is_folder': True, 'hideable': True,
        'plot': "Catálogos por cadena de TV (HBO, Netflix, Apple TV+, AMC, Disney+, FX, Hulu) y por estudio de cine (A24, Marvel, Pixar, Studio Ghibli, DreamWorks, Universal, Blumhouse).",
    },
    'decades_tops': {
        'label': "Por Década", 'icon': 'top_decada.png', 'action': 'decades_menu', 'is_folder': True, 'hideable': True,
        'plot': "Las mejores películas de cada década, de los años 70 a los 2020, vía TMDB.",
    },
    'genres_tops': {
        'label': "Por Género", 'icon': 'top_genero.png', 'action': 'genres_menu', 'is_folder': True, 'hideable': True,
        'plot': "Top de películas por género: acción, terror, ciencia ficción, comedia, drama y más.",
    },
    'archive_org': {
        'label': "Cine de Dominio Público", 'icon': 'archive.png', 'action': 'archive_org', 'is_folder': True, 'hideable': True,
        'plot': "Películas de dominio público desde Internet Archive: clásicos, cine negro, ciencia ficción, mudo, animación y documentales. Reproducción directa, contenido libre de derechos.",
    },
    'rtve_alacarta': {
        'label': "RTVE a la carta", 'icon': 'rtve.png', 'action': 'rtve_menu', 'is_folder': True, 'hideable': True,
        'plot': "Canales de RTVE en directo y catálogo de programas, series y documentales de RTVE Play.",
    },
    'surprise_me': {
        'label': "Sorpréndeme", 'icon': 'top_sorpresa.png',
        'action': 'surprise_me', 'is_folder': False, 'hideable': True,
        'plot': "Elige una película o serie al azar de los tops cargados y abre su ficha. Solución al eterno \"¿qué vemos hoy?\".",
    },
    'film_history_today': {
        'label': "Hoy en la historia del cine", 'icon': 'top_hist_hoy.png',
        'action': 'film_history_today', 'is_folder': False, 'hideable': True,
        'plot': "Efemérides del cine: estrenos y hechos notables ocurridos un día como hoy a lo largo de la historia.",
    },
    'options_menu': {
        'label': "Opciones", 'icon': 'opciones.png', 'action': 'options_menu', 'is_folder': True, 'hideable': False,
        'plot': "Ajustes, accesibilidad visual, backup y limpieza.",
    },
    'info_menu': {
        'label': "EspaKodi e Información", 'icon': 'info.png', 'action': 'info_menu', 'is_folder': True, 'hideable': False,
        'plot': "Universo EspaKodi, versión, términos y avisos.",
    },
}


def _menu_item_icon(icon):
    if not icon:
        return 'DefaultFolder.png'
    if icon.startswith('Default'):
        return icon
    p = _mi(icon)
    return p if os.path.isfile(p) else 'DefaultFolder.png'


def _get_effective_layout():
    """Lista ordenada de ids visibles según el layout guardado.

    Aplica el 'order' (solo ids válidos, sin duplicar), añade al final los ids del
    MASTER que no estén en el orden guardado (entradas nuevas tras una actualización)
    y quita los 'hidden'. Las entradas hideable=False nunca se ocultan.
    """
    layout = core_settings.load_menu_layout()
    valid = list(_MENU_ITEMS_MASTER)
    valid_set = set(valid)
    hidden = set(layout.get('hidden', []))

    order, seen = [], set()
    for k in layout.get('order', []):
        if k in valid_set and k not in seen:
            order.append(k)
            seen.add(k)
    for k in valid:
        if k not in seen:
            order.append(k)
            seen.add(k)

    return [k for k in order
            if not (_MENU_ITEMS_MASTER[k].get('hideable', True) and k in hidden)]


def _render_menu_item(key, h, fanart, _bold, _strip, _color, full_order, is_hidden=False):
    """Pinta una entrada del menú. Aislada: un error en una entrada (label/plot/icono
    de una versión futura) no debe tumbar el menú entero."""
    defn = _MENU_ITEMS_MASTER.get(key)
    if not defn:
        return False
    try:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            "[B]{0}[/B]".format(defn['label']), bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': _menu_item_icon(defn.get('icon', '')), 'fanart': fanart})
        plot = defn.get('plot', '')
        if plot:
            li.setInfo('video', {'plot': plot})

        idx = full_order.index(key) if key in full_order else -1
        cm = []
        if idx > 0:
            cm.append(("Subir en el menú", _runplugin(action='menu_item_up', key=key)))
        if 0 <= idx < len(full_order) - 1:
            cm.append(("Bajar en el menú", _runplugin(action='menu_item_down', key=key)))
        if defn.get('hideable', True):
            label = "Mostrar en el menú" if is_hidden else "Ocultar del menú"
            cm.append((label, _runplugin(action='menu_toggle_hidden', key=key)))
        cm.append(("Personalizar menú…", _runplugin(action='customize_menu_screen')))
        li.addContextMenuItems(cm)

        xbmcplugin.addDirectoryItem(handle=h, url=_u(action=defn['action'], **defn.get('params', {})),
                                     listitem=li, isFolder=defn.get('is_folder', True))
        return True
    except Exception as e:
        xbmc.log("[TopZilla] Menú: entrada '{0}' omitida por error: {1}".format(key, e), xbmc.LOGWARNING)
        return False


def _main_menu():
    h = int(sys.argv[1])
    _bold = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()
    _fanart = core_settings.addon_fanart()

    # full_order incluye TODAS las entradas (también las ocultas): el menú contextual
    # lo usa para saber si una entrada puede subir/bajar. El bucle solo pinta las visibles.
    full_order = _main_menu_full_order()
    hidden = set(core_settings.load_menu_layout().get('hidden', []))

    # RTVE solo es relevante en español: se muestra únicamente si Kodi está en español.
    show_rtve = xbmc.getLanguage(xbmc.ISO_639_1) == 'es'

    for key in _get_effective_layout():
        if key == 'rtve_alacarta' and not show_rtve:
            continue
        _render_menu_item(key, h, _fanart, _bold, _strip, _color, full_order, is_hidden=key in hidden)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)

    # Ventana de bienvenida (una vez por versión; el gating vive dentro de show()).
    # Se lanza tras pintar el menú para que quede de fondo; un fallo aquí no debe
    # impedir que el menú se muestre.
    try:
        import welcome_splash
        welcome_splash.show()
    except Exception as e:
        xbmc.log("[TopZilla] welcome_splash: {0}".format(e), xbmc.LOGWARNING)



def _menu_shift(key, delta):
    full = _main_menu_full_order()
    if key not in full:
        return
    i = full.index(key)
    j = i + delta
    if j < 0 or j >= len(full):
        return
    full[i], full[j] = full[j], full[i]
    layout = core_settings.load_menu_layout()
    core_settings.save_menu_layout({'order': full, 'hidden': layout.get('hidden', [])})


def _menu_toggle_hidden(key):
    defn = _MENU_ITEMS_MASTER.get(key)
    if not defn or not defn.get('hideable', True):
        return
    layout = core_settings.load_menu_layout()
    hidden = [k for k in layout.get('hidden', []) if k in _MENU_ITEMS_MASTER]
    if key in hidden:
        hidden.remove(key)
    else:
        hidden.append(key)
    order = layout.get('order') or _main_menu_full_order()
    core_settings.save_menu_layout({'order': order, 'hidden': hidden})


def _main_menu_full_order():
    """Orden completo actual (todas las entradas, visibles y ocultas)."""
    layout = core_settings.load_menu_layout()
    full, seen = [], set()
    for k in layout.get('order', []):
        if k in _MENU_ITEMS_MASTER and k not in seen:
            full.append(k)
            seen.add(k)
    for k in _MENU_ITEMS_MASTER:
        if k not in seen:
            full.append(k)
            seen.add(k)
    return full


def _customize_menu_screen():
    h = int(sys.argv[1])
    _bold = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()
    af = core_settings.addon_fanart()

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Reordenar / ocultar entradas[/B]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _menu_item_icon('adv_priorizar.png'), 'fanart': af})
    li.setInfo('video', {'plot': "Sube, baja u oculta las entradas del menú principal a tu gusto."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="reorder_menu"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR orange][B]Restaurar menú por defecto[/B][/COLOR]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultIconInfo.png', 'fanart': af})
    li.setInfo('video', {'plot': "Devuelve el menú principal a su orden original y muestra todas las entradas."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="reset_menu_layout"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _reset_menu_layout_action():
    if xbmcgui.Dialog().yesno("Restaurar menú", "¿Devolver el menú principal a su orden original y mostrar todas las entradas?"):
        core_settings.reset_menu_layout()
        xbmcgui.Dialog().notification("TopZilla", "Menú restaurado", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


def _menu_plain_label(key):
    """Etiqueta sin BBCode para mostrarla en los diálogos de reordenación."""
    label = _MENU_ITEMS_MASTER.get(key, {}).get('label', key)
    return re.sub(r'\[/?(?:B|I|COLOR[^\]]*)\]', '', label).strip()


def _reorder_menu():
    while True:
        full = _main_menu_full_order()
        layout = core_settings.load_menu_layout()
        hidden = set(layout.get('hidden', []))
        if len(full) < 2:
            xbmcgui.Dialog().notification("TopZilla", "No hay entradas suficientes para reordenar", xbmcgui.NOTIFICATION_INFO)
            return

        labels = []
        for k in full:
            name = _menu_plain_label(k)
            if k in hidden and _MENU_ITEMS_MASTER[k].get('hideable', True):
                name += "  [COLOR grey][oculto][/COLOR]"
            labels.append("↕  " + name)
        labels.append("[COLOR orange]Restaurar por defecto[/COLOR]")

        sel = xbmcgui.Dialog().select("Reordenar / ocultar menú", labels)
        if sel < 0:
            xbmc.executebuiltin("Container.Refresh")
            return
        if sel == len(full):
            if xbmcgui.Dialog().yesno("Restaurar menú", "¿Devolver el menú a su orden original y mostrar todas las entradas?"):
                core_settings.reset_menu_layout()
                xbmcgui.Dialog().notification("TopZilla", "Menú restaurado", xbmcgui.NOTIFICATION_INFO)
            continue

        key = full[sel]
        defn = _MENU_ITEMS_MASTER.get(key, {})
        is_hidden = key in hidden
        opts = []
        if sel > 0:
            opts.append(('up', "↑ Subir"))
        if sel < len(full) - 1:
            opts.append(('down', "↓ Bajar"))
        if defn.get('hideable', True):
            opts.append(('toggle', "Mostrar" if is_hidden else "Ocultar"))
        opts.append(('cancel', "Cancelar"))

        sel2 = xbmcgui.Dialog().select('"{0}"'.format(_menu_plain_label(key)), [o[1] for o in opts])
        if sel2 < 0:
            continue
        act = opts[sel2][0]
        if act == 'cancel':
            continue
        if act == 'up':
            _menu_shift(key, -1)
        elif act == 'down':
            _menu_shift(key, 1)
        elif act == 'toggle':
            _menu_toggle_hidden(key)


def _add_kodi_favourite(title, sec_action, params, icon):
    """Añade una sección del addon a los Favoritos nativos de Kodi vía JSON-RPC.
    Devuelve True si Kodi confirma el alta."""
    try:
        plugin_url = core_settings.make_url(action=sec_action, **params)
        resp = json.loads(xbmc.executeJSONRPC(json.dumps({
            'jsonrpc': '2.0', 'id': 1,
            'method': 'Favourites.AddFavourite',
            'params': {'title': title, 'type': 'window', 'window': 'videos',
                       'windowparameter': plugin_url, 'thumbnail': icon},
        })) or '{}')
        return resp.get('result') == 'OK'
    except (ValueError, TypeError, RuntimeError) as e:
        xbmc.log("[TopZilla] fav_kodi: {0}".format(e), xbmc.LOGWARNING)
        return False


# Secciones del menú que son configuración pura: no tiene sentido guardarlas
# como acceso directo de contenido en los favoritos de Kodi.
_FAV_SECTION_EXCLUDE = frozenset({'options_menu'})


def _fav_add_section_picker():
    """Elige una sección del addon y la guarda en los Favoritos de Kodi
    (pantalla de inicio) como acceso directo."""
    h = int(sys.argv[1])
    keys = [k for k in _MENU_ITEMS_MASTER if k not in _FAV_SECTION_EXCLUDE]
    labels = [re.sub(r'\[/?[A-Za-z][^\]]*\]', '', _MENU_ITEMS_MASTER[k]['label']).strip()
              for k in keys]
    # Cerramos el directorio antes del diálogo (igual que wikipedia/tmdb_extras):
    # no dejamos un contenedor del plugin a medio cargar bajo el select.
    xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
    sel = xbmcgui.Dialog().select("Añadir sección a Favoritos de Kodi", labels)
    if sel < 0:
        return
    defn = _MENU_ITEMS_MASTER[keys[sel]]
    title = labels[sel]
    icon = _menu_item_icon(defn.get('icon', ''))
    if _add_kodi_favourite(title, defn['action'], defn.get('params', {}), icon):
        xbmcgui.Dialog().notification("TopZilla", "Añadido a Favoritos de Kodi: {0}".format(title),
                                      xbmcgui.NOTIFICATION_INFO, 2500)
    else:
        xbmcgui.Dialog().notification("TopZilla", "No se pudo añadir a Favoritos de Kodi",
                                      xbmcgui.NOTIFICATION_WARNING, 3000)


def _my_library_menu():
    h = int(sys.argv[1])
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()

    items = [
        ("Mis Favoritos",           "favoritos.png",       "favorites_menu",          True,  "Tus películas y series marcadas como favoritas."),
        ("Quiero ver",              "DefaultPlaylist.png", "watchlist_menu",          True,  "Lista de títulos pendientes de ver. Añade aquí lo que quieres ver y muévelo a Favoritos cuando lo hayas visto."),
        ("Mis Categorías",          "DefaultPlaylist.png", "categories_menu",         True,  "Tus colecciones personalizadas de películas."),
        ("Historial de Visionado",  "hist_visionado.png",  "watch_history_menu",      True,  "Películas y series que has marcado como vistas."),
        ("Historial de Navegación", "historial.png",       "navigation_history_menu", True,  "Películas que has visitado recientemente."),
        ("Mis estadísticas",        "DefaultIconInfo.png", "stats_personal",          False, "Resumen de tu biblioteca: favoritos, historial, géneros preferidos, décadas y tiempo total visto."),
        ("Mi nube Debrid",          "descargas.png",       "debrid_cloud",            True,  "Contenido alojado en tu cuenta Debrid (AllDebrid, Real-Debrid, TorBox o Premiumize). Reproduce o borra directamente desde tu nube."),
        ("Añadir sección a Favoritos de Kodi", "favoritos.png", "fav_add_section_picker", True, "Guarda cualquier sección del addon en los Favoritos de Kodi (pantalla de inicio) para un acceso directo."),
        ("Exportar a TXT",          "DefaultFile.png",     "export_txt",              False, "Exporta favoritos, listas, historiales, categorías y estadísticas a un archivo de texto legible."),
    ]
    for label, icon, action, is_folder, plot in items:
        li = xbmcgui.ListItem(label=core_settings.apply_label("[B]{0}[/B]".format(label), bold=_bold, strip=_strip, color_mode=_color))
        icon_path = icon if icon.startswith('Default') else _mi(icon)
        li.setArt({'icon': icon_path, 'fanart': core_settings.addon_fanart()})
        li.setInfo('video', {'plot': plot})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action=action), listitem=li, isFolder=is_folder)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _surprise_me():
    import random
    import search_movies
    import movie_ref as mr

    pool = search_movies._collect_all_items()
    if not pool:
        xbmcgui.Dialog().notification(
            "TopZilla", "Abre algunos tops primero para alimentar Sorpréndeme",
            xbmcgui.NOTIFICATION_INFO, 3500)
        xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=False)
        return

    # Filtro opcional: solo no vistos si hay historial
    try:
        import watch_history
        watched = watch_history.watched_keys()
        pool_unseen = [i for i in pool if mr.ref_key(mr.make_ref(
            title=i.get('title', ''), year=i.get('year'),
            tmdb_id=i.get('tmdb_id'), imdb_id=i.get('imdb_id'),
            media_type=i.get('media_type', 'movie'))) not in watched]
        if pool_unseen:
            pool = pool_unseen
    except Exception:
        pass

    item = random.choice(pool)
    ref = mr.make_ref(
        title=item.get('title', ''),
        year=item.get('year'),
        tmdb_id=item.get('tmdb_id'),
        imdb_id=item.get('imdb_id'),
        media_type=item.get('media_type', 'movie'),
        poster=item.get('poster', ''),
    )
    _search_alternatives_prompt(
        ref['title'], ref.get('poster', ''), ref.get('media_type', 'movie'), ref=ref)
    xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=False)


# EspaKodi e Información

def info_menu():
    h = int(sys.argv[1])
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()
    af = core_settings.addon_fanart()

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR skyblue][B]Universo EspaKodi[/B][/COLOR]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('info_universo.png'), 'fanart': af})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="show_universo"), listitem=li, isFolder=False)

    try:
        ver = xbmcaddon.Addon().getAddonInfo("version") or "?.?.?"
    except Exception:
        ver = "?.?.?"
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Versión {0}[/B]".format(ver), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('info_version.png'), 'fanart': af})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="easter_egg_lumiere"), listitem=li, isFolder=False)

    _ek_logo = _mi('espakodi_logo.jpg')
    _ek_icon = _ek_logo if os.path.exists(_ek_logo) else _mi('descargas.png')
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR gold][B]EspaKodi Addons[/B][/COLOR]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _ek_icon, 'fanart': af})
    li.setInfo('video', {'plot': "Instala y gestiona todos los addons del ecosistema EspaKodi: EspaTV, EspaDaily, AtresDaily, LoioLog, Flow FavManager, StreamNinja."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="espakodi_addons_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR yellow][B]La VPN puede causar fallos o ser necesaria[/B][/COLOR] — Algunos servidores bloquean VPNs (desactívala si algo no carga). En Dailymotion puede ocurrir lo contrario, si no carga prueba activando la VPN.",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('info_vpn.png'), 'fanart': af})
    li.setInfo('video', {'plot': "Algunos servidores bloquean VPNs (desactívala si algo no carga). En Dailymotion puede ocurrir lo contrario, si no carga prueba activando la VPN."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="vpn_info"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR lightgreen][B]Próximamente: más países e idiomas[/B][/COLOR] — Este addon se adaptará a más países y contará con más idiomas en futuras versiones.",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_idioma.png'), 'fanart': af})
    li.setInfo('video', {'plot': "Este addon se adaptará a más países y contará con más idiomas en futuras versiones."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="future_i18n_info"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def _info():
    t = (
        "[B]AVISO LEGAL Y TÉCNICO IMPORTANTE:[/B]\n\n"

        "[B]1. Gratuito y sin ánimo de lucro:[/B]\n"
        "Este addon es completamente GRATUITO y siempre lo será. Si alguien te lo ha vendido, te han estafado. Cualquier etiqueta tipo \"Premium\" o equivalente hace referencia a la suscripción de la plataforma de origen; no a este addon.\n\n"

        "[B]2. Responsabilidad del Usuario:[/B]\n"
        "El desarrollador no tiene control sobre los resultados encontrados en servidores externos. El usuario es el único responsable de verificar la legalidad del acceso a dichos contenidos según las leyes de su país de residencia. Este addon se proporciona \"tal cual\", sin garantías de ningún tipo.\n\n"

        "[B]3. No Afiliación:[/B]\n"
        "Este proyecto es independiente. NO tiene ninguna afiliación, acuerdo ni vinculación con FilmAffinity, SensaCine, TMDB, Trakt, Cinemeta, ni con ninguna otra plataforma o entidad oficial. Las marcas comerciales se utilizan con fin únicamente descriptivo para organizar los menús de búsqueda.\n\n"

        "[B]4. Naturaleza Técnica (Agregador de Búsqueda):[/B]\n"
        "Este software actúa exclusivamente como una herramienta de automatización. NO contiene, aloja ni sube contenido protegido.\n"
        "• El addon nunca interactúa, descifra ni elude la seguridad de servidores de terceros.\n"
        "• Funciona realizando búsquedas de texto en servidores públicos de terceros, mostrando resultados que ya son accesibles públicamente en cualquier navegador web.\n\n"

        "[B]5. Propósito:[/B]\n"
        "Proyecto amateur. Sin publicidad ni recolección de hábitos de uso.\n\n"

        "[B]Contacto y Retirada:[/B]\n"
        "Si usted es titular de derechos y considera que este software le perjudica, puede solicitar la retirada de funcionalidad relacionada a través de los canales indicados en el repositorio oficial.\n\n"

        "[B]¿Qué puedo encontrar?[/B]\n"
        "El addon intenta filtrar los resultados con la mayor precisión posible, pero la precisión depende totalmente del contenido disponible públicamente en ese momento.\n"
        "• A veces solo aparecerán tráilers, resúmenes o clips.\n"
        "• En ocasiones pueden aparecer resultados solo relacionados o similares.\n"
        "El addon NO garantiza qué resultados aparecen, ya que depende exclusivamente de lo que otros usuarios hayan compartido en la red."
    )
    xbmcgui.Dialog().textviewer("Información de TopZilla", t)


def _parental_gate():
    """True si se puede abrir Opciones: sin protección, sin PIN configurado (para no
    dejar al usuario fuera), o PIN correcto. El PIN se borra desde los ajustes nativos
    de Kodi si se olvida (esos no pasan por aquí)."""
    if not core_settings.is_parental_options_protected():
        return True
    pin = core_settings.get_parental_pin()
    if not pin:
        return True
    entered = xbmcgui.Dialog().input("PIN de control parental",
                                     type=xbmcgui.INPUT_NUMERIC)
    if entered == pin:
        return True
    if entered:  # '' = cancelado; no molestar con aviso al cancelar
        xbmcgui.Dialog().notification("TopZilla", "PIN incorrecto",
                                      xbmcgui.NOTIFICATION_WARNING, 2000)
    return False


def _options_menu():
    h = int(sys.argv[1])
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()

    auto = core_settings._auto_fetch_enabled()
    auto_tag = core_settings.state_tag(auto)
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Enriquecer metadatos con TMDB[/B] (no siempre es lo mejor)  {0}".format(auto_tag), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_busqueda.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Consulta TMDB al navegar para completar lo que ya trae cada fuente. Añade sinopsis en español, géneros, reparto con fotos y carátulas de mayor calidad (úsalo solo si lo que ves no te convence, no siempre es lo mejor).\n\nLa principal ventaja es obtener datos en español cuando la fuente original carece de ellos o los tiene en otro idioma.\n\nLos datos se guardan en caché 30 días; solo se hacen peticiones nuevas la primera vez que se visita cada título.\n\n[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="toggle_auto_fetch"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label("[B]Atajos en ¿Dónde buscar?[/B]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_busqueda.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': (
        "Añade atajos al menú '¿Dónde buscar?' que aparece al hacer clic en cualquier película o serie.\n\n"
        "Puedes añadir cualquier addon instalado en Kodi para abrirlo directamente, o añadir "
        "comandos de Kodi.\n\n"
        "Los atajos personalizados aparecen en dorado dentro del menú.")})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="search_shortcuts_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label=core_settings.apply_label("[B]Modo Cine y listas[/B]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('modo_grid.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Configura el Modo Cine (filas, tráiler, carga perezosa, recordar posición y apertura al iniciar) y el modo de apertura de las listas de películas."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="cine_options_menu"), listitem=li, isFolder=True)

    ctx = core_settings._show_context_menu_enabled()
    ctx_tag = core_settings.state_tag(ctx)
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Guardar en biblioteca (menú contextual global)[/B]  {0}".format(ctx_tag), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_contexto.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Inserta \"Añadir a Favoritos (TopZilla)\" en el menú contextual de casi cualquier película o serie en Kodi para ver su ficha en TopZilla. Permite guardarlo en tus Favoritos sin abrir antes TopZilla. El menú contextual se abre con clic derecho, manteniendo pulsado en pantallas táctiles o con el botón de menú del mando.\n\nCuando ya hayas visto ese título en TopZilla, la carátula y la sinopsis se rellenan desde la caché local sin tocar la red. Si el título no está en la caché y tienes activado \"Enriquecer metadatos con TMDB\", se hará una consulta a TMDB y el resultado quedará guardado para los siguientes accesos.\n\n[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="toggle_show_context_menu"), listitem=li, isFolder=False)

    cm_wl = core_settings.get_bool_setting('show_context_menu_watchlist', False)
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Guardar en \"Quiero ver\" (menú contextual global)[/B]  {0}".format(core_settings.state_tag(cm_wl)), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_contexto.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Añade \"Añadir a Quiero ver (TopZilla)\" al menú contextual de Kodi para guardar títulos pendientes de ver.\n\n[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="toggle_context_watchlist"), listitem=li, isFolder=False)

    ctx_vc = core_settings._show_context_menu_view_card_enabled()
    ctx_vc_tag = core_settings.state_tag(ctx_vc)
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Ver ficha desde menú contextual global[/B]  {0}".format(ctx_vc_tag), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('info.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Inserta \"Ver ficha (TopZilla)\" en el menú contextual de casi cualquier película o serie en Kodi. Abre directamente la ficha nativa de TopZilla (el diálogo con \"¿Dónde verla en España?\", YouTube, Dailymotion, Wikipedia, ficha completa…) sobre el título seleccionado, sin necesidad de añadirlo antes a Favoritos.\n\nLos títulos abiertos por esta vía [B]no[/B] se guardan en el Historial de navegación de TopZilla, ya que provienen de fuentes externas al addon.\n\n[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="toggle_show_context_menu_view_card"), listitem=li, isFolder=False)

    cm_copy = core_settings.get_bool_setting('show_context_menu_copy', False)
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Copiar título desde menú contextual[/B]  {0}".format(core_settings.state_tag(cm_copy)), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('compartir.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': 'Añade "Copiar título" al menú contextual. Copia el nombre de cualquier peli o serie para volver a buscarlo después sin tener que escribirlo de nuevo.\n\n[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]'})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="toggle_context_copy"), listitem=li, isFolder=False)

    cm_paste = core_settings.get_bool_setting('show_context_menu_paste', False)
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Pegar texto desde menú contextual[/B]  {0}".format(core_settings.state_tag(cm_paste)), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('url_paste.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': 'Añade "Pegar texto" al menú contextual. Si te mandan el nombre de una peli o serie por WhatsApp, cópialo y pégalo en el buscador de un toque, sin escribirlo.\n\n[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]'})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="toggle_context_paste"), listitem=li, isFolder=False)

    clip_sync = core_settings.get_bool_setting('clipboard_sync_to_os', True)
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Sincronizar portapapeles con el sistema[/B]  {0}".format(core_settings.state_tag(clip_sync)), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('url_clipboard.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Al copiar dentro de TopZilla, copia también al portapapeles del sistema operativo. En Android no está disponible.\n\n[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="toggle_clipboard_sync"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label("[B]Fanart de fondo[/B]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_fanart.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Controla la imagen de fondo que se muestra en los menús del addon.\n\nPuedes usar la imagen del propio addon, una imagen tuya o desactivarlo por completo."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="fanart_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label=core_settings.apply_label("[B]Claves API[/B]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_api_key.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Configura tus claves API de TMDB y Trakt para mayor velocidad y estabilidad."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="api_keys_menu"), listitem=li, isFolder=True)

    tws_tag = core_settings.state_tag(core_settings.get_trakt_write_sync())
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Enviar vistas y favoritos a Trakt[/B]  {0}".format(tws_tag), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_api_key.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Al marcar una película como vista, se añade a tu historial de Trakt. Tus favoritos del addon se sincronizan también con tu watchlist de Trakt. Necesitas la cuenta vinculada desde Mi Trakt.\n\n[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="toggle_trakt_write_sync"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label("[B]Accesibilidad[/B]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_accesibilidad.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Opciones de accesibilidad visual: modo de color, negrita forzada y sustitución de símbolos.\n\nAdapta la apariencia del addon para distintas necesidades visuales (daltonismo, alto contraste, etc.)."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="accessibility_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label=core_settings.apply_label("[B]Modo Televisión Vintage (CRT)[/B]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('crt_tv.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Simula una televisión de tubo antigua sobre el vídeo con líneas de barrido, viñeta, marco curvo, tinte cálido, grano y parpadeo, cada uno activable por separado. Se aplica a cualquier vídeo que reproduzcas en Kodi mientras esté activo."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="crt_config_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label=core_settings.apply_label("[B]Backup y restauración[/B]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_backup.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Crea backups ZIP de tus favoritos, categorías, historiales y configuración Trakt.\nRestaura desde un backup previo (modo Sustituir o Fusionar)."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="backup_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label=core_settings.apply_label("[B]Limpieza[/B]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_limpieza.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Limpieza básica y gestor de almacenamiento avanzado."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="limpieza_parent_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label=core_settings.apply_label("[B]Personalizar menú principal[/B]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_editar.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Reordena, oculta o muestra las entradas del menú principal a tu gusto."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="customize_menu_screen"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label=core_settings.apply_label("[B]Tráileres de YouTube (avanzado)[/B]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultAddonVideo.png', 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Reproducir tráileres con yt-dlp del sistema (solo Windows) y configurar las cookies para evitar el bloqueo 'confirma que no eres un bot'."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="youtube_options_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label=core_settings.apply_label("[B]Escribir sin mando[/B]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('url_remote.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Cómo introducir texto (búsquedas, claves): teclado del mando, servidor local en tu red, o servidor online vía relay."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="remote_input_options_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label=core_settings.apply_label("[B]Control parental[/B]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_api_key.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Proteger el menú Opciones con un PIN numérico."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="parental_options_menu"), listitem=li, isFolder=True)

    fanart_tv = core_settings.get_bool_setting('fanart_tv_enabled', False)
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Arte de Fanart.tv (logos/fondos HD)[/B]  {0}".format(core_settings.state_tag(fanart_tv)), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_fanart.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Usa Fanart.tv para clearlogo y fondos de alta calidad, con TMDB de respaldo. Requiere tu clave personal de Fanart.tv (Opciones → Claves API).\n\n[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="toggle_fanart_tv"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label("[B]Inicio automático de addons[/B]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('shortcut_addon.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Configura hasta 3 addons que se abrirán solos al arrancar Kodi, con un retardo opcional para cada uno."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="autostart_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label=core_settings.apply_label("[B]Inicio automático de favoritos[/B]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('favoritos.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Configura hasta 3 favoritos de Kodi que se abrirán solos al arrancar, con un retardo opcional para cada uno."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="autofav_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label=core_settings.apply_label("[B]Ventana de ajustes nativa de Kodi[/B]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_ajustes.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Abre el panel de ajustes del addon."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="open_addon_settings"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label("[B]Diagnóstico[/B]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_debug.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Herramientas de diagnóstico: modo debug, visor de log y estado del registro de Kodi."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="diagnostico_menu"), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _toggle_debug():
    # Settings.SetSettingValue (síncrono, fija un valor exacto) en vez de
    # ToggleDebugLogging (builtin asíncrono que obligaría a esperar para leer
    # el estado). Mismo enfoque que LoioLog.
    new_state = not xbmc.getCondVisibility("System.GetBool(debug.showloginfo)")
    xbmc.executeJSONRPC(json.dumps({
        "jsonrpc": "2.0", "id": 1, "method": "Settings.SetSettingValue",
        "params": {"setting": "debug.showloginfo", "value": new_state},
    }))
    xbmcgui.Dialog().notification(
        "TopZilla", "Modo Debug " + ("activado" if new_state else "desactivado"),
        xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin("Container.Refresh")


def _view_log():
    import xbmcvfs
    import log_manager
    path = xbmcvfs.translatePath('special://logpath/kodi.log')
    try:
        with open(path, 'r', encoding='utf-8', errors='ignore') as fh:
            lines = [ln for ln in fh if 'TopZilla' in ln]
    except OSError as e:
        xbmcgui.Dialog().ok("TopZilla", "No se pudo leer el log de Kodi:\n{0}".format(e))
        return
    if not lines:
        xbmcgui.Dialog().ok("TopZilla", "Aún no hay entradas de TopZilla en el log.")
        return
    tail = lines[-200:]
    xbmcgui.Dialog().textviewer(
        "Log de TopZilla (últimas {0} líneas)".format(len(tail)),
        "".join(log_manager.sanitize_line(l) for l in tail))


def _diagnostico_menu():
    h = int(sys.argv[1])
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()
    af = core_settings.addon_fanart()

    kodi_dbg = xbmc.getCondVisibility("System.GetBool(debug.showloginfo)")
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Modo Debug[/B]  {0}".format(core_settings.state_tag(kodi_dbg)), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_debug.png'), 'fanart': af})
    li.setInfo('video', {'plot': "Activa el registro detallado de Kodi (nivel DEBUG), necesario para que las entradas de TopZilla en el log sean útiles al diagnosticar un fallo.\n\nEquivalente a Ajustes → Sistema → Registro → Activar registro de depuración.\n\n[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="toggle_debug"), listitem=li, isFolder=False)

    redact = core_settings.get_bool_setting('log_redact_paths', True)
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Censurar datos sensibles del log[/B]  {0}".format(core_settings.state_tag(redact)), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_api_key.png'), 'fanart': af})
    li.setInfo('video', {'plot': "Oculta del log las rutas del sistema (la carpeta de tu usuario) y las direcciones IP, para poder compartirlo sin filtrar datos personales.\n\nLas claves API y los tokens se ocultan siempre, independientemente de esta opción.\n\n[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="toggle_log_redact"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label("[B]Visor de log[/B]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultFile.png', 'fanart': af})
    li.setInfo('video', {'plot': "Ver, buscar y exportar el log de Kodi para diagnosticar fallos. Las líneas de TopZilla aparecen destacadas y las claves o tokens se ocultan automáticamente."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="log_manager_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label=core_settings.apply_label("[B]Ver log de TopZilla[/B]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_busqueda.png'), 'fanart': af})
    li.setInfo('video', {'plot': "Muestra las últimas 200 líneas del log correspondientes a TopZilla, con los datos sensibles censurados."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="view_log"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _toggle_log_redact():
    core_settings.set_bool_setting(
        'log_redact_paths', not core_settings.get_bool_setting('log_redact_paths', True))
    xbmc.executebuiltin("Container.Refresh")


# Defaults espejo de settings.xml (categoría "Modo Vintage"): única fuente que usan
# el menú para pintar el estado y el toggle para invertirlo antes del primer guardado.
_CRT_DEFAULTS = {
    'crt_enabled': False, 'crt_scanlines': True, 'crt_vignette': True,
    'crt_bezel': True, 'crt_sepia': False, 'crt_grain': True,
    'crt_rollbar': False, 'crt_flicker': False,
}
_CRT_EFFECTS = [
    ('crt_scanlines', 'Líneas de barrido (scanlines)', 'Finas líneas horizontales oscuras, el rasgo más reconocible de una TV de tubo.'),
    ('crt_vignette',  'Viñeta (bordes oscuros)',       'Oscurece las esquinas para imitar el brillo desigual del tubo.'),
    ('crt_bezel',     'Marco curvo del tubo',          'Marco oscuro con esquinas redondeadas que simula la curvatura de la pantalla.'),
    ('crt_sepia',     'Tinte cálido (sepia)',          'Da un tono ámbar cálido a la imagen, como el fósforo de las pantallas viejas.'),
    ('crt_grain',     'Grano / estática',              'Ruido animado superpuesto, como la nieve de una señal débil de antena.'),
    ('crt_rollbar',   'Barra de desincronización',     'Banda de luz tenue que recorre la pantalla de arriba abajo, como una TV mal sintonizada.'),
    ('crt_flicker',   'Parpadeo de brillo',            'Leve parpadeo del brillo, como el barrido inestable de un tubo antiguo.'),
]


def _crt_config_menu():
    h = int(sys.argv[1])
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()

    master = core_settings.get_bool_setting('crt_enabled', _CRT_DEFAULTS['crt_enabled'])
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Activar Modo CRT[/B]  {0}".format(core_settings.state_tag(master)),
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('crt_tv.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Activa o desactiva el filtro de TV de tubo sobre la reproducción de vídeo. Se aplica a TODOS los vídeos de Kodi mientras esté activo.\n\nSi lo activas a mitad de sesión puede que necesites reiniciar Kodi una vez para que el servicio del filtro arranque.\n\n[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="crt_toggle", key="crt_enabled"), listitem=li, isFolder=False)

    if master:
        for key, label, plot in _CRT_EFFECTS:
            on = core_settings.get_bool_setting(key, _CRT_DEFAULTS[key])
            li = xbmcgui.ListItem(label=core_settings.apply_label(
                "[B]{0}:[/B] {1}".format(label, core_settings.state_tag(on)),
                bold=_bold, strip=_strip, color_mode=_color))
            li.setArt({'icon': _mi('crt_tv.png'), 'fanart': core_settings.addon_fanart()})
            li.setInfo('video', {'plot': plot + "\n\n[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]"})
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="crt_toggle", key=key), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _crt_toggle(key):
    if key not in _CRT_DEFAULTS:
        return
    new_val = not core_settings.get_bool_setting(key, _CRT_DEFAULTS[key])
    core_settings.set_bool_setting(key, new_val)
    if key == 'crt_enabled' and new_val:
        xbmcgui.Dialog().ok(
            "Modo CRT activado",
            "El filtro se aplicará a [B]todos los vídeos[/B] que reproduzcas en Kodi "
            "mientras esté activo.\n\n"
            "Si no aparece al reproducir, [B]reinicia Kodi[/B] una vez para que el "
            "servicio del filtro arranque.")
    xbmc.executebuiltin("Container.Refresh")


def _cine_options_menu():
    h = int(sys.argv[1])
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()
    fanart = core_settings.addon_fanart()

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Configurar filas del Modo Cine[/B]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_editar.png'), 'fanart': fanart})
    li.setInfo('video', {'plot': "Elige qué filas de categorías se muestran en el Modo Cine."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="configure_cinema_rows"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Ordenar filas del Modo Cine[/B]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_editar.png'), 'fanart': fanart})
    li.setInfo('video', {'plot': "Cambia el orden en que aparecen las filas activas del Modo Cine."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="reorder_cinema_rows"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Configurar tráiler del Modo Cine[/B]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultAddonVideo.png', 'fanart': fanart})
    li.setInfo('video', {'plot': "Ajusta el comportamiento del tráiler de fondo en el Modo Cine."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="trailer_config"), listitem=li, isFolder=False)

    lazy_tag = core_settings.state_tag(core_settings.is_flix_lazy_enabled())
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Carga perezosa del Modo Cine[/B]  {0}".format(lazy_tag), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_lazy.png'), 'fanart': fanart})
    li.setInfo('video', {'plot': "Carga las filas del Modo Cine a medida que las recorres en lugar de todas al inicio.\n\n[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="toggle_flix_lazy_load"), listitem=li, isFolder=False)

    rpos_tag = core_settings.state_tag(core_settings.is_flix_remember_pos_enabled())
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Recordar posición en el Modo Cine[/B]  {0}".format(rpos_tag), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('historial.png'), 'fanart': fanart})
    li.setInfo('video', {'plot': "Conserva la posición dentro del Modo Cine al volver a entrar.\n\n[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="toggle_flix_remember_pos"), listitem=li, isFolder=False)

    auto_tag = core_settings.state_tag(core_settings.cinema_mode_auto_enabled())
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Abrir Modo Cine al iniciar[/B]  {0}".format(auto_tag), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_autostart.png'), 'fanart': fanart})
    li.setInfo('video', {'plot': "Abre el Modo Cine automáticamente al entrar en el addon.\n\n[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="toggle_cinema_auto"), listitem=li, isFolder=False)

    grid_mode = (xbmcaddon.Addon().getSetting('pelis_grid_mode') or 'Preguntar').strip() or 'Preguntar'
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Vista de las listas de películas[/B]  [COLOR cyan]{0}[/COLOR]".format(grid_mode), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('modo_grid.png'), 'fanart': fanart})
    li.setInfo('video', {'plot': "Cómo se abren las listas de películas: Preguntar, Lista, Botón o Grid directo.\n\n[COLOR blue][I]Pulsa para cambiar.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="set_pelis_grid_mode"), listitem=li, isFolder=False)

    rlp_tag = core_settings.state_tag(core_settings.remember_list_position())
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Recordar posición en las listas[/B]  {0}".format(rlp_tag), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('historial.png'), 'fanart': fanart})
    li.setInfo('video', {'plot': "Conserva la posición al volver con ATRÁS desde una lista. A cambio, el contenido puede quedar algo viejo hasta refrescar.\n\n[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="toggle_remember_list_position"), listitem=li, isFolder=False)

    ttl_label = core_settings._SNAPSHOT_TTL_LABELS[core_settings.get_snapshot_ttl_index()]
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Refrescar el catálogo del Modo Cine cada[/B]  [COLOR cyan]{0}[/COLOR]".format(ttl_label), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_refrescar.png'), 'fanart': fanart})
    li.setInfo('video', {'plot': "Al reabrir el Modo Cine, si la última carga es más reciente que esto se pinta al instante sin volver a descargar. Pasado ese tiempo, refresca en segundo plano.\n\n[COLOR blue][I]Pulsa para cambiar.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="set_snapshot_ttl"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _toggle_cinema_auto():
    new_state = 'false' if core_settings.cinema_mode_auto_enabled() else 'true'
    xbmcaddon.Addon().setSetting('cinema_mode_auto', new_state)
    xbmc.executebuiltin("Container.Refresh")


def _toggle_remember_list_position():
    new_state = 'false' if core_settings.remember_list_position() else 'true'
    xbmcaddon.Addon().setSetting('remember_list_position', new_state)
    xbmc.executebuiltin("Container.Refresh")


def _set_pelis_grid_mode():
    opciones = ["Preguntar", "Lista", "Botón", "Grid directo"]
    idx = xbmcgui.Dialog().select("Vista de las listas de películas", opciones)
    if idx < 0:
        return
    xbmcaddon.Addon().setSetting('pelis_grid_mode', opciones[idx])
    xbmcgui.Dialog().notification("TopZilla", "Vista guardada: {0}".format(opciones[idx]),
                                   xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin("Container.Refresh")


def _set_snapshot_ttl():
    opciones = list(core_settings._SNAPSHOT_TTL_LABELS)
    idx = xbmcgui.Dialog().select("Refrescar el catálogo del Modo Cine cada", opciones)
    if idx < 0:
        return
    core_settings.set_snapshot_ttl_index(idx)
    xbmc.executebuiltin("Container.Refresh")


def _toggle_trakt_write_sync():
    core_settings.set_trakt_write_sync(not core_settings.get_trakt_write_sync())
    xbmc.executebuiltin("Container.Refresh")


# --- Paridad: toggles de menú contextual / arte ---

def _toggle_bool_setting(setting_id, default):
    core_settings.set_bool_setting(setting_id, not core_settings.get_bool_setting(setting_id, default))
    xbmc.executebuiltin("Container.Refresh")


def _toggle_context_copy():
    _toggle_bool_setting('show_context_menu_copy', False)


def _toggle_context_paste():
    _toggle_bool_setting('show_context_menu_paste', False)


def _toggle_clipboard_sync():
    _toggle_bool_setting('clipboard_sync_to_os', True)


def _toggle_fanart_tv():
    nuevo = not core_settings.get_bool_setting('fanart_tv_enabled', False)
    core_settings.set_bool_setting('fanart_tv_enabled', nuevo)
    if nuevo and not core_settings.get_text_setting('fanart_tv_api_key', ''):
        xbmcgui.Dialog().notification('TopZilla', 'Configura tu clave Fanart.tv en Claves API',
                                       xbmcgui.NOTIFICATION_WARNING, 3500)
    xbmc.executebuiltin("Container.Refresh")


# --- Paridad: submenú Tráileres de YouTube (yt-dlp) ---

_YTDLP_COOKIE_BROWSERS = ['Ninguno', 'Chrome', 'Edge', 'Firefox', 'Brave', 'Opera', 'Vivaldi']


def _youtube_options_menu():
    h = int(sys.argv[1])
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()
    fanart = core_settings.addon_fanart()

    on = core_settings.get_bool_setting('youtube_ytdlp_enabled', False)
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Reproducir tráileres con yt-dlp (solo Windows)[/B]  {0}".format(core_settings.state_tag(on)), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_busqueda.png'), 'fanart': fanart})
    li.setInfo('video', {'plot': "Desactivado: los tráileres usan el addon de YouTube. Activado: se resuelven con yt-dlp del sistema (requiere Python + yt-dlp) y, si falla, cae al addon de YouTube.\n\n[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="toggle_ytdlp_enabled"), listitem=li, isFolder=False)

    cookiefile = core_settings.get_text_setting('youtube_ytdlp_cookiefile', '')
    cf_tag = "[COLOR green]configurado[/COLOR]" if cookiefile else "[COLOR grey]vacío[/COLOR]"
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Fichero cookies.txt[/B]  {0}".format(cf_tag), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_busqueda.png'), 'fanart': fanart})
    li.setInfo('video', {'plot': "Ruta a un cookies.txt para evitar el bloqueo 'confirma que no eres un bot'. SEGURIDAD: contiene tu sesión, guárdalo FUERA de la carpeta del addon.\n\n[COLOR blue][I]Pulsa para editar la ruta.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="set_ytdlp_cookiefile"), listitem=li, isFolder=False)

    cookies = core_settings.get_text_setting('youtube_ytdlp_cookies', 'Ninguno')
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Cookies del navegador[/B]  [COLOR cyan]{0}[/COLOR]".format(cookies), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_busqueda.png'), 'fanart': fanart})
    li.setInfo('video', {'plot': "Alternativa al fichero: leer las cookies del navegador (solo Firefox funciona en Windows; Chrome/Edge 127+ las cifran).\n\n[COLOR blue][I]Pulsa para elegir.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="set_ytdlp_cookies"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _toggle_ytdlp_enabled():
    _toggle_bool_setting('youtube_ytdlp_enabled', False)


def _set_ytdlp_cookiefile():
    import remote_input
    current = core_settings.get_text_setting('youtube_ytdlp_cookiefile', '')
    raw = remote_input.get_text_input('Ruta al fichero cookies.txt (vacío para no usarlo)', current, allow_clear=True)
    if raw is None:
        return
    core_settings.set_text_setting('youtube_ytdlp_cookiefile', raw.strip())
    xbmc.executebuiltin("Container.Refresh")


def _set_ytdlp_cookies():
    idx = xbmcgui.Dialog().select("Cookies del navegador", _YTDLP_COOKIE_BROWSERS)
    if idx < 0:
        return
    core_settings.set_text_setting('youtube_ytdlp_cookies', _YTDLP_COOKIE_BROWSERS[idx])
    xbmc.executebuiltin("Container.Refresh")


# --- Paridad: submenú Escribir sin mando ---

_SEARCH_INPUT_MODES = ['Preguntar siempre', 'Teclado (mando)', 'Servidor local', 'Servidor online']


def _remote_input_options_menu():
    h = int(sys.argv[1])
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()
    fanart = core_settings.addon_fanart()

    mode = core_settings.get_text_setting('search_input_default', 'Preguntar siempre')
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Cómo escribir el texto[/B]  [COLOR cyan]{0}[/COLOR]".format(mode), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_idioma.png'), 'fanart': fanart})
    li.setInfo('video', {'plot': "Teclado: el de Kodi. Servidor local: escribe desde el móvil/PC en tu misma red. Servidor online: desde cualquier sitio vía relay (ntfy).\n\n[COLOR blue][I]Pulsa para elegir.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="set_search_input_default"), listitem=li, isFolder=False)

    port = core_settings.get_text_setting('remote_port', '8089')
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Puerto del servidor local[/B]  [COLOR cyan]{0}[/COLOR]".format(port), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_idioma.png'), 'fanart': fanart})
    li.setInfo('video', {'plot': "Puerto (8089–8099) del servidor local para escribir desde el móvil.\n\n[COLOR blue][I]Pulsa para cambiar.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="set_remote_port"), listitem=li, isFolder=False)

    secure = core_settings.get_bool_setting('remote_secure', False)
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Requerir código de acceso (servidor local)[/B]  {0}".format(core_settings.state_tag(secure)), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_idioma.png'), 'fanart': fanart})
    li.setInfo('video', {'plot': "Exige un código para escribir en el servidor local.\n\n[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="toggle_remote_secure"), listitem=li, isFolder=False)

    server = core_settings.get_text_setting('webremote_server', 'https://ntfy.sh')
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Servidor relay (modo online)[/B]  [COLOR cyan]{0}[/COLOR]".format(server), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_idioma.png'), 'fanart': fanart})
    li.setInfo('video', {'plot': "Servidor ntfy para el modo online.\n\n[COLOR blue][I]Pulsa para cambiar.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="set_webremote_server"), listitem=li, isFolder=False)

    topic = core_settings.get_text_setting('webremote_topic', '')
    topic_tag = topic if topic else "[COLOR grey]automático[/COLOR]"
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Canal del relay[/B]  [COLOR cyan]{0}[/COLOR]".format(topic_tag), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_idioma.png'), 'fanart': fanart})
    li.setInfo('video', {'plot': "Canal del relay (vacío = se genera automáticamente).\n\n[COLOR blue][I]Pulsa para cambiar.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="set_webremote_topic"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _set_search_input_default():
    idx = xbmcgui.Dialog().select("Cómo escribir el texto", _SEARCH_INPUT_MODES)
    if idx < 0:
        return
    core_settings.set_text_setting('search_input_default', _SEARCH_INPUT_MODES[idx])
    xbmc.executebuiltin("Container.Refresh")


def _set_remote_port():
    import remote_input
    current = core_settings.get_text_setting('remote_port', '8089')
    raw = remote_input.get_text_input('Puerto del servidor local (8089–8099)', current, allow_clear=True)
    if raw is None:
        return
    raw = (raw or '').strip()
    if not raw.isdigit() or not (8089 <= int(raw) <= 8099):
        xbmcgui.Dialog().notification('TopZilla', 'Puerto inválido (debe estar entre 8089 y 8099)',
                                       xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    core_settings.set_text_setting('remote_port', raw)
    xbmc.executebuiltin("Container.Refresh")


def _toggle_remote_secure():
    _toggle_bool_setting('remote_secure', False)


def _set_webremote_server():
    import remote_input
    current = core_settings.get_text_setting('webremote_server', 'https://ntfy.sh')
    raw = remote_input.get_text_input('Servidor relay (modo online)', current, allow_clear=True)
    if raw is None:
        return
    core_settings.set_text_setting('webremote_server', raw.strip() or 'https://ntfy.sh')
    xbmc.executebuiltin("Container.Refresh")


def _set_webremote_topic():
    import remote_input
    current = core_settings.get_text_setting('webremote_topic', '')
    raw = remote_input.get_text_input('Canal del relay (vacío = automático)', current, allow_clear=True)
    if raw is None:
        return
    core_settings.set_text_setting('webremote_topic', raw.strip())
    xbmc.executebuiltin("Container.Refresh")


# --- Paridad: submenú Control parental (protegido por el PIN actual) ---

def _parental_options_menu():
    if not _parental_gate():  # pide el PIN actual si hay protección activa
        return
    h = int(sys.argv[1])
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()
    fanart = core_settings.addon_fanart()

    protected = core_settings.is_parental_options_protected() and bool(core_settings.get_parental_pin())
    estado = "[COLOR green]protegido[/COLOR]" if protected else "[COLOR grey]sin protección[/COLOR]"
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Estado del menú Opciones:[/B] {0}".format(estado), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('info.png'), 'fanart': fanart})
    li.setInfo('video', {'plot': "El control parental pide un PIN antes de abrir Opciones. Es un bloqueo disuasorio, no un control del sistema."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="parental_set_pin"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Poner o cambiar PIN[/B]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_api_key.png'), 'fanart': fanart})
    li.setInfo('video', {'plot': "Define un PIN numérico y activa la protección del menú Opciones."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="parental_set_pin"), listitem=li, isFolder=False)

    if protected:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            "[COLOR red][B]Quitar PIN y desproteger[/B][/COLOR]", bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': _mi('adv_limpieza.png'), 'fanart': fanart})
        li.setInfo('video', {'plot': "Borra el PIN y desactiva la protección."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="parental_clear"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _parental_set_pin():
    if not _parental_gate():  # exige el PIN actual antes de cambiarlo
        return
    import remote_input
    pin = remote_input.get_text_input('Nuevo PIN numérico (vacío = no cambiar)', '', allow_clear=True)
    if pin is None:
        return
    pin = (pin or '').strip()
    if not pin:
        return
    if not pin.isdigit():
        xbmcgui.Dialog().notification('TopZilla', 'El PIN debe ser numérico',
                                       xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    core_settings.set_parental_pin(pin)
    core_settings.set_parental_protect_options(True)
    xbmcgui.Dialog().notification('TopZilla', 'PIN guardado, protección activada',
                                   xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin("Container.Refresh")


def _parental_clear():
    if not _parental_gate():  # exige el PIN actual antes de quitarlo
        return
    core_settings.set_parental_pin('')
    core_settings.set_parental_protect_options(False)
    xbmcgui.Dialog().notification('TopZilla', 'Protección desactivada',
                                   xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin("Container.Refresh")


# --- Puente ZORG: API entrante para que otros addons reporten vistas (G2) ---
# Uso desde otro addon (input LOCAL, no de red; validamos tipos básicos):
#   RunPlugin(plugin://plugin.video.topzilla/?action=api_mark_watched&tmdb_id=157336&mode=movie&title=Interstellar&year=2014)
#   RunPlugin(plugin://plugin.video.topzilla/?action=api_is_watched&tmdb_id=157336&mode=movie)
#   → deja el resultado en Window(10000).Property('topzilla.api.is_watched') = '1'/'0'.

def _api_parse_ref(params):
    """Construye un MovieRef desde los params de la API. Devuelve (ref, mode) o
    (None, _) si tmdb_id no es válido."""
    import movie_ref
    try:
        tmdb_id = int(params.get('tmdb_id') or 0)
    except (TypeError, ValueError):
        tmdb_id = 0
    if tmdb_id <= 0:
        return None, 'movie'
    mode = 'show' if params.get('mode') in ('show', 'tv') else 'movie'
    try:
        year = int(params.get('year') or 0) or None
    except (TypeError, ValueError):
        year = None
    title = urllib.parse.unquote(params.get('title', '') or '') or 'tmdb:{0}'.format(tmdb_id)
    ref = movie_ref.make_ref(title=title, year=year, tmdb_id=tmdb_id,
                             media_type=mode, source='zorg')
    return ref, mode


def _api_mark_watched(params):
    ref, _ = _api_parse_ref(params)
    if ref is None:
        xbmc.log("[TopZilla] api_mark_watched: tmdb_id inválido", xbmc.LOGWARNING)
        return
    import watch_history
    watch_history.mark(ref)  # local + Trakt (opt-in) + invalida el índice del ✔


def _api_is_watched(params):
    import movie_ref, watch_history
    ref, _ = _api_parse_ref(params)
    watched = ref is not None and watch_history.is_watched(movie_ref.ref_key(ref))
    xbmcgui.Window(10000).setProperty('topzilla.api.is_watched', '1' if watched else '0')


# Atajos en "¿Dónde buscar?"

def _topzilla_addon_id():
    try:
        return xbmcaddon.Addon().getAddonInfo('id')
    except Exception:
        return 'plugin.video.topzilla'


def _shortcut_addon_installed(sc):
    """Devuelve True si el atajo no depende de un addon o si el addon está instalado."""
    if not isinstance(sc, dict):
        return True
    aid = sc.get('addon_id')
    if not aid:
        # Atajos manuales sin addon_id asociado: no podemos validarlos, asumimos OK.
        return True
    try:
        return xbmc.getCondVisibility('System.HasAddon({0})'.format(aid))
    except Exception:
        return True


def _search_shortcuts_menu():
    h = int(sys.argv[1])
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()
    af = core_settings.addon_fanart()

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR limegreen][B]+ Añadir atajo de addon instalado[/B][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('shortcut_addon.png'), 'fanart': af})
    li.setInfo('video', {'plot': (
        "Selecciona cualquier addon instalado en Kodi para añadirlo como acceso directo "
        "en el menú '¿Dónde buscar?'. Al seleccionarlo desde ese menú se abrirá el addon "
        "directamente sin pasar por los menús de Kodi.")})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='search_shortcut_add_addon'),
                                 listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR limegreen][B]+ Añadir comando[/B][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('comando.png'), 'fanart': af})
    li.setInfo('video', {'plot': (
        "Escribe manualmente un nombre y un comando Kodi para añadirlo al menú '¿Dónde buscar?'. Ejemplos:\n"
        "  ActivateWindow(Videos,plugin://plugin.video.youtube/search/?q={query})\n"
        "  RunPlugin(plugin://plugin.video.dailymotion_com/?mode=search&keyword={query})\n"
        "  RunScript(script.foo,query={queryraw})\n"
        "  RunAddon(\"plugin.video.youtube\")\n\n"
        "Tokens disponibles:\n"
        "  {query}    - consulta URL-encoded (úsala dentro de URLs y plugin://...).\n"
        "  {queryraw} - consulta tal cual (úsala en RunScript, Notification, etc.).\n"
        "  {tmdb_id}  - id de TMDB del título (vacío si no hay match).\n"
        "  {mode}     - 'movie' o 'show'.")})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='search_shortcut_add_manual'),
                                 listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR limegreen][B]+ Añadir desde favoritos de Kodi[/B][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultFavourites.png', 'fanart': af})
    li.setInfo('video', {'plot': (
        "Elige uno de los favoritos que ya tienes guardados en Kodi "
        "para añadirlo como atajo en el menú '¿Dónde buscar?'. "
        "Se conservan el nombre, el icono y el comando exactos.")})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='search_shortcut_add_favourite'),
                                 listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR deepskyblue][B]↕ Reordenar / ocultar ventana '¿Dónde buscar?'[/B][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_busqueda.png'), 'fanart': af})
    li.setInfo('video', {'plot': (
        "Cambia el orden y oculta cualquier entrada del menú "
        "'¿Dónde buscar?' (YouTube, Dailymotion, Wikipedia, TMDB, Ficha completa, "
        "atajos personalizados, etc.). Puedes intercalar atajos entre las entradas fijas. "
        "Las ocultas se siguen mostrando aquí, marcadas, para volver a activarlas.")})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='search_menu_reorder'),
                                 listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR khaki][B]── EXTRA ──[/B][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultAddonNone.png', 'fanart': af})
    li.setInfo('video', {'plot': "Entradas opcionales para el menú '¿Dónde buscar?'."})
    xbmcplugin.addDirectoryItem(handle=h, url='', listitem=li, isFolder=False)

    ost_on = core_settings.show_soundtrack_button_enabled()
    ost_state = "[COLOR lime](ON)[/COLOR]" if ost_on else "[COLOR gray](OFF)[/COLOR]"
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]♪ Buscar Banda Sonora en YouTube[/B] {0}".format(ost_state),
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultMusicSongs.png', 'fanart': af})
    li.setInfo('video', {'plot': (
        "Al activarlo añade una entrada en el menú '¿Dónde buscar?' que lanza una búsqueda "
        "automática en YouTube de la banda sonora ('{título} {año} soundtrack').\n\n"
        "Requiere el addon plugin.video.youtube instalado.")})
    xbmcplugin.addDirectoryItem(
        handle=h,
        url=_u(action='toggle_soundtrack_button'),
        listitem=li, isFolder=False)

    omdb_on = core_settings.show_omdb_button_enabled()
    omdb_state = "[COLOR lime](ON)[/COLOR]" if omdb_on else "[COLOR gray](OFF)[/COLOR]"
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Críticas (RT / Metacritic / IMDb) vía OMDb[/B] {0}".format(omdb_state),
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultIconInfo.png', 'fanart': af})
    li.setInfo('video', {'plot': (
        "Al activarlo añade una entrada en el menú '¿Dónde buscar?' que muestra "
        "las notas agregadas de Rotten Tomatoes, Metacritic e IMDb para la película "
        "seleccionada.\n\n"
        "Para mayor estabilidad, configura tu clave en Opciones → Claves API → OMDb.")})
    xbmcplugin.addDirectoryItem(
        handle=h,
        url=_u(action='toggle_omdb_button'),
        listitem=li, isFolder=False)

    share_on = core_settings.show_share_button_enabled()
    share_state = "[COLOR lime](ON)[/COLOR]" if share_on else "[COLOR gray](OFF)[/COLOR]"
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Compartir esta peli[/B] {0}".format(share_state),
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('compartir.png'), 'fanart': af})
    li.setInfo('video', {'plot': (
        "Al activarlo añade una entrada en el menú '¿Dónde buscar?' que copia al portapapeles "
        "el título, año, nota TMDB y enlace de la película.\n\n"
        "Si la nota o el ID TMDB no estuvieran cacheados, se consulta TMDB en el momento "
        "(requiere clave en Opciones → Claves API).")})
    xbmcplugin.addDirectoryItem(
        handle=h,
        url=_u(action='toggle_share_button'),
        listitem=li, isFolder=False)

    mega_on = core_settings.show_megabuscador_button_enabled()
    mega_state = "[COLOR lime](ON)[/COLOR]" if mega_on else "[COLOR gray](OFF)[/COLOR]"
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Megabuscador (varias plataformas)[/B] {0}".format(mega_state),
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('busqueda.png'), 'fanart': af})
    li.setInfo('video', {'plot': (
        "Al activarlo añade una entrada en el menú '¿Dónde buscar?' que lanza el "
        "Megabuscador con el título de la película. Busca a la vez en Dailymotion, "
        "YouTube, Odysee, PeerTube y BitChute y une los resultados ordenados por "
        "relevancia.\n\n"
        "Elige plataformas y opciones (limpiar títulos, ranking, proxy) en el propio "
        "menú del Megabuscador. YouTube necesita el addon plugin.video.youtube.")})
    xbmcplugin.addDirectoryItem(
        handle=h,
        url=_u(action='toggle_megabuscador_button'),
        listitem=li, isFolder=False)

    if mega_on:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            "    Plataformas y ajustes del Megabuscador",
            bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': _mi('busqueda.png'), 'fanart': af})
        li.setInfo('video', {'plot': (
            "Abre el menú del Megabuscador para elegir en qué plataformas busca "
            "(Dailymotion, YouTube, Odysee, PeerTube, BitChute), afinar el ranking y el "
            "filtrado, configurar el proxy y hacer búsquedas manuales con 'Buscar ahora'.")})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='megabuscador'),
            listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR khaki][B]── ATAJOS PRECONFIGURADOS ──[/B][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultAddonNone.png', 'fanart': af})
    li.setInfo('video', {'plot': "Integración directa con otros addons instalados."})
    xbmcplugin.addDirectoryItem(handle=h, url='', listitem=li, isFolder=False)

    if xbmc.getCondVisibility("System.HasAddon(plugin.video.espadaily)"):
        eda_on = core_settings._espadaily_integration_enabled()
        eda_state = "[COLOR lime](ON)[/COLOR]" if eda_on else "[COLOR gray](OFF)[/COLOR]"
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            "[B]Buscar en EspaDaily[/B] {0}".format(eda_state),
            bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': _mi('adv_busqueda.png'), 'fanart': af})
        li.setInfo('video', {'plot': _ESPADAILY_INTRO_TEXT})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='toggle_espadaily_integration'),
            listitem=li, isFolder=False)

    if xbmc.getCondVisibility("System.HasAddon(plugin.video.atresdaily)"):
        atres_on = core_settings._atresdaily_integration_enabled()
        atres_state = "[COLOR lime](ON)[/COLOR]" if atres_on else "[COLOR gray](OFF)[/COLOR]"
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            "[B]Abrir búsqueda en el addon AtresDaily[/B] {0}".format(atres_state),
            bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': _mi('adv_busqueda.png'), 'fanart': af})
        li.setInfo('video', {'plot': _ATRESDAILY_INTRO_TEXT})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='toggle_atresdaily_integration'),
            listitem=li, isFolder=False)

    espatv_on = core_settings._espatv_integration_enabled()
    espatv_state = "[COLOR lime](ON)[/COLOR]" if espatv_on else "[COLOR gray](OFF)[/COLOR]"
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Buscar en EspaTV[/B] {0}".format(espatv_state),
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_busqueda.png'), 'fanart': af})
    li.setInfo('video', {'plot': _ESPATV_INTRO_TEXT})
    xbmcplugin.addDirectoryItem(
        handle=h,
        url=_u(action='toggle_espatv_integration'),
        listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR khaki][B]── ATAJOS ──[/B][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultAddonNone.png', 'fanart': af})
    li.setInfo('video', {'plot': "Atajos configurados para el menú '¿Dónde buscar?'."})
    xbmcplugin.addDirectoryItem(handle=h, url='', listitem=li, isFolder=False)

    shortcuts = core_settings.load_search_shortcuts()
    if not shortcuts:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            "[COLOR gray](Sin atajos configurados)[/COLOR]",
            bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': 'DefaultIconInfo.png', 'fanart': af})
        xbmcplugin.addDirectoryItem(handle=h, url='', listitem=li, isFolder=False)
    else:
        for i, sc in enumerate(shortcuts):
            name = sc.get('name', 'Atajo {0}'.format(i + 1))
            icon = sc.get('icon') or 'DefaultAddonVideo.png'
            cmd  = sc.get('command', '')
            installed = _shortcut_addon_installed(sc)
            if installed:
                label = "[COLOR gold][B]{0}[/B][/COLOR]".format(name)
                plot  = "Comando: {0}".format(cmd)
            else:
                label = "[COLOR red][B]{0}[/B][/COLOR] [COLOR gray](addon no instalado)[/COLOR]".format(name)
                plot  = "[COLOR red]El addon '{0}' no está instalado.[/COLOR]\n\nComando: {1}".format(
                    sc.get('addon_id', ''), cmd)
            li = xbmcgui.ListItem(label=core_settings.apply_label(
                label, bold=_bold, strip=_strip, color_mode=_color))
            li.setArt({'icon': icon, 'fanart': af})
            li.setInfo('video', {'plot': plot})
            ctx = []
            ctx.append(("Renombrar",
                "RunPlugin({0})".format(_u(action='search_shortcut_rename', idx=i))))
            ctx.append(("Eliminar atajo",
                "RunPlugin({0})".format(_u(action='search_shortcut_remove', idx=i))))
            li.addContextMenuItems(ctx)
            xbmcplugin.addDirectoryItem(
                handle=h,
                url=_u(action='search_shortcut_actions', idx=i),
                listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _search_shortcut_add_addon():
    addons = []
    for addon_type in ('xbmc.addon.video', 'xbmc.addon.audio',
                        'xbmc.addon.image', 'xbmc.addon.executable'):
        try:
            req = json.dumps({
                'jsonrpc': '2.0', 'method': 'Addons.GetAddons',
                'params': {'type': addon_type, 'enabled': True,
                           'properties': ['name', 'thumbnail']},
                'id': 1,
            })
            data = json.loads(xbmc.executeJSONRPC(req) or '{}')
            addons += (data.get('result') or {}).get('addons') or []
        except Exception:
            pass

    own_id = _topzilla_addon_id()
    seen = set()
    unique = []
    for a in addons:
        if not isinstance(a, dict):
            continue
        aid = a.get('addonid')
        if not aid or aid == own_id or aid in seen:
            continue
        seen.add(aid)
        unique.append(a)
    unique.sort(key=lambda x: (x.get('name') or '').lower())

    if not unique:
        xbmcgui.Dialog().notification('TopZilla', 'No se encontraron addons instalados',
                                       xbmcgui.NOTIFICATION_INFO, 3000)
        return

    names = [a.get('name') or a.get('addonid', '') for a in unique]
    sel = xbmcgui.Dialog().select('Seleccionar addon para añadir como atajo', names)
    if sel < 0:
        return

    addon    = unique[sel]
    addon_id = addon.get('addonid', '')
    name     = core_settings.sanitize_shortcut_name(addon.get('name')) or addon_id
    thumb    = addon.get('thumbnail') if isinstance(addon.get('thumbnail'), str) else ''
    if not thumb:
        thumb = 'DefaultAddonVideo.png'

    # Dos formas de invocar el addon desde "¿Dónde buscar?":
    #  - Pasarle el título: necesita una URL plugin:// con el parámetro de búsqueda
    #    propio del addon (varía en cada uno), por eso la plantilla es editable.
    #  - Solo abrir (RunAddon): el usuario busca a mano dentro del addon.
    choice = xbmcgui.Dialog().select(
        '¿Qué hace el atajo con el título seleccionado?',
        ['Pasarle el título buscado', 'Solo abrir el addon (buscar a mano)'])
    if choice < 0:
        return
    if choice == 0:
        import remote_input
        template = 'ActivateWindow(Videos,plugin://{0}/?q={{query}})'.format(addon_id)
        command = remote_input.get_text_input(
            'Ajusta la ruta/parámetro al addon. Tokens: {query} {queryraw} {tmdb_id} {mode}',
            default=template).strip()
        if not command:
            return
    else:
        command = 'RunAddon("{0}")'.format(addon_id)

    shortcuts = core_settings.load_search_shortcuts()
    for sc in shortcuts:
        if sc.get('addon_id') == addon_id or sc.get('command') == command:
            xbmcgui.Dialog().notification('TopZilla', 'Este addon ya está en los atajos',
                                           xbmcgui.NOTIFICATION_INFO, 2000)
            return

    shortcuts.append({'name': name, 'icon': thumb, 'command': command,
                      'type': 'addon', 'addon_id': addon_id})
    core_settings.save_search_shortcuts(shortcuts)
    xbmcgui.Dialog().notification('TopZilla', 'Atajo añadido: {0}'.format(name),
                                   xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


# Match RunAddon("addon.id") / RunAddon(addon.id) / plugin://addon.id/...
_RUNADDON_RE = re.compile(r'RunAddon\s*\(\s*"?([\w\.\-]+)"?\s*\)', re.IGNORECASE)
_PLUGIN_URL_RE = re.compile(r'plugin://([\w\.\-]+)', re.IGNORECASE)


def _extract_addon_id_from_command(cmd):
    if not cmd:
        return ''
    m = _RUNADDON_RE.search(cmd)
    if m:
        return m.group(1)
    m = _PLUGIN_URL_RE.search(cmd)
    if m:
        return m.group(1)
    return ''


def _search_shortcut_add_manual():
    import remote_input
    name = core_settings.sanitize_shortcut_name(remote_input.get_text_input('Nombre del atajo'))
    if not name:
        return

    command = remote_input.get_text_input('Comando (ActivateWindow, RunPlugin, RunScript, RunAddon...)').strip()
    if not command:
        return

    shortcuts = core_settings.load_search_shortcuts()
    for sc in shortcuts:
        if sc.get('command') == command:
            xbmcgui.Dialog().notification('TopZilla', 'Ya existe un atajo con ese comando',
                                           xbmcgui.NOTIFICATION_INFO, 2000)
            return

    addon_id = _extract_addon_id_from_command(command)
    shortcuts.append({'name': name, 'icon': 'DefaultIconInfo.png', 'command': command,
                      'type': 'manual', 'addon_id': addon_id})
    core_settings.save_search_shortcuts(shortcuts)
    xbmcgui.Dialog().notification('TopZilla', 'Atajo añadido: {0}'.format(name),
                                   xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


def _search_shortcut_add_favourite():
    fav_path = xbmcvfs.translatePath('special://profile/favourites.xml')

    if not os.path.isfile(fav_path):
        xbmcgui.Dialog().notification('TopZilla', 'No tienes favoritos guardados en Kodi',
                                       xbmcgui.NOTIFICATION_INFO, 2500)
        return

    try:
        root = ET.parse(fav_path).getroot()
    except ET.ParseError:
        xbmcgui.Dialog().notification('TopZilla', 'Los favoritos de Kodi están dañados',
                                       xbmcgui.NOTIFICATION_ERROR, 2500)
        return
    except OSError:
        xbmcgui.Dialog().notification('TopZilla', 'No se pudieron leer los favoritos',
                                       xbmcgui.NOTIFICATION_ERROR, 2500)
        return

    favs = []
    for fav in root.findall('favourite'):
        cmd = (fav.text or '').strip()
        if not cmd:
            continue
        favs.append({
            'name':  core_settings.sanitize_shortcut_name(fav.get('name')) or cmd[:40],
            'thumb': fav.get('thumb') or '',
            'cmd':   cmd,
        })

    if not favs:
        xbmcgui.Dialog().notification('TopZilla', 'No hay favoritos en Kodi',
                                       xbmcgui.NOTIFICATION_INFO, 2500)
        return

    items = []
    for f in favs:
        it = xbmcgui.ListItem(label=f['name'])
        if f['thumb']:
            it.setArt({'icon': f['thumb'], 'thumb': f['thumb']})
        items.append(it)
    sel = xbmcgui.Dialog().select('Seleccionar favorito', items, useDetails=True)
    if sel < 0:
        return

    chosen  = favs[sel]
    command = chosen['cmd']

    shortcuts = core_settings.load_search_shortcuts()
    for sc in shortcuts:
        if sc.get('command') == command:
            xbmcgui.Dialog().notification('TopZilla', 'Ya existe un atajo con ese comando',
                                           xbmcgui.NOTIFICATION_INFO, 2000)
            return

    addon_id = _extract_addon_id_from_command(command)
    icon = chosen['thumb'] or 'DefaultFavourites.png'
    shortcuts.append({'name': chosen['name'], 'icon': icon, 'command': command,
                      'type': 'manual', 'addon_id': addon_id})
    core_settings.save_search_shortcuts(shortcuts)
    xbmcgui.Dialog().notification('TopZilla', 'Atajo añadido: {0}'.format(chosen['name']),
                                   xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


_ESPADAILY_INTRO_TEXT = (
    "¿Habilitar la búsqueda delegada en tu addon EspaDaily?\n\n"
    "Aprovecha al máximo el addon EspaDaily. "
    "Permite saltar de TopZilla a EspaDaily en un clic, con la misma búsqueda ya escrita. "
    "Útil cuando TopZilla no encuentra algo y quieres probar el otro sin volver a teclear.\n\n"
    "El proceso utiliza una URL estándar de Kodi (tipo plugin://) para abrir el addon y "
    "adjunta el texto de tu consulta. Al tratarse de un simple enlace, esta característica "
    "no modifica el código de EspaDaily ni recopila su información.\n\n"
    "Nota: Puedes añadir, modificar o desactivar estos atajos en cualquier momento desde "
    "los ajustes de TopZilla."
)

_ATRESDAILY_INTRO_TEXT = (
    "¿Habilitar la búsqueda delegada en tu addon AtresDaily?\n\n"
    "Aprovecha al máximo el addon AtresDaily. "
    "Permite saltar de TopZilla a AtresDaily en un clic, con la misma búsqueda ya escrita. "
    "Útil cuando TopZilla no encuentra algo y quieres probar el otro sin volver a teclear.\n\n"
    "El proceso utiliza una URL estándar de Kodi (tipo plugin://) para abrir el addon y "
    "adjunta el texto de tu consulta. Al tratarse de un simple enlace, esta característica "
    "no modifica el código de AtresDaily ni recopila su información.\n\n"
    "Nota: Puedes añadir, modificar o desactivar estos atajos en cualquier momento desde "
    "los ajustes de TopZilla."
)

_ESPATV_INTRO_TEXT = (
    "¿Habilitar la búsqueda delegada en tu addon EspaTV?\n\n"
    "Aprovecha al máximo el addon EspaTV. "
    "Permite saltar de TopZilla a EspaTV en un clic, con la misma búsqueda ya escrita. "
    "Útil cuando TopZilla no encuentra algo y quieres probar el otro sin volver a teclear.\n\n"
    "El proceso utiliza una URL estándar de Kodi (tipo plugin://) para abrir el addon y "
    "adjunta el texto de tu consulta. Al tratarse de un simple enlace, esta característica "
    "no modifica el código de EspaTV ni recopila su información.\n\n"
    "Nota: Puedes añadir, modificar o desactivar estos atajos en cualquier momento desde "
    "los ajustes de TopZilla."
)


def _toggle_espadaily_integration():
    new_state = not core_settings._espadaily_integration_enabled()
    core_settings.set_espadaily_integration_enabled(new_state)
    if new_state:
        try:
            shown = xbmcaddon.Addon().getSetting('espadaily_intro_shown') == 'true'
        except Exception:
            shown = False
        if not shown:
            xbmcgui.Dialog().textviewer("Buscar en EspaDaily", _ESPADAILY_INTRO_TEXT)
            try:
                xbmcaddon.Addon().setSetting('espadaily_intro_shown', 'true')
            except Exception:
                pass
    msg = 'Integración EspaDaily activada' if new_state else 'Integración EspaDaily desactivada'
    xbmcgui.Dialog().notification('TopZilla', msg, xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


def _toggle_atresdaily_integration():
    new_state = not core_settings._atresdaily_integration_enabled()
    core_settings.set_atresdaily_integration_enabled(new_state)
    if new_state:
        try:
            shown = xbmcaddon.Addon().getSetting('atresdaily_intro_shown') == 'true'
        except Exception:
            shown = False
        if not shown:
            xbmcgui.Dialog().textviewer("Abrir búsqueda en el addon AtresDaily", _ATRESDAILY_INTRO_TEXT)
            try:
                xbmcaddon.Addon().setSetting('atresdaily_intro_shown', 'true')
            except Exception:
                pass
    msg = 'Integración AtresDaily activada' if new_state else 'Integración AtresDaily desactivada'
    xbmcgui.Dialog().notification('TopZilla', msg, xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


def _toggle_espatv_integration():
    new_state = not core_settings._espatv_integration_enabled()
    core_settings.set_espatv_integration_enabled(new_state)
    if new_state:
        try:
            shown = xbmcaddon.Addon().getSetting('espatv_intro_shown') == 'true'
        except Exception:
            shown = False
        if not shown:
            xbmcgui.Dialog().textviewer("Buscar en EspaTV", _ESPATV_INTRO_TEXT)
            try:
                xbmcaddon.Addon().setSetting('espatv_intro_shown', 'true')
            except Exception:
                pass
    msg = 'Integración EspaTV activada' if new_state else 'Integración EspaTV desactivada'
    xbmcgui.Dialog().notification('TopZilla', msg, xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


def _search_shortcut_remove(idx):
    shortcuts = core_settings.load_search_shortcuts()
    if 0 <= idx < len(shortcuts):
        name = shortcuts[idx].get('name', '')
        del shortcuts[idx]
        core_settings.save_search_shortcuts(shortcuts)
        xbmcgui.Dialog().notification('TopZilla', 'Atajo eliminado: {0}'.format(name),
                                       xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


def _search_shortcut_rename(idx):
    shortcuts = core_settings.load_search_shortcuts()
    if not (0 <= idx < len(shortcuts)):
        return
    import remote_input
    new_name = core_settings.sanitize_shortcut_name(
        remote_input.get_text_input('Nuevo nombre', shortcuts[idx].get('name', '')))
    if not new_name:
        return
    shortcuts[idx]['name'] = new_name
    core_settings.save_search_shortcuts(shortcuts)
    xbmc.executebuiltin('Container.Refresh')


def _search_shortcut_actions(idx):
    """Diálogo con las acciones disponibles para un atajo.
    Se invoca al hacer clic izquierdo sobre un atajo (alternativa accesible
    al menú contextual)."""
    shortcuts = core_settings.load_search_shortcuts()
    if not (0 <= idx < len(shortcuts)):
        return
    sc   = shortcuts[idx]
    name = sc.get('name', 'Atajo')

    options = ['Renombrar', '[COLOR red]Eliminar atajo[/COLOR]']
    actions = ['rename', 'remove']

    sel = xbmcgui.Dialog().select("'{0}' — ¿Qué acción?".format(name), options)
    if sel < 0:
        return

    action = actions[sel]
    if action == 'rename':
        _search_shortcut_rename(idx)
    elif action == 'remove':
        _search_shortcut_remove(idx)


def _search_menu_reorder():
    """Diálogo subir/bajar/ocultar para la ventana '¿Dónde buscar?'.
    Muestra TODAS las entradas posibles (fijas + atajos) sin filtrar por
    modo, para que el orden valga tanto para películas como para series.
    Las ocultas se siguen mostrando aquí (marcadas) para poder restaurarlas."""
    # Unimos las entradas posibles en modo 'movie' y 'show' por si en el
    # futuro alguno tiene exclusivas. Hoy son el mismo set.
    base = _build_search_entries('movie')
    ids_seen = {e[0] for e in base}
    for e in _build_search_entries('show'):
        if e[0] not in ids_seen:
            base.append(e)
            ids_seen.add(e[0])
    base = [e for e in base if e[0]]  # descartar entradas sin id

    saved = core_settings.load_search_menu_order()
    if saved:
        index = {eid: i for i, eid in enumerate(saved)}
        base.sort(key=lambda e: index.get(e[0], 10**6))

    hidden = core_settings.load_search_hidden()

    while True:
        labels = []
        for i, (eid, lbl, _act, _vis) in enumerate(base):
            arrows = ''
            if i > 0:
                arrows += '↑ '
            if i < len(base) - 1:
                arrows += '↓ '
            mark = '[COLOR gray](oculta)[/COLOR] ' if eid in hidden else ''
            labels.append("{0}{1}{2}".format(arrows, mark, lbl))
        reset_pos = len(labels)
        labels.append("[COLOR orange]Restaurar orden y mostrar todas[/COLOR]")

        sel = xbmcgui.Dialog().select("Reordenar / ocultar '¿Dónde buscar?' (se guarda al instante)", labels)
        if sel < 0:
            return
        if sel == reset_pos:
            if xbmcgui.Dialog().yesno("TopZilla",
                    "¿Restaurar el orden por defecto y mostrar todas las opciones del menú '¿Dónde buscar?'?"):
                core_settings.reset_search_menu_order()
                core_settings.save_search_hidden(set())
                xbmcgui.Dialog().notification('TopZilla',
                    'Restaurado', xbmcgui.NOTIFICATION_INFO, 1500)
                return
            continue

        # Submenú subir/bajar/ocultar para el elemento seleccionado.
        eid = base[sel][0]
        opts = []
        if sel > 0:
            opts.append(('up',   '↑ Subir'))
        if sel < len(base) - 1:
            opts.append(('down', '↓ Bajar'))
        opts.append(('show', 'Mostrar') if eid in hidden else ('hide', 'Ocultar'))
        opts.append(('cancel', 'Cancelar'))
        choice = xbmcgui.Dialog().select("Mover / ocultar elemento", [o[1] for o in opts])
        if choice < 0 or opts[choice][0] == 'cancel':
            continue
        act = opts[choice][0]
        if act == 'up':
            base[sel - 1], base[sel] = base[sel], base[sel - 1]
            core_settings.save_search_menu_order([e[0] for e in base])
        elif act == 'down':
            base[sel], base[sel + 1] = base[sel + 1], base[sel]
            core_settings.save_search_menu_order([e[0] for e in base])
        elif act == 'hide':
            hidden.add(eid)
            core_settings.save_search_hidden(hidden)
            if all(e[0] in hidden for e in base):
                xbmcgui.Dialog().notification('TopZilla',
                    'Has ocultado todas las opciones', xbmcgui.NOTIFICATION_INFO, 3000)
        elif act == 'show':
            hidden.discard(eid)
            core_settings.save_search_hidden(hidden)


def _trakt_lists_reorder():
    """Diálogo subir/bajar para reordenar las listas Trakt del menú raíz."""
    lists = list(core_settings.get_trakt_lists())
    order = core_settings.load_trakt_lists_order()
    if order:
        index = {lid: i for i, lid in enumerate(order)}
        lists.sort(key=lambda l: index.get(l.get("id", ""), 10**6))

    if not lists:
        xbmcgui.Dialog().ok("TopZilla", "No hay listas Trakt para reordenar.")
        return

    while True:
        labels = []
        for i, l in enumerate(lists):
            arrows = ''
            if i > 0:
                arrows += '↑ '
            if i < len(lists) - 1:
                arrows += '↓ '
            count = l.get('item_count', 0)
            labels.append("{0}[B]{1}[/B] [COLOR gray]({2} ítems)[/COLOR]".format(
                arrows, l.get('name', l.get('id', '')), count))
        reset_pos = len(labels)
        labels.append("[COLOR orange]Restaurar orden por defecto[/COLOR]")

        sel = xbmcgui.Dialog().select(
            "Reordenar listas Trakt (los cambios se guardan al instante)", labels)
        if sel < 0:
            return
        if sel == reset_pos:
            if xbmcgui.Dialog().yesno("TopZilla",
                    "¿Restaurar el orden por defecto de las listas Trakt?"):
                core_settings.reset_trakt_lists_order()
                xbmcgui.Dialog().notification('TopZilla',
                    'Orden restaurado', xbmcgui.NOTIFICATION_INFO, 1500)
                return
            continue

        opts = []
        if sel > 0:
            opts.append(('up',   '↑ Subir'))
        if sel < len(lists) - 1:
            opts.append(('down', '↓ Bajar'))
        opts.append(('cancel', 'Cancelar'))
        choice = xbmcgui.Dialog().select("Mover elemento", [o[1] for o in opts])
        if choice < 0 or opts[choice][0] == 'cancel':
            continue
        if opts[choice][0] == 'up':
            lists[sel - 1], lists[sel] = lists[sel], lists[sel - 1]
        else:
            lists[sel], lists[sel + 1] = lists[sel + 1], lists[sel]
        core_settings.save_trakt_lists_order([l.get('id', '') for l in lists])


def _api_keys_menu():
    h = int(sys.argv[1])
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()
    fanart = core_settings.addon_fanart()

    tmdb_user = core_settings.get_tmdb_user_key()
    tmdb_tag  = "[COLOR green]Personalizada[/COLOR]" if tmdb_user else "[COLOR grey]No configurada[/COLOR]"
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]TMDB:[/B] {0}".format(tmdb_tag), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_api_key.png'), 'fanart': fanart})
    li.setInfo('video', {'plot': (
        "Clave API para metadatos, carátulas y calendarios de TMDB.\n\n"
        "Usar esta clave mejora la estabilidad del addon. Si el addon empieza a fallar, cámbiala.\n\n"
        "[COLOR blue][I]Pulsa para introducir o borrar tu clave.[/I][/COLOR]"
    )})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="api_key_set_tmdb"), listitem=li, isFolder=False)

    trakt_user = core_settings.get_trakt_user_key()
    trakt_tag  = "[COLOR green]Personalizada[/COLOR]" if trakt_user else "[COLOR grey]No configurada[/COLOR]"
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Trakt Client ID:[/B] {0}".format(trakt_tag), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_api_key.png'), 'fanart': fanart})
    li.setInfo('video', {'plot': (
        "Client ID para las listas y funciones de Trakt.tv.\n\n"
        "Usar este Client ID mejora la estabilidad del addon. Si el addon empieza a fallar, cámbialo.\n\n"
        "[COLOR blue][I]Pulsa para introducir o borrar tu clave.[/I][/COLOR]"
    )})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="api_key_set_trakt"), listitem=li, isFolder=False)

    trakt_secret = core_settings.get_trakt_client_secret()
    secret_tag   = "[COLOR green]Configurado[/COLOR]" if trakt_secret else "[COLOR grey]No configurado[/COLOR]"
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Trakt Client Secret:[/B] {0}".format(secret_tag), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_api_key.png'), 'fanart': fanart})
    li.setInfo('video', {'plot': (
        "Client Secret de tu app de Trakt. Solo hace falta para conectar tu cuenta "
        "en \"Mi Trakt\" (login OAuth); para las listas públicas basta con el Client ID.\n\n"
        "Créalo gratis junto al Client ID en trakt.tv/oauth/applications\n\n"
        "[COLOR blue][I]Pulsa para introducir o borrar tu Client Secret.[/I][/COLOR]"
    )})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="api_key_set_trakt_secret"), listitem=li, isFolder=False)

    omdb_user = core_settings.get_omdb_user_key()
    omdb_tag  = "[COLOR green]Personalizada[/COLOR]" if omdb_user else "[COLOR grey]No configurada[/COLOR]"
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]OMDb:[/B] {0}".format(omdb_tag), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_api_key.png'), 'fanart': fanart})
    li.setInfo('video', {'plot': (
        "Clave API para consultar puntuaciones de Rotten Tomatoes, "
        "Metacritic e IMDb (botón 'Críticas' en el menú ¿Dónde buscar?).\n\n"
        "Usar esta clave mejora la estabilidad del addon. Si el addon empieza a fallar, cámbiala.\n\n"
        "Puedes obtener una en omdbapi.com/apikey.aspx\n\n"
        "[COLOR blue][I]Pulsa para introducir o borrar tu clave.[/I][/COLOR]"
    )})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="api_key_set_omdb"), listitem=li, isFolder=False)

    mdblist_user = core_settings.get_mdblist_api_key()
    mdblist_tag  = "[COLOR green]Personalizada[/COLOR]" if mdblist_user else "[COLOR grey]No configurada[/COLOR]"
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]MDbList:[/B] {0}".format(mdblist_tag), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_api_key.png'), 'fanart': fanart})
    li.setInfo('video', {'plot': (
        "Clave API gratuita de mdblist.com para acceder a las listas curadas.\n\n"
        "Sin ella el addon sigue funcionando con el contenido gratuito.\n\n"
        "Puedes obtener una en mdblist.com\n\n"
        "[COLOR blue][I]Pulsa para introducir o borrar tu clave.[/I][/COLOR]"
    )})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="api_key_set_mdblist"), listitem=li, isFolder=False)

    mal_user = core_settings.get_mal_client_id()
    mal_tag  = "[COLOR green]Personalizada[/COLOR]" if mal_user else "[COLOR grey]No configurada[/COLOR]"
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]MyAnimeList (Client ID):[/B] {0}".format(mal_tag), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_api_key.png'), 'fanart': fanart})
    li.setInfo('video', {'plot': (
        "Client ID gratuito de myanimelist.net para los rankings MAL.\n\n"
        "Sin él AniList sigue funcionando con normalidad.\n\n"
        "Puedes obtener uno en myanimelist.net\n\n"
        "[COLOR blue][I]Pulsa para introducir o borrar tu clave.[/I][/COLOR]"
    )})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="api_key_set_mal"), listitem=li, isFolder=False)

    fanarttv_user = core_settings.get_text_setting('fanart_tv_api_key', '')
    fanarttv_tag  = "[COLOR green]Personalizada[/COLOR]" if fanarttv_user else "[COLOR grey]No configurada[/COLOR]"
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Fanart.tv:[/B] {0}".format(fanarttv_tag), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_api_key.png'), 'fanart': fanart})
    li.setInfo('video', {'plot': (
        "Clave API personal de fanart.tv para arte de alta calidad (clearlogo, fondos).\n\n"
        "Actívala en Opciones → 'Arte de Fanart.tv'. Sin clave el addon usa TMDB.\n\n"
        "Puedes obtener una en fanart.tv/get-an-api-key\n\n"
        "[COLOR blue][I]Pulsa para introducir o borrar tu clave.[/I][/COLOR]"
    )})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="api_key_set_fanarttv"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _api_key_prompt(current, prompt, validator):
    """Pide una clave (teclado/servidor) y la valida. Tres estados:
    None  -> el usuario canceló (no tocar la clave actual).
    ''    -> confirmó vacío (borrar la clave).
    str   -> clave validada a guardar.
    La validación solo aplica a texto no vacío."""
    import remote_input
    raw = remote_input.get_text_input(prompt, current, allow_clear=True)
    if raw is None:
        return None
    new_key = raw.strip()
    if not new_key:
        return ''
    bg = xbmcgui.DialogProgressBG()
    bg.create("TopZilla", "Validando clave...")
    try:
        valid = validator(new_key)
    finally:
        bg.close()
    if valid is False:
        if not xbmcgui.Dialog().yesno(
            "TopZilla — Clave inválida",
            "La API rechaza esta clave (no autorizada).\n\n¿Guardarla igualmente?",
            nolabel="Cancelar", yeslabel="Guardar"
        ):
            return None
    return new_key


def _api_key_set_tmdb():
    current = core_settings.get_tmdb_user_key()
    new_key = _api_key_prompt(current,
                               'Clave API de TMDB (dejar vacio para usar la integrada)',
                               core_settings.validate_tmdb_key)
    if new_key is None:
        return
    if not core_settings.set_tmdb_api_key(new_key):
        xbmcgui.Dialog().notification("TopZilla", "No se pudo guardar la clave",
                                       xbmcgui.NOTIFICATION_ERROR, 3000)
        return
    if new_key != current and xbmcgui.Dialog().yesno(
        "TopZilla",
        "Clave guardada. ¿Borrar la caché de metadatos para que se redescargue con la nueva clave?",
        nolabel="No", yeslabel="Borrar caché"
    ):
        try:
            import metadata_enricher
            metadata_enricher.delete_db()
        except Exception:
            xbmcgui.Dialog().notification("TopZilla", "No se pudo borrar la cache",
                                           xbmcgui.NOTIFICATION_WARNING, 3000)
    xbmcgui.Dialog().notification("TopZilla", "Clave TMDB guardada",
                                   xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin("Container.Refresh")


def _api_key_set_trakt():
    current = core_settings.get_trakt_user_key()
    new_key = _api_key_prompt(current,
                               'Client ID de Trakt (dejar vacio para usar el integrado)',
                               core_settings.validate_trakt_key)
    if new_key is None:
        return
    if not core_settings.set_trakt_api_key(new_key):
        xbmcgui.Dialog().notification("TopZilla", "No se pudo guardar la clave",
                                       xbmcgui.NOTIFICATION_ERROR, 3000)
        return
    xbmcgui.Dialog().notification("TopZilla", "Clave Trakt guardada",
                                   xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin("Container.Refresh")


def _api_key_set_trakt_secret():
    # Sin validación local: un Client Secret solo se puede comprobar haciendo el
    # OAuth de "Mi Trakt", que se lanza aparte. Aquí solo se guarda/borra.
    import remote_input
    current = core_settings.get_trakt_client_secret()
    raw = remote_input.get_text_input('Client Secret de Trakt (dejar vacio para borrarlo)', current, allow_clear=True)
    if raw is None:
        return
    new_secret = raw.strip()
    if not core_settings.set_trakt_client_secret(new_secret):
        xbmcgui.Dialog().notification("TopZilla", "No se pudo guardar el Client Secret",
                                       xbmcgui.NOTIFICATION_ERROR, 3000)
        return
    xbmcgui.Dialog().notification("TopZilla", "Client Secret guardado" if new_secret else "Client Secret borrado",
                                   xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin("Container.Refresh")


def _api_key_set_omdb():
    import omdb
    current = core_settings.get_omdb_user_key()
    new_key = _api_key_prompt(current,
                               'Clave API de OMDb',
                               omdb.validate_key)
    if new_key is None:
        return
    if not core_settings.set_omdb_api_key(new_key):
        xbmcgui.Dialog().notification("TopZilla", "No se pudo guardar la clave",
                                       xbmcgui.NOTIFICATION_ERROR, 3000)
        return
    xbmcgui.Dialog().notification("TopZilla", "Clave OMDb guardada",
                                   xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin("Container.Refresh")


def _api_key_set_mdblist():
    import remote_input
    current = core_settings.get_mdblist_api_key()
    raw = remote_input.get_text_input('Clave API de MDbList (dejar vacio para no usarla)', current, allow_clear=True)
    if raw is None:
        return  # cancelado: no tocar
    new_key = raw.strip()
    core_settings.set_mdblist_api_key(new_key)
    xbmcgui.Dialog().notification("TopZilla", "Clave MDbList guardada" if new_key else "Clave MDbList borrada",
                                   xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin("Container.Refresh")


def _api_key_set_mal():
    import remote_input
    current = core_settings.get_mal_client_id()
    raw = remote_input.get_text_input('Client ID de MyAnimeList (dejar vacio para no usarlo)', current, allow_clear=True)
    if raw is None:
        return  # cancelado: no tocar
    new_key = raw.strip()
    core_settings.set_mal_client_id(new_key)
    xbmcgui.Dialog().notification("TopZilla", "Client ID de MyAnimeList guardado" if new_key else "Client ID borrado",
                                   xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin("Container.Refresh")


def _api_key_set_fanarttv():
    import remote_input
    current = core_settings.get_text_setting('fanart_tv_api_key', '')
    raw = remote_input.get_text_input('Clave API personal de Fanart.tv (dejar vacio para no usarla)', current, allow_clear=True)
    if raw is None:
        return  # cancelado: no tocar
    new_key = raw.strip()
    core_settings.set_text_setting('fanart_tv_api_key', new_key)
    xbmcgui.Dialog().notification("TopZilla", "Clave Fanart.tv guardada" if new_key else "Clave Fanart.tv borrada",
                                   xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin("Container.Refresh")


# Fanart de fondo

_FANART_MODES   = ['addon', 'custom', 'disabled']
_FANART_MODE_TAGS = {
    'addon':    '[COLOR green]Imagen del addon[/COLOR]',
    'custom':   '[COLOR cyan]Imagen personalizada[/COLOR]',
    'disabled': '[COLOR red]Desactivado[/COLOR]',
}
_FANART_MODE_PLOTS = {
    'addon':    "Se usa la imagen fanart.png incluida con el addon.",
    'custom':   "Se usa la imagen que hayas seleccionado tú.",
    'disabled': "No se muestra ninguna imagen de fondo en los menús.",
}


def _fanart_menu():
    h = int(sys.argv[1])
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()
    _fanart = core_settings.addon_fanart()

    mode = core_settings.get_fanart_mode()
    mode_tag = _FANART_MODE_TAGS.get(mode, mode)
    mode_plot = _FANART_MODE_PLOTS.get(mode, '')
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Modo[/B]  {0}".format(mode_tag), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_refrescar.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "{0}\n\nPulsa para cambiar entre imagen del addon, imagen personalizada y desactivado.".format(mode_plot)})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="fanart_cycle_mode"), listitem=li, isFolder=False)

    custom_path = core_settings.get_custom_fanart_path()
    if custom_path:
        custom_tag = "[COLOR cyan]{0}[/COLOR]".format(custom_path)
        custom_plot = "Imagen actual: {0}\n\nPulsa para elegir otra imagen.".format(custom_path)
    else:
        custom_tag = "[COLOR grey]Sin configurar[/COLOR]"
        custom_plot = "Aún no has seleccionado ninguna imagen personalizada.\n\nPulsa para explorar tus archivos y elegir una."
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Imagen personalizada[/B]  {0}".format(custom_tag), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultFolder.png', 'fanart': _fanart})
    li.setInfo('video', {'plot': custom_plot + "\n\nFormatos soportados: JPG, PNG."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="fanart_browse_custom"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _fanart_cycle_mode():
    mode = core_settings.get_fanart_mode()
    modes = _FANART_MODES
    next_mode = modes[(modes.index(mode) + 1) % len(modes)] if mode in modes else 'addon'
    core_settings.set_fanart_mode(next_mode)
    xbmc.executebuiltin("Container.Refresh")


def _fanart_browse_custom():
    path = str(xbmcgui.Dialog().browse(1, 'Seleccionar imagen de fondo', 'files', '.jpg|.jpeg|.png', False, False, ''))
    if path and path != '0' and os.path.exists(path):
        core_settings.set_custom_fanart_path(path)
        core_settings.set_fanart_mode('custom')
    xbmc.executebuiltin("Container.Refresh")


def _accessibility_menu():
    h = int(sys.argv[1])

    color_mode = core_settings.get_acc_color_mode()
    bold_on    = core_settings.get_acc_force_bold()
    strip_sym  = core_settings.get_acc_strip_symbols()

    _bold  = bold_on
    _strip = strip_sym
    _color = color_mode

    color_name = _ACC_COLOR_NAMES.get(color_mode, color_mode)
    color_tag  = "[COLOR green]" if color_mode != 'none' else "[COLOR grey]"
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Modo de color:[/B] {0}{1}[/COLOR]".format(color_tag, color_name),
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_accesibilidad.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': _ACC_COLOR_PLOTS.get(color_mode, "") + "\n\n[COLOR blue][I]Pulsa para cambiar el modo de color.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="acc_set_color"), listitem=li, isFolder=False)

    bold_tag = core_settings.state_tag(bold_on)
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Negrita forzada:[/B] {0}".format(bold_tag),
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_accesibilidad.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Muestra los títulos de películas y secciones en negrita.\n\n[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="acc_toggle_bold"), listitem=li, isFolder=False)

    sym_tag = "[COLOR green]ACTIVADA[/COLOR]" if strip_sym else "[COLOR grey]DESACTIVADA[/COLOR]"
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Sustitución de símbolos especiales:[/B] {0}".format(sym_tag),
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_accesibilidad.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Reemplaza caracteres Unicode especiales (★ ● ▲ ▼ etc.) por equivalentes ASCII (* ^ v).\nÚtil si tu skin no muestra correctamente estos caracteres.\n\n[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="acc_toggle_symbols"), listitem=li, isFolder=False)

    font_size_on = core_settings.get_acc_font_size()
    font_tag = core_settings.state_tag(font_size_on)
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Texto en mayúsculas:[/B] {0}".format(font_tag),
        bold=_bold, strip=_strip, color_mode=_color, font_size=font_size_on))
    li.setArt({'icon': _mi('adv_accesibilidad.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Muestra todo el texto del addon en MAYÚSCULAS para mejorar la legibilidad.\n\n[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="acc_toggle_font_size"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _acc_set_color():
    modes = list(_ACC_COLOR_NAMES.keys())
    current = core_settings.get_acc_color_mode()
    idx = modes.index(current) if current in modes else 0
    chosen = xbmcgui.Dialog().select("Modo de color", list(_ACC_COLOR_NAMES.values()), preselect=idx)
    if chosen < 0:
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return
    core_settings.set_acc_color_mode(modes[chosen])
    xbmcgui.Dialog().notification("TopZilla", "Modo de color guardado.", xbmcgui.NOTIFICATION_INFO, 3000)
    xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
    xbmc.executebuiltin("Container.Refresh")


def _acc_toggle_bold():
    new_val = not core_settings.get_acc_force_bold()
    core_settings.set_acc_force_bold(new_val)
    msg = "ACTIVADA" if new_val else "DESACTIVADA"
    xbmcgui.Dialog().notification("TopZilla", "Negrita {0}.".format(msg), xbmcgui.NOTIFICATION_INFO, 3000)
    xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
    xbmc.executebuiltin("Container.Refresh")


def _acc_toggle_symbols():
    new_val = not core_settings.get_acc_strip_symbols()
    core_settings.set_acc_strip_symbols(new_val)
    msg = "ACTIVADA" if new_val else "DESACTIVADA"
    xbmcgui.Dialog().notification("TopZilla", "Sustitución de símbolos {0}.".format(msg), xbmcgui.NOTIFICATION_INFO, 4000)
    xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
    xbmc.executebuiltin("Container.Refresh")


def _acc_toggle_font_size():
    new_val = not core_settings.get_acc_font_size()
    core_settings.set_acc_font_size(new_val)
    msg = "ACTIVADA" if new_val else "DESACTIVADA"
    xbmcgui.Dialog().notification("TopZilla", "Texto en mayúsculas {0}.".format(msg), xbmcgui.NOTIFICATION_INFO, 3000)
    xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
    xbmc.executebuiltin("Container.Refresh")


def _limpieza_parent_menu():
    h = int(sys.argv[1])
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()
    af = core_settings.addon_fanart()

    li = xbmcgui.ListItem(label=core_settings.apply_label("[B]Limpieza[/B]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_limpieza.png'), 'fanart': af})
    li.setInfo('video', {'plot': "Opciones para liberar espacio: borrar cachés temporales, compactar la base de metadatos o restablecer el addon a estado de fábrica."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="cleanup_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label=core_settings.apply_label("[B]Limpieza avanzada (almacenamiento)[/B]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_limpieza.png'), 'fanart': af})
    li.setInfo('video', {'plot': "Gestor de almacenamiento: muestra el espacio que ocupa cada caché y permite borrarlas por categoría, vaciar la base de metadatos o eliminar los backups, con detalle de tamaños."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="storage_manager"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label=core_settings.apply_label("[B]Limpieza y mantenimiento de Kodi[/B]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_anti_errores.png'), 'fanart': af})
    li.setInfo('video', {'plot': "Mantenimiento general de Kodi: paquetes de instalación, miniaturas en desuso, compactar bases de datos y copia de tu configuración de Kodi. No toca tus datos de TopZilla ni los de otros addons."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="kodi_maintenance_menu"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _cleanup_menu():
    h = int(sys.argv[1])
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()

    li = xbmcgui.ListItem(label=core_settings.apply_label("[COLOR yellow][B]Limpiar caché (recomendado)[/B][/COLOR]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_cache.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Borra los archivos de caché temporales: miniaturas TMDB, metadatos de FilmAffinity, SensaCine, Cinemeta y carátulas de películas.\n\nNo afecta a tus ajustes ni a la configuración de accesibilidad."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="cleanup_caches"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label("[COLOR cyan][B]Compactar base de metadatos[/B][/COLOR]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultHardDisk.png', 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Elimina las entradas caducadas (más de 30 días) de la base de datos de metadatos TMDB y compacta el archivo.\n\nMantiene los datos recientes y libera el espacio que ocupaban los caducados."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="vacuum_metadata_db"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label("[COLOR orange][B]Borrar base de metadatos completa[/B][/COLOR]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultHardDisk.png', 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Elimina por completo la base de datos de metadatos TMDB.\n\nLos metadatos se volverán a descargar cuando navegues. No afecta a favoritos, categorías ni historiales."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="delete_metadata_db"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label("[COLOR red][B]Restablecer addon (factory reset)[/B][/COLOR]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultIconError.png', 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "BORRA TODOS LOS DATOS DEL ADDON y deja la instalación como recién instalada.\n\nSe pierden tus favoritos, categorías, historiales, atajos de búsqueda, listas de Trakt, cachés, base de metadatos, backups y todos los ajustes (accesibilidad, claves API, descargas y menú contextual).\n\nEsta acción NO se puede deshacer."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="factory_reset"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _cleanup_caches():
    if not xbmcgui.Dialog().yesno(
        "TopZilla - Limpieza",
        "¿Borrar los archivos de caché temporales?\n\nNo afecta a tus favoritos, categorías, historiales ni ajustes."
    ):
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return

    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    freed = 0
    cache_files = [
        'topzilla_fa_cache.json',
        'topzilla_sc_cache.json',
        'topzilla_cinemeta_cache.json',
        'topzilla_tmdb_lists_cache.json',
        'topzilla_on_air_calendar.json',
        'topzilla_top_movies_thumbs.json',
        'topzilla_yt_search_cache.json',
        'topzilla_wikipedia_cache.json',
        'topzilla_explore_cache.json',
        'topzilla_trakt_tops_cache.json',
        'topzilla_streaming_tops_cache.json',
        'topzilla_anime_cache.json',
        'topzilla_mdblist_cache.json',
        'topzilla_letterboxd_cache.json',
        'topzilla_flix_cache.json',
        'trakt_meta_items.json',
        'trakt_meta_downloaded.flag',
    ]
    for fn in cache_files:
        fp = os.path.join(profile, fn)
        if os.path.exists(fp):
            try:
                freed += os.path.getsize(fp)
                os.remove(fp)
            except OSError:
                pass

    # Carátulas Trakt (patrón trakt_thumbs_*.json), todas reconstruibles
    if os.path.exists(profile):
        for fn in os.listdir(profile):
            if fn.startswith('trakt_thumbs_') and fn.endswith('.json'):
                fp = os.path.join(profile, fn)
                try:
                    freed += os.path.getsize(fp)
                    os.remove(fp)
                except OSError:
                    pass

    xbmcgui.Dialog().ok(
        "TopZilla - Limpieza",
        "Caché borrada.\n\nSe han liberado {0}.".format(_human_size(freed))
    )
    xbmc.executebuiltin("Container.Refresh")
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def _vacuum_metadata_db():
    if not xbmcgui.Dialog().yesno(
        "TopZilla - Compactar metadatos",
        "¿Eliminar entradas caducadas (más de 30 días) y compactar la base de datos?\n\nLos metadatos recientes se conservan."
    ):
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    try:
        import metadata_enricher
        deleted, freed = metadata_enricher.prune_and_vacuum()
        xbmcgui.Dialog().ok(
            "TopZilla - Compactar metadatos",
            "Se han borrado {0} entradas y liberado {1}.".format(deleted, _human_size(freed))
        )
    except Exception as e:
        xbmcgui.Dialog().ok("TopZilla - Error", "No se pudo compactar.\n\n{0}".format(str(e)))
    xbmc.executebuiltin("Container.Refresh")
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def _delete_metadata_db():
    if not xbmcgui.Dialog().yesno(
        "TopZilla - Borrar metadatos",
        "¿Borrar completamente la base de datos de metadatos TMDB?\n\nLos metadatos se volverán a descargar al navegar. No afecta a favoritos, categorías ni historiales.",
        nolabel="Cancelar",
        yeslabel="Borrar"
    ):
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    try:
        import metadata_enricher
        freed = metadata_enricher.delete_db()
    except Exception as e:
        xbmcgui.Dialog().ok("TopZilla - Error", "No se pudo borrar la base de datos.\n\n{0}".format(str(e)))
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    xbmcgui.Dialog().ok(
        "TopZilla - Borrar metadatos",
        "Base de datos eliminada.\n\nSe han liberado {0}.".format(_human_size(freed))
    )
    xbmc.executebuiltin("Container.Refresh")
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def _factory_reset():
    if not xbmcgui.Dialog().yesno(
        "TopZilla - Restablecer addon",
        "Vas a BORRAR TODOS LOS DATOS DEL ADDON y dejarlo como recién instalado.\n\nSe perderán: tus favoritos, categorías, historiales (visionado, navegación, búsquedas), atajos de búsqueda, listas de Trakt importadas, los cachés, la base de metadatos, los backups guardados y todos los ajustes (accesibilidad, claves API, descargas automáticas y menú contextual).\n\nEsta acción NO se puede deshacer. ¿Continuar?",
        nolabel="Cancelar",
        yeslabel="Restablecer"
    ):
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return

    # Segunda confirmación para una acción irreversible: exige teclear BORRAR.
    confirm = xbmcgui.Dialog().input(
        "Escribe BORRAR (en mayúsculas) para confirmar el restablecimiento",
        type=xbmcgui.INPUT_ALPHANUM)
    if (confirm or "").strip() != "BORRAR":
        xbmcgui.Dialog().notification("TopZilla", "Restablecimiento cancelado",
                                       xbmcgui.NOTIFICATION_INFO, 2500)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return

    core_settings.reset_all_settings()

    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if os.path.exists(profile):
        for fn in os.listdir(profile):
            fp = os.path.join(profile, fn)
            if fn.endswith('.json') or fn.endswith('.db') or fn.endswith('.flag'):
                try:
                    os.remove(fp)
                except Exception:
                    pass
        backups_dir = os.path.join(profile, 'backups')
        if os.path.isdir(backups_dir):
            for fn in os.listdir(backups_dir):
                fp = os.path.join(backups_dir, fn)
                try:
                    os.remove(fp)
                except Exception:
                    pass

    xbmcgui.Dialog().notification("TopZilla", "Addon restablecido", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


# Alternativas de reproducción

def _build_search_entries(mode):
    """Devuelve [(id, label, action, visible)] con TODAS las entradas posibles
    del menú '¿Dónde buscar?' (fijas + atajos), en su orden por defecto."""
    has_yt   = xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)")
    has_emb  = False
    try:
        import context_menu as _cm
        has_emb = _cm.has_embuary()
    except Exception:
        pass
    espa_on   = (core_settings._espadaily_integration_enabled()
                 and xbmc.getCondVisibility("System.HasAddon(plugin.video.espadaily)"))
    atres_on  = (core_settings._atresdaily_integration_enabled()
                 and xbmc.getCondVisibility("System.HasAddon(plugin.video.atresdaily)"))
    espatv_on = (core_settings._espatv_integration_enabled()
                 and xbmc.getCondVisibility("System.HasAddon(plugin.video.espatv)"))
    is_mov_show = mode in ('movie', 'show')
    ost_on   = core_settings.show_soundtrack_button_enabled()
    omdb_on  = core_settings.show_omdb_button_enabled()
    share_on = core_settings.show_share_button_enabled()
    mega_on  = core_settings.show_megabuscador_button_enabled()
    # AddonIsEnabled (no HasAddon): HasAddon es true aunque el addon esté
    # deshabilitado; el label "usable" solo debe salir si está habilitado.
    tmdbh_on = xbmc.getCondVisibility("System.AddonIsEnabled(plugin.video.themoviedb.helper)")

    emb_label = ("[COLOR orange]Ficha[/COLOR]" if has_emb
                 else "[COLOR gray]Ficha (instala Embuary Info)[/COLOR]")
    tmdbh_label = ("[COLOR plum]Ver en otro addon[/COLOR]" if tmdbh_on
                   else "[COLOR gray]Ver en otro addon (instala TMDB Helper)[/COLOR]")

    # Solo se ofrece si hay una cuenta Debrid vinculada (is_authorized no hace red).
    debrid_on = False
    try:
        import debrid_resolver as _dr
        debrid_on = _dr.get_resolver().is_authorized()
    except Exception as e:
        xbmc.log("[TopZilla] gate debrid búsqueda: {0}".format(e), xbmc.LOGWARNING)

    entries = [
        ('watch_providers',    "[COLOR lightgreen]¿Dónde verla en España?[/COLOR]",   'watch_providers',    is_mov_show),
        ('omdb_reviews',       "[COLOR orange]Críticas (RT / Metacritic / IMDb)[/COLOR]", 'omdb_reviews',  omdb_on and is_mov_show),
        ('youtube',            "[COLOR red]Buscar en YouTube[/COLOR]",                'youtube',            has_yt),
        ('soundtrack_yt',      "[COLOR magenta]Buscar Banda Sonora[/COLOR]",          'soundtrack_yt',      ost_on and has_yt and is_mov_show),
        ('dailymotion_native', "[COLOR cyan]Buscar en Dailymotion[/COLOR]",           'dailymotion_native', True),
        ('tmdb_extras',        "[COLOR white]Más información[/COLOR]",                'tmdb_extras',        is_mov_show),
        ('wikipedia',          "[COLOR deepskyblue]Buscar en Wikipedia[/COLOR]",      'wikipedia',          True),
        ('embuary_info',       emb_label,                                             'embuary_info',       is_mov_show),
        ('open_espadaily',     "[COLOR violet]Buscar en EspaDaily[/COLOR]",           'open_espadaily',     espa_on),
        ('open_atresdaily',    "[COLOR violet]Abrir búsqueda en el addon AtresDaily[/COLOR]",          'open_atresdaily',    atres_on),
        ('open_espatv',        "[COLOR violet]Buscar en EspaTV[/COLOR]",              'open_espatv',        espatv_on),
        ('tmdb_helper',        tmdbh_label,                                           'tmdb_helper',        True),
        ('share_movie',        "[COLOR pink]Compartir esta peli[/COLOR]",             'share_movie',        share_on and is_mov_show),
        ('megabuscador_bt',    "[COLOR deeppink]Megabuscador[/COLOR]",                'megabuscador_bt',    mega_on),
        ('debrid_search',      "[COLOR aquamarine]Buscar en mi nube (Debrid)[/COLOR]", 'debrid_search',    debrid_on),
    ]

    for i, sc in enumerate(core_settings.load_search_shortcuts()):
        sid  = core_settings.shortcut_stable_id(sc)
        name = sc.get('name', 'Atajo {0}'.format(i + 1))
        if _shortcut_addon_installed(sc):
            lbl = "[COLOR gold]{0}[/COLOR]".format(name)
        else:
            lbl = "[COLOR red]{0} (no instalado)[/COLOR]".format(name)
        entries.append((sid, lbl, 'custom_{0}'.format(i), bool(sid)))

    return entries


def _copy_to_clipboard(text):
    if not text:
        return False
    data = text.encode('utf-8')
    try:
        import subprocess
        if xbmc.getCondVisibility('System.Platform.Windows'):
            try:
                CREATE_NO_WINDOW = 0x08000000
                p = subprocess.Popen(['clip'], stdin=subprocess.PIPE,
                                     creationflags=CREATE_NO_WINDOW)
                p.communicate(input=data)
                return p.returncode == 0
            except (OSError, IOError):
                return False
        if xbmc.getCondVisibility('System.Platform.OSX'):
            try:
                p = subprocess.Popen(['pbcopy'], stdin=subprocess.PIPE)
                p.communicate(input=data)
                return p.returncode == 0
            except (OSError, IOError):
                return False
        if xbmc.getCondVisibility('System.Platform.Linux'):
            import shutil
            for cmd in (['wl-copy'], ['xclip', '-selection', 'clipboard'], ['xsel', '-b', '-i']):
                if not shutil.which(cmd[0]):
                    continue
                try:
                    p = subprocess.Popen(cmd, stdin=subprocess.PIPE)
                    p.communicate(input=data)
                    if p.returncode == 0:
                        return True
                except (OSError, IOError):
                    continue
            return False
    except Exception:
        return False
    return False


# Acciones de "¿dónde buscar?" que cargan resultados/navegan (vs. las
# informativas: ¿dónde ver?, críticas OMDb, compartir). El Modo Cine cierra su
# modal antes de estas para no taparlas (on_navigate).
_NAV_ACTIONS = frozenset({'youtube', 'soundtrack_yt', 'dailymotion_native',
                          'wikipedia', 'open_espadaily', 'open_atresdaily', 'open_espatv',
                          'megabuscador_bt', 'tmdb_helper', 'debrid_search'})


def _search_alternatives_prompt(query, ot='', mode='', ref=None, tmdb_id='', season='', episode='', on_navigate=None):
    h = int(sys.argv[1])

    entries = _build_search_entries(mode)
    order   = core_settings.load_search_menu_order()
    if order:
        index = {eid: i for i, eid in enumerate(order)}
        # Las entradas no presentes en el orden guardado van al final.
        entries.sort(key=lambda e: index.get(e[0], 10**6))
    hidden = core_settings.load_search_hidden()
    entries = [e for e in entries if e[3] and e[0] not in hidden]

    opciones = [e[1] for e in entries]
    acciones = [e[2] for e in entries]

    # tmdb_id puede venir como parámetro URL o, como fallback, del ref:
    # record_navigation / show_card_from_context / menú contextual pasan ref
    # (que sí lo lleva) pero no el parámetro. Lo consume el handler tmdb_helper.
    try:
        _th_id = int(tmdb_id or (ref or {}).get('tmdb_id', 0) or 0)
        _th_id = _th_id if _th_id > 0 else 0
    except (ValueError, TypeError):
        _th_id = 0

    if not any(a.startswith('custom_') for a in acciones):
        opciones.append("[COLOR gray]Puedes añadir más en Opciones[/COLOR]")
        acciones.append("hint_shortcuts")

    if not opciones:
        if xbmcgui.Dialog().yesno(
                "TopZilla",
                "No hay addons de reproducción instalados.\n\nInstala YouTube para buscar '{0}'.".format(query),
                yeslabel="Instalar", nolabel="Cancelar"):
            xbmc.executebuiltin("InstallAddon(plugin.video.youtube)")
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
        return

    idx = xbmcgui.Dialog().select("¿Dónde buscar '{0}'?".format(query), opciones)
    if idx < 0:
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
        return

    accion = acciones[idx]

    # Modo Cine: cierra el modal (WindowXMLDialog) antes de navegar a una fuente
    # que carga resultados; si no, taparía la lista. on_navigate es None en el
    # flujo normal (RunPlugin), así que no cambia nada fuera del Modo Cine.
    if on_navigate and (accion in _NAV_ACTIONS or accion.startswith('custom_')):
        try:
            on_navigate()
        except Exception as e:
            xbmc.log("[TopZilla] on_navigate: {0}".format(e), xbmc.LOGWARNING)

    if accion == "watch_providers":
        import metadata_enricher as me
        me_mode = mode if mode in ('movie', 'show') else 'movie'
        meta = me.enrich(title=query, media_type=me_mode)
        tmdb_id = str((meta.get('ids') or {}).get('tmdb', '')) if meta else ''
        if not tmdb_id:
            xbmcgui.Dialog().notification("TopZilla", "No se pudo identificar en TMDB", xbmcgui.NOTIFICATION_WARNING)
            xbmcplugin.endOfDirectory(h, cacheToDisc=False)
            return
        providers = me.fetch_watch_providers(tmdb_id, media_type=me_mode)
        lines = []
        if providers.get('flatrate'):
            lines.append("Suscripción: " + ", ".join(providers['flatrate']))
        if providers.get('free'):
            lines.append("Gratis: " + ", ".join(providers['free']))
        if providers.get('rent'):
            lines.append("Alquiler: " + ", ".join(providers['rent']))
        if providers.get('buy'):
            lines.append("Compra: " + ", ".join(providers['buy']))
        if lines:
            xbmcgui.Dialog().textviewer(
                "¿Dónde ver '{0}' en España?".format(query),
                "\n".join(lines),
            )
        else:
            xbmcgui.Dialog().ok(
                "¿Dónde ver '{0}'?".format(query),
                "No disponible en ninguna plataforma de streaming en España según TMDB.",
            )
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)

    elif accion == "omdb_reviews":
        api_key = core_settings.get_omdb_api_key()
        if not api_key:
            xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
            if xbmcgui.Dialog().yesno(
                "OMDb",
                "Configura tu clave de OMDb en Opciones → Claves API.\n\n"
                "Puedes obtener una en omdbapi.com/apikey.aspx",
                yeslabel="Ir a Claves API", nolabel="Cancelar"):
                xbmc.executebuiltin("Container.Update({0})".format(_u(action='api_keys_menu')))
            return

        me_mode = mode if mode in ('movie', 'show') else 'movie'
        imdb_id = (ref or {}).get('imdb_id') if ref else None
        year    = (ref or {}).get('year') if ref else None
        clave_propia = bool(core_settings.get_omdb_user_key())

        import omdb as _omdb
        bg = xbmcgui.DialogProgressBG()
        bg.create("TopZilla", "Consultando OMDb...")
        try:
            if not imdb_id:
                try:
                    import metadata_enricher as me
                    meta = me.enrich(title=query, media_type=me_mode, year=year if year else None)
                    if meta:
                        imdb_id = (meta.get('ids') or {}).get('imdb')
                        if not year:
                            year = meta.get('year')
                except Exception:
                    pass
            data = _omdb.fetch(api_key, imdb_id=imdb_id, title=query, year=year, media_type=me_mode)
            primer_err = data.get('_topzilla_error') if isinstance(data, dict) else None
            if not clave_propia:
                ya_probadas = {api_key}
                while primer_err in ('invalid_key', 'rate_limit'):
                    core_settings.mark_omdb_pool_key_dead(api_key)
                    otra_clave = core_settings.get_omdb_api_key()
                    if not otra_clave or otra_clave in ya_probadas:
                        break
                    ya_probadas.add(otra_clave)
                    data = _omdb.fetch(otra_clave, imdb_id=imdb_id, title=query, year=year, media_type=me_mode)
                    api_key = otra_clave
                    primer_err = data.get('_topzilla_error') if isinstance(data, dict) else None
        finally:
            bg.close()

        err = data.get('_topzilla_error') if isinstance(data, dict) else None
        if err == 'invalid_key':
            xbmcgui.Dialog().ok(
                "OMDb",
                "La clave OMDb no es válida. Revisa Opciones → Claves API.")
            xbmcplugin.endOfDirectory(h, cacheToDisc=False)
            return
        if err == 'rate_limit':
            xbmcgui.Dialog().ok(
                "OMDb",
                "OMDb no está disponible ahora mismo. Inténtalo más tarde, "
                "o configura tu propia clave en Opciones → Claves API para mayor estabilidad.")
            xbmcplugin.endOfDirectory(h, cacheToDisc=False)
            return
        if err == 'network':
            xbmcgui.Dialog().ok("OMDb", "Sin conexión con OMDb. Comprueba tu acceso a Internet.")
            xbmcplugin.endOfDirectory(h, cacheToDisc=False)
            return
        if err == 'http':
            xbmcgui.Dialog().ok("OMDb", "Error en el servidor OMDb. Inténtalo más tarde.")
            xbmcplugin.endOfDirectory(h, cacheToDisc=False)
            return
        if not data:
            xbmcgui.Dialog().ok("OMDb", "No se encontraron datos para '{0}'.".format(query))
            xbmcplugin.endOfDirectory(h, cacheToDisc=False)
            return

        rt_val = mc_val = imdb_val = None
        ratings = data.get('Ratings')
        if not isinstance(ratings, list):
            ratings = []
        for rating in ratings:
            if not isinstance(rating, dict):
                continue
            source = rating.get('Source', '')
            value  = rating.get('Value', '')
            if value == 'N/A' or not value:
                continue
            if 'Rotten Tomatoes' in source:
                rt_val = value
            elif 'Metacritic' in source:
                mc_val = value
            elif 'Internet Movie Database' in source:
                imdb_val = value

        lines = []
        if imdb_val:
            lines.append("[COLOR gold][B]IMDb:[/B][/COLOR]              {0}".format(imdb_val))
        if rt_val:
            lines.append("[COLOR red][B]Rotten Tomatoes:[/B][/COLOR]   {0}".format(rt_val))
        if mc_val:
            lines.append("[COLOR yellow][B]Metacritic:[/B][/COLOR]        {0}".format(mc_val))

        imdb_votes = data.get('imdbVotes', '')
        if imdb_votes and imdb_votes != 'N/A':
            if lines:
                lines.append("")
            lines.append("[COLOR gray]({0} votos en IMDb)[/COLOR]".format(imdb_votes))

        title_omdb = data.get('Title')
        title_year = title_omdb if title_omdb and title_omdb != 'N/A' else query
        year_omdb = data.get('Year')
        if year_omdb and year_omdb != 'N/A':
            title_year = "{0} ({1})".format(title_year, year_omdb)

        if not lines:
            xbmcgui.Dialog().ok(
                "Críticas: {0}".format(title_year),
                "No hay puntuaciones disponibles en OMDb para esta película.")
        else:
            xbmcgui.Dialog().textviewer(
                "Críticas: {0}".format(title_year),
                "\n".join(lines))
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)

    elif accion == "youtube":
        _search_youtube_from_results(query)
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)

    elif accion == "soundtrack_yt":
        year = ''
        if ref and isinstance(ref, dict):
            y = ref.get('year') or 0
            if y:
                year = ' {0}'.format(y)
        yt_query = "{0}{1} soundtrack".format(query, year)
        xbmc.executebuiltin("Container.Update({0})".format(_u(action='yt_results', query=yt_query)))
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)

    elif accion == "dailymotion_native":
        xbmc.executebuiltin("Container.Update({0})".format(_u(action='lfr', q=query, ot=ot, mode=mode)))
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)

    elif accion == "wikipedia":
        # Cerrar la acción del plugin ANTES de abrir el flujo Wikipedia: así
        # no queda un contenedor intermedio en el historial. wikipedia_results
        # es un flujo de diálogos puro y vuelve al origen al cerrarse.
        xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
        import search_movies as _sm
        _sm.wikipedia_results(query)
        return

    elif accion == "tmdb_extras":
        xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
        import search_movies as _sm
        _sm.tmdb_extras_dialog(query,
            media_type=mode if mode in ('movie', 'show') else 'movie')
        return

    elif accion == "embuary_info":
        import context_menu as _cm
        if not _cm.has_embuary():
            xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
            if xbmcgui.Dialog().yesno(
                "Embuary Info",
                "Embuary Info no está instalado.\n\n"
                "Instálalo para ver fichas detalladas (sinopsis ampliada, reparto, tráilers, recomendados...).",
                yeslabel="Instalar", nolabel="Cancelar"):
                xbmc.executebuiltin("InstallAddon(script.embuary.info)")
            return
        script = _cm._embuary_script(ref) if ref else None
        if not script:
            call_type = 'tv' if mode == 'show' else 'movie'
            safe = query.replace('"', ' ').replace(',', ' ').strip()
            if safe:
                script = "RunScript(script.embuary.info,call={0},query={1})".format(call_type, safe)
        xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
        if script:
            xbmc.executebuiltin(script)
        return

    elif accion == "open_espadaily":
        params = {
            'action': 'search_alt_prompt',
            'q': query,
            'ot': ot or '',
        }
        if mode in ('movie', 'show'):
            params['mode'] = mode
        url = "plugin://plugin.video.espadaily/?" + urllib.parse.urlencode(params)
        xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
        xbmc.executebuiltin('RunPlugin({0})'.format(url))
        return

    elif accion == "open_atresdaily":
        params = {
            'action': 'search_alt_prompt',
            'q': query,
            'ot': ot or '',
        }
        if mode in ('movie', 'show'):
            params['mode'] = mode
        url = "plugin://plugin.video.atresdaily/?" + urllib.parse.urlencode(params)
        xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
        xbmc.executebuiltin('RunPlugin({0})'.format(url))
        return

    elif accion == "megabuscador_bt":
        # bt_run (busqueda_total nativo) renderiza un listado de resultados: navegamos con
        # Container.Update (no RunPlugin, que ejecutaría la búsqueda pero descartaría la
        # lista). Mismo patrón que soundtrack_yt/dailymotion_native.
        xbmc.executebuiltin("Container.Update({0})".format(_u(action='bt_run', q=query)))
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)

    elif accion == "open_espatv":
        params = {
            'action': 'search_alt_prompt',
            'q': query,
            'ot': ot or '',
        }
        if mode in ('movie', 'show'):
            params['mode'] = mode
        url = "plugin://plugin.video.espatv/?" + urllib.parse.urlencode(params)
        xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
        xbmc.executebuiltin('RunPlugin({0})'.format(url))
        return

    elif accion == "share_movie":
        me_mode = mode if mode in ('movie', 'show') else 'movie'
        title   = (ref.get('title') if ref else '') or query
        year    = (ref.get('year') if ref else 0) or 0
        tmdb_id = ref.get('tmdb_id') if ref else None
        rating  = None

        if not tmdb_id or not rating:
            try:
                import metadata_enricher as me
                meta = me.enrich(title=title, media_type=me_mode,
                                 year=year if year else None,
                                 tmdb_id=tmdb_id)
                if meta:
                    if not tmdb_id:
                        tmdb_id = (meta.get('ids') or {}).get('tmdb')
                    if not year:
                        year = meta.get('year') or 0
                    r = meta.get('rating') or 0
                    if r:
                        rating = round(float(r), 1)
            except Exception:
                pass

        header = '{0}'.format(title)
        if year:
            header += ' ({0})'.format(year)
        parts = [header]
        if rating:
            parts.append('{0}/10 (TMDB)'.format(rating))
        if tmdb_id:
            url_path = 'tv' if me_mode == 'show' else 'movie'
            parts.append('https://www.themoviedb.org/{0}/{1}'.format(url_path, tmdb_id))
        msg = '\n'.join(parts)

        if _copy_to_clipboard(msg):
            xbmcgui.Dialog().notification(
                'TopZilla', 'Mensaje copiado al portapapeles',
                xbmcgui.NOTIFICATION_INFO, 3000)
        else:
            xbmcgui.Dialog().textviewer('Compartir esta peli', msg)
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)

    elif accion == "tmdb_helper":
        es_serie = mode in ('show', 'tv')
        if not xbmc.getCondVisibility('System.AddonIsEnabled(plugin.video.themoviedb.helper)'):
            xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
            if xbmcgui.Dialog().yesno(
                    "TMDB Helper",
                    "TMDB Helper no está instalado o está deshabilitado.\n¿Deseas instalarlo ahora?",
                    yeslabel="Instalar", nolabel="Cancelar"):
                xbmc.executebuiltin("InstallAddon(plugin.video.themoviedb.helper)")
            return
        # Sin tmdb_id (p. ej. desde la búsqueda libre de Dailymotion): intentar
        # resolverlo por título. El enricher usa 'show' (mapea a endpoint tv él mismo).
        if not _th_id:
            try:
                import metadata_enricher as me
                me_mode = 'show' if es_serie else 'movie'
                _me_year = (ref.get('year') if ref else None) or None
                meta = me.enrich(title=query, media_type=me_mode, year=_me_year)
                _th_id = int((meta.get('ids') or {}).get('tmdb', 0) or 0) if meta else 0
            except Exception:
                pass
        if not _th_id:
            xbmcgui.Dialog().notification(
                "TopZilla", "No se pudo identificar en TMDB", xbmcgui.NOTIFICATION_WARNING)
            xbmcplugin.endOfDirectory(h, cacheToDisc=False)
            return
        try:
            _ep = int(episode)
        except (ValueError, TypeError):
            _ep = 0
        try:
            _se = int(season or 0)
        except (ValueError, TypeError):
            _se = 0
        xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
        if not es_serie:
            xbmc.executebuiltin("RunPlugin(plugin://plugin.video.themoviedb.helper/?info=play&tmdb_type=movie&tmdb_id={0})".format(_th_id))
        elif _ep >= 1:
            xbmc.executebuiltin("RunPlugin(plugin://plugin.video.themoviedb.helper/?info=play&tmdb_type=tv&tmdb_id={0}&season={1}&episode={2})".format(_th_id, _se, _ep))
        else:
            xbmc.executebuiltin("Container.Update(plugin://plugin.video.themoviedb.helper/?info=seasons&tmdb_type=tv&tmdb_id={0})".format(_th_id))
        return

    elif accion == "hint_shortcuts":
        xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
        xbmc.executebuiltin("Container.Update({0})".format(_u(action='search_shortcuts_menu')))
        return

    elif accion.startswith("custom_"):
        try:
            sc_idx = int(accion.split("_", 1)[1])
        except (ValueError, IndexError):
            sc_idx = -1
        shortcuts = core_settings.load_search_shortcuts()
        if not (0 <= sc_idx < len(shortcuts)):
            xbmcplugin.endOfDirectory(h, cacheToDisc=False)
            return
        sc  = shortcuts[sc_idx]
        cmd = sc.get('command', '')
        if not cmd:
            xbmcplugin.endOfDirectory(h, cacheToDisc=False)
            return
        aid = sc.get('addon_id') or ''
        if aid and not xbmc.getCondVisibility('System.HasAddon({0})'.format(aid)):
            xbmcgui.Dialog().notification(
                'TopZilla',
                "El addon '{0}' no está instalado".format(aid),
                xbmcgui.NOTIFICATION_WARNING, 3000)
            xbmcplugin.endOfDirectory(h, cacheToDisc=False)
            return
        # Aviso de primer uso (una sola vez): qué hace un atajo externo.
        if not core_settings.is_shortcut_first_use_shown():
            cont = xbmcgui.Dialog().yesno(
                "TopZilla — Atajos de búsqueda",
                "Los atajos abren otro addon o comando de Kodi pasándole el "
                "título seleccionado.\n\n"
                "TopZilla no modifica ni copia el otro addon: solo lo invoca. El "
                "resultado depende por completo de ese addon.\n\n¿Continuar?",
                yeslabel="Continuar", nolabel="Cancelar")
            core_settings.mark_shortcut_first_use_shown()
            if not cont:
                xbmcplugin.endOfDirectory(h, cacheToDisc=False)
                return
        # Sustituye tokens. {query} = URL-encoded (para plugin:// y URLs).
        # {queryraw} = texto plano sin tocar (para RunScript, Notification...).
        # {tmdb_id} = id de TMDB del título (vacío si el resultado no tuvo match).
        # {mode} = 'movie'/'show' del item.
        cmd = cmd.replace('{query}', urllib.parse.quote(query, safe=''))
        cmd = cmd.replace('{queryraw}', query)
        # _th_id resuelve el id del ref cuando no llega por parámetro URL
        # (p. ej. atajos invocados desde el Modo Cine o el menú contextual).
        cmd = cmd.replace('{tmdb_id}', str(tmdb_id or _th_id or ''))
        cmd = cmd.replace('{mode}', mode or '')
        xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
        xbmc.executebuiltin(cmd)
        return

    elif accion == "debrid_search":
        import debrid_resolver as _dr
        r = _dr.get_resolver()
        if not r.is_authorized():
            xbmcgui.Dialog().notification("TopZilla", "No hay cuenta Debrid vinculada",
                                          xbmcgui.NOTIFICATION_WARNING, 3000)
            xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
            return
        bg = xbmcgui.DialogProgressBG()
        bg.create("TopZilla", "Buscando en tu nube Debrid…")
        items = None
        auth_err = False
        try:
            items = r.list_library()
        except _dr.DebridAuthError:
            auth_err = True
        except Exception as e:
            xbmc.log("[TopZilla] búsqueda nube: {0}".format(e), xbmc.LOGWARNING)
        finally:
            bg.close()
        if items is None:
            msg = ("Tu cuenta Debrid necesita reconectarse" if auth_err
                   else "No se pudo consultar tu nube Debrid")
            xbmcgui.Dialog().notification("TopZilla", msg, xbmcgui.NOTIFICATION_WARNING, 3500)
            xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
            return
        # Match por palabras (no substring crudo): el query trae espacios y los
        # nombres de la nube separadores (puntos/guiones). Pedimos que todas las
        # palabras del título estén presentes como palabras del nombre del archivo.
        _norm = lambda s: re.sub(r'[^a-z0-9]+', ' ', (s or '').lower()).strip()
        q_words = _norm(query).split()
        matches = [it for it in items
                   if it.get("ready") and q_words
                   and set(q_words) <= set(_norm(it.get("filename")).split())]
        if not matches:
            xbmcgui.Dialog().notification(
                "TopZilla", "Sin resultados en tu nube para '{0}'".format(query),
                xbmcgui.NOTIFICATION_INFO, 3000)
            xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
            return
        if len(matches) == 1:
            chosen = matches[0]
        else:
            labels = ["{0}  [{1:.2f} GB]".format(it.get("filename", "?"),
                                                 (it.get("size", 0) or 0) / 1e9) for it in matches]
            sel = xbmcgui.Dialog().select("Tu nube Debrid: '{0}'".format(query), labels)
            if sel < 0:
                xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
                return
            chosen = matches[sel]
        stream = None
        try:
            stream = r.resolve_library_item(chosen.get("id"))
        except Exception as e:
            xbmc.log("[TopZilla] resolver nube: {0}".format(e), xbmc.LOGWARNING)
        xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
        if not stream:
            xbmcgui.Dialog().notification("TopZilla", "No se pudo reproducir",
                                          xbmcgui.NOTIFICATION_WARNING, 3000)
            return
        li = xbmcgui.ListItem(path=stream)
        li.setContentLookup(False)
        name = chosen.get("filename") or ""
        if name:
            li.setInfo("video", {"title": name})
        xbmc.Player().play(stream, li)
        return

    else:
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)


# YouTube scraping (sin API key)

def _yt_fetch_html(url, timeout=15):
    import urllib.request, gzip, io
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "es-ES,es;q=0.9,en;q=0.8",
        "Accept-Encoding": "gzip, identity",
        "Cookie": "SOCS=CAI",
        "Sec-CH-UA": '"Chromium";v="138", "Google Chrome";v="138", "Not-A.Brand";v="99"',
        "Sec-CH-UA-Mobile": "?0",
        "Sec-CH-UA-Platform": '"Windows"',
        "Upgrade-Insecure-Requests": "1",
    }
    req = urllib.request.Request(url, headers=headers)
    resp = urllib.request.urlopen(req, timeout=timeout)
    raw = resp.read()
    if (resp.headers.get("Content-Encoding") or "").lower() == "gzip":
        try:
            raw = gzip.GzipFile(fileobj=io.BytesIO(raw)).read()
        except OSError:
            pass
    return raw.decode("utf-8", errors="replace")


def _yt_parse_initial_data(html):
    import json as _json
    m = re.search(r'var ytInitialData\s*=\s*(\{.*?\});\s*</script>', html, re.DOTALL)
    if not m:
        m = re.search(r'ytInitialData"\]\s*=\s*(\{.*?\});', html, re.DOTALL)
    if not m:
        return None
    try:
        return _json.loads(m.group(1))
    except (ValueError, TypeError):
        return None


def _yt_parse_video_renderer(vr):
    vid = vr.get("videoId", "")
    if not vid or len(vid) != 11:
        return None
    title = ""
    try:
        runs = vr.get("title", {}).get("runs", [])
        title = runs[0].get("text", "") if runs else vr.get("title", {}).get("simpleText", "")
    except (KeyError, TypeError, IndexError):
        pass
    dur = ""
    try:
        dur = vr.get("lengthText", {}).get("simpleText", "") or ""
    except (KeyError, TypeError):
        pass
    channel = ""
    try:
        chan_runs = vr.get("ownerText", {}).get("runs", [])
        channel = chan_runs[0].get("text", "") if chan_runs else ""
    except (KeyError, TypeError, IndexError):
        pass
    views = ""
    try:
        views = (vr.get("viewCountText", {}).get("simpleText", "")
                 or vr.get("shortViewCountText", {}).get("simpleText", "") or "")
    except (KeyError, TypeError):
        pass
    published = ""
    try:
        published = vr.get("publishedTimeText", {}).get("simpleText", "") or ""
    except (KeyError, TypeError):
        pass
    return {"vid": vid, "title": title or "Video", "duration": dur,
            "channel": channel, "views": views, "published": published}


def _yt_extract_videos(data):
    try:
        sections = data["contents"]["twoColumnSearchResultsRenderer"]["primaryContents"]["sectionListRenderer"]["contents"]
    except (KeyError, TypeError):
        return []
    results = []
    for section in sections or []:
        if not isinstance(section, dict):
            continue
        isr = section.get("itemSectionRenderer")
        if not isr:
            continue
        for item in isr.get("contents", []):
            if not isinstance(item, dict):
                continue
            vr = item.get("videoRenderer")
            if vr:
                parsed = _yt_parse_video_renderer(vr)
                if parsed:
                    results.append(parsed)
    return results


def _yt_fallback_parse(html):
    import json as _json
    results = []
    seen = set()
    pattern = re.compile(
        r'"videoRenderer":\{"videoId":"([^"]{11})".*?"title":\{"runs":\[\{"text":"([^"]+)"\}',
        re.DOTALL,
    )
    for m in pattern.finditer(html):
        vid = m.group(1)
        try:
            title = _json.loads('"' + m.group(2) + '"')
        except (ValueError, TypeError):
            title = m.group(2)
        if vid not in seen:
            seen.add(vid)
            results.append({"vid": vid, "title": title, "duration": "", "channel": "", "views": "", "published": ""})
        if len(results) >= 20:
            break
    return results


def _search_youtube_from_results(query):
    if not query:
        return
    if not xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)"):
        if xbmcgui.Dialog().yesno(
                "TopZilla",
                "El plugin de YouTube no está instalado.\n\n"
                "Instálalo desde el repositorio oficial de Kodi para reproducir los resultados.",
                yeslabel="Instalar", nolabel="Cancelar"):
            xbmc.executebuiltin("InstallAddon(plugin.video.youtube)")
        return
    import remote_input
    txt = remote_input.get_text_input('Buscar en YouTube', query).strip()
    if not txt:
        return
    xbmc.executebuiltin("Container.Update({0})".format(_u(action='yt_results', query=txt)))


_YT_CACHE_TTL = 6 * 3600


def _yt_cache_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    os.makedirs(profile, exist_ok=True)
    return os.path.join(profile, 'topzilla_yt_search_cache.json')


def _yt_cache_load():
    import json as _json
    import time as _time
    p = _yt_cache_path()
    if not os.path.exists(p):
        return {}
    try:
        with open(p, 'r', encoding='utf-8') as fh:
            data = _json.load(fh)
        if not isinstance(data, dict):
            return {}
        now = _time.time()
        return {k: v for k, v in data.items()
                if isinstance(v, dict) and (now - v.get('ts', 0)) < _YT_CACHE_TTL}
    except (OSError, ValueError):
        return {}


def _yt_cache_save(cache):
    import json as _json
    try:
        p = _yt_cache_path()
        tmp = p + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as fh:
            _json.dump(cache, fh, ensure_ascii=False)
        os.replace(tmp, p)
    except OSError as e:
        xbmc.log("[TopZilla] yt cache save: {0}".format(e), xbmc.LOGWARNING)


def _yt_native_search_results(query):
    import time as _time
    h = int(sys.argv[1])
    query = (query or "").strip()
    if not query:
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return

    cache = _yt_cache_load()
    cache_key = query.lower()
    entry = cache.get(cache_key)
    if entry and (_time.time() - entry.get('ts', 0)) < _YT_CACHE_TTL and entry.get('results'):
        results = entry['results']
    else:
        dp = xbmcgui.DialogProgress()
        dp.create("TopZilla", "Buscando en YouTube: {0}...".format(query))
        results = []
        try:
            encoded = urllib.parse.quote_plus(query)
            url = "https://www.youtube.com/results?search_query={0}".format(encoded)
            html = _yt_fetch_html(url)
            if dp.iscanceled():
                dp.close()
                xbmcplugin.endOfDirectory(h, succeeded=False)
                return
            dp.update(60)
            data = _yt_parse_initial_data(html)
            results = _yt_extract_videos(data) if data else []
            if not results:
                results = _yt_fallback_parse(html)
            dp.close()
        except (urllib.error.URLError, OSError, ValueError) as e:
            dp.close()
            xbmc.log("[TopZilla] Error buscando en YouTube: {0}".format(e), xbmc.LOGERROR)
            xbmcgui.Dialog().ok("TopZilla", "Error al buscar en YouTube:\n{0}".format(e))
            xbmcplugin.endOfDirectory(h, succeeded=False)
            return
        except Exception as e:
            dp.close()
            xbmc.log("[TopZilla] Error inesperado en YouTube: {0}".format(e), xbmc.LOGERROR)
            xbmcgui.Dialog().ok("TopZilla", "Error inesperado al buscar en YouTube:\n{0}".format(e))
            xbmcplugin.endOfDirectory(h, succeeded=False)
            return

        if results:
            cache[cache_key] = {'ts': _time.time(), 'results': results}
            _yt_cache_save(cache)

    if not results:
        xbmcgui.Dialog().ok("TopZilla", "No se encontraron resultados para:\n{0}".format(query))
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return

    xbmcplugin.setContent(h, 'videos')
    import yt_resolve
    _ytdlp_on = yt_resolve.ytdlp_enabled()
    for r in results:
        vid = r["vid"]
        title = r["title"]
        li = xbmcgui.ListItem(label=core_settings.apply_label(title))
        thumb = 'https://i.ytimg.com/vi/{0}/hqdefault.jpg'.format(vid)
        li.setArt({'icon': 'DefaultMusicVideos.png', 'thumb': thumb, 'poster': thumb, 'fanart': thumb})
        plot_lines = []
        if r.get("channel"):   plot_lines.append("Canal: {0}".format(r["channel"]))
        if r.get("duration"):  plot_lines.append("Duración: {0}".format(r["duration"]))
        if r.get("views"):     plot_lines.append("Vistas: {0}".format(r["views"]))
        if r.get("published"): plot_lines.append("Subido: {0}".format(r["published"]))
        li.setInfo('video', {'plot': "\n".join(plot_lines) or title, 'title': title, 'mediatype': 'video'})
        li.setProperty('IsPlayable', 'true')
        if _ytdlp_on:
            item_url = _u(action='yt_play', vid=vid)
        else:
            item_url = "plugin://plugin.video.youtube/play/?video_id={0}".format(vid)
        xbmcplugin.addDirectoryItem(handle=h, url=item_url, listitem=li, isFolder=False)

    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR yellow][B]Buscar otra cosa en YouTube...[/B][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultAddonsSearch.png', 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': 'Muestra hasta 20 resultados. Prueba términos más específicos si no encuentras lo que buscas.'})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='yt_results_kb'), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _yt_results_keyboard():
    import remote_input
    h = int(sys.argv[1])
    txt = remote_input.get_text_input('Buscar en YouTube').strip()
    if not txt:
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    xbmc.executebuiltin("Container.Update({0})".format(_u(action='yt_results', query=txt)))


def _yt_play_resolve(vid):
    """Resuelve un resultado de búsqueda de YouTube con yt-dlp y lo reproduce.
    Si yt-dlp falla, redirige al addon de YouTube como respaldo."""
    import yt_resolve
    h = int(sys.argv[1])
    url = yt_resolve.resolve_url(vid) if vid else ''
    if url:
        li = xbmcgui.ListItem(path=url)
        li.setContentLookup(False)
        if yt_resolve.is_hls(url):
            li.setMimeType('application/x-mpegURL')
    else:
        li = xbmcgui.ListItem(path='plugin://plugin.video.youtube/play/?video_id={0}'.format(vid))
    xbmcplugin.setResolvedUrl(h, True, li)


# Búsqueda nativa Dailymotion

def _dm_search_direct(q, extra_params=None):
    params = {
        "search": q,
        "fields": "id,title,owner.username,duration,thumbnail_360_url,thumbnail_720_url",
        "limit": 50,
    }
    if extra_params:
        params.update(extra_params)
    ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    for verify in (True, False):
        try:
            r = requests.get(
                "https://api.dailymotion.com/videos",
                params=params,
                headers={"User-Agent": ua},
                timeout=15,
                verify=verify,
            )
            return r.json().get("list", [])
        except Exception:
            continue
    return []


def _sr(q, extra_params=None):
    return _dm_search_direct(q, extra_params or None)


def _clean_title(t):
    if " : " in t:
        parts = t.split(" : ")
        t = parts[1] if len(parts[1]) > len(parts[0]) else parts[0]
    return t.strip()


def _gsr(q, rs, mode=""):
    if not rs:
        return []
    sc = []
    ql = q.lower().strip()
    qn = re.findall(r'(\d+)', ql)
    for r in rs:
        t = r.get("title", "").strip()
        tl = t.lower()
        if not t:
            continue
        s = difflib.SequenceMatcher(None, ql, tl).ratio()
        q_words = [w for w in ql.split() if len(w) > 3]
        if q_words:
            matches = sum(1 for w in q_words if w in tl)
            if matches == 0:
                s -= 1.0
            elif matches < len(q_words):
                s -= 0.1
        if ql in tl:
            s += 0.35
        words_q = set(ql.split())
        words_t = set(tl.split())
        common = words_q.intersection(words_t)
        if common:
            s += (len(common) / len(words_q)) * 0.2
        tn = re.findall(r'(\d+)', tl)
        if qn and tn:
            if qn[-1] in tn:
                s += 0.4
            if set(qn).issubset(set(tn)):
                s += 0.1
        du = r.get("duration", 0)
        try:
            du = int(du)
        except (ValueError, TypeError):
            du = 0
        if s > 0.3:
            if du > 600:
                s += 0.6
            elif du > 300:
                s += 0.2
            if du < 180:
                s -= 0.1
        if any(w in tl for w in ["español", "castellano", "spanish"]):
            s += 0.15
        if mode == "movie":
            if any(w in tl for w in ["trailer", "avance", "entrevista", "making", "detras", "clip", "promo"]):
                s -= 0.5
            if any(w in tl for w in ["pelicula", "completa", "movie", "film"]):
                s += 0.2
        sc.append((min(s, 1.0), r))
    sc.sort(key=lambda x: x[0], reverse=True)
    return sc


def _lfd(q, ot, mode="", extra_params=None):
    cq = _clean_title(q)
    rs = []
    if mode == "movie":
        for v in [
            "{0} pelicula completa castellano".format(cq),
            "{0} pelicula completa español".format(cq),
            "{0} pelicula completa".format(cq),
            "{0} completa español".format(cq),
            "{0} castellano".format(cq),
            cq,
        ]:
            rs = _sr(v, extra_params)
            if rs:
                break
    else:
        rs = _sr(cq, extra_params)
        if not rs and cq != q:
            rs = _sr(q, extra_params)
    if not rs:
        kw = " ".join([w for w in re.findall(r'\w+', cq) if len(w) > 3])
        if kw:
            rs = _sr(kw, extra_params)

    h = int(sys.argv[1])
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()
    li_alt = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR yellow][B]¿No es lo que buscas? Editar o buscar en otro sitio[/B][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li_alt.setArt({'icon': 'DefaultAddonsSearch.png', 'fanart': core_settings.addon_fanart()})
    li_alt.setInfo('video', {'plot': "Edita la búsqueda o prueba en YouTube u otro addon."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="search_alt_prompt", q=cq, ot=ot), listitem=li_alt, isFolder=False)

    if not rs:
        xbmcgui.Dialog().notification("TopZilla", "No se encontraron resultados en Dailymotion", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
        return

    sr = _gsr(cq, rs, mode)[:25]
    if not sr:
        if xbmcgui.Dialog().yesno("TopZilla", "No se encontraron coincidencias relevantes.\n\n¿Quieres editar las palabras clave y probar otra vez?"):
            import remote_input
            new_q = remote_input.get_text_input('Editar Búsqueda', q)
            if new_q:
                xbmc.executebuiltin("Container.Update({0})".format(_u(action='lfr', q=new_q, ot=ot)))
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
        return

    for sc, v in sr:
        vt = v.get("title", "Video")
        vi = v.get("id")
        ow = v.get("owner.username", "Unknown")
        du = v.get("duration", 0)
        try:
            du = int(du)
        except (ValueError, TypeError):
            du = 0
        dth = v.get("thumbnail_720_url") or v.get("thumbnail_360_url") or ot
        lb = vt if mode == "movie" else "{0} ({1}% match)".format(vt, int(sc * 100))
        li = xbmcgui.ListItem(label=core_settings.apply_label(lb))
        li.setArt({'thumb': dth, 'icon': dth, 'fanart': core_settings.addon_fanart()})
        li.setInfo('video', {'title': vt, 'plot': "Subido por: {0}\nDuración: {1}s".format(ow, du), 'duration': du})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="pv", vid=vi, title=urllib.parse.quote(vt)),
            listitem=li,
            isFolder=False,
        )
    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


_UA_DM_DESKTOP = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36"
)
_HEADERS_DM_DESKTOP = {
    "User-Agent": _UA_DM_DESKTOP,
    "Origin": "https://www.dailymotion.com",
    "Referer": "https://www.dailymotion.com/",
}


def _fetch_hls_variants(master_url, headers=None):
    """Devuelve las variantes del master playlist HLS, ordenadas de mayor a menor bitrate."""
    from urllib.parse import urljoin
    variants = []
    try:
        r = requests.get(master_url, headers=headers or {}, timeout=15)
        if r.status_code != 200:
            return variants
        current_label = "unknown"
        current_bw = 0
        expecting_url = False
        for line in r.text.strip().splitlines():
            line = line.strip()
            if not line:
                continue
            if line.startswith('#EXT-X-STREAM-INF'):
                res_match = re.search(r'RESOLUTION=(\d+x\d+)', line)
                bw_match = re.search(r'BANDWIDTH=(\d+)', line)
                current_label = res_match.group(1) if res_match else "unknown"
                current_bw = int(bw_match.group(1)) if bw_match else 0
                expecting_url = True
            elif expecting_url and not line.startswith('#'):
                stream_url = line if line.startswith('http') else urljoin(master_url, line)
                variants.append({'label': current_label, 'url': stream_url, 'bandwidth': current_bw})
                expecting_url = False
        variants.sort(key=lambda x: x.get('bandwidth', 0), reverse=True)
    except (requests.RequestException, ValueError):
        pass
    return variants


def _dm_play_direct(vid, max_quality=1080):
    """Resolución directa via API de metadatos. URLs limpias sin headers pipe.
    Ideal para Android/Linux donde el reproductor nativo no acepta pipe headers.
    Devuelve {url, mime, subs} o None."""
    if not isinstance(vid, str) or not vid.strip():
        return None
    try:
        meta_url = "https://www.dailymotion.com/player/metadata/video/{0}".format(urllib.parse.quote(vid.strip()))
        r = requests.get(meta_url, headers=_HEADERS_DM_DESKTOP, timeout=15)
        if r.status_code != 200:
            xbmc.log("[TopZilla] _dm_play_direct HTTP: {0}".format(r.status_code), xbmc.LOGWARNING)
            return None
        data = r.json()
        if data.get("error"):
            xbmc.log("[TopZilla] DM API error: {0}".format(data["error"].get("message", "")), xbmc.LOGWARNING)
            return None

        qualities = data.get("qualities", {})
        subtitles = []
        subs_data = data.get("subtitles", {})
        if isinstance(subs_data, dict):
            for sub_list in subs_data.values():
                if isinstance(sub_list, list):
                    for sub in sub_list:
                        if isinstance(sub, dict) and sub.get("url"):
                            subtitles.append(sub["url"])

        # MP4 directo: mejor compatibilidad en Android que HLS.
        best_mp4, best_res = None, 0
        for res_key, formats in qualities.items():
            if res_key == "auto":
                continue
            try:
                res_val = int(res_key)
            except (ValueError, TypeError):
                continue
            if res_val > max_quality:
                continue
            for fmt in formats:
                if isinstance(fmt, dict) and fmt.get("type") == "video/mp4" and res_val > best_res:
                    best_mp4 = fmt.get("url")
                    best_res = res_val
        if best_mp4:
            xbmc.log("[TopZilla] _dm_play_direct MP4 {0}p".format(best_res), xbmc.LOGINFO)
            return {"url": best_mp4, "mime": "video/mp4", "subs": subtitles, "headers": _HEADERS_DM_DESKTOP}

        # Fallback HLS: _pv detecta mime mpegURL y configura inputstream.adaptive
        # con headers, lo que evita 403 al pedir segmentos.
        hls_url = None
        if "auto" in qualities:
            for item in qualities["auto"]:
                if isinstance(item, dict) and item.get("type") == "application/x-mpegURL":
                    hls_url = item.get("url")
                    break
        if hls_url:
            variants = _fetch_hls_variants(hls_url, headers=_HEADERS_DM_DESKTOP)
            if variants:
                filtered = []
                for v in variants:
                    label = v.get("label", "")
                    try:
                        height = int(label.split("x")[1].split(" ")[0]) if "x" in label else 0
                    except (ValueError, IndexError):
                        height = 0
                    if 0 < height <= max_quality:
                        filtered.append(v)
                target = filtered[0] if filtered else variants[-1]
                xbmc.log("[TopZilla] _dm_play_direct HLS variant", xbmc.LOGINFO)
                return {"url": target["url"], "mime": "application/x-mpegURL", "subs": subtitles, "headers": _HEADERS_DM_DESKTOP}
            xbmc.log("[TopZilla] _dm_play_direct HLS master", xbmc.LOGINFO)
            return {"url": hls_url, "mime": "application/x-mpegURL", "subs": subtitles, "headers": _HEADERS_DM_DESKTOP}
    except (requests.RequestException, ValueError) as exc:
        xbmc.log("[TopZilla] _dm_play_direct error: {0}".format(exc), xbmc.LOGERROR)
    return None


_DM_SYSPY_SCRIPT = r'''
import sys, json, re
try:
    import requests
    _GET = lambda u, h: requests.get(u, headers=h, timeout=15)
    _STATUS = lambda r: r.status_code
    _TEXT = lambda r: r.text
except ImportError:
    import urllib.request
    def _GET(u, h):
        return urllib.request.urlopen(urllib.request.Request(u, headers=h), timeout=15)
    _STATUS = lambda r: r.getcode()
    _TEXT = lambda r: r.read().decode()
vid = sys.argv[1]
hdr = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36",
       "Origin":"https://www.dailymotion.com","Referer":"https://www.dailymotion.com/"}
r = _GET("https://www.dailymotion.com/player/metadata/video/"+vid, hdr)
if _STATUS(r) != 200:
    sys.exit(1)
data = json.loads(_TEXT(r))
if data.get("error"):
    sys.exit(2)
hls = ""
for it in data.get("qualities",{}).get("auto",[]):
    if it.get("type") == "application/x-mpegURL":
        hls = it.get("url",""); break
if not hls:
    sys.exit(3)
r2 = _GET(hls, hdr)
if _STATUS(r2) != 200:
    sys.exit(4)
master = _TEXT(r2)
m = re.findall(r"NAME=\"(\d+)\"[^\n]*\n([^\n]+)", master)
m.sort(key=lambda x: int(x[0]), reverse=True)
url = (m[0][1] if m else hls).split("#cell")[0]
print(json.dumps({"url": url}))
'''


def _pv(vid, title=""):
    """Reproduce un vídeo de Dailymotion.
    Cascada Windows: system-python -> yt-dlp -> directo -> dm_gujal -> navegador.
    Cascada Android: directo -> dm_gujal -> navegador."""
    h = int(sys.argv[1])
    # El vid llega por URL de plugin: las IDs reales de Dailymotion son alfanuméricas.
    # Validar evita que un vid con '/', '?' o '#' apunte a un endpoint inesperado.
    if not re.match(r'^[A-Za-z0-9]{1,16}$', vid or ''):
        xbmc.log("[TopZilla] _pv: vid inválido: {0!r}".format(vid), xbmc.LOGWARNING)
        xbmcgui.Dialog().notification(
            'TopZilla', 'Identificador de vídeo no válido',
            xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    dm_web_url = "https://www.dailymotion.com/video/{0}".format(vid)
    _is_windows = xbmc.getCondVisibility("System.Platform.Windows")

    _python_missing = False
    _ytdlp_missing = False

    if _is_windows:
        try:
            import subprocess, json as _json
            xbmcgui.Dialog().notification("TopZilla", "Resolviendo con Python sistema...", xbmcgui.NOTIFICATION_INFO, 2000)
            _proc = subprocess.run(
                ['python', '-c', _DM_SYSPY_SCRIPT, vid],
                capture_output=True, text=True, timeout=20,
                creationflags=0x08000000,
            )
            if _proc.returncode == 0 and _proc.stdout.strip():
                stream_url = _json.loads(_proc.stdout).get('url', '')
                if stream_url:
                    xbmc.log("[TopZilla] system-python OK", xbmc.LOGINFO)
                    li = xbmcgui.ListItem(label=title or vid, path=stream_url)
                    li.setMimeType('application/x-mpegURL')
                    li.setProperty('IsPlayable', 'true')
                    li.setContentLookup(False)
                    xbmcplugin.setResolvedUrl(h, True, li)
                    return
            xbmc.log("[TopZilla] system-python rc={0} err={1}".format(
                _proc.returncode, _proc.stderr[:200] if _proc.stderr else ''), xbmc.LOGWARNING)
        except FileNotFoundError:
            _python_missing = True
            xbmc.log("[TopZilla] system-python: python no encontrado en PATH", xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log("[TopZilla] system-python fallido: {0}".format(e), xbmc.LOGWARNING)

    # Windows: yt-dlp vía subprocess cuando el script inline falla.
    # yt-dlp cubre más casos del extractor (cookies, geo-bypass, etc.).
    if _is_windows and not _python_missing:
        try:
            import subprocess, json as _json
            xbmcgui.Dialog().notification("TopZilla", "Resolviendo con yt-dlp...", xbmcgui.NOTIFICATION_INFO, 2000)
            _proc = subprocess.run(
                ['python', '-m', 'yt_dlp', '--dump-json', '--no-download',
                 '--format', 'best[ext=mp4]/best', '--no-playlist', dm_web_url],
                capture_output=True, text=True, timeout=30,
                creationflags=0x08000000,
            )
            if _proc.returncode == 0 and _proc.stdout.strip():
                stream_url = _json.loads(_proc.stdout).get('url', '')
                if stream_url:
                    xbmc.log("[TopZilla] yt-dlp OK", xbmc.LOGINFO)
                    li = xbmcgui.ListItem(label=title or vid, path=stream_url)
                    li.setProperty('IsPlayable', 'true')
                    li.setContentLookup(False)
                    xbmcplugin.setResolvedUrl(h, True, li)
                    return
            _err = (_proc.stderr or '') + (_proc.stdout or '')
            if 'No module named' in _err and 'yt_dlp' in _err:
                _ytdlp_missing = True
            xbmc.log("[TopZilla] yt-dlp sin URL", xbmc.LOGWARNING)
        except FileNotFoundError:
            _python_missing = True
        except Exception as e:
            xbmc.log("[TopZilla] yt-dlp fallido: {0}".format(e), xbmc.LOGWARNING)

    if _is_windows and (_python_missing or _ytdlp_missing):
        if _python_missing:
            _msg = "Instala Python y yt-dlp para reproducción fiable en Windows"
        else:
            _msg = "Instala yt-dlp (pip install yt-dlp) para reproducción más fiable"
        xbmcgui.Dialog().notification("TopZilla - Dailymotion", _msg, xbmcgui.NOTIFICATION_INFO, 6000)

    # API directa. Si HLS -> inputstream.adaptive con headers
    # (Kodi propaga UA/Origin/Referer al manifiesto y a los segmentos).
    result = _dm_play_direct(vid)
    if result:
        url_val = result.get("url")
        if isinstance(url_val, str) and url_val:
            mime_val = result.get("mime") or "application/x-mpegURL"
            subs_val = result.get("subs")
            headers_dict = result.get("headers") or {}
            is_hls = "mpegURL" in mime_val
            header_str = ""
            if isinstance(headers_dict, dict) and headers_dict:
                header_str = "&".join(
                    "{0}={1}".format(k, urllib.parse.quote(str(v)))
                    for k, v in headers_dict.items()
                )

            stream_url = url_val
            if not is_hls and header_str:
                stream_url = "{0}|{1}".format(url_val, header_str)

            li = xbmcgui.ListItem(label=title or vid, path=stream_url)
            li.setMimeType(mime_val)
            li.setContentLookup(False)
            if is_hls and header_str:
                li.setProperty("inputstream", "inputstream.adaptive")
                li.setProperty("inputstream.adaptive.manifest_type", "hls")
                li.setProperty("inputstream.adaptive.manifest_headers", header_str)
                li.setProperty("inputstream.adaptive.stream_headers", header_str)
            if isinstance(subs_val, list) and subs_val:
                li.setSubtitles(subs_val)
            xbmc.log("[TopZilla] DM: API directa OK", xbmc.LOGINFO)
            xbmcplugin.setResolvedUrl(h, True, li)
            return

    xbmc.log("[TopZilla] DM: API directa sin stream, probando dm_gujal", xbmc.LOGWARNING)
    # dm_gujal (extreme → basic, headers en pipe).
    try:
        import dm_gujal
        url, subs, mime = dm_gujal.play_dm_extreme(vid)
        if not url:
            url, mime = dm_gujal.play_dm_basic(vid)
            subs = []
        if url:
            li = xbmcgui.ListItem(label=title or vid, path=url)
            li.setMimeType(mime or 'application/x-mpegURL')
            li.setContentLookup(False)
            if subs:
                li.setSubtitles(subs)
            xbmc.log("[TopZilla] DM: dm_gujal OK", xbmc.LOGINFO)
            xbmcplugin.setResolvedUrl(h, True, li)
            return
    except Exception as e:
        xbmc.log("[TopZilla] DM: dm_gujal fallido: {0}".format(e), xbmc.LOGWARNING)

    xbmc.log("[TopZilla] DM: agotadas todas las vías para vid={0}, ofreciendo navegador".format(vid),
             xbmc.LOGWARNING)
    # Último recurso: abrir el vídeo en el navegador web.
    if xbmcgui.Dialog().yesno(
        "TopZilla - Dailymotion",
        "No se pudo reproducir en Kodi.\n\n"
        "¿Quieres abrir el vídeo en el navegador web?",
        yeslabel="Navegador", nolabel="Cancelar",
    ):
        try:
            import webbrowser
            webbrowser.open(dm_web_url)
            xbmcgui.Dialog().notification("TopZilla", "Enlace enviado al navegador", xbmcgui.NOTIFICATION_INFO, 2000)
        except Exception:
            xbmcgui.Dialog().ok("TopZilla", "Abre esta URL en tu navegador:\n\n{0}".format(dm_web_url))
    else:
        xbmcgui.Dialog().notification("TopZilla", "No se encontró stream válido", xbmcgui.NOTIFICATION_ERROR)
    try:
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
    except Exception:
        pass


def _configure_cinema_rows():
    """Elegir qué filas se muestran en el Modo Cine (películas y series)."""
    import pelis_flix
    dlg = xbmcgui.Dialog()
    sel0 = dlg.select("Configurar filas del Modo Cine",
                      ["Películas (Cine)", "Series", "[Restaurar filas por defecto]"])
    if sel0 < 0:
        return
    if sel0 == 2:
        if dlg.yesno("Modo Cine", "¿Restaurar las filas por defecto en Cine y Series?"):
            core_settings.reset_flix_rows()
            dlg.notification("TopZilla", "Filas restauradas", xbmcgui.NOTIFICATION_INFO)
        return

    mode = pelis_flix.MODE_CINE if sel0 == 0 else pelis_flix.MODE_SERIES
    catalog = pelis_flix.catalog_for(mode)
    active = set(core_settings.load_flix_rows(mode) or pelis_flix.default_ids(catalog))
    labels = [r['title'] for r in catalog]
    preselect = [i for i, r in enumerate(catalog) if r['id'] in active]
    sel = dlg.multiselect("Filas a mostrar", labels, preselect=preselect)
    if sel is None:
        return
    if not sel:
        dlg.notification("TopZilla", "Deja al menos una fila activa", xbmcgui.NOTIFICATION_WARNING)
        return
    # Conserva el orden ya personalizado de las filas que siguen activas; las recién
    # activadas se añaden al final en orden de catálogo. Así no se pierde un reordenado
    # previo al cambiar la visibilidad (multiselect devuelve siempre orden de catálogo).
    selected = {catalog[i]['id'] for i in sel}
    ordered, seen = [], set()
    for cid in (core_settings.load_flix_rows(mode) or []):
        if cid in selected and cid not in seen:
            ordered.append(cid)
            seen.add(cid)
    for i in sel:
        cid = catalog[i]['id']
        if cid not in seen:
            ordered.append(cid)
            seen.add(cid)
    core_settings.save_flix_rows(mode, ordered)
    dlg.notification("TopZilla", "Filas actualizadas", xbmcgui.NOTIFICATION_INFO)


def _reorder_cinema_rows():
    """Cambiar el orden de las filas activas del Modo Cine (películas y series).
    Solo reordena; qué filas se muestran se decide en 'Configurar filas'."""
    import pelis_flix
    dlg = xbmcgui.Dialog()
    sel0 = dlg.select("Ordenar filas del Modo Cine", ["Películas (Cine)", "Series"])
    if sel0 < 0:
        return

    mode = pelis_flix.MODE_CINE if sel0 == 0 else pelis_flix.MODE_SERIES
    catalog = pelis_flix.catalog_for(mode)
    by_id = {r['id']: r for r in catalog}
    order = [i for i in (core_settings.load_flix_rows(mode) or pelis_flix.default_ids(catalog)) if i in by_id]
    if not order:
        order = pelis_flix.default_ids(catalog)
    if len(order) < 2:
        dlg.notification("TopZilla", "Activa al menos 2 filas en 'Configurar filas' para reordenarlas",
                         xbmcgui.NOTIFICATION_INFO, 4000)
        return

    while True:
        labels = []
        for i, rid in enumerate(order):
            arrows = ''
            if i > 0:
                arrows += '↑ '
            if i < len(order) - 1:
                arrows += '↓ '
            labels.append(f"{arrows}{by_id[rid]['title']}")
        reset_pos = len(labels)
        labels.append("[COLOR orange]Restaurar orden por defecto[/COLOR]")

        sel = dlg.select("Ordenar filas (se guarda al instante)", labels)
        if sel < 0:
            return
        if sel == reset_pos:
            if dlg.yesno("TopZilla", "¿Restaurar el orden por defecto de las filas?"):
                # Reordena las filas activas al orden de catálogo, sin tocar su visibilidad.
                order = [r['id'] for r in catalog if r['id'] in set(order)]
                core_settings.save_flix_rows(mode, order)
                dlg.notification("TopZilla", "Orden restaurado", xbmcgui.NOTIFICATION_INFO, 1500)
            continue

        opts = []
        if sel > 0:
            opts.append(('up',  '↑ Subir'))
            opts.append(('top', '↑ Subir al principio'))
        if sel < len(order) - 1:
            opts.append(('down',   '↓ Bajar'))
            opts.append(('bottom', '↓ Bajar al final'))
        opts.append(('cancel', 'Cancelar'))
        choice = dlg.select(f"Mover \"{by_id[order[sel]]['title']}\"", [o[1] for o in opts])
        if choice < 0 or opts[choice][0] == 'cancel':
            continue
        act = opts[choice][0]
        if act == 'up':
            order[sel - 1], order[sel] = order[sel], order[sel - 1]
        elif act == 'down':
            order[sel], order[sel + 1] = order[sel + 1], order[sel]
        elif act == 'top':
            order.insert(0, order.pop(sel))
        elif act == 'bottom':
            order.append(order.pop(sel))
        core_settings.save_flix_rows(mode, order)


_TRAILER_HELP = (
    "[B]Tráiler en el Modo Cine[/B]\n"
    "Al pasar unos segundos sobre una película se reproduce su tráiler de YouTube en la zona del "
    "fanart. Requiere el addon de YouTube. En Android puede saltar a pantalla completa.\n\n"
    "[B]Tiempo hasta reproducir[/B]\n"
    "Segundos quieto sobre una ficha antes de lanzar el tráiler. Subirlo (8-15s) reduce cuántos "
    "tráilers se abren al navegar y, con ello, los cuelgues intermitentes.\n\n"
    "[B]Idioma del tráiler[/B]\n"
    "Español o Inglés. En inglés casi siempre está el tráiler oficial; en español puede no haber, "
    "y en ese caso se usa el inglés como respaldo.\n\n"
    "[B]Indicador de carga (spinner)[/B]\n"
    "Oculto: cierra el círculo de carga que oscurece la pantalla mientras YouTube prepara el "
    "vídeo. Puede parpadear o no funcionar igual en todos los dispositivos."
)


def _trailer_config():
    """Submenú del comportamiento del tráiler (activar / reproducción / idioma / spinner)."""
    cfg = core_settings.load_trailer_config()
    while True:
        rows = []
        if cfg['enabled']:
            rows.append(("enabled", "Tráiler: [COLOR green]ACTIVADO[/COLOR]"))
            rows.append(("hover", "   Tiempo hasta reproducir: [COLOR cyan]{0}s[/COLOR]".format(cfg['hover_s'])))
            lang_lbl = "Español" if cfg['lang'] == 'es-ES' else "Inglés (oficial)"
            rows.append(("lang", "   Idioma del tráiler: [COLOR cyan]{0}[/COLOR]".format(lang_lbl)))
            spin = ("[COLOR cyan]OCULTO (truco)[/COLOR]" if cfg['hide_busy']
                    else "[COLOR grey]VISIBLE[/COLOR]")
            rows.append(("hide_busy", "   Spinner al cargar: " + spin))
            notify = ("[COLOR green]ACTIVADO[/COLOR]" if cfg['notify']
                      else "[COLOR grey]DESACTIVADO[/COLOR]")
            rows.append(("notify", "   Aviso al reproducir: " + notify))
        else:
            rows.append(("enabled", "Tráiler: [COLOR grey]DESACTIVADO[/COLOR]"))
        rows.append(("help", "[COLOR blue]Ver ayuda de los modos[/COLOR]"))
        rows.append(("close", "[ Cerrar ]"))

        sel = xbmcgui.Dialog().select("Comportamiento del tráiler (YouTube)", [r[1] for r in rows])
        if sel < 0:
            break
        key = rows[sel][0]
        if key == "close":
            break
        if key == "help":
            xbmcgui.Dialog().textviewer("Tráiler del Modo Cine", _TRAILER_HELP)
            continue
        if key == "enabled":
            cfg['enabled'] = not cfg['enabled']
        elif key == "hide_busy":
            cfg['hide_busy'] = not cfg['hide_busy']
        elif key == "notify":
            cfg['notify'] = not cfg['notify']
        elif key == "hover":
            opts = [2, 3, 5, 8, 10, 15]
            labels = ["{0} segundos".format(o) + ("  (más espera = menos cuelgues)" if o >= 8 else "") for o in opts]
            s = xbmcgui.Dialog().select("Segundos sobre una ficha antes de reproducir", labels)
            if s >= 0:
                cfg['hover_s'] = opts[s]
        elif key == "lang":
            cfg['lang'] = 'es-ES' if cfg['lang'] == 'en-US' else 'en-US'
        core_settings.save_trailer_config(cfg)
    xbmc.executebuiltin("Container.Refresh")


_AUTOSTART_DELAY_LABELS = ['Sin espera', '5 seg', '10 seg', '15 seg', '30 seg', '1 min']

# Prefijos de addons que no tiene sentido lanzar como autostart
_AUTOSTART_SKIP_PREFIXES = (
    'xbmc.', 'kodi.', 'service.', 'skin.', 'resource.',
    'script.module.', 'metadata.', 'inputstream.', 'pvr.',
)

def _get_launchable_addons():
    try:
        resp = json.loads(xbmc.executeJSONRPC(json.dumps({
            'jsonrpc': '2.0', 'id': 1,
            'method': 'Addons.GetAddons',
            'params': {'enabled': True}
        })))
    except Exception:
        return []
    addons = (resp.get('result') or {}).get('addons') or []
    result = [
        (a.get('name', a['addonid']), a['addonid'])
        for a in addons
        if not any(a['addonid'].startswith(p) for p in _AUTOSTART_SKIP_PREFIXES)
        and a['addonid'] != 'plugin.video.topzilla'
    ]
    result.sort(key=lambda x: x[0].lower())
    return result

def _autostart_delay_label(raw):
    try:
        idx = int(raw)
        return _AUTOSTART_DELAY_LABELS[idx] if 0 <= idx < len(_AUTOSTART_DELAY_LABELS) else 'Sin espera'
    except (ValueError, TypeError):
        return raw if raw in _AUTOSTART_DELAY_LABELS else 'Sin espera'

def _autostart_menu():
    h = int(sys.argv[1])
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()
    addon = xbmcaddon.Addon()
    _mp = os.path.join(addon.getAddonInfo('path'), 'resources', 'media')
    def _ico(name, fallback):
        p = os.path.join(_mp, name)
        return p if os.path.isfile(p) else fallback
    for i in range(1, 4):
        enabled = addon.getSetting(f'autostart_{i}_enabled') == 'true'
        addon_id = addon.getSetting(f'autostart_{i}_id').strip()
        delay_label = _autostart_delay_label(addon.getSetting(f'autostart_{i}_delay'))

        if enabled and addon_id:
            nombre = addon_id
            try:
                nombre = xbmcaddon.Addon(addon_id).getAddonInfo('name')
            except RuntimeError:
                pass
            label = f"Slot {i}: [COLOR green]{nombre}[/COLOR]  ({delay_label})"
            plot = f"Addon: {nombre}\nID: {addon_id}\nRetardo: {delay_label}\n\n[I]Pulsa para editar o desactivar.[/I]"
        else:
            label = f"Slot {i}: [COLOR grey]Sin configurar[/COLOR]"
            plot = "Slot vacío. Pulsa para configurar un addon que se abrirá automáticamente al arrancar Kodi."

        li = xbmcgui.ListItem(label=core_settings.apply_label(label, bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': _ico('adv_autostart.png', 'DefaultAddonService.png'), 'fanart': core_settings.addon_fanart()})
        li.setInfo('video', {'plot': plot})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="autostart_config_slot", slot=i), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)

def _autostart_config_slot(slot):
    addon = xbmcaddon.Addon()
    addon_id = addon.getSetting(f'autostart_{slot}_id').strip()
    enabled = addon.getSetting(f'autostart_{slot}_enabled') == 'true'
    delay_label = _autostart_delay_label(addon.getSetting(f'autostart_{slot}_delay'))
    delay_idx = next((i for i, l in enumerate(_AUTOSTART_DELAY_LABELS) if l == delay_label), 0)

    nombre = addon_id
    if addon_id:
        try:
            nombre = xbmcaddon.Addon(addon_id).getAddonInfo('name')
        except RuntimeError:
            pass

    if enabled and addon_id:
        # Slot activo: mostrar info real de lo que va a pasar y opciones concretas
        delay_txt = f'después de {delay_label}' if delay_label != 'Sin espera' else 'en cuanto Kodi arranque'
        sel = xbmcgui.Dialog().select(
            f'Slot {slot}: {nombre} se abre {delay_txt}',
            ['Cambiar addon', 'Cambiar retardo', 'Desactivar este slot']
        )
        if sel < 0:
            return
        if sel == 2:
            addon.setSetting(f'autostart_{slot}_enabled', 'false')
            xbmcgui.Dialog().notification("TopZilla", f"Slot {slot} desactivado", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
            return
        if sel == 1:
            idx = xbmcgui.Dialog().select("Retardo antes de lanzar", _AUTOSTART_DELAY_LABELS, preselect=delay_idx)
            if idx < 0:
                return
            addon.setSetting(f'autostart_{slot}_delay', _AUTOSTART_DELAY_LABELS[idx])
            xbmcgui.Dialog().notification("TopZilla", f"Retardo: {_AUTOSTART_DELAY_LABELS[idx]}", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
            return
        # sel == 0: cambiar addon → flujo de picker completo abajo

    # Flujo completo: slot vacío/desactivado, o "Cambiar addon"
    addons_lista = _get_launchable_addons()
    if not addons_lista:
        xbmcgui.Dialog().notification("TopZilla", "No se encontraron addons instalados", xbmcgui.NOTIFICATION_WARNING)
        xbmc.executebuiltin("Container.Refresh")
        return

    names = [f"{name}  [COLOR grey]({aid})[/COLOR]" for name, aid in addons_lista]
    presel = next((i for i, (_, aid) in enumerate(addons_lista) if aid == addon_id), -1)
    sel_addon = xbmcgui.Dialog().select("Seleccionar addon a lanzar al arrancar", names, preselect=presel)
    if sel_addon < 0:
        return

    nuevo_id = addons_lista[sel_addon][1]
    nuevo_nombre = addons_lista[sel_addon][0]

    idx = xbmcgui.Dialog().select("Retardo antes de lanzar", _AUTOSTART_DELAY_LABELS, preselect=delay_idx)
    nuevo_delay = _AUTOSTART_DELAY_LABELS[idx] if idx >= 0 else delay_label

    # Guardar todo de una vez solo cuando se han completado ambas selecciones
    addon.setSetting(f'autostart_{slot}_enabled', 'true')
    addon.setSetting(f'autostart_{slot}_id', nuevo_id)
    addon.setSetting(f'autostart_{slot}_delay', nuevo_delay)

    xbmcgui.Dialog().notification("TopZilla", f"Slot {slot}: {nuevo_nombre}", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _get_kodi_favourites():
    # El texto de cada <favourite> es el builtin exacto que Kodi ejecuta
    # (RunAddon(...), ActivateWindow(...), PlayMedia(...)). Lo leemos tal cual
    # en vez de reconstruirlo desde JSON-RPC, que es ambiguo para los plugin://.
    ruta = xbmcvfs.translatePath('special://profile/favourites.xml')
    try:
        root = ET.parse(ruta).getroot()
    except (OSError, ET.ParseError):
        # No existe (aún no hay favoritos), ilegible, o XML corrupto.
        return []
    favs = []
    for elem in root.findall('favourite'):
        cmd = (elem.text or '').strip()
        name = elem.get('name') or cmd
        if cmd:
            favs.append((name, cmd, elem.get('thumb') or ''))
    return favs

def _autofav_menu():
    h = int(sys.argv[1])
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()
    addon = xbmcaddon.Addon()
    _mp = os.path.join(addon.getAddonInfo('path'), 'resources', 'media')
    def _ico(name, fallback):
        p = os.path.join(_mp, name)
        return p if os.path.isfile(p) else fallback
    for i in range(1, 4):
        enabled = addon.getSetting(f'autofav_{i}_enabled') == 'true'
        titulo = addon.getSetting(f'autofav_{i}_title').strip()
        delay_label = _autostart_delay_label(addon.getSetting(f'autofav_{i}_delay'))

        if enabled and titulo:
            label = f"Favorito {i}: [COLOR green]{titulo}[/COLOR]  ({delay_label})"
            plot = f"Favorito: {titulo}\nRetardo: {delay_label}\n\n[I]Pulsa para editar o desactivar.[/I]"
        else:
            label = f"Favorito {i}: [COLOR grey]Sin configurar[/COLOR]"
            plot = "Slot vacío. Pulsa para elegir un favorito de Kodi que se abrirá automáticamente al arrancar."

        li = xbmcgui.ListItem(label=core_settings.apply_label(label, bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': _ico('adv_autostart.png', 'DefaultAddonService.png'), 'fanart': core_settings.addon_fanart()})
        li.setInfo('video', {'plot': plot})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="autofav_config_slot", slot=i), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)

def _autofav_config_slot(slot):
    addon = xbmcaddon.Addon()
    titulo = addon.getSetting(f'autofav_{slot}_title').strip()
    enabled = addon.getSetting(f'autofav_{slot}_enabled') == 'true'
    delay_label = _autostart_delay_label(addon.getSetting(f'autofav_{slot}_delay'))
    delay_idx = next((i for i, l in enumerate(_AUTOSTART_DELAY_LABELS) if l == delay_label), 0)

    if enabled and titulo:
        delay_txt = f'después de {delay_label}' if delay_label != 'Sin espera' else 'en cuanto Kodi arranque'
        sel = xbmcgui.Dialog().select(
            f'Favorito {slot}: {titulo} se abre {delay_txt}',
            ['Cambiar favorito', 'Cambiar retardo', 'Desactivar este slot']
        )
        if sel < 0:
            return
        if sel == 2:
            addon.setSetting(f'autofav_{slot}_enabled', 'false')
            xbmcgui.Dialog().notification("TopZilla", f"Favorito {slot} desactivado", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
            return
        if sel == 1:
            idx = xbmcgui.Dialog().select("Retardo antes de lanzar", _AUTOSTART_DELAY_LABELS, preselect=delay_idx)
            if idx < 0:
                return
            addon.setSetting(f'autofav_{slot}_delay', _AUTOSTART_DELAY_LABELS[idx])
            xbmcgui.Dialog().notification("TopZilla", f"Retardo: {_AUTOSTART_DELAY_LABELS[idx]}", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
            return
        # sel == 0: cambiar favorito → flujo de picker completo abajo

    favs = _get_kodi_favourites()
    if not favs:
        xbmcgui.Dialog().notification("TopZilla", "No tienes favoritos guardados en Kodi", xbmcgui.NOTIFICATION_WARNING)
        xbmc.executebuiltin("Container.Refresh")
        return

    names = [name for name, _cmd, _thumb in favs]
    presel = next((i for i, (name, _c, _t) in enumerate(favs) if name == titulo), -1)
    sel_fav = xbmcgui.Dialog().select("Seleccionar favorito a lanzar al arrancar", names, preselect=presel)
    if sel_fav < 0:
        return

    nuevo_titulo, nuevo_cmd, _ = favs[sel_fav]

    idx = xbmcgui.Dialog().select("Retardo antes de lanzar", _AUTOSTART_DELAY_LABELS, preselect=delay_idx)
    nuevo_delay = _AUTOSTART_DELAY_LABELS[idx] if idx >= 0 else delay_label

    addon.setSetting(f'autofav_{slot}_enabled', 'true')
    addon.setSetting(f'autofav_{slot}_title', nuevo_titulo)
    addon.setSetting(f'autofav_{slot}_cmd', nuevo_cmd)
    addon.setSetting(f'autofav_{slot}_delay', nuevo_delay)

    xbmcgui.Dialog().notification("TopZilla", f"Favorito {slot}: {nuevo_titulo}", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


def _render_widget(h, movies, media_type):
    """Pinta una lista de dicts del grid (ya enriquecidos desde caché por el loader)
    como directorio Kodi estándar, consumible por widgets de skin. Cada item abre la
    ficha/"¿Dónde ver?" al pulsarlo, igual que las listas normales."""
    import context_menu
    import movie_ref

    af = core_settings.addon_fanart()
    mediatype = 'tvshow' if media_type == 'show' else 'movie'
    xbmcplugin.setContent(h, 'tvshows' if media_type == 'show' else 'movies')
    for m in movies:
        title = m.get('title', '')
        try:
            year = int(m.get('year') or 0)
        except (TypeError, ValueError):
            year = 0
        li = xbmcgui.ListItem(label=core_settings.apply_label(title))
        poster = m.get('poster') or ''
        li.setArt({'icon': 'DefaultVideo.png', 'thumb': poster,
                   'poster': poster, 'fanart': m.get('fanart') or af})
        cast = [c.strip() for c in (m.get('cast_str') or '').split(',') if c.strip()]
        info = {'title': title, 'year': year, 'plot': m.get('plot', ''),
                'genre': m.get('genre', ''), 'mediatype': mediatype}
        if m.get('rating'):
            info['rating'] = m['rating']
        if m.get('director'):
            info['director'] = m['director']
        if m.get('runtime'):
            info['duration'] = int(m['runtime']) * 60
        if cast:
            info['cast'] = cast
        li.setInfo('video', info)
        li.setProperty('IsPlayable', 'false')
        ref = movie_ref.make_ref(
            title=title, year=year or None,
            tmdb_id=m.get('tmdb_id') or None, imdb_id=m.get('imdb_id') or None,
            poster=poster, media_type=media_type, source='widget', plot=m.get('plot', ''))
        context_menu.attach(li, ref)
        xbmcplugin.addDirectoryItem(handle=h, url=context_menu.build_play_url(ref),
                                    listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)


def _run():
    stats.ping()
    params = dict(urllib.parse.parse_qsl(sys.argv[2].lstrip('?')))
    a = params.get('action', '')

    if not a:
        # Modo Cine automático (opt-in): se abre encima del menú; al cerrarlo,
        # el menú principal ya está renderizado detrás.
        if core_settings.cinema_mode_auto_enabled():
            try:
                import pelis_flix
                pelis_flix.show(search_fn=_search_alternatives_prompt, initial_mode='movie')
            except Exception as e:
                xbmc.log("[TopZilla] cinema_mode_auto: {0}".format(e), xbmc.LOGWARNING)
        _main_menu()

    elif a == "report_watched":
        # API entrante: otro addon reporta que el usuario ha visto un título. Se
        # invoca con RunPlugin(plugin://plugin.video.topzilla/?action=report_watched
        # &title=...&media_type=movie|show&tmdb_id=...&imdb_id=...&year=...&source=...).
        # 'title' es obligatorio (lo exige el historial); los ids son opcionales pero
        # recomendados para que el scrobble a Trakt funcione. watch_history.mark()
        # dispara, si está activado, el scrobble opt-in (F2).
        import movie_ref
        import watch_history
        title = (params.get("title") or "").strip()
        if not title:
            xbmc.log("[TopZilla] report_watched: sin título, ignorado", xbmc.LOGWARNING)
        else:
            mt = "show" if params.get("media_type") == "show" else "movie"
            watch_history.mark(movie_ref.make_ref(
                title=title,
                year=params.get("year") or None,
                tmdb_id=params.get("tmdb_id") or None,
                imdb_id=params.get("imdb_id") or None,
                media_type=mt,
                source=params.get("source") or "api",
            ))
    elif a == "widget_row":
        # Widget de skin: devuelve una fila del catálogo del Modo Cine como directorio.
        # plugin://plugin.video.topzilla/?action=widget_row&row=<id>&media_type=movie|show
        # Reusa los mismos loaders del Modo Cine (pelis_grid._LOADERS), así cualquier
        # fila (mis_favs, continuar, top10, cartelera, netflix…) es widgetable.
        import pelis_flix
        import pelis_grid
        h = int(sys.argv[1])
        mode = "show" if params.get("media_type") == "show" else "movie"
        entry = next((r for r in pelis_flix.catalog_for(mode)
                      if r["id"] == params.get("row", "")), None)
        if entry is None:
            xbmc.log("[TopZilla] widget_row: fila desconocida '{0}'".format(
                params.get("row", "")), xbmc.LOGWARNING)
            xbmcplugin.endOfDirectory(h, succeeded=False)
        else:
            loader = pelis_grid._LOADERS.get(entry["key"])
            try:
                movies = (loader(entry.get("params") or {}) or []) if loader else []
            except Exception as e:
                xbmc.log("[TopZilla] widget_row loader {0}: {1}".format(
                    entry["key"], e), xbmc.LOGERROR)
                movies = []
            _render_widget(h, movies, mode)
    elif a == "filmaffinity_menu":
        import filmaffinity
        filmaffinity.menu()
    elif a == "filmaffinity_list":
        import filmaffinity
        filmaffinity.show_list(params.get("genre", ""))
    elif a == "filmaffinity_submenu":
        h = int(sys.argv[1])
        _bold  = core_settings.get_acc_force_bold()
        _strip = core_settings.get_acc_strip_symbols()
        _color = core_settings.get_acc_color_mode()
        for label, action, icon, plot in [
            ("En Cines España",             "filmaffinity_cartelera", "top_encines.png",      "Películas en cines en España según FilmAffinity."),
            ("Top Valoradas (TMDB)",        "filmaffinity_top",       "top_mejores.png",      "Las películas mejor valoradas según TMDB."),
            ("Top FilmAffinity (Comunidad)","filmaffinity_topfa",     "top_lists_popular.png","Las mejores películas según los usuarios de FilmAffinity."),
        ]:
            li = xbmcgui.ListItem(label=core_settings.apply_label("[B]{0}[/B]".format(label), bold=_bold, strip=_strip, color_mode=_color))
            li.setArt({'icon': core_settings.addon_media(icon), 'fanart': core_settings.addon_fanart()})
            li.setInfo('video', {'plot': plot})
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action=action), listitem=li, isFolder=True)
        for label, group, icon, plot in [
            ("Novedades en streaming",     "streaming", "top_netflix.png",    "Últimas novedades por plataforma de streaming según FilmAffinity."),
            ("En cines (internacional)",   "cines",     "fa_cines_intl.png",  "Estrenos en cines de varios países según FilmAffinity."),
            ("Alquiler y venta",           "rent",      "fa_alquiler.png",    "Novedades disponibles en alquiler y venta según FilmAffinity."),
            ("Más de FilmAffinity",        "otros",     "top_encines_tv.png",  "Próximos estrenos y actualidad según FilmAffinity."),
        ]:
            li = xbmcgui.ListItem(label=core_settings.apply_label("[B]{0}[/B]".format(label), bold=_bold, strip=_strip, color_mode=_color))
            li.setArt({'icon': core_settings.addon_media(icon), 'fanart': core_settings.addon_fanart()})
            li.setInfo('video', {'plot': plot})
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action='filmaffinity_cat_submenu', group=group), listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
    elif a == "filmaffinity_cartelera":
        import filmaffinity
        filmaffinity.show_cartelera()
    elif a == "filmaffinity_top":
        import filmaffinity
        filmaffinity.show_top()
    elif a == "filmaffinity_topfa":
        import filmaffinity
        filmaffinity.show_topfa()
    elif a == "filmaffinity_cache_cartelera_meta":
        import filmaffinity
        filmaffinity.cache_cartelera_meta()
    elif a == "filmaffinity_clear_cartelera_meta":
        import filmaffinity
        filmaffinity.clear_cartelera_meta()
    elif a == "filmaffinity_cat":
        import filmaffinity
        filmaffinity.show_cat(params.get('src', ''))
    elif a == "filmaffinity_cat_submenu":
        import filmaffinity
        h = int(sys.argv[1])
        _bold  = core_settings.get_acc_force_bold()
        _strip = core_settings.get_acc_strip_symbols()
        _color = core_settings.get_acc_color_mode()
        for s in filmaffinity.cat_sections_for(params.get('group', '')):
            li = xbmcgui.ListItem(label=core_settings.apply_label("[B]{0}[/B]".format(s['label']), bold=_bold, strip=_strip, color_mode=_color))
            li.setArt({'icon': core_settings.addon_media(s['icon']), 'fanart': core_settings.addon_fanart()})
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action='filmaffinity_cat', src=s['src']), listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)

    elif a == "trakt_tops_menu":
        import trakt_tops
        trakt_tops.show_menu()
    elif a == "trakt_tops_list":
        import trakt_tops
        trakt_tops.show_list(params.get('path', ''), params.get('media_type', 'movie'),
                             params.get('wrapped', '1'), params.get('page', 1))

    elif a == "streaming_tops_menu":
        import streaming_tops
        streaming_tops.show_menu()
    elif a == "streaming_tops_list":
        import streaming_tops
        streaming_tops.show_provider_list(params.get('provider_id', ''), params.get('media_type', 'movie'),
                                          params.get('page', 1))

    elif a == "mdblist_menu":
        import mdblist
        mdblist.show_menu()
    elif a == "mdblist_category":
        import mdblist
        mdblist.show_category_lists(params.get('query', ''), params.get('label', ''))
    elif a == "mdblist_top":
        import mdblist
        mdblist.show_top_lists()
    elif a == "mdblist_user":
        import mdblist
        mdblist.show_user_lists()
    elif a == "mdblist_search":
        import mdblist
        mdblist.search_lists()
    elif a == "mdblist_list":
        import mdblist
        mdblist.show_list_items(params.get('list_id', ''), params.get('list_name', ''), params.get('page', 1))
    elif a == "mdblist_add_key":
        import mdblist
        mdblist._add_api_key()
    elif a == "mdblist_setup_key":
        import mdblist
        mdblist._setup_api_key()

    elif a == "anime_menu":
        import anime_tops
        anime_tops.show_menu()
    elif a == "anime_anilist_menu":
        import anime_tops
        anime_tops.show_anilist_menu()
    elif a == "anime_anilist_list":
        import anime_tops
        anime_tops.show_anilist_list(params.get('sort_key', ''), params.get('page', 1))
    elif a == "anime_mal_menu":
        import anime_tops
        anime_tops.show_mal_menu()
    elif a == "anime_mal_list":
        import anime_tops
        anime_tops.show_mal_list(params.get('ranking_type', ''), params.get('page', 1))
    elif a == "anime_mal_setup":
        import anime_tops
        anime_tops._setup_mal_key()

    elif a == "letterboxd_menu":
        import letterboxd
        letterboxd.show_menu()
    elif a == "letterboxd_list":
        import letterboxd
        letterboxd.show_list(params.get('list_key', ''), params.get('list_url', ''))
    elif a == "letterboxd_cache_meta":
        import letterboxd
        letterboxd.cache_list_meta(params.get('list_key', ''), params.get('list_url', ''))
    elif a == "letterboxd_clear_meta":
        import letterboxd
        letterboxd.clear_list_meta(params.get('list_key', ''), params.get('list_url', ''))

    elif a == "pelis_grid_open":
        import pelis_grid
        _gp = {k: v for k, v in params.items() if k not in ('action', 'source')}
        pelis_grid.show_from_source(params.get('source', ''), _gp)

    elif a == "pelis_flix":
        import pelis_flix
        # search_fn síncrono para que el Modo Cine pueda cerrar su modal al
        # navegar a una fuente (evita que el modal tape los resultados).
        pelis_flix.show(search_fn=_search_alternatives_prompt,
                        initial_mode=params.get('mode') or None)

    elif a == "search_online_director":
        import search_movies
        search_movies.online_search_director(params.get('q') or None)
    elif a == "search_online_genres":
        import search_movies
        search_movies.online_genres_menu()
    elif a == "search_online_genre":
        import search_movies
        search_movies.online_search_genre(params.get('id', ''), params.get('label', ''))
    elif a == "search_online_year":
        import search_movies
        search_movies.online_search_year(params.get('q') or None)

    elif a == "cine_options_menu":
        _cine_options_menu()
    elif a == "configure_cinema_rows":
        _configure_cinema_rows()
    elif a == "reorder_cinema_rows":
        _reorder_cinema_rows()
    elif a == "trailer_config":
        _trailer_config()
    elif a == "toggle_flix_lazy_load":
        core_settings.set_flix_lazy_enabled(not core_settings.is_flix_lazy_enabled())
        xbmc.executebuiltin("Container.Refresh")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "toggle_flix_remember_pos":
        core_settings.set_flix_remember_pos_enabled(not core_settings.is_flix_remember_pos_enabled())
        xbmc.executebuiltin("Container.Refresh")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "toggle_cinema_auto":
        _toggle_cinema_auto()
    elif a == "toggle_remember_list_position":
        _toggle_remember_list_position()
    elif a == "set_pelis_grid_mode":
        _set_pelis_grid_mode()
    elif a == "set_snapshot_ttl":
        _set_snapshot_ttl()
    elif a == "toggle_trakt_write_sync":
        _toggle_trakt_write_sync()
    elif a == "toggle_context_watchlist":
        new_val = not core_settings.get_bool_setting('show_context_menu_watchlist', False)
        if core_settings.set_bool_setting('show_context_menu_watchlist', new_val):
            msg = "ACTIVADO" if new_val else "DESACTIVADO"
            xbmcgui.Dialog().notification("TopZilla", "\"Quiero ver\" en menú contextual {0}.".format(msg), xbmcgui.NOTIFICATION_INFO, 3000)
        else:
            xbmcgui.Dialog().notification("TopZilla", "No se pudo guardar el ajuste.", xbmcgui.NOTIFICATION_ERROR, 3000)
        xbmc.executebuiltin("Container.Refresh")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "toggle_context_copy":
        _toggle_context_copy()
    elif a == "toggle_context_paste":
        _toggle_context_paste()
    elif a == "toggle_clipboard_sync":
        _toggle_clipboard_sync()
    elif a == "toggle_fanart_tv":
        _toggle_fanart_tv()
    elif a == "api_key_set_fanarttv":
        _api_key_set_fanarttv()
    elif a == "youtube_options_menu":
        _youtube_options_menu()
    elif a == "toggle_ytdlp_enabled":
        _toggle_ytdlp_enabled()
    elif a == "set_ytdlp_cookiefile":
        _set_ytdlp_cookiefile()
    elif a == "set_ytdlp_cookies":
        _set_ytdlp_cookies()
    elif a == "remote_input_options_menu":
        _remote_input_options_menu()
    elif a == "set_search_input_default":
        _set_search_input_default()
    elif a == "set_remote_port":
        _set_remote_port()
    elif a == "toggle_remote_secure":
        _toggle_remote_secure()
    elif a == "set_webremote_server":
        _set_webremote_server()
    elif a == "set_webremote_topic":
        _set_webremote_topic()
    elif a == "parental_options_menu":
        _parental_options_menu()
    elif a == "parental_set_pin":
        _parental_set_pin()
    elif a == "parental_clear":
        _parental_clear()
    elif a == "similar_watched":
        import similar_watched
        similar_watched.show_menu()
    elif a == "collections_menu":
        import collections_tops
        collections_tops.show_menu()
    elif a == "collection_list":
        import collections_tops
        collections_tops.show_list(params.get('collection_id', ''))
    elif a == "network_tops_menu":
        import network_tops
        network_tops.show_menu()
    elif a == "network_tops_list":
        import network_tops
        network_tops.show_list(params.get('kind', ''), params.get('tmdb_id', ''),
                               params.get('media_type', 'movie'), params.get('page', 1))
    elif a == "decades_menu":
        import discover_lists
        discover_lists.show_decades_menu()
    elif a == "decade_list":
        import discover_lists
        discover_lists.show_decade_list(params.get('start', 0), params.get('end', 0), params.get('page', 1))
    elif a == "genres_menu":
        import discover_lists
        discover_lists.show_genres_menu()
    elif a == "genre_list":
        import discover_lists
        discover_lists.show_genre_list(params.get('genre_id', 0), params.get('page', 1))
    elif a == "api_mark_watched":
        _api_mark_watched(params)
    elif a == "api_is_watched":
        _api_is_watched(params)
    elif a == "api_consulta_pelis":
        # API de consulta saliente: otro addon pide el catálogo de cine vía
        # Files.GetDirectory. render_directory hace su propio endOfDirectory.
        import topzilla_api
        topzilla_api.render_directory(params)

    elif a == "sensacine_submenu":
        h = int(sys.argv[1])
        _bold  = core_settings.get_acc_force_bold()
        _strip = core_settings.get_acc_strip_symbols()
        _color = core_settings.get_acc_color_mode()
        for label, action, icon, plot in [
            ("En Cartelera",      "sensacine_menu",     "top_encines.png",    "Películas en cines según SensaCine."),
            ("Estrenos",          "sensacine_estrenos", "top_anticipated.png", "Últimos estrenos según SensaCine."),
            ("Mejores Películas", "sensacine_mejores",  "top_mejores.png",    "Las mejores películas de todos los tiempos según los usuarios de SensaCine."),
            ("Taquilla",          "sensacine_taquilla", "top_boxoffice.png",  "Las películas más vistas en taquilla actualmente."),
        ]:
            li = xbmcgui.ListItem(label=core_settings.apply_label("[B]{0}[/B]".format(label), bold=_bold, strip=_strip, color_mode=_color))
            li.setArt({'icon': core_settings.addon_media(icon), 'fanart': core_settings.addon_fanart()})
            li.setInfo('video', {'plot': plot})
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action=action), listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
    elif a == "sensacine_menu":
        import sensacine
        sensacine.show_cartelera()
    elif a == "sensacine_estrenos":
        import sensacine
        sensacine.show_estrenos()
    elif a == "sensacine_mejores":
        import sensacine
        sensacine.show_mejores()
    elif a == "sensacine_taquilla":
        import sensacine
        sensacine.show_taquilla()
    elif a == "sensacine_cache_cartelera_meta":
        import sensacine
        sensacine.cache_cartelera_meta()
    elif a == "sensacine_clear_cartelera_meta":
        import sensacine
        sensacine.clear_cartelera_meta()
    elif a == "sensacine_cache_estrenos_meta":
        import sensacine
        sensacine.cache_estrenos_meta()
    elif a == "sensacine_clear_estrenos_meta":
        import sensacine
        sensacine.clear_estrenos_meta()
    elif a == "sensacine_cache_mejores_meta":
        import sensacine
        sensacine.cache_mejores_meta()
    elif a == "sensacine_clear_mejores_meta":
        import sensacine
        sensacine.clear_mejores_meta()
    elif a == "sensacine_cache_taquilla_meta":
        import sensacine
        sensacine.cache_taquilla_meta()
    elif a == "sensacine_clear_taquilla_meta":
        import sensacine
        sensacine.clear_taquilla_meta()

    elif a == "cinemeta_submenu":
        h = int(sys.argv[1])
        _bold  = core_settings.get_acc_force_bold()
        _strip = core_settings.get_acc_strip_symbols()
        _color = core_settings.get_acc_color_mode()
        for label, action, icon, plot in [
            ("Top Películas", "cinemeta_top",         "oscar.png",       "Las películas más populares según Cinemeta/Stremio (~190 títulos)."),
            ("Por Género",    "cinemeta_genres_menu", "top_genero.png",   "Películas top filtradas por género."),
        ]:
            li = xbmcgui.ListItem(label=core_settings.apply_label("[B]{0}[/B]".format(label), bold=_bold, strip=_strip, color_mode=_color))
            li.setArt({'icon': core_settings.addon_media(icon), 'fanart': core_settings.addon_fanart()})
            li.setInfo('video', {'plot': plot})
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action=action), listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
    elif a == "cinemeta_top":
        import cinemeta
        cinemeta.show_top()
    elif a == "cinemeta_genres_menu":
        import cinemeta
        cinemeta.show_genres_menu()
    elif a == "cinemeta_genre":
        import cinemeta
        cinemeta.show_genre(params.get("slug", ""))
    elif a == "cinemeta_cache_meta":
        import cinemeta
        cinemeta.cache_meta()
    elif a == "cinemeta_clear_meta":
        import cinemeta
        cinemeta.clear_meta()

    elif a == "tmdb_lists_menu":
        import tmdb_lists
        tmdb_lists.show_menu()
    elif a == "tmdb_lists_show":
        import tmdb_lists
        tmdb_lists.show_list(params.get("endpoint", ""), params.get("media_type", "movie"), params.get("page", 1))

    elif a == "on_air_calendar":
        import on_air_calendar
        on_air_calendar.show_calendar()
    elif a == "on_air_calendar_refresh":
        import on_air_calendar
        on_air_calendar.refresh()

    elif a == "archive_org":
        import archive_org
        archive_org.show_menu()
    elif a == "archive_category":
        import archive_org
        archive_org.show_category(params.get('q', ''), params.get('page', 1))
    elif a == "archive_search_ui":
        import archive_org
        archive_org.search_ui()
    elif a == "archive_play":
        import archive_org
        # title ya viene decodificado por parse_qsl (la URL se construye con
        # make_url, que codifica una sola vez); no re-decodificar.
        archive_org.play(params.get('archive_id', ''), params.get('title', ''))

    elif a == "debrid_cloud":
        import debrid_library
        debrid_library.cloud_menu()
    elif a == "debrid_cloud_view":
        import debrid_library
        debrid_library.set_view()
    elif a == "debrid_cloud_files":
        import debrid_library
        debrid_library.cloud_files(params.get('id'))
    elif a == "debrid_cloud_play":
        import debrid_library
        debrid_library.cloud_play(params.get('id'), params.get('file'))
    elif a == "debrid_cloud_delete":
        import debrid_library
        debrid_library.cloud_delete(params.get('id'))
    elif a == "debrid_cloud_download":
        import debrid_library
        debrid_library.cloud_download(params.get('id'), params.get('title', ''))
    elif a == "debrid_setup":
        import debrid_library
        debrid_library.setup_menu()
    elif a == "debrid_set_provider":
        import debrid_library
        debrid_library.setup_set_provider()
    elif a == "debrid_authorize_pin":
        import debrid_library
        debrid_library.setup_authorize_pin()
    elif a == "debrid_authorize_key":
        import debrid_library
        debrid_library.setup_authorize_key()
    elif a == "debrid_account":
        import debrid_library
        debrid_library.setup_account()
    elif a == "debrid_deauthorize":
        import debrid_library
        debrid_library.setup_deauthorize()

    elif a == "rtve_menu":
        import rtve_alacarta
        rtve_alacarta.main_menu()
    elif a == "rtve_live":
        import rtve_alacarta
        rtve_alacarta.live_channels()
    elif a == "rtve_category":
        import rtve_alacarta
        rtve_alacarta.category(params.get('cat_id', ''), params.get('cat_name', ''),
                               params.get('page', 1), params.get('parent_id', ''))
    elif a == "rtve_search":
        import rtve_alacarta
        rtve_alacarta.search()
    elif a == "play_rtve_live":
        import rtve_alacarta
        rtve_alacarta.play_live(params.get('url', ''), params.get('title', ''))
    elif a == "play_rtve_video":
        import rtve_alacarta
        rtve_alacarta.play_video(params.get('video_id', ''), params.get('title', ''))

    elif a == "top_movies":
        import top_movies
        top_movies.show_top(params.get("page", 1))
    elif a == "cache_top_movies_covers":
        import top_movies
        top_movies.cache_covers()
    elif a == "clear_top_movies_cache":
        import top_movies
        top_movies.clear_cache()

    elif a == "oscar_movies":
        import oscar_movies
        oscar_movies.show_oscar(params.get("page", 1))
    elif a == "cache_oscar_movies_covers":
        import oscar_movies
        oscar_movies.cache_covers()
    elif a == "clear_oscar_movies_cache":
        import oscar_movies
        oscar_movies.clear_cache()

    elif a == "awards_menu":
        import awards
        awards.show_menu()
    elif a == "awards_category":
        import awards
        awards.show_award(params.get("key", ""), params.get("page", 1))
    elif a == "cache_awards_covers":
        import awards
        awards.cache_covers(params.get("key", ""))
    elif a == "clear_awards_cache":
        import awards
        awards.clear_cache(params.get("key", ""))

    elif a == "options_menu":
        if _parental_gate():
            _options_menu()
        else:
            xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
    elif a == "customize_menu_screen":
        _customize_menu_screen()
    elif a == "reorder_menu":
        _reorder_menu()
    elif a == "reset_menu_layout":
        _reset_menu_layout_action()
    elif a == "menu_item_up":
        _menu_shift(params.get("key", ""), -1)
        xbmc.executebuiltin("Container.Refresh")
    elif a == "menu_item_down":
        _menu_shift(params.get("key", ""), 1)
        xbmc.executebuiltin("Container.Refresh")
    elif a == "menu_toggle_hidden":
        _menu_toggle_hidden(params.get("key", ""))
        xbmc.executebuiltin("Container.Refresh")
    elif a == "autostart_menu":
        _autostart_menu()
    elif a == "autostart_config_slot":
        try:
            _autostart_config_slot(int(params.get('slot', 0)))
        except (ValueError, TypeError):
            pass
    elif a == "autofav_menu":
        _autofav_menu()
    elif a == "autofav_config_slot":
        try:
            _autofav_config_slot(int(params.get('slot', 0)))
        except (ValueError, TypeError):
            pass
    elif a == "diagnostico_menu":
        _diagnostico_menu()
    elif a == "toggle_debug":
        _toggle_debug()
    elif a == "toggle_log_redact":
        _toggle_log_redact()
    elif a == "view_log":
        _view_log()
    elif a == "open_addon_settings":
        import xbmcaddon
        xbmcaddon.Addon().openSettings()
        xbmc.executebuiltin("Container.Refresh")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "toggle_auto_fetch":
        new_val = not core_settings._auto_fetch_enabled()
        if core_settings.set_auto_fetch_enabled(new_val):
            msg = "ACTIVADA" if new_val else "DESACTIVADA"
            xbmcgui.Dialog().notification("TopZilla", "Enriquecimiento con TMDB {0}.".format(msg), xbmcgui.NOTIFICATION_INFO, 3000)
        else:
            xbmcgui.Dialog().notification("TopZilla", "No se pudo guardar el ajuste.", xbmcgui.NOTIFICATION_ERROR, 3000)
        xbmc.executebuiltin("Container.Refresh")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "toggle_show_context_menu":
        new_val = not core_settings._show_context_menu_enabled()
        if core_settings.set_show_context_menu_enabled(new_val):
            msg = "ACTIVADA" if new_val else "DESACTIVADA"
            xbmcgui.Dialog().notification("TopZilla", "Opción en menú contextual {0}.".format(msg), xbmcgui.NOTIFICATION_INFO, 3000)
        else:
            xbmcgui.Dialog().notification("TopZilla", "No se pudo guardar el ajuste.", xbmcgui.NOTIFICATION_ERROR, 3000)
        xbmc.executebuiltin("Container.Refresh")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "toggle_show_context_menu_view_card":
        new_val = not core_settings._show_context_menu_view_card_enabled()
        if core_settings.set_show_context_menu_view_card_enabled(new_val):
            msg = "ACTIVADA" if new_val else "DESACTIVADA"
            xbmcgui.Dialog().notification("TopZilla", "\"Ver ficha\" en menú contextual {0}.".format(msg), xbmcgui.NOTIFICATION_INFO, 3000)
        else:
            xbmcgui.Dialog().notification("TopZilla", "No se pudo guardar el ajuste.", xbmcgui.NOTIFICATION_ERROR, 3000)
        xbmc.executebuiltin("Container.Refresh")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "fanart_menu":
        _fanart_menu()
    elif a == "fanart_cycle_mode":
        _fanart_cycle_mode()
    elif a == "fanart_browse_custom":
        _fanart_browse_custom()

    elif a == "api_keys_menu":
        _api_keys_menu()
    elif a == "api_key_set_tmdb":
        _api_key_set_tmdb()
    elif a == "api_key_set_trakt":
        _api_key_set_trakt()
    elif a == "api_key_set_trakt_secret":
        _api_key_set_trakt_secret()
    elif a == "api_key_set_omdb":
        _api_key_set_omdb()
    elif a == "api_key_set_mdblist":
        _api_key_set_mdblist()
    elif a == "api_key_set_mal":
        _api_key_set_mal()

    elif a == "accessibility_menu":
        _accessibility_menu()
    elif a == "crt_config_menu":
        _crt_config_menu()
    elif a == "crt_toggle":
        _crt_toggle(params.get("key", ""))
    elif a == "acc_set_color":
        _acc_set_color()
    elif a == "acc_toggle_bold":
        _acc_toggle_bold()
    elif a == "acc_toggle_symbols":
        _acc_toggle_symbols()
    elif a == "acc_toggle_font_size":
        _acc_toggle_font_size()
    elif a == "limpieza_parent_menu":
        _limpieza_parent_menu()
    elif a == "kodi_maintenance_menu":
        import kodi_maintenance
        kodi_maintenance.maintenance_menu()
    elif a == "cleanup_menu":
        _cleanup_menu()
    elif a == "cleanup_caches":
        _cleanup_caches()
    elif a == "vacuum_metadata_db":
        _vacuum_metadata_db()
    elif a == "delete_metadata_db":
        _delete_metadata_db()
    elif a == "factory_reset":
        _factory_reset()

    elif a == "storage_manager":
        import storage_manager
        storage_manager.menu_almacenamiento()
    elif a == "storage_clear_category":
        import storage_manager
        storage_manager.borrar_categoria(params.get('key', ''))
    elif a == "storage_clear_all":
        import storage_manager
        storage_manager.borrar_todas()
    elif a == "storage_clear_metadata":
        import storage_manager
        storage_manager.borrar_metadata()
    elif a == "storage_clear_backups":
        import storage_manager
        storage_manager.borrar_backups()
    elif a == "storage_info":
        import storage_manager
        storage_manager.info_almacenamiento()

    elif a == "log_manager_menu":
        import log_manager
        log_manager.menu()
    elif a == "log_view_kodi":
        import log_manager
        log_manager.view_log()
    elif a == "log_view_full":
        import log_manager
        log_manager.view_full()
    elif a == "log_view_errors":
        import log_manager
        log_manager.view_errors()
    elif a == "log_view_visual":
        import log_manager
        log_manager.view_visual()
    elif a == "log_search":
        import log_manager
        log_manager.search()
    elif a == "log_export":
        import log_manager
        log_manager.export()
    elif a == "log_info":
        import log_manager
        log_manager.info()
    elif a == "log_loiolog":
        import log_manager
        log_manager.loiolog()
    elif a == "log_show_line":
        import log_manager
        log_manager.show_line(params.get('data', ''))

    elif a == "search_shortcuts_menu":
        _search_shortcuts_menu()
    elif a == "search_shortcut_add_addon":
        _search_shortcut_add_addon()
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "search_shortcut_add_manual":
        _search_shortcut_add_manual()
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "search_shortcut_add_favourite":
        _search_shortcut_add_favourite()
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "search_shortcut_remove":
        try:
            _search_shortcut_remove(int(params.get('idx', -1)))
        except (ValueError, TypeError):
            pass
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "search_shortcut_rename":
        try:
            _search_shortcut_rename(int(params.get('idx', -1)))
        except (ValueError, TypeError):
            pass
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "search_shortcut_actions":
        try:
            _search_shortcut_actions(int(params.get('idx', -1)))
        except (ValueError, TypeError):
            pass
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "search_menu_reorder":
        _search_menu_reorder()
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False, cacheToDisc=False)
    elif a == "toggle_espadaily_integration":
        _toggle_espadaily_integration()
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "toggle_atresdaily_integration":
        _toggle_atresdaily_integration()
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "toggle_espatv_integration":
        _toggle_espatv_integration()
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "toggle_soundtrack_button":
        new_state = not core_settings.show_soundtrack_button_enabled()
        core_settings.set_show_soundtrack_button_enabled(new_state)
        msg = "Botón Banda Sonora: " + ("ACTIVADO" if new_state else "DESACTIVADO")
        xbmcgui.Dialog().notification("TopZilla", msg, xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("Container.Refresh")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "toggle_omdb_button":
        new_state = not core_settings.show_omdb_button_enabled()
        core_settings.set_show_omdb_button_enabled(new_state)
        msg = "Botón Críticas OMDb: " + ("ACTIVADO" if new_state else "DESACTIVADO")
        xbmcgui.Dialog().notification("TopZilla", msg, xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("Container.Refresh")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "toggle_share_button":
        new_state = not core_settings.show_share_button_enabled()
        core_settings.set_show_share_button_enabled(new_state)
        msg = "Botón Compartir: " + ("ACTIVADO" if new_state else "DESACTIVADO")
        xbmcgui.Dialog().notification("TopZilla", msg, xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("Container.Refresh")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "toggle_megabuscador_button":
        new_state = not core_settings.show_megabuscador_button_enabled()
        core_settings.set_show_megabuscador_button_enabled(new_state)
        msg = "Botón Megabuscador: " + ("ACTIVADO" if new_state else "DESACTIVADO")
        xbmcgui.Dialog().notification("TopZilla", msg, xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("Container.Refresh")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    elif a == "search_alt_prompt":
        import movie_ref as _mr
        _search_alternatives_prompt(params.get("q", ""), params.get("ot", ""), params.get("mode", ""),
                                    ref=_mr.loads_ref_strict(params.get("ref", "")) or None,
                                    tmdb_id=params.get("tmdb_id", ""),
                                    season=params.get("season", ""),
                                    episode=params.get("episode", ""))

    elif a == "record_navigation":
        import movie_ref
        import navigation_history
        ref = movie_ref.loads_ref_strict(params.get('ref', ''))
        navigation_history.record(ref)
        if not (ref and ref.get('title')):
            # Este click ES navegación de directorio (build_play_url, no RunPlugin como
            # show_card_from_context): hay que cerrar el handle o el spinner queda colgado.
            xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False, cacheToDisc=False)
            return
        _search_alternatives_prompt(
            ref.get('title', ''),
            ref.get('poster', ''),
            ref.get('media_type', 'movie'),
            ref=ref,
        )

    elif a == "show_card_from_context":
        import movie_ref
        ref = movie_ref.loads_ref_strict(params.get('ref', ''))
        if ref and ref.get('title'):
            _search_alternatives_prompt(
                ref.get('title', ''),
                ref.get('poster', ''),
                ref.get('media_type', 'movie'),
                ref=ref,
            )

    elif a == "search_menu":
        import search_movies
        search_movies.show_search_menu()
    elif a == "search_query":
        import search_movies
        search_movies.perform_search(params.get('q') or None)
    elif a == "search_history_menu":
        import search_movies
        search_movies.show_history()
    elif a == "search_history_delete":
        import search_movies
        search_movies.delete_history_entry(params.get('q', ''))
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "search_history_clear":
        import search_movies
        search_movies.clear_history()
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "search_youtube_prompt":
        h = int(sys.argv[1])
        # Cerramos el directorio vacío SIEMPRE (succeeded=True para que Kodi
        # no lo trate como error). Después Container.Update,replace cambia
        # el container al listado real, dejando una sola entrada en el
        # historial para que el botón atrás vuelva al menú padre.
        xbmcplugin.endOfDirectory(h, succeeded=True, cacheToDisc=False)
        if not xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)"):
            if xbmcgui.Dialog().yesno(
                    "TopZilla",
                    "El plugin de YouTube no está instalado.\n\n"
                    "Instálalo desde el repositorio oficial de Kodi.",
                    yeslabel="Instalar", nolabel="Cancelar"):
                xbmc.executebuiltin("InstallAddon(plugin.video.youtube)")
        else:
            import remote_input
            q = remote_input.get_text_input('Buscar en YouTube...').strip()
            if q:
                import search_movies
                search_movies._add_to_history(q)
                xbmc.executebuiltin("Container.Update({0},replace)".format(
                    _u(action='yt_results', query=q)))
    elif a == "search_dailymotion_prompt":
        import remote_input
        h = int(sys.argv[1])
        xbmcplugin.endOfDirectory(h, succeeded=True, cacheToDisc=False)
        q = remote_input.get_text_input('Buscar en Dailymotion...').strip()
        if q:
            import search_movies
            search_movies._add_to_history(q)
            xbmc.executebuiltin("Container.Update({0},replace)".format(
                _u(action='lfr', q=q)))

    elif a == "search_wikipedia_prompt":
        import remote_input
        h = int(sys.argv[1])
        xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
        q = remote_input.get_text_input('Buscar en Wikipedia...').strip()
        if q:
            import search_movies
            search_movies._add_to_history(q)
            search_movies.wikipedia_results(q)

    elif a == "wikipedia_results":
        # Compatibilidad: si algo aún invoca esta acción por URL, la cerramos
        # y delegamos al flujo de diálogos.
        h = int(sys.argv[1])
        xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
        import search_movies
        search_movies.wikipedia_results(params.get('query', ''))

    elif a == "explore_cache_menu":
        import search_movies
        search_movies.show_explore_menu()
    elif a == "explore_cache_by":
        import search_movies
        search_movies.show_explore_values(params.get('field', ''))
    elif a == "explore_cache_filter":
        import search_movies
        search_movies.show_explore_results(params.get('field', ''),
                                            params.get('value', ''))

    elif a == "my_library_menu":
        _my_library_menu()

    elif a == "export_txt":
        import export_txt
        export_txt.export()
        xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=False)

    elif a == "stats_personal":
        import stats_personal
        stats_personal.show_panel()
        xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=False)

    elif a == "surprise_me":
        _surprise_me()

    elif a == "film_history_today":
        import film_history
        film_history.show_today()
        xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=False)

    elif a == "favorites_menu":
        import favorites
        favorites.show_menu()
    elif a == "add_favorite":
        import favorites, movie_ref
        ref = movie_ref.loads_ref_strict(params.get('ref', ''))
        favorites.add_with_dialog(ref)
    elif a == "remove_favorite":
        import favorites
        favorites.remove(params.get('key', ''))
    elif a == "edit_favorite":
        import favorites
        favorites.edit(params.get('key', ''))
    elif a == "favorites_edit_menu":
        import favorites
        favorites.show_edit_menu()
    elif a == "favorite_pick_action":
        import favorites
        favorites.pick_action(params.get('key', ''))
    elif a == "favorites_clear_all":
        import favorites
        favorites.clear_all()
    elif a == "flowfav_launch":
        import espakodi_installer
        espakodi_installer.launch_by_id("plugin.program.flowfavmanager")
    elif a == "fav_add_section_picker":
        _fav_add_section_picker()

    elif a == "watchlist_menu":
        import watchlist
        watchlist.show_menu()
    elif a == "add_watchlist":
        import watchlist, movie_ref
        ref = movie_ref.loads_ref_strict(params.get('ref', ''))
        watchlist.add(ref)
    elif a == "remove_watchlist":
        import watchlist
        watchlist.remove(params.get('key', ''))
    elif a == "watchlist_pick_action":
        import watchlist
        watchlist.pick_action(params.get('key', ''))
    elif a == "watchlist_clear_all":
        import watchlist
        watchlist.clear_all()
    elif a == "watchlist_move_to_fav":
        import watchlist
        watchlist.move_to_favorites(params.get('key', ''))

    elif a == "categories_menu":
        import category_manager
        category_manager.main_menu()
    elif a == "cat_create":
        import category_manager
        category_manager.create_category()
    elif a == "cat_delete":
        import category_manager
        category_manager.delete_category(params.get('name', ''))
    elif a == "cat_rename":
        import category_manager
        category_manager.rename_category(params.get('name', ''))
    elif a == "cat_view":
        import category_manager
        category_manager.view_category(params.get('name', ''))
    elif a == "cat_remove_item":
        import category_manager
        category_manager.remove_item(params.get('cat', ''), params.get('key', ''))
    elif a == "cat_move_item":
        import category_manager
        category_manager.move_item(params.get('from_cat', ''), params.get('key', ''))
    elif a == "cat_backup_menu":
        import category_manager
        category_manager.backup_menu()
    elif a == "cat_export":
        import category_manager
        category_manager.export_categories()
    elif a == "cat_import":
        import category_manager
        category_manager.import_categories()

    elif a == "watch_history_menu":
        import watch_history
        watch_history.show_menu()

    elif a == "navigation_history_menu":
        import navigation_history
        navigation_history.show_menu()
    elif a == "navigation_history_delete":
        import navigation_history
        navigation_history.delete(params.get('key', ''))
    elif a == "navigation_history_clear_all":
        import navigation_history
        navigation_history.clear_all()

    elif a == "trakt_root":
        import trakt_manager
        trakt_manager.menu_trakt_root()

    elif a == "trakt_personal_menu":
        import trakt_personal
        trakt_personal.show_menu()
    elif a == "trakt_personal_onboarding":
        import trakt_personal
        trakt_personal.onboarding()
    elif a == "trakt_personal_login":
        import trakt_personal
        trakt_personal.login()
    elif a == "trakt_personal_logout":
        import trakt_personal
        trakt_personal.logout()
    elif a == "trakt_personal_watchlist":
        import trakt_personal
        trakt_personal.show_watchlist()
    elif a == "trakt_personal_continue":
        import trakt_personal
        trakt_personal.show_continue()
    elif a == "trakt_personal_upnext":
        import trakt_personal
        trakt_personal.show_upnext()
    elif a == "trakt_personal_recommended":
        import trakt_personal
        trakt_personal.show_recommended()
    elif a == "trakt_personal_history":
        import trakt_personal
        trakt_personal.show_history()

    elif a == "trakt_options":
        import trakt_manager
        trakt_manager.menu_options()
    elif a == "trakt_help_guide":
        import trakt_manager
        trakt_manager.help_guide()
    elif a == "trakt_set_key":
        import trakt_manager
        trakt_manager.set_api_key()
    elif a == "trakt_import":
        import trakt_manager
        trakt_manager.import_list()
    elif a == "trakt_lists_reorder":
        _trakt_lists_reorder()
    elif a == "trakt_discover_menu":
        import trakt_manager
        trakt_manager.menu_discover_lists()
    elif a == "trakt_browse_list_index":
        import trakt_manager
        trakt_manager.browse_list_index(params.get('path', ''), params.get('page', 1))
    elif a == "trakt_search_lists":
        import trakt_manager
        trakt_manager.search_trakt_lists()
    elif a == "trakt_view_list":
        import trakt_manager
        trakt_manager.view_list(params.get('list_id', ''))
    elif a == "trakt_delete_list":
        import trakt_manager
        trakt_manager.delete_list(params.get('list_id', ''))
    elif a == "trakt_refresh_defaults":
        import trakt_manager
        trakt_manager.refresh_all_lists()
    elif a == "trakt_cache_covers":
        import trakt_manager
        trakt_manager.cache_covers(params.get('list_id', ''))
    elif a == "trakt_clear_cache":
        import trakt_manager
        trakt_manager.clear_cache(params.get('list_id', ''))
    elif a == "trakt_cache_all_meta":
        import trakt_manager
        trakt_manager.cache_all_meta()
    elif a == "trakt_clear_all_meta":
        import trakt_manager
        trakt_manager.clear_all_meta()

    elif a == "backup_menu":
        import backup_manager
        backup_manager.show_menu()
    elif a == "backup_create":
        import backup_manager
        backup_manager.create_backup()
    elif a == "backup_list":
        import backup_manager
        backup_manager.list_backups()
    elif a == "backup_restore":
        import backup_manager
        backup_manager.restore_backup(params.get('path', ''))
    elif a == "backup_restore_external":
        import backup_manager
        backup_manager.restore_external()
    elif a == "backup_delete":
        import backup_manager
        backup_manager.delete_backup(params.get('path', ''))
    elif a == "backup_delete_all":
        import backup_manager
        backup_manager.delete_all_backups()
    elif a == "backup_set_dir":
        import backup_manager
        backup_manager.choose_backup_dir()

    elif a == "mark_watched":
        import watch_history, movie_ref
        ref = movie_ref.loads_ref_strict(params.get('ref', ''))
        watch_history.mark(ref)

    elif a == "unmark_watched":
        import watch_history
        watch_history.unmark(params.get('key', ''))

    elif a == "watch_history_clear_all":
        import watch_history
        watch_history.clear_all()

    elif a == "cat_add_item":
        import category_manager, movie_ref
        ref = movie_ref.loads_ref_strict(params.get('ref', ''))
        category_manager.add_item_dialog(ref)

    elif a == "info_menu":
        info_menu()

    elif a == "espakodi_addons_menu":
        import espakodi_installer
        espakodi_installer.render_menu(int(sys.argv[1]))

    elif a == "ek_launch":
        import espakodi_installer
        espakodi_installer.launch_by_id(params.get("addon_id", ""))

    elif a == "check_repo_status":
        import espakodi_installer
        espakodi_installer.check_repo_status()

    elif a == "show_universo":
        import universo; universo.show()

    elif a == "info":
        _info()

    elif a == "vpn_info":
        xbmcgui.Dialog().ok(
            "La VPN puede causar fallos o ser necesaria",
            "Algunos servidores bloquean VPNs (desactívala si algo no carga).\n\n"
            "En Dailymotion puede ocurrir lo contrario, si no carga prueba activando la VPN."
        )

    elif a == "future_i18n_info":
        xbmcgui.Dialog().ok(
            "Próximamente: más países e idiomas",
            "Este addon se adaptará a más países y contará con más idiomas en futuras versiones."
        )

    elif a == "easter_egg_lumiere":
        _yt_id = "C87lzxoHCDw"
        xbmcgui.Dialog().notification(
            "TopZilla", "El día que nació el cine (28 dic 1895)",
            xbmcgui.NOTIFICATION_INFO, 3000,
        )
        if xbmc.getCondVisibility("System.Platform.Android"):
            xbmc.executebuiltin(
                'StartAndroidActivity("com.google.android.youtube",'
                '"android.intent.action.VIEW","","https://www.youtube.com/watch?v={0}")'.format(_yt_id)
            )
        else:
            import yt_resolve
            yt_resolve.play_async(_yt_id)

    elif a == "noop":
        pass

    elif a == "yt_results":
        _yt_native_search_results(params.get('query', ''))

    elif a == "yt_play":
        _yt_play_resolve(params.get('vid', ''))

    elif a == "yt_results_kb":
        _yt_results_keyboard()

    elif a == "lfr":
        _lfd(params.get('q', ''), params.get('ot', ''), params.get('mode', ''))

    elif a == "pv":
        _pv(params.get('vid', ''), urllib.parse.unquote(params.get('title', '')))

    # --- Megabuscador (agregador multi-plataforma nativo) ---
    elif a == "megabuscador":
        import busqueda_total; busqueda_total.show_menu(int(sys.argv[1]))
    elif a == "bt_search":
        import busqueda_total; busqueda_total.prompt_and_run(int(sys.argv[1]))
    elif a == "bt_run":
        import busqueda_total; busqueda_total.run(int(sys.argv[1]), params.get("q", ""))
    elif a == "bt_toggle":
        import busqueda_total; busqueda_total.toggle(int(sys.argv[1]), params.get("key", ""))
    elif a == "bt_rank_menu":
        import busqueda_total; busqueda_total.show_rank_menu(int(sys.argv[1]))
    elif a == "bt_sources_menu":
        import busqueda_total; busqueda_total.show_sources_menu(int(sys.argv[1]))
    elif a == "bt_cine_menu":
        import busqueda_total; busqueda_total.show_cine_menu(int(sys.argv[1]))
    elif a == "bt_set_mindur":
        import busqueda_total; busqueda_total.set_min_duration(int(sys.argv[1]))
    elif a == "bt_proxy_find":
        import busqueda_total; busqueda_total.proxy_find(int(sys.argv[1]))
    elif a == "bt_proxy_clear":
        import busqueda_total; busqueda_total.proxy_clear(int(sys.argv[1]))
    elif a == "odysee_play":
        import odysee_search
        odysee_search.play_item(int(sys.argv[1]), params.get("name", ""), params.get("claim_id", ""))
    elif a == "peertube_play":
        import peertube_search
        peertube_search.play_item(int(sys.argv[1]), params.get("uuid", ""))
    elif a == "bitchute_play":
        import bitchute_search
        bitchute_search.play_item(int(sys.argv[1]), params.get("video_id", ""))

    else:
        xbmc.log("[TopZilla] acción desconocida: {0}".format(a), xbmc.LOGWARNING)
        xbmcgui.Dialog().notification(
            "TopZilla", "Acción no reconocida (¿enlace antiguo tras actualizar?)",
            xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))


if __name__ == '__main__':
    try:
        _run()
    except (SystemExit, KeyboardInterrupt):
        raise
    except Exception as _e:
        # Defensa de borde: cualquier fallo (ImportError de un handler, etc.) NO debe
        # dejar a Kodi con el directorio sin cerrar (rueda de carga eterna).
        try:
            xbmc.log("[TopZilla] _run fatal: {0}".format(_e), xbmc.LOGERROR)
        except Exception:
            pass
        try:
            xbmcgui.Dialog().notification(
                'TopZilla', 'Error inesperado — revisa kodi.log',
                xbmcgui.NOTIFICATION_ERROR, 4000)
        except Exception:
            pass
        try:
            xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False, cacheToDisc=False)
        except Exception:
            pass
