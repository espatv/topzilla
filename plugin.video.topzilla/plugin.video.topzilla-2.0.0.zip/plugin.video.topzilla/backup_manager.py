# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""
Backup y restauración de los datos de usuario.

NO se incluye nada reconstruible:
  - topzilla_metadata.db (caché TMDB)
  - topzilla_*_cache.json (cachés de scraping)
  - trakt_meta_items.json + trakt_meta_downloaded.flag
  - trakt_thumbs_*.json
  - settings.xml (accesibilidad, depende de Kodi y no portable)

Solo datos de usuario:
  - favorites.json
  - watch_history.json
  - navigation_history.json
  - search_history.json
  - custom_categories.json
  - trakt_settings.json (api_key + listas importadas)
"""
import json
import os
import sys
import tempfile
import time
import zipfile

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import core_settings


_BACKUP_DIR = 'backups'

# Pares (etiqueta, archivo), todos JSON de datos de usuario
GROUPS = [
    ("Favoritos",                 'favorites.json'),
    ("Quiero ver",                'watchlist.json'),
    ("Categorías",                'custom_categories.json'),
    ("Historial de Visionado",    'watch_history.json'),
    ("Historial de Navegación",   'navigation_history.json'),
    ("Historial de Búsquedas",    'search_history.json'),
    ("Trakt: API key y datos",    'trakt_settings.json'),
]

# Archivos que admiten "Fusionar" además de "Sustituir/Omitir":
# (listas) por dedupe via ref_key, (dicts) merge por clave
_LIST_FILES = {'favorites.json', 'watchlist.json', 'watch_history.json',
               'navigation_history.json', 'search_history.json'}
_DICT_FILES = {'custom_categories.json', 'trakt_settings.json'}


def _u(**kwargs):
    return core_settings.make_url(**kwargs)


def _handle():
    return int(sys.argv[1])


def _mi(name):
    return os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media', name)


def _backup_dir_default():
    return os.path.join(core_settings.profile_dir(), _BACKUP_DIR)


def _resolve_path(p):
    """Traduce paths virtuales de Kodi (special://) a rutas reales del SO."""
    if not p:
        return ''
    if p.startswith('special://'):
        try:
            return xbmcvfs.translatePath(p)
        except Exception:
            return p
    return p


def _ensure_dir(d):
    """Asegura que `d` existe como directorio. Devuelve True si al final existe.

    NO realiza ningún test de escritura, es barato para llamadas frecuentes
    desde el path crítico del menú.
    """
    if not d:
        return False
    try:
        if not os.path.exists(d):
            os.makedirs(d, exist_ok=True)
        return os.path.isdir(d)
    except (OSError, ValueError):
        return False


def _is_writable_dir(d):
    """True si `d` es directorio y permite escritura.

    Usa tempfile.mkstemp para evitar colisiones entre invocaciones
    concurrentes y obtener un nombre único. Solo debe llamarse cuando la
    escritura es necesaria (al elegir carpeta), NO en el path del menú.
    """
    if not _ensure_dir(d):
        return False
    fd = None
    probe = None
    try:
        fd, probe = tempfile.mkstemp(prefix='.topzilla_wt_', dir=d)
        os.close(fd)
        fd = None
        return True
    except (OSError, ValueError):
        if fd is not None:
            try:
                os.close(fd)
            except OSError:
                pass
        return False
    finally:
        if probe:
            try:
                os.remove(probe)
            except OSError:
                pass


def _backup_dir():
    """Devuelve la carpeta de backups efectiva.

    Si la carpeta configurada no existe (USB desenchufado, ruta inválida),
    hace fallback silencioso a la carpeta por defecto para que el menú no se
    rompa. La incidencia queda en el log de Kodi.

    NO valida escritura aquí: una carpeta de solo-lectura con backups
    antiguos debe seguir siendo legible. El error de escritura aparecerá
    al intentar crear un nuevo backup, con mensaje específico.
    """
    saved = xbmcaddon.Addon().getSetting('backup_path')
    if saved:
        saved = saved.strip()
    if saved:
        resolved = _resolve_path(saved)
        if _ensure_dir(resolved):
            return resolved
        xbmc.log("[TopZilla-BK] Carpeta de backup configurada no accesible: {0}. "
                 "Usando carpeta por defecto.".format(saved), xbmc.LOGWARNING)
    default_d = _backup_dir_default()
    _ensure_dir(default_d)
    return default_d


def choose_backup_dir():
    addon = xbmcaddon.Addon()
    current_saved = (addon.getSetting('backup_path') or '').strip()
    current_display = _resolve_path(current_saved) if current_saved else _backup_dir_default()
    chosen = xbmcgui.Dialog().browse(3, "Elegir carpeta de guardado de backups",
                                      'files', '', False, False, current_display)
    if isinstance(chosen, list):
        chosen = chosen[0] if chosen else ''
    if not chosen:
        return
    chosen = chosen.strip()
    if not chosen:
        return
    # Normalizar separadores finales para comparación
    chosen_norm = chosen.rstrip('/\\')
    current_norm = current_display.rstrip('/\\')
    if chosen_norm == current_norm:
        return

    resolved = _resolve_path(chosen)
    if not _is_writable_dir(resolved):
        xbmcgui.Dialog().ok(
            "TopZilla - Backup",
            "La carpeta seleccionada no es accesible o no permite escritura:\n\n{0}\n\n"
            "Elige otra ubicación.".format(chosen),
        )
        return

    addon.setSetting('backup_path', chosen)
    xbmcgui.Dialog().notification(
        "TopZilla - Backup",
        "Carpeta guardada",
        xbmcgui.NOTIFICATION_INFO, 3000,
    )
    xbmc.executebuiltin("Container.Refresh")


def _human_size(b):
    for unit in ('B', 'KB', 'MB', 'GB'):
        if b < 1024:
            return "{0:.1f} {1}".format(b, unit)
        b /= 1024
    return "{0:.1f} TB".format(b)


def show_menu():
    h = _handle()

    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()

    effective_dir = _backup_dir()

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR limegreen][B]Crear backup ahora[/B][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_backup.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Selecciona qué tipos de datos respaldar y guarda un ZIP en:\n{0}".format(effective_dir)})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='backup_create'),
                                 listitem=li, isFolder=False)

    backups = _list_backup_files()
    if backups:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            "[COLOR cyan][B]Restaurar / Listar backups guardados ({0})[/B][/COLOR]".format(len(backups)),
            bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': 'DefaultFolder.png', 'fanart': core_settings.addon_fanart()})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action='backup_list'),
                                     listitem=li, isFolder=True)

        li = xbmcgui.ListItem(label=core_settings.apply_label(
            "[COLOR orange][B]Borrar todos los backups[/B][/COLOR]",
            bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': 'DefaultIconError.png', 'fanart': core_settings.addon_fanart()})
        li.setInfo('video', {'plot': "Elimina todos los archivos ZIP de backup guardados ({0} en total).\n\nEsta acción NO se puede deshacer.".format(len(backups))})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action='backup_delete_all'),
                                     listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Restaurar desde archivo externo...[/B]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_backup.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Selecciona un ZIP de TopZilla guardado en cualquier ubicación."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='backup_restore_external'),
                                 listitem=li, isFolder=False)

    saved_dir = (xbmcaddon.Addon().getSetting('backup_path') or '').strip()
    saved_resolved = _resolve_path(saved_dir) if saved_dir else ''
    fallback_active = bool(saved_dir) and saved_resolved.rstrip('/\\') != effective_dir.rstrip('/\\')

    if fallback_active:
        label_text = "[COLOR orange][B]Carpeta de guardado (no accesible)...[/B][/COLOR]"
        plot = ("Carpeta configurada (NO accesible):\n{0}\n\n"
                "Usando carpeta por defecto:\n{1}\n\n"
                "Selecciona una carpeta válida.").format(saved_dir, effective_dir)
    else:
        label_text = "[B]Carpeta de guardado...[/B]"
        plot = "Carpeta actual:\n{0}\n\nSeleccionar una carpeta diferente donde guardar los ZIPs de backup.".format(effective_dir)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        label_text, bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultFolder.png', 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='backup_set_dir'),
                                 listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def list_backups():
    h = _handle()
    backups = _list_backup_files()
    if not backups:
        li = xbmcgui.ListItem(label=core_settings.apply_label("[COLOR gray]No hay backups guardados[/COLOR]"))
        li.setArt({'icon': 'DefaultIconInfo.png', 'fanart': core_settings.addon_fanart()})
        xbmcplugin.addDirectoryItem(handle=h, url='', listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
        return

    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()
    for fname, fpath, size, mtime in backups:
        date_str = time.strftime("%d/%m/%Y %H:%M", time.localtime(mtime))
        label = "[B]{0}[/B] [COLOR gray]({1}, {2})[/COLOR]".format(fname, _human_size(size), date_str)
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            label, bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': 'DefaultFile.png', 'fanart': core_settings.addon_fanart()})
        cm = [
            ("Borrar este backup",
             "RunPlugin({0})".format(_u(action='backup_delete', path=fpath))),
        ]
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(handle=h,
                                     url=_u(action='backup_restore', path=fpath),
                                     listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _list_backup_files():
    out = []
    d = _backup_dir()
    if not os.path.exists(d):
        return out
    try:
        entries = os.listdir(d)
    except OSError as e:
        xbmc.log("[TopZilla-BK] No se puede listar {0}: {1}".format(d, e),
                 xbmc.LOGWARNING)
        return out
    for fn in entries:
        if not fn.lower().endswith('.zip'):
            continue
        p = os.path.join(d, fn)
        try:
            stat = os.stat(p)
            out.append((fn, p, stat.st_size, stat.st_mtime))
        except OSError:
            pass
    out.sort(key=lambda x: x[3], reverse=True)
    return out


def create_backup():
    available = [(label, fname) for label, fname in GROUPS
                 if os.path.exists(core_settings.profile_file(fname))]
    if not available:
        xbmcgui.Dialog().ok("TopZilla - Backup",
                              "No hay datos de usuario para respaldar.")
        return

    labels = [label for label, _ in available]
    selected_indexes = xbmcgui.Dialog().multiselect(
        "Selecciona qué incluir en el backup",
        labels,
        preselect=list(range(len(labels))),
    )
    if selected_indexes is None or not selected_indexes:
        return

    selected = [available[i] for i in selected_indexes]

    ts = time.strftime("%Y%m%d_%H%M")
    out_name = "topzilla_backup_{0}.zip".format(ts)
    target_dir = _backup_dir()
    out_path = os.path.join(target_dir, out_name)

    if not _is_writable_dir(target_dir):
        xbmcgui.Dialog().ok(
            "TopZilla - Backup",
            "No se puede escribir en la carpeta de backups:\n\n{0}\n\n"
            "Comprueba los permisos o cambia la carpeta desde el menú Backup."
            .format(target_dir),
        )
        return

    try:
        with zipfile.ZipFile(out_path, 'w', zipfile.ZIP_DEFLATED) as zf:
            manifest = {'created_at': int(time.time()), 'addon': 'plugin.video.topzilla',
                          'files': []}
            for label, fname in selected:
                src = core_settings.profile_file(fname)
                if os.path.exists(src):
                    zf.write(src, arcname=fname)
                    manifest['files'].append(fname)
            zf.writestr('_manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2))
    except (OSError, zipfile.BadZipFile) as e:
        xbmcgui.Dialog().ok("Error", "No se pudo crear el backup:\n{0}".format(e))
        return

    try:
        size = os.path.getsize(out_path)
    except OSError:
        size = 0

    xbmcgui.Dialog().ok(
        "TopZilla - Backup",
        "Backup creado:\n{0}\n\nTamaño: {1}\nArchivos: {2}".format(
            out_name, _human_size(size), len(manifest['files'])),
    )
    xbmc.executebuiltin("Container.Refresh")


def restore_backup(path):
    if not path or not os.path.exists(path):
        xbmcgui.Dialog().notification("Error", "No existe el archivo",
                                       xbmcgui.NOTIFICATION_ERROR)
        return

    try:
        zf = zipfile.ZipFile(path, 'r')
    except (OSError, zipfile.BadZipFile) as e:
        xbmcgui.Dialog().ok("Error", "ZIP no válido:\n{0}".format(e))
        return

    try:
        # Solo restauramos los ficheros conocidos del backup. Filtrar por la whitelist
        # (no por endswith('.json')) cierra el path traversal: un ZIP externo hostil con
        # arcname '..\\..\\x.json' o ruta absoluta escribiría fuera del perfil vía save_json.
        _known = _LIST_FILES | _DICT_FILES
        names = [n for n in zf.namelist() if n in _known]
        if not names:
            xbmcgui.Dialog().ok("Backup vacío", "El ZIP no contiene datos restaurables.")
            return

        mode = xbmcgui.Dialog().select("¿Cómo restaurar?",
                                         ["Sustituir (reemplaza los datos actuales)",
                                          "Fusionar (combina con los actuales)"])
        if mode < 0:
            return

        replaced = 0
        merged = 0
        for n in names:
            try:
                payload = zf.read(n).decode('utf-8')
                new_data = json.loads(payload)
            except (ValueError, UnicodeDecodeError) as e:
                xbmc.log("[TopZilla-BK] {0}: {1}".format(n, e), xbmc.LOGWARNING)
                continue

            if mode == 0:  # Sustituir
                core_settings.save_json(n, new_data)  # atómico (tmp+os.replace)
                replaced += 1
            else:  # Fusionar
                _merge_into_file(n, new_data)
                merged += 1
    finally:
        zf.close()

    summary = "Restauración completada.\n"
    if replaced:
        summary += "Sustituidos: {0}\n".format(replaced)
    if merged:
        summary += "Fusionados: {0}\n".format(merged)
    xbmcgui.Dialog().ok("TopZilla - Backup", summary)
    xbmc.executebuiltin("Container.Refresh")


def restore_external():
    f = xbmcgui.Dialog().browse(1, 'Selecciona el ZIP de backup',
                                  'files', '.zip', False, False, '')
    if f:
        restore_backup(f)


def delete_backup(path):
    if not path or not os.path.exists(path):
        return
    if not xbmcgui.Dialog().yesno("Borrar backup",
                                    "¿Borrar definitivamente este backup?\n{0}".format(os.path.basename(path))):
        return
    try:
        os.remove(path)
        xbmcgui.Dialog().notification("TopZilla", "Backup eliminado",
                                       xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin("Container.Refresh")
    except OSError as e:
        xbmcgui.Dialog().notification("Error", str(e),
                                       xbmcgui.NOTIFICATION_ERROR)


def delete_all_backups():
    backups = _list_backup_files()
    if not backups:
        xbmcgui.Dialog().notification("TopZilla", "No hay backups que borrar",
                                       xbmcgui.NOTIFICATION_INFO)
        return
    total_size = sum(size for _, _, size, _ in backups)
    if not xbmcgui.Dialog().yesno(
        "Borrar todos los backups",
        "¿Borrar los {0} backups guardados ({1} en total)?\n\nEsta acción NO se puede deshacer.".format(
            len(backups), _human_size(total_size)),
        nolabel="Cancelar",
        yeslabel="Borrar todos"
    ):
        return
    freed = 0
    for _, fpath, size, _ in backups:
        try:
            os.remove(fpath)
            freed += size
        except OSError:
            pass
    xbmcgui.Dialog().notification(
        "TopZilla",
        "Backups eliminados. Liberados {0}.".format(_human_size(freed)),
        xbmcgui.NOTIFICATION_INFO, 4000
    )
    xbmc.executebuiltin("Container.Refresh")


# Fusión por tipo de archivo

def _merge_into_file(fname, new_data):
    """Fusiona `new_data` con el archivo del perfil `fname` según su tipo."""
    import movie_ref

    if fname in _LIST_FILES:
        # listas de MovieRef o de dicts (search_history): dedupe por ref_key o por 'query'
        existing = core_settings.load_json(fname, default=[])
        if not isinstance(existing, list):
            existing = []
        if not isinstance(new_data, list):
            new_data = []
        if fname == 'search_history.json':
            seen = {e.get('query') for e in existing if isinstance(e, dict)}
            for entry in new_data:
                if isinstance(entry, dict) and entry.get('query') and entry['query'] not in seen:
                    existing.append(entry)
                    seen.add(entry['query'])
        else:
            seen = {movie_ref.ref_key(r) for r in existing if isinstance(r, dict)}
            for ref in new_data:
                if isinstance(ref, dict):
                    k = movie_ref.ref_key(ref)
                    if k and k not in seen:
                        existing.append(ref)
                        seen.add(k)
        core_settings.save_json(fname, existing)
    elif fname == 'custom_categories.json':
        existing = core_settings.load_json(fname, default={})
        if not isinstance(existing, dict):
            existing = {}
        if not isinstance(new_data, dict):
            return
        for cat, refs in new_data.items():
            if not isinstance(refs, list):
                continue
            target = existing.get(cat, [])
            seen = {movie_ref.ref_key(r) for r in target if isinstance(r, dict)}
            for ref in refs:
                if isinstance(ref, dict):
                    k = movie_ref.ref_key(ref)
                    if k and k not in seen:
                        target.append(ref)
                        seen.add(k)
            existing[cat] = target
        core_settings.save_json(fname, existing)
    elif fname == 'trakt_settings.json':
        existing = core_settings.load_json(fname, default={"api_key": "", "lists": []})
        if not isinstance(existing, dict):
            existing = {"api_key": "", "lists": []}
        if not isinstance(new_data, dict):
            return
        if new_data.get('api_key') and not existing.get('api_key'):
            existing['api_key'] = new_data['api_key']
        cur_lists = existing.get('lists', []) or []
        new_lists = new_data.get('lists', []) or []
        existing_ids = {l.get('id') for l in cur_lists if isinstance(l, dict)}
        for l in new_lists:
            if isinstance(l, dict) and l.get('id') and l['id'] not in existing_ids:
                cur_lists.append(l)
                existing_ids.add(l['id'])
        existing['lists'] = cur_lists
        cur_rm = set(existing.get('removed_defaults', []) or [])
        cur_rm.update(new_data.get('removed_defaults', []) or [])
        existing['removed_defaults'] = sorted(cur_rm)
        core_settings.save_json(fname, existing)
    else:
        core_settings.save_json(fname, new_data)
