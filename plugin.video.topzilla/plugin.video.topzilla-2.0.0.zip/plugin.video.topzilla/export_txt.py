# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""
Exporta los datos de Mi Biblioteca a un archivo TXT legible.

A diferencia de backup_manager (ZIP de JSONs reimportables), esto genera texto
plano pensado para leer/imprimir/compartir: favoritos, listas, historiales,
categorías y un resumen de estadísticas.
"""
import os
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

import core_settings
import movie_ref as mr


def _resolve_path(p):
    if p and p.startswith('special://'):
        return xbmcvfs.translatePath(p)
    return p


def _fmt_date(ts):
    try:
        ts = int(ts)
    except (TypeError, ValueError):
        return ''
    if ts <= 0:
        return ''
    return time.strftime('%d/%m/%Y', time.localtime(ts))


def _ref_line(ref, date_field):
    parts = [mr.display_label(ref),
             'serie' if ref.get('media_type') == 'show' else 'peli']
    src = mr.format_source(ref.get('source', ''))
    if src:
        parts.append(src)
    d = _fmt_date(ref.get(date_field)) if date_field else ''
    if d:
        parts.append(d)
    return '  - ' + '  ·  '.join(parts)


def _header(title, count=None):
    bar = '=' * 48
    head = title if count is None else '{0}  ({1})'.format(title, count)
    return [bar, head, bar]


def _list_section(title, refs, date_field):
    lines = _header(title, len(refs))
    if not refs:
        lines.append('  (sin datos)')
        return lines
    for ref in refs:
        if isinstance(ref, dict):
            lines.append(_ref_line(ref, date_field))
    return lines


def _cats_section(cats):
    total = sum(len(v) for v in cats.values() if isinstance(v, list))
    lines = _header('Mis Categorías', '{0} categorías · {1} títulos'.format(len(cats), total))
    for cat, refs in cats.items():
        refs = refs if isinstance(refs, list) else []
        lines.append('')
        lines.append('  [{0}]  ({1})'.format(cat, len(refs)))
        for ref in refs:
            if isinstance(ref, dict):
                lines.append('  ' + _ref_line(ref, 'added_at'))
    return lines


def _stats_section():
    import stats_personal as sp
    try:
        s = sp.compute()
    except Exception as e:
        xbmc.log("[TopZilla] export_txt stats: {0}".format(e), xbmc.LOGWARNING)
        return _header('Mis estadísticas') + ['  (no disponibles)']

    lines = _header('Mis estadísticas')
    lines.append('Favoritos: {0}  (pelis {1} · series {2})'.format(
        s['fav_total'], s['fav_movies'], s['fav_shows']))
    lines.append('  Vistos: {0}  ·  Sin ver: {1}'.format(s['fav_watched'], s['fav_unwatched']))
    if s['avg_rating'] is not None:
        lines.append('  Puntuación media propia: {0}/10  (sobre {1} títulos)'.format(
            s['avg_rating'], len(s['rated'])))
    lines.append('Historial visto: {0}  (pelis {1} · series {2})'.format(
        s['hist_total'], s['hist_movies'], s['hist_shows']))
    if s['hist_movies']:
        lines.append('  Tiempo total (pelis): ~{0}'.format(sp._format_time(s['total_min'])))
    if s['decade_counter']:
        lines.append('Décadas favoritas:')
        for decade, cnt in s['decade_counter'].most_common(5):
            lines.append('  {0}s: {1} títulos'.format(decade, cnt))
    if s['genre_counter']:
        lines.append('Géneros más frecuentes:')
        for genre, cnt in s['genre_counter'].most_common(6):
            lines.append('  {0}: {1}'.format(genre, cnt))
    if s['director_counter']:
        lines.append('Directores más vistos:')
        for director, cnt in s['director_counter'].most_common(5):
            lines.append('  {0}: {1} pelis'.format(director, cnt))
    return lines


def _available_sections():
    """Lista de (etiqueta_para_multiselect, builder) solo para secciones con datos.

    El builder se invoca solo si el usuario marca la sección; cierra sobre los
    datos ya cargados para no releer los JSON.
    """
    import favorites
    import watchlist
    import watch_history
    import navigation_history
    import category_manager

    out = []
    fav = favorites._load()
    if fav:
        out.append(("Mis Favoritos ({0})".format(len(fav)),
                    lambda: _list_section('Mis Favoritos', fav, 'added_at')))
    wl = watchlist._load()
    if wl:
        out.append(("Quiero ver ({0})".format(len(wl)),
                    lambda: _list_section('Quiero ver', wl, 'added_at')))
    cats = category_manager.load_cats()
    if cats:
        out.append(("Mis Categorías ({0})".format(len(cats)),
                    lambda: _cats_section(cats)))
    wh = watch_history._load()
    if wh:
        out.append(("Historial de Visionado ({0})".format(len(wh)),
                    lambda: _list_section('Historial de Visionado', wh, 'watched_at')))
    nh = navigation_history._load()
    if nh:
        out.append(("Historial de Navegación ({0})".format(len(nh)),
                    lambda: _list_section('Historial de Navegación', nh, 'visited_at')))
    if fav or wh:
        out.append(("Mis estadísticas", _stats_section))
    return out


def _build_text(builders):
    addon = xbmcaddon.Addon()
    out = ["{0} v{1} — Exportación de Mi Biblioteca".format(
               addon.getAddonInfo('name'), addon.getAddonInfo('version')),
           "Generado: {0}".format(time.strftime('%d/%m/%Y %H:%M')),
           '']
    for build in builders:
        out.extend(build())
        out.append('')
    return '\n'.join(out).rstrip() + '\n'


def export():
    specs = _available_sections()
    if not specs:
        xbmcgui.Dialog().ok("TopZilla - Exportar", "No hay datos de usuario para exportar.")
        return

    labels = [lbl for lbl, _ in specs]
    selected = xbmcgui.Dialog().multiselect(
        "Selecciona qué exportar a TXT", labels, preselect=list(range(len(labels))))
    if not selected:
        return
    builders = [specs[i][1] for i in selected]

    dest = xbmcgui.Dialog().browse(
        3, "Carpeta donde guardar el TXT", 'files', '', False, False,
        core_settings.profile_dir())
    if isinstance(dest, list):
        dest = dest[0] if dest else ''
    if not dest:
        return
    dest = _resolve_path(dest)
    if not os.path.isdir(dest):
        xbmcgui.Dialog().ok("TopZilla - Exportar", "La carpeta seleccionada no es válida.")
        return

    fname = "topzilla_export_{0}.txt".format(time.strftime('%Y%m%d_%H%M'))
    out_path = os.path.join(dest, fname)
    try:
        with open(out_path, 'w', encoding='utf-8') as fh:
            fh.write(_build_text(builders))
    except OSError as e:
        xbmcgui.Dialog().ok("TopZilla - Exportar",
                            "No se pudo escribir el archivo:\n{0}".format(e))
        return

    xbmcgui.Dialog().ok("TopZilla - Exportar",
                        "Exportado:\n{0}\n\nEn:\n{1}".format(fname, dest))
