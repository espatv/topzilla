# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
import json
import os
import sys

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import core_settings

_PER_PAGE = 50

# (title_es, film_year, oscar_year, imdb_rating, director, genre, plot_es)
_OSCAR_WINNERS = [
    ("El brutalista", 2024, 2025, 7.7, "Brady Corbet",
     "Drama",
     "Un arquitecto judío húngaro sobreviviente del Holocausto emigra a Estados Unidos tras la Segunda Guerra Mundial, donde intenta reconstruir su vida y su carrera arquitectónica frente a la adversidad, el racismo y la traición."),
    ("Oppenheimer", 2023, 2024, 8.3, "Christopher Nolan",
     "Drama / Biográfico / Historia",
     "La vida del físico teórico J. Robert Oppenheimer y su papel en el Proyecto Manhattan, el programa secreto que desarrolló las primeras armas nucleares, cuya detonación cambió el destino de la humanidad para siempre."),
    ("Todo a la vez en todas partes", 2022, 2023, 7.8, "Daniel Kwan, Daniel Scheinert",
     "Comedia / Acción / Ciencia ficción",
     "Una lavandera chino-americana se ve arrastrada a una aventura interdimensional en la que debe conectar con versiones de sí misma de otros universos paralelos para salvar el mundo de una amenaza caótica que ella misma desencadenó."),
    ("CODA", 2021, 2022, 7.6, "Siân Heder",
     "Drama / Música",
     "Ruby es la única oyente en una familia de sordos. Cuando descubre su pasión por el canto, debe elegir entre seguir su sueño musical en la universidad o quedarse en casa para ayudar al negocio familiar de pesca."),
    ("Nomadland", 2020, 2021, 7.3, "Chloé Zhao",
     "Drama / Aventura",
     "Tras el colapso económico de su ciudad natal, una mujer de sesenta años empaca su furgoneta y se embarca en un viaje por el Oeste americano viviendo como nómada moderna, encontrando una comunidad de personas que comparten su forma de vida libre."),
    ("Parásitos", 2019, 2020, 8.5, "Bong Joon-ho",
     "Thriller / Drama",
     "La familia Ki-taek, completamente en paro, se va infiltrando uno a uno en la vida de la adinerada familia Park, hasta que un inesperado giro transforma la situación en algo mucho más oscuro y violento de lo que nadie podía imaginar."),
    ("Green Book", 2018, 2019, 8.2, "Peter Farrelly",
     "Drama / Comedia / Biográfico",
     "Un pianista afroamericano de clase alta contrata a un conductor italiano-americano para una gira por el Sur racista de los años 60. Lo que comienza como una relación estrictamente profesional se convierte en una profunda amistad entre dos mundos opuestos."),
    ("La forma del agua", 2017, 2018, 7.3, "Guillermo del Toro",
     "Fantasía / Drama / Romance",
     "Una empleada de limpieza muda trabaja en un laboratorio secreto del gobierno donde tienen cautiva a una extraordinaria criatura anfibia. Entre ellos nace un romance que desafía a todos los que quieren explotar o destruir al ser."),
    ("Moonlight", 2016, 2017, 7.4, "Barry Jenkins",
     "Drama",
     "En tres actos, seguimos a Chiron desde su infancia atormentada en los barrios pobres de Miami, pasando por su adolescencia marcada por el acoso escolar, hasta su madurez, mientras descubre su identidad y su sexualidad."),
    ("Spotlight", 2015, 2016, 8.1, "Tom McCarthy",
     "Drama",
     "El equipo de investigación especial del Boston Globe descubre los abusos sexuales sistemáticos cometidos por sacerdotes católicos y encubiertos deliberadamente por la propia Iglesia durante décadas, publicando una historia que sacude al mundo."),
    ("Birdman", 2014, 2015, 7.7, "Alejandro González Iñárritu",
     "Drama / Comedia",
     "Riggan Thomson, ex actor famoso por interpretar al superhéroe Birdman, intenta recuperar su relevancia artística produciendo una obra en Broadway, mientras batalla con su ego desbordado, sus relaciones rotas y su propia cordura."),
    ("12 años de esclavitud", 2013, 2014, 8.1, "Steve McQueen",
     "Drama / Biográfico / Historia",
     "Solomon Northup, un hombre negro libre y músico de Nueva York, es engañado, secuestrado y vendido como esclavo en las plantaciones del Sur profundo de Estados Unidos, donde sobrevivirá durante doce interminables años."),
    ("Argo", 2012, 2013, 7.7, "Ben Affleck",
     "Thriller / Drama / Historia",
     "Un especialista de la CIA idea una descabellada pero brillante operación encubierta para rescatar a seis diplomáticos americanos atrapados en Teherán durante la Revolución Iraní, fingiendo ser el equipo de producción de una película de ciencia ficción."),
    ("El artista", 2011, 2012, 7.9, "Michel Hazanavicius",
     "Drama / Romance / Comedia",
     "En el Hollywood de los años 20, un gran actor del cine mudo se niega a adaptarse a la llegada del cine sonoro mientras su carrera se hunde, al mismo tiempo que una actriz a quien él ayudó a lanzar triunfa en la nueva era."),
    ("El discurso del rey", 2010, 2011, 8.0, "Tom Hooper",
     "Drama / Biográfico / Historia",
     "El futuro rey Jorge VI del Reino Unido busca la ayuda de un excéntrico logopeda para superar su tartamudez y encontrar su voz como líder de la nación en el momento en que el mundo se precipita hacia la Segunda Guerra Mundial."),
    ("En tierra hostil", 2008, 2010, 7.6, "Kathryn Bigelow",
     "Drama / Bélico / Acción",
     "Un experto en desactivación de explosivos lidera su equipo en las peligrosas calles de Bagdad. Su valentía, que raya en la temeridad, pone en riesgo a sus compañeros mientras lidia con el miedo y la adrenalina de la guerra."),
    ("Slumdog Millionaire", 2008, 2009, 8.0, "Danny Boyle",
     "Drama / Romance / Aventura",
     "Jamal Malik, un joven de los suburbios de Mumbai sin ninguna educación, llega a las preguntas finales del concurso ¿Quién quiere ser millonario? Detenido como sospechoso, relata cómo cada pregunta conecta con un episodio de su dura vida."),
    ("No es país para viejos", 2007, 2008, 8.2, "Joel Coen, Ethan Coen",
     "Thriller / Drama / Crimen",
     "En Texas en 1980, un cazador encuentra dos millones de dólares en el escenario de una masacre narco. Su decisión de quedarse con el dinero desencadena una imparable persecución por parte de un asesino implacable y sin escrúpulos."),
    ("Infiltrados", 2006, 2007, 8.5, "Martin Scorsese",
     "Crimen / Drama / Thriller",
     "La policía de Massachusetts y la mafia irlandesa se infiltran mutuamente: un agente encubierto trabaja dentro del crimen mientras un topo trabaja dentro de la policía. Cada bando trata desesperadamente de identificar al infiltrado del otro."),
    ("Crash", 2004, 2006, 7.7, "Paul Haggis",
     "Drama / Crimen",
     "En las 36 horas siguientes a un accidente en Los Ángeles, múltiples historias de personas de diferentes razas y condiciones sociales se entrelazan, revelando los prejuicios y las complejas relaciones raciales que definen la sociedad americana."),
    ("Million Dollar Baby", 2004, 2005, 8.1, "Clint Eastwood",
     "Drama / Deporte",
     "Una joven determinada convence a un entrenador de boxeo veterano y desencantado para que la entrene. Lo que comienza como una relación de mutua desconfianza se convierte en un vínculo profundo y transformador que ninguno esperaba."),
    ("El Señor de los Anillos: El retorno del Rey", 2003, 2004, 8.9, "Peter Jackson",
     "Aventura / Fantasía / Acción",
     "En la batalla final por la Tierra Media, Frodo y Sam se acercan al Monte del Destino para destruir el Anillo Único mientras Aragorn reúne las fuerzas del hombre para una batalla decisiva que dará a Frodo el tiempo necesario para cumplir su misión."),
    ("Chicago", 2002, 2003, 7.2, "Rob Marshall",
     "Musical / Drama / Comedia",
     "En el Chicago de los locos años 20, Roxie Hart mata a su amante y, junto a la famosa reclusa Velma Kelly, manipula a la prensa y al sistema judicial ayudada por el abogado más espectacular de la ciudad para convertirse en una celebridad."),
    ("Una mente maravillosa", 2001, 2002, 8.2, "Ron Howard",
     "Drama / Biográfico",
     "La historia de John Forbes Nash Jr., brillante matemático de Princeton que revolucionó la economía con su teoría de juegos pero que durante décadas batalló en secreto contra la esquizofrenia paranoide, ganando finalmente el Nobel en 1994."),
    ("Gladiator", 2000, 2001, 8.5, "Ridley Scott",
     "Acción / Aventura / Drama",
     "El general romano Máximo es traicionado y esclavizado por el ambicioso hijo del emperador, que asesina a su familia y toma el trono. Para sobrevivir y vengar su honor, deberá convertirse en el mejor gladiador de Roma."),
    ("American Beauty", 1999, 2000, 8.3, "Sam Mendes",
     "Drama",
     "Lester Burnham, un publicista de 42 años atrapado en una vida vacía y un matrimonio muerto, sufre una crisis vital que transforma a todos los que le rodean de maneras profundas e inesperadas."),
    ("Shakespeare enamorado", 1998, 1999, 7.1, "John Madden",
     "Comedia / Drama / Romance",
     "En el Londres isabelino de 1593, un joven William Shakespeare busca inspiración para su nueva obra mientras se enamora apasionadamente de Viola De Lesseps, una aristócrata que se disfraza de hombre para poder actuar en el teatro."),
    ("Titanic", 1997, 1998, 7.9, "James Cameron",
     "Drama / Romance / Aventura",
     "En el viaje inaugural del RMS Titanic en 1912, el joven artista Jack Dawson y la aristocrática Rose DeWitt Bukater se enamoran apasionadamente, cuando ambos están destinados a mundos completamente distintos."),
    ("El paciente inglés", 1996, 1997, 7.4, "Anthony Minghella",
     "Drama / Romance / Guerra",
     "Al final de la Segunda Guerra Mundial, una enfermera cuida a un misterioso hombre gravemente quemado en un monasterio italiano. A través de sus recuerdos emerge la historia de un apasionado y fatal romance en el desierto del norte de África."),
    ("Braveheart", 1995, 1996, 8.4, "Mel Gibson",
     "Acción / Drama / Historia",
     "William Wallace, un guerrero escocés del siglo XIII, lidera la rebelión contra la brutal ocupación inglesa del rey Eduardo I tras el asesinato de su amada esposa, convirtiéndose en el símbolo de la lucha por la independencia de Escocia."),
    ("Forrest Gump", 1994, 1995, 8.8, "Robert Zemeckis",
     "Drama / Comedia / Romance",
     "Forrest Gump, un hombre de Alabama con coeficiente intelectual bajo pero un corazón enorme, está presente sin pretenderlo en los momentos más importantes de la historia norteamericana de 1950 a 1980, mientras busca incansablemente a su amor."),
    ("La lista de Schindler", 1993, 1994, 9.0, "Steven Spielberg",
     "Drama / Biográfico / Historia",
     "Oskar Schindler, empresario alemán miembro del partido nazi, llega a Polonia dispuesto a enriquecerse con mano de obra judía barata. Testigo del horror del Holocausto, va arriesgando todo para salvar la vida de más de mil judíos."),
    ("Sin perdón", 1992, 1993, 8.2, "Clint Eastwood",
     "Western / Drama",
     "William Munny, un viejo pistolero reformado que cría cerdos con sus hijos, acepta por necesidad un último trabajo: matar a los vaqueros que mutilaron a una prostituta. Esta decisión le arrastra de vuelta a la violencia que intentó dejar atrás."),
    ("El silencio de los inocentes", 1991, 1992, 8.6, "Jonathan Demme",
     "Thriller / Terror / Crimen",
     "La joven agente del FBI Clarice Starling es enviada a entrevistar al Dr. Hannibal Lecter, un brillante psiquiatra y caníbal encarcelado, para obtener su ayuda en la captura de un asesino en serie que desolla a sus víctimas."),
    ("Bailando con lobos", 1990, 1991, 8.0, "Kevin Costner",
     "Drama / Western / Aventura",
     "El teniente John Dunbar, herido en combate, pide ser destinado al lejano Oeste. Allí entabla una relación con la tribu sioux que cambiará su visión del mundo para siempre, cuestionando todo lo que consideraba civilizado."),
    ("Conduciendo a Miss Daisy", 1989, 1990, 7.4, "Bruce Beresford",
     "Drama / Comedia",
     "A lo largo de veinticinco años en el sur de los Estados Unidos, la anciana y testaruda Miss Daisy y su chófer negro Hoke desarrollan una profunda e inesperada amistad que trasciende las barreras raciales y generacionales de la época."),
    ("Rain Man", 1988, 1989, 8.0, "Barry Levinson",
     "Drama",
     "Charlie Babbitt descubre que su padre ha dejado toda su fortuna a un hermano mayor con autismo savant, Raymond, cuya existencia desconocía. En un viaje en coche a través de América los dos hermanos aprenden a conocerse y respetarse."),
    ("El último emperador", 1987, 1988, 7.7, "Bernardo Bertolucci",
     "Drama / Biográfico / Historia",
     "La vida extraordinaria de Pu Yi, coronado emperador de China a los tres años, que pasó de ser el monarca más poderoso del mundo a prisionero de guerra y finalmente a simple jardinero ciudadano en la China comunista."),
    ("Platoon", 1986, 1987, 8.1, "Oliver Stone",
     "Drama / Bélico",
     "Chris Taylor, un joven universitario voluntario, llega a Vietnam y descubre los horrores reales de la guerra. Atrapado entre dos sargentos que representan visiones opuestas del mundo, pierde poco a poco su inocencia en la jungla."),
    ("Memorias de África", 1985, 1986, 7.2, "Sydney Pollack",
     "Drama / Romance / Aventura",
     "La baronesa Karen Blixen se instala en Kenia para cultivar café. En la vasta belleza del continente africano vive una historia de amor apasionada con el libre cazador Denys Finch Hatton, mientras lucha por mantener su granja en pie."),
    ("Amadeus", 1984, 1985, 8.4, "Miloš Forman",
     "Drama / Biográfico / Música",
     "El compositor Antonio Salieri, consumido por la envidia, narra desde un asilo mental su obsesiva rivalidad con el genio Wolfgang Amadeus Mozart, cuya música perfecta Salieri podía comprender pero nunca jamás igualar."),
    ("Términos de ternura", 1983, 1984, 7.4, "James L. Brooks",
     "Drama / Comedia",
     "La relación entre Aurora Greenway, una madre sobreprotectora, y su hija Emma a lo largo de treinta años de alegrías y dolores, desde las bodas y divorcios hasta una enfermedad que pondrá a prueba los lazos que las unen."),
    ("Gandhi", 1982, 1983, 8.0, "Richard Attenborough",
     "Drama / Biográfico / Historia",
     "La vida de Mahatma Gandhi, desde su humillación en Sudáfrica como joven abogado hasta convertirse en el líder espiritual de millones, usando la resistencia pacífica para liberar a la India del dominio colonial británico."),
    ("Carros de fuego", 1981, 1982, 7.1, "Hugh Hudson",
     "Drama / Deporte / Biográfico",
     "Basada en hechos reales: dos corredores británicos, el judío Harold Abrahams y el cristiano devoto Eric Liddell, se preparan para los Juegos Olímpicos de París de 1924 impulsados por motivaciones muy diferentes pero con la misma determinación."),
    ("Gente corriente", 1980, 1981, 7.7, "Robert Redford",
     "Drama",
     "Una familia americana aparentemente normal de Chicago lidia con la muerte accidental de su hijo mayor. El padre lucha por mantener unidos al hijo superviviente, atormentado por la culpa, y a su esposa, incapaz de expresar su dolor."),
    ("Kramer contra Kramer", 1979, 1980, 7.8, "Robert Benton",
     "Drama",
     "Ted Kramer, un publicitario absorbido por su trabajo, se ve obligado a criar solo a su hijo de seis años cuando su esposa los abandona. Al regresar ella, se desata una dolorosa batalla legal por la custodia del niño."),
    ("El cazador", 1978, 1979, 8.1, "Michael Cimino",
     "Drama / Bélico",
     "Tres amigos de una comunidad obrera de Pennsylvania van a Vietnam, donde son capturados y sometidos a la traumatizante ruleta rusa. La guerra les marca de por vida, cambiando irremediablemente sus relaciones y su visión del mundo."),
    ("Annie Hall", 1977, 1978, 8.0, "Woody Allen",
     "Comedia / Romance",
     "Alvy Singer, un cómico neurótico de Nueva York, reflexiona sobre su relación con la excéntrica y fascinante Annie Hall, analizando desde múltiples ángulos por qué el amor es tan difícil y tan necesario al mismo tiempo."),
    ("Rocky", 1976, 1977, 8.1, "John G. Avildsen",
     "Drama / Deporte",
     "Rocky Balboa, un boxeador mediocre de Filadelfia que cobra deudas para la mafia local, recibe la oportunidad de su vida: enfrentarse al campeón mundial Apollo Creed en una pelea que absolutamente nadie espera que pueda ganar."),
    ("Alguien voló sobre el nido del cuco", 1975, 1976, 8.7, "Miloš Forman",
     "Drama",
     "Randle Patrick McMurphy, un delincuente que finge locura para evitar la cárcel, es internado en un hospital psiquiátrico donde choca frontalmente con la autoritaria enfermera Ratched, convirtiéndose en defensor de los derechos de los pacientes."),
    ("El Padrino: Parte II", 1974, 1975, 9.0, "Francis Ford Coppola",
     "Crimen / Drama",
     "En paralelo se narra el ascenso del joven Vito Corleone en el Nueva York de los años 20 y la paulatina corrupción moral de su hijo Michael como padrino, que consolida el imperio criminal a cualquier precio ético o humano."),
    ("El golpe", 1973, 1974, 8.3, "George Roy Hill",
     "Comedia / Crimen / Drama",
     "En el Chicago de los años 30, dos timadores profesionales traman una elaborada y sofisticada estafa para vengar a un amigo asesinado y arruinar a un peligroso jefe del crimen organizado que no sospecha nada."),
    ("El padrino", 1972, 1973, 9.2, "Francis Ford Coppola",
     "Crimen / Drama",
     "Don Vito Corleone, el patriarca de la familia mafiosa más poderosa de Nueva York, es atacado. Su hijo menor Michael, que siempre quiso mantenerse alejado del crimen, se ve arrastrado irremediablemente al mundo de su familia."),
    ("La conexión francesa", 1971, 1972, 7.7, "William Friedkin",
     "Crimen / Thriller / Drama",
     "Los detectives Popeye Doyle y Cloudy Russo investigan una gran red de tráfico de heroína procedente de Marsella en una investigación que culmina en una de las más famosas persecuciones de coches de la historia del cine."),
    ("Patton", 1970, 1971, 7.9, "Franklin J. Schaffner",
     "Drama / Bélico / Biográfico",
     "El retrato épico del brillante pero controvertido general americano George S. Patton, uno de los comandantes más efectivos de la Segunda Guerra Mundial, cuya genialidad estratégica convivía con una personalidad arrogante y profundamente compleja."),
    ("Cowboy de medianoche", 1969, 1970, 7.8, "John Schlesinger",
     "Drama",
     "Joe Buck, un joven texano ingenuo, llega a Nueva York creyendo que las mujeres ricas pagarán por sus favores. Allí conoce a Ratso Rizzo, un estafador tuberculoso, y entre ambos nace una amistad inesperada mientras sueñan con escapar a Florida."),
    ("Oliver!", 1968, 1969, 7.4, "Carol Reed",
     "Musical / Drama",
     "Adaptación musical de Oliver Twist de Dickens: el huérfano Oliver escapa de un orfanato victoriano y en las calles de Londres conoce al pícaro Artful Dodger, quien le introduce en la banda de carteristas del maestro ladrón Fagin."),
    ("En el calor de la noche", 1967, 1968, 7.9, "Norman Jewison",
     "Crimen / Drama",
     "El detective negro Virgil Tibbs, de Filadelfia, se ve obligado a colaborar con el racista sheriff de un pueblo de Mississippi para resolver el asesinato de un industrial, en plena lucha por los derechos civiles de los años 60."),
    ("Un hombre para la eternidad", 1966, 1967, 7.7, "Fred Zinnemann",
     "Drama / Biográfico / Historia",
     "Sir Thomas More, Lord Canciller de Inglaterra, hombre de profundas convicciones católicas, se niega a aprobar el segundo matrimonio del rey Enrique VIII y su ruptura con Roma, sabiendo que esta decisión le costará la vida."),
    ("Sonrisas y lágrimas", 1965, 1966, 8.1, "Robert Wise",
     "Musical / Drama / Familia",
     "En el Austria de 1938, María, una novicia que no encaja en el convento, es enviada como institutriz a casa del capitán Von Trapp, donde cambiará la vida del viudo y sus siete hijos gracias a la música y su carácter vital e incontenible."),
    ("My Fair Lady", 1964, 1965, 7.8, "George Cukor",
     "Musical / Drama / Comedia",
     "El profesor de fonética Henry Higgins apuesta que puede transformar a Eliza Doolittle, una florista cockney de habla vulgar y acento cerrado, en una dama de la alta sociedad de Londres en tan solo seis meses."),
    ("Tom Jones", 1963, 1964, 6.7, "Tony Richardson",
     "Aventura / Comedia / Drama",
     "Las pícaras aventuras de Tom Jones, un joven de origen misterioso en la Inglaterra del siglo XVIII, cuyo buen corazón y encanto natural le llevan de una aventura amorosa a otra mientras busca su verdadera identidad."),
    ("Lawrence de Arabia", 1962, 1963, 8.3, "David Lean",
     "Drama / Aventura / Historia",
     "La historia real del oficial británico T.E. Lawrence, quien en la Primera Guerra Mundial unió a las tribus árabes rebeldes en una campaña guerrillera contra el Imperio Otomano, convirtiéndose en una leyenda del desierto."),
    ("West Side Story", 1961, 1962, 7.3, "Robert Wise, Jerome Robbins",
     "Musical / Drama / Romance",
     "Romeo y Julieta en el Nueva York de los años 50: Tony de los Jets y María de los Sharks se enamoran a pesar de la violenta rivalidad entre sus respectivas bandas de inmigrantes en el Upper West Side de Manhattan."),
    ("El apartamento", 1960, 1961, 8.4, "Billy Wilder",
     "Comedia / Drama / Romance",
     "C.C. Baxter, un oficinista en Nueva York, presta su apartamento a sus jefes casados para sus aventuras amorosas esperando ascensos. Todo se complica cuando se enamora de la chica de su jefe más importante."),
    ("Ben-Hur", 1959, 1960, 8.1, "William Wyler",
     "Drama / Acción / Aventura",
     "Judá Ben-Hur, un príncipe judío en la Judea del siglo I, es traicionado por su amigo romano y condenado a galeras. Tras años de esclavitud y convertirse en campeón de cuadrigas, regresa para buscar venganza y reencontrar a su familia."),
    ("Gigi", 1958, 1959, 7.1, "Vincente Minnelli",
     "Musical / Comedia / Romance",
     "En el París de la Belle Époque, la joven Gigi es educada por su familia para convertirse en una elegante cortesana. Sin embargo, su amigo de la infancia Gaston, el soltero más codiciado de París, descubre que la ama de verdad."),
    ("El puente sobre el río Kwai", 1957, 1958, 8.1, "David Lean",
     "Drama / Bélico / Aventura",
     "Prisioneros de guerra británicos son obligados por sus captores japoneses a construir un puente ferroviario estratégico en la jungla birmana. El coronel Nicholson cumple la orden por honor militar mientras los Aliados planean sabotear el puente."),
    ("La vuelta al mundo en 80 días", 1956, 1957, 6.9, "Michael Anderson",
     "Aventura / Comedia",
     "El excéntrico y flemático Phileas Fogg apuesta todo su capital a que puede circunnavegar el globo en exactamente ochenta días. Acompañado de su fiel criado Passepartout, emprende una carrera contra el tiempo llena de aventuras y obstáculos."),
    ("Marty", 1955, 1956, 7.7, "Delbert Mann",
     "Drama / Romance",
     "Marty Piletti es un carnicero solitario del Bronx de 34 años que ha renunciado a encontrar pareja. Una noche conoce a Clara, una chica igualmente tímida y sencilla, y por primera vez en su vida siente que podría no estar solo."),
    ("La ley del silencio", 1954, 1955, 8.2, "Elia Kazan",
     "Drama / Crimen",
     "Terry Malloy, un ex boxeador que trabaja en los muelles de Nueva York controlados por la mafia sindical, es testigo del asesinato de un compañero. Atormentado entre la lealtad criminal y su conciencia, decide enfrentarse al sindicato corrupto."),
    ("De aquí a la eternidad", 1953, 1954, 7.6, "Fred Zinnemann",
     "Drama / Romance / Bélico",
     "En una base militar americana en Hawái en 1941, las tensiones entre soldados, sus sargentos y sus amores se entrelazan en los días previos al ataque japonés a Pearl Harbor que arrastrará a Estados Unidos a la Segunda Guerra Mundial."),
    ("El mayor espectáculo del mundo", 1952, 1953, 6.7, "Cecil B. DeMille",
     "Drama / Aventura",
     "El director de un gran circo ambulante debe tomar decisiones difíciles para mantener el negocio a flote durante una temporada completa, mientras lidia con las rivalidades entre sus estrellas y el misterioso payaso que nunca se quita el maquillaje."),
    ("Un americano en París", 1951, 1952, 7.3, "Vincente Minnelli",
     "Musical / Romance / Comedia",
     "Jerry Mulligan, un pintor americano que vive en el París de posguerra gracias a una mecenas adinerada, se debate entre la comodidad de su situación y su amor por Lise, una joven francesa ya comprometida con otro hombre."),
    ("Eva al desnudo", 1950, 1951, 8.2, "Joseph L. Mankiewicz",
     "Drama / Comedia",
     "La prestigiosa actriz de teatro Margo Channing adopta bajo su ala a una fan apasionada llamada Eve Harrington. Poco a poco descubre que la joven es una manipuladora sin escrúpulos dispuesta a robarle su carrera y su vida."),
    ("Todos los hombres del rey", 1949, 1950, 7.4, "Robert Rossen",
     "Drama / Crimen",
     "Willie Stark, un político del sur de Estados Unidos que empieza como honesto defensor del pueblo, asciende al poder corrompido por el mismo. Un periodista que lo ayudó a llegar a la cima debe decidir si puede seguir apoyándole."),
    ("Hamlet", 1948, 1949, 7.7, "Laurence Olivier",
     "Drama",
     "El príncipe danés Hamlet descubre a través del fantasma de su padre que su tío Claudio lo asesinó para usurpar el trono y casarse con su madre. Torturado por las dudas y la indecisión, Hamlet planea lentamente su venganza."),
    ("La barrera invisible", 1947, 1948, 7.2, "Elia Kazan",
     "Drama",
     "Un periodista se hace pasar por judío para escribir un reportaje en profundidad sobre el antisemitismo en América. La experiencia de vivir la discriminación en primera persona transforma su forma de entender el mundo y a quienes le rodean."),
    ("Los mejores años de nuestra vida", 1946, 1947, 8.1, "William Wyler",
     "Drama / Romance",
     "Tres veteranos de la Segunda Guerra Mundial regresan a su ciudad natal americana. Cada uno encuentra dificultades para readaptarse a la vida civil: uno lidia con su matrimonio, otro con su discapacidad, y el tercero con el desempleo."),
    ("Días sin huella", 1945, 1946, 8.0, "Billy Wilder",
     "Drama",
     "Don Birnam, un escritor alcohólico en crisis creativa, viaja con su hermano a los viñedos de California para celebrar su boda. Pero el viaje se convierte en una espiral destructiva cuando Don cae de nuevo en las garras de la bebida."),
    ("Siguiendo mi camino", 1944, 1945, 7.0, "Leo McCarey",
     "Comedia / Musical / Drama",
     "El padre O'Malley, un joven sacerdote moderno y aficionado al béisbol, es enviado a ayudar a una parroquia en apuros de Nueva York. Su método poco convencional choca con el anciano párroco pero juntos logran revitalizar la comunidad."),
    ("Casablanca", 1942, 1944, 8.5, "Michael Curtiz",
     "Drama / Romance / Bélico",
     "Durante la Segunda Guerra Mundial, Rick Blaine regenta un café en la Casablanca francesa. La inesperada llegada de su ex amor Ilsa y su marido, un líder de la resistencia que necesita huir, le obliga a elegir entre el amor y el honor."),
    ("La señora Miniver", 1942, 1943, 7.5, "William Wyler",
     "Drama / Bélico",
     "Kay Miniver, un ama de casa de clase media en un pueblo inglés, ve su vida cotidiana transformada por el estallido de la Segunda Guerra Mundial, que pone a prueba la valentía y la unión de toda su familia y su comunidad."),
    ("¿Cómo era mi valle?", 1941, 1942, 7.8, "John Ford",
     "Drama",
     "A través de los recuerdos nostálgicos de Huw Morgan ya anciano, se narra la vida de su familia minera galesa del siglo XIX: momentos de felicidad, conflictos laborales y la gradual desintegración de un modo de vida que desaparece para siempre."),
    ("Rebecca", 1940, 1941, 8.1, "Alfred Hitchcock",
     "Drama / Misterio / Thriller",
     "Una joven tímida se casa con el aristócrata Maxim de Winter y va a vivir a su imponente mansión inglesa. Allí, la omnipresente sombra de Rebecca, la primera esposa muerta, la oprime y acosa sin piedad mientras oculta un oscuro secreto."),
    ("Lo que el viento se llevó", 1939, 1940, 8.2, "Victor Fleming",
     "Drama / Romance / Historia",
     "La apasionada y voluntariosa Scarlett O'Hara ve su mundo del Sur americano destruido por la Guerra de Secesión. Luchando desesperadamente por salvar su plantación Tara y recuperar al indomable Rhett Butler, muestra una supervivencia legendaria."),
]


def _get_movies_list():
    return [m[0] for m in _OSCAR_WINNERS]


def _get_details(title):
    for m in _OSCAR_WINNERS:
        if m[0] == title:
            return {'film_year': m[1], 'oscar_year': m[2], 'rating': m[3],
                    'director': m[4], 'genre': m[5], 'plot': m[6]}
    return {}


def _u(**kwargs):
    return core_settings.make_url(**kwargs)


def _handle():
    return int(sys.argv[1])


def _cache_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    os.makedirs(profile, exist_ok=True)
    return os.path.join(profile, 'topzilla_oscar_movies_thumbs.json')


def _load_cache():
    path = _cache_path()
    if os.path.exists(path):
        try:
            with open(path, 'r', encoding='utf-8') as fh:
                return json.load(fh)
        except Exception:
            pass
    return {}


def _save_cache(data):
    try:
        path = _cache_path()
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, path)
    except Exception as e:
        xbmc.log("[TopZilla-Oscar] cache save: {0}".format(e), xbmc.LOGWARNING)


def show_oscar(page=1):
    try:
        page = int(page)
    except (ValueError, TypeError):
        page = 1

    h = _handle()

    if page == 1:
        import pelis_grid as _pg
        if _pg.apply_grid_mode(h, 'oscar', "Ganadoras del Oscar"):
            return

    addon = xbmcaddon.Addon()
    ai = addon.getAddonInfo('icon')
    af = core_settings.addon_fanart()

    movies = _get_movies_list()
    total = len(movies)
    start = (page - 1) * _PER_PAGE
    end = start + _PER_PAGE
    page_items = movies[start:end]

    cache = _load_cache()

    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()

    import metadata_enricher as me
    import context_menu, movie_ref

    items_meta = []
    for title in page_items:
        d = _get_details(title)
        items_meta.append((title, d))

    if items_meta:
        first_title = items_meta[0][0]
        first_year  = items_meta[0][1].get('film_year') or None
        has_meta = bool(me.enrich(title=first_title, year=first_year,
                                  media_type='movie', use_cache_only=True))
    else:
        has_meta = False

    if not has_meta:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            "[COLOR yellow][B]Descargar carátulas y reparto desde TMDB[/B][/COLOR]",
            bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': os.path.join(addon.getAddonInfo('path'), 'resources', 'media', 'adv_refrescar.png'), 'fanart': af})
        li.setInfo('video', {'plot': "Descarga carátulas en alta calidad y reparto en español de todas las ganadoras del Oscar a Mejor Película.\n\nSe guarda durante 30 días en caché local.\nProceso paralelo (~5-10 segundos)."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="cache_oscar_movies_covers"), listitem=li, isFolder=False)
    else:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            "[COLOR red][B]Borrar carátulas y reparto descargados[/B][/COLOR]",
            bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': 'DefaultIconError.png', 'fanart': af})
        li.setInfo('video', {'plot': "Elimina los metadatos descargados de TMDB. La sección volverá a usar solo los datos locales (sin carátulas en alta calidad ni reparto)."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="clear_oscar_movies_cache"), listitem=li, isFolder=False)

    for title, d in items_meta:
        film_year  = d.get('film_year', 0)
        oscar_year = d.get('oscar_year', 0)
        rating     = d.get('rating', 0.0)
        director   = d.get('director', '')
        genre      = d.get('genre', '')
        plot_local = d.get('plot', '')

        meta = me.enrich(title=title, year=film_year or None, media_type='movie',
                         use_cache_only=True)

        thumb = (meta.get('poster') if meta else None) or cache.get(title, ai)

        label_text = "[B]{0}  ·  Oscar {1}[/B]".format(title, oscar_year)
        li = xbmcgui.ListItem(label=core_settings.apply_label(label_text, bold=_bold, strip=_strip, color_mode=_color))

        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
        else:
            plot = (
                "[COLOR gold][B]Oscar:[/B][/COLOR] [COLOR deepskyblue]{0}[/COLOR]  |  "
                "[COLOR gold][B]Género:[/B][/COLOR] [COLOR deepskyblue]{1}[/COLOR]  |  "
                "[COLOR gold][B]Año:[/B][/COLOR] [COLOR deepskyblue]{2}[/COLOR]  |  "
                "[COLOR gold][B]IMDb:[/B][/COLOR] [COLOR deepskyblue]{3}[/COLOR]\n"
                "[COLOR gold][B]Director:[/B][/COLOR] [COLOR deepskyblue]{4}[/COLOR]\n\n"
                "{5}"
            ).format(oscar_year, genre, film_year, rating, director, plot_local)
            li.setArt({'thumb': thumb, 'icon': thumb, 'poster': thumb, 'fanart': af})
            li.setInfo('video', {
                'title':    title,
                'plot':     plot,
                'genre':    genre,
                'year':     film_year,
                'rating':   float(rating),
                'director': director,
                'mediatype': 'movie',
            })

        tmdb_id = (meta or {}).get('ids', {}).get('tmdb') if meta else None
        plot_ref = meta.get('overview', '') if meta else plot_local
        ref = movie_ref.make_ref(
            title=title, year=film_year,
            tmdb_id=tmdb_id, poster=thumb,
            media_type='movie', source='oscar_movies', plot=plot_ref,
        )
        context_menu.attach(li, ref)
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(handle=h, url=context_menu.build_play_url(ref), listitem=li, isFolder=False)

    if end < total:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            "[B]Siguiente Página ({0}) >>[/B]".format(page + 1),
            bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': 'DefaultFolder.png', 'fanart': af})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='oscar_movies', page=page + 1),
            listitem=li,
            isFolder=True,
        )

    xbmcplugin.endOfDirectory(h)


def cache_covers():
    if not xbmcgui.Dialog().yesno(
        "TopZilla",
        "¿Descargar carátulas en alta calidad y reparto desde TMDB?\n\n"
        "Tarda ~5-10s. Se guarda durante 30 días.",
    ):
        return

    import metadata_enricher as me

    items = [{'title': m[0], 'year': m[1], 'media_type': 'movie'} for m in _OSCAR_WINNERS]

    pDialog = xbmcgui.DialogProgress()
    pDialog.create("TopZilla", "Descargando metadatos desde TMDB...")
    try:
        count = me.batch_fetch_with_progress(items, pDialog)
    finally:
        pDialog.close()

    xbmcgui.Dialog().notification(
        "TopZilla",
        "Metadatos descargados: {0}/{1}".format(count, len(items)),
        xbmcgui.NOTIFICATION_INFO,
    )
    xbmc.executebuiltin("Container.Refresh")


def clear_cache():
    try:
        _save_cache({})

        import metadata_enricher as me
        items = [{'title': m[0], 'year': m[1], 'media_type': 'movie'} for m in _OSCAR_WINNERS]
        me.delete_items(items)

        xbmcgui.Dialog().notification(
            "TopZilla",
            "Metadatos del Oscar eliminados.",
            xbmcgui.NOTIFICATION_INFO,
            4000,
        )
        xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        xbmc.log("[TopZilla-Oscar] error borrando caché: {0}".format(e), xbmc.LOGWARNING)
