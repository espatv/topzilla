# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""Menús de la cuenta personal de Trakt (Mi Trakt): watchlist, continuar viendo,
recomendaciones e historial. Usa trakt_auth para las llamadas autenticadas.

Caché: NO se cachean en disco los datos personales (watchlist/playback/history/
recomendaciones). Son datos sensibles y de poco volumen, cambian al ver algo y
hacerlo persistir dejaría huella del usuario en el perfil; el coste de pedirlos
en cada apertura es bajo (una request por listado). El enriquecimiento TMDB sí
reusa la caché compartida de metadata_enricher (use_cache_only), que es metadata
pública, no datos del usuario.
"""
import sys

import xbmc
import xbmcgui
import xbmcplugin

import context_menu
import core_settings
import movie_ref
import trakt_auth

_ONBOARDING = (
    "Para usar tu cuenta Trakt: crea una app gratuita en "
    "https://trakt.tv/oauth/applications y pon el Client ID y el Client Secret "
    "en Opciones → Claves API."
)


def _u(**kwargs):
    return core_settings.make_url(**kwargs)


def _handle():
    return int(sys.argv[1])


def _media(filename):
    return core_settings.addon_media(filename)


def _acc():
    return (core_settings.get_acc_force_bold(),
            core_settings.get_acc_strip_symbols(),
            core_settings.get_acc_color_mode())


def _add_entry(h, label, action, icon, plot, is_folder=True):
    bold, strip, color = _acc()
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        label, bold=bold, strip=strip, color_mode=color))
    li.setArt({'icon': icon, 'fanart': core_settings.addon_fanart()})
    if plot:
        li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action=action),
                                listitem=li, isFolder=is_folder)


def show_menu():
    h = _handle()

    if not trakt_auth.is_authorized():
        if not trakt_auth.has_credentials():
            _add_entry(h, "[COLOR yellow][B]Configura tu app de Trakt[/B][/COLOR]",
                       'trakt_personal_onboarding', 'DefaultIconInfo.png',
                       _ONBOARDING, is_folder=False)
        _add_entry(h, "[COLOR limegreen][B]Conectar mi cuenta Trakt[/B][/COLOR]",
                   'trakt_personal_login', 'DefaultAddonService.png',
                   "Inicia sesión con tu cuenta de Trakt mediante un código.",
                   is_folder=False)
        xbmcplugin.endOfDirectory(h)
        return

    entries = [
        ("[B]Mi Watchlist[/B]", 'trakt_personal_watchlist',
         'DefaultPlaylist.png', "Tu lista de pendientes (películas y series)."),
        ("[B]Continuar viendo[/B]", 'trakt_personal_continue',
         'DefaultInProgressShows.png', "Lo que dejaste a medias, con tu progreso."),
        ("[B]Próximos episodios (mis series)[/B]", 'trakt_personal_upnext',
         'DefaultInProgressShows.png', "El siguiente episodio sin ver de las series que sigues."),
        ("[B]Recomendado para mí[/B]", 'trakt_personal_recommended',
         'DefaultVideoPlaylists.png', "Sugerencias personalizadas según tu actividad."),
        ("[B]Mi historial reciente[/B]", 'trakt_personal_history',
         'DefaultRecentlyAddedMovies.png', "Lo último que has marcado como visto."),
    ]
    for label, action, icon, plot in entries:
        _add_entry(h, label, action, icon, plot, is_folder=True)

    _add_entry(h, "[COLOR red][B]Cerrar sesión[/B][/COLOR]",
               'trakt_personal_logout', 'DefaultIconError.png',
               "Desconecta tu cuenta de Trakt de este dispositivo.",
               is_folder=False)
    xbmcplugin.endOfDirectory(h)


def onboarding():
    xbmcgui.Dialog().textviewer("[COLOR yellow]Conectar tu cuenta Trakt[/COLOR]",
                                _ONBOARDING)


def login():
    if not trakt_auth.has_credentials():
        xbmcgui.Dialog().ok("TopZilla", _ONBOARDING)
        return
    if trakt_auth.authorize():
        xbmc.executebuiltin("Container.Refresh")


def logout():
    if xbmcgui.Dialog().yesno("TopZilla", "¿Cerrar la sesión de tu cuenta Trakt?"):
        trakt_auth.sign_out()
        xbmc.executebuiltin("Container.Refresh")


def _normalize(raw, media_filter=None):
    """Aplana la respuesta de Trakt a items {tmdb_id, imdb_id, title, year, overview,
    media_type, progress}. Acepta tanto entradas envueltas ({movie:{...}}/{show:{...}})
    como objetos directos (recommendations). media_filter restringe a 'movie'/'show'."""
    items = []
    for entry in raw or []:
        if not isinstance(entry, dict):
            continue

        media_type = None
        obj = None
        progress = entry.get('progress')
        if 'movie' in entry and isinstance(entry['movie'], dict):
            media_type, obj = 'movie', entry['movie']
        elif 'show' in entry and isinstance(entry['show'], dict):
            media_type, obj = 'show', entry['show']
        elif entry.get('ids'):  # objeto directo (recommendations)
            media_type = 'show' if media_filter == 'show' else 'movie'
            obj = entry
        if not obj:
            continue
        if media_filter and media_type != media_filter:
            continue

        ids = obj.get('ids') or {}
        title = obj.get('title') or ''
        if not title:
            continue
        items.append({
            'tmdb_id':    ids.get('tmdb'),
            'imdb_id':    ids.get('imdb') or '',
            'title':      title,
            'year':       obj.get('year') or 0,
            'overview':   obj.get('overview') or '',
            'media_type': media_type,
            'progress':   progress,
        })
    return items


def _fetch(path, params=None, media_filter=None):
    r = trakt_auth.authed_get(path, params=params)
    if r is None or r.status_code != 200:
        return None
    try:
        raw = r.json()
    except ValueError:
        return None
    if not isinstance(raw, list):
        return []
    return _normalize(raw, media_filter)


def _render(items, title):
    """Pinta los items con enriquecimiento TMDB (mismo patrón que trakt_tops)."""
    import metadata_enricher as me

    h = _handle()
    if items is None:
        xbmcgui.Dialog().notification(
            "TopZilla", "No se pudo cargar tu Trakt", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(h)
        return
    if not items:
        xbmcgui.Dialog().notification(
            "TopZilla", "No hay nada en esta lista", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(h)
        return

    af = core_settings.addon_fanart()
    bold, strip, color = _acc()
    missing_meta = []

    for item in items:
        media = item['media_type']
        year = item['year'] or 0
        label = f"{item['title']} ({year})" if year else item['title']
        prog = item.get('progress')
        if isinstance(prog, (int, float)) and prog > 0:
            label = f"{label}  [COLOR gray]({int(prog)}%)[/COLOR]"
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            label, bold=bold, strip=strip, color_mode=color))

        meta = me.enrich(
            tmdb_id=item['tmdb_id'], imdb_id=item['imdb_id'],
            title=item['title'], year=year or None,
            media_type=media, use_cache_only=True,
        )
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or ''
        else:
            li.setArt({'icon': 'DefaultVideo.png', 'fanart': af})
            li.setInfo('video', {
                'title':     item['title'],
                'year':      year,
                'plot':      item['overview'],
                'mediatype': 'tvshow' if media == 'show' else 'movie',
            })
            poster = ''
            missing_meta.append({
                'tmdb_id':    item['tmdb_id'],
                'imdb_id':    item['imdb_id'],
                'title':      item['title'],
                'year':       year or None,
                'media_type': media,
            })

        tmdb_id = (meta.get('ids') or {}).get('tmdb', item['tmdb_id']) if meta else item['tmdb_id']
        ref = movie_ref.make_ref(
            title=item['title'], year=year or None,
            tmdb_id=tmdb_id, imdb_id=item['imdb_id'],
            poster=poster, media_type=media, source='trakt', plot=item['overview'],
        )
        context_menu.attach(li, ref)
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(
            handle=h, url=context_menu.build_play_url(ref), listitem=li, isFolder=False)

    if missing_meta:
        import threading

        def _bg():
            try:
                if any(me.batch_enrich(missing_meta, max_workers=2)):
                    xbmc.executebuiltin("Container.Refresh")
            except Exception as e:  # hilo daemon: solo loguear, no propagar
                xbmc.log(f"[TopZilla-TP] bg enrich: {e}", xbmc.LOGWARNING)

        threading.Thread(target=_bg, daemon=True).start()

    xbmcplugin.endOfDirectory(h, cacheToDisc=core_settings.remember_list_position())


def show_watchlist():
    movies = _fetch('sync/watchlist/movies', {'extended': 'full'})
    shows = _fetch('sync/watchlist/shows', {'extended': 'full'})
    if movies is None and shows is None:  # ambas peticiones fallaron
        _render(None, "Mi Watchlist")
        return
    _render((movies or []) + (shows or []), "Mi Watchlist")


def show_continue():
    items = _fetch('sync/playback', {'extended': 'full'})
    _render(items, "Continuar viendo")


def show_recommended():
    movies = _fetch('recommendations/movies', {'extended': 'full'}, media_filter='movie')
    shows = _fetch('recommendations/shows', {'extended': 'full'}, media_filter='show')
    if movies is None and shows is None:
        _render(None, "Recomendado para mí")
        return
    _render((movies or []) + (shows or []), "Recomendado para mí")


def show_history():
    items = _fetch('sync/history', {'extended': 'full', 'limit': 40})
    _render(items, "Mi historial reciente")


def show_upnext():
    """Próximos episodios sin ver de las series que sigues. Toma las series vistas
    (ordenadas por última actividad, top 25) y consulta el progreso de cada una
    para sacar su next_episode. Pool acotado para no abusar del rate limit."""
    import concurrent.futures

    r = trakt_auth.authed_get('sync/watched/shows', params={'extended': 'full'})
    if r is None or r.status_code != 200:
        _render(None, "Próximos episodios")
        return
    try:
        raw = r.json()
    except ValueError:
        _render(None, "Próximos episodios")
        return
    shows = [e for e in (raw or []) if isinstance(e, dict) and isinstance(e.get('show'), dict)]
    shows.sort(key=lambda e: e.get('last_watched_at') or '', reverse=True)
    shows = shows[:25]

    def _next(entry):
        show = entry['show']
        ids = show.get('ids') or {}
        tid = ids.get('trakt')
        if not tid:
            return None
        pr = trakt_auth.authed_get(f"shows/{tid}/progress/watched")
        if pr is None or pr.status_code != 200:
            return None
        try:
            nxt = (pr.json() or {}).get('next_episode')
        except ValueError:
            return None
        if not isinstance(nxt, dict):
            return None  # serie al día / terminada: sin próximo episodio
        s, e = nxt.get('season'), nxt.get('number')
        ep_title = nxt.get('title') or ''
        head = f"[COLOR limegreen]▶ Próximo: T{s}E{e}[/COLOR]" + (f" — {ep_title}" if ep_title else "")
        return {
            'tmdb_id':    ids.get('tmdb'),
            'imdb_id':    ids.get('imdb') or '',
            'title':      show.get('title') or '',
            'year':       show.get('year') or 0,
            'overview':   head + "\n\n" + (show.get('overview') or ''),
            'media_type': 'show',
            'progress':   None,
        }

    items = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex:
        for res in ex.map(_next, shows):
            if res:
                items.append(res)
    _render(items, "Próximos episodios de mis series")
