# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""Popup modal que muestra una URL como QR escaneable.

Pensado para "comparte la URL de esta fuente con otro dispositivo": panel con
titulo + URL en texto (para quien no pueda escanear) + imagen QR + cerrar con
OK o Atras. Misma base WindowDialog no-XML que welcome_splash.py / universo.py.
"""
import os
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui

import qr_generator

_ADDON_PATH = xbmcaddon.Addon().getAddonInfo("path")
_MEDIA = os.path.join(_ADDON_PATH, "resources", "media")
_TEX_WHITE = os.path.join(_MEDIA, "white.png")

_ACCENT = "FF3090FF"      # azul de marca (igual que welcome_splash.py / universo.py)


class _QRPopup(xbmcgui.WindowDialog):
    _W, _H = 1280, 720
    _PANEL_W, _PANEL_H = 620, 560
    _PANEL_X = (_W - _PANEL_W) // 2
    _PANEL_Y = (_H - _PANEL_H) // 2

    _C_TITLE = "FFFFFFFF"
    _C_URL = _ACCENT
    _C_HINT = "FF8B949E"

    _ALIGN_CENTER = 0x00000002

    _CLOSE_ACTIONS = (10, 92, 110)   # PREVIOUS_MENU / NAV_BACK / la X del mando

    def __init__(self, title, url, hint="Pulsa OK o Atras para cerrar"):
        super().__init__()
        self._url = url
        self._qr_path = None

        px, py, pw, ph = self._PANEL_X, self._PANEL_Y, self._PANEL_W, self._PANEL_H

        # Panel de fondo via white.png tintado. Si falta la textura, sin panel
        # (degradacion elegante): el texto/QR siguen siendo legibles sobre el menu.
        if os.path.exists(_TEX_WHITE):
            self.addControl(xbmcgui.ControlImage(
                px, py, pw, ph, _TEX_WHITE, colorDiffuse="EE111418",
            ))
        self.addControl(xbmcgui.ControlLabel(
            px, py + 24, pw, 30, title,
            font="font20", textColor=self._C_TITLE, alignment=self._ALIGN_CENTER,
        ))
        self.addControl(xbmcgui.ControlLabel(
            px + 20, py + 64, pw - 40, 28, url,
            font="font14", textColor=self._C_URL, alignment=self._ALIGN_CENTER,
        ))

        qr_size = 380
        self._qr_size = qr_size
        self._qr_x = px + (pw - qr_size) // 2
        self._qr_y = py + 110

        self._fallback_lbl = xbmcgui.ControlLabel(
            self._qr_x, self._qr_y + qr_size // 2 - 14, qr_size, 28,
            "",
            font="font14", textColor=self._C_HINT, alignment=self._ALIGN_CENTER,
        )
        self.addControl(self._fallback_lbl)

        self.addControl(xbmcgui.ControlLabel(
            px, py + ph - 40, pw, 24,
            hint,
            font="font12", textColor=self._C_HINT, alignment=self._ALIGN_CENTER,
        ))

        self._add_qr_image()

    def _add_qr_image(self):
        self._qr_path = qr_generator.generate(self._url)
        if not self._qr_path:
            xbmc.log("[TopZilla/qr] qr_generator devolvio None", xbmc.LOGWARNING)
            self._fallback_lbl.setLabel("No se pudo generar el QR")
            return
        try:
            self.addControl(xbmcgui.ControlImage(
                self._qr_x, self._qr_y, self._qr_size, self._qr_size,
                self._qr_path,
            ))
        except (ValueError, RuntimeError, TypeError) as e:
            xbmc.log(f"[TopZilla/qr] no se pudo cargar el QR: {e}", xbmc.LOGWARNING)
            self._fallback_lbl.setLabel("No se pudo cargar el QR")

    def onAction(self, action):
        if action.getId() in self._CLOSE_ACTIONS:
            self.close()

    def cleanup(self):
        qr_generator.cleanup(self._qr_path)
        self._qr_path = None


def show(title, url):
    """Muestra un QR modal con `title` y `url`. Bloquea hasta que el usuario cierra."""
    if not url:
        return
    dlg = _QRPopup(title, url)
    try:
        dlg.doModal()
    finally:
        dlg.cleanup()
        del dlg


def show_and_wait(title, url, text_event, timeout=300):
    """Muestra el QR modal y espera a que text_event se active o el usuario cancele.

    Cierra el modal automáticamente cuando text_event se activa. Si el usuario
    pulsa Atrás antes de que llegue el texto, devuelve False sin mostrar nada más.

    Devuelve True si text_event se activó, False si el usuario canceló.
    """
    if not url:
        return False

    dlg = _QRPopup(title, url, hint="Atrás para cancelar")
    stop = threading.Event()
    timed_out = threading.Event()

    def _watcher():
        deadline = time.monotonic() + timeout
        while not stop.is_set():
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                if not stop.is_set():
                    timed_out.set()
                    dlg.close()
                return
            if text_event.wait(timeout=min(0.5, remaining)):
                if not stop.is_set():
                    dlg.close()
                return

    t = threading.Thread(target=_watcher, daemon=True)
    t.start()
    try:
        dlg.doModal()
    finally:
        stop.set()
        t.join(timeout=1.5)
        dlg.cleanup()

    if timed_out.is_set():
        xbmcgui.Dialog().notification(
            "TopZilla", "Tiempo agotado",
            xbmcgui.NOTIFICATION_WARNING, 2000,
        )

    return text_event.is_set()
