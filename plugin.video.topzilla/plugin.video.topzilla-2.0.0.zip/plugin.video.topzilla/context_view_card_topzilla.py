# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""
Script invocado por kodi.context.item desde otros addons para abrir la ficha
nativa de TopZilla (diálogo "¿Dónde buscar?") sin añadir a favoritos.
"""
import urllib.parse

import xbmc
import xbmcgui

import movie_ref
from context_add_topzilla import _capture_meta, _try_enrich, _merge

_PLUGIN_URL = "plugin://plugin.video.topzilla/"


def _run():
    meta = _capture_meta()
    if not meta['title']:
        xbmcgui.Dialog().notification(
            'TopZilla',
            'No se encontró un título en este elemento.',
            xbmcgui.NOTIFICATION_WARNING,
            3000,
        )
        return

    original_title = meta['title']
    import remote_input
    text = remote_input.get_text_input('Ver ficha (TopZilla)', original_title).strip()
    if not text:
        return
    meta['title'] = text

    # IDs y año pertenecen al ítem original: si el usuario cambió el título,
    # ya no son válidos y envenenarían el lookup del enrich.
    if text.strip().lower() != original_title.strip().lower():
        meta['tmdb_id'] = None
        meta['imdb_id'] = None
        meta['year'] = None

    enriched = _try_enrich(meta)
    final = _merge(meta, enriched)

    ref = movie_ref.make_ref(
        title=final['title'],
        year=final.get('year'),
        tmdb_id=final.get('tmdb_id'),
        imdb_id=final.get('imdb_id'),
        media_type=final.get('media_type', 'movie'),
        poster=final.get('poster') or '',
        plot=final.get('plot') or '',
        source='context_external_view',
    )
    ref_enc = movie_ref.dumps_ref(ref)
    url = _PLUGIN_URL + '?' + urllib.parse.urlencode(
        {'action': 'show_card_from_context', 'ref': ref_enc})
    xbmc.executebuiltin('RunPlugin({0})'.format(url))


if __name__ == '__main__':
    _run()
