# TopZilla - Mi nube Debrid
# Licencia: GPL-2.0-or-later
"""Vista de "Mi nube" Debrid dentro de Mi biblioteca: listar, reproducir y
borrar lo que el usuario tiene guardado en su cuenta Debrid, más un submenú de
configuración (proveedor y vinculación). La resolución de magnets/hosters para
el catálogo queda fuera de este módulo a propósito: aquí solo se ve la nube.
"""
import os
import sys
import urllib.parse

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

import core_settings
import debrid_resolver

_PROVIDERS = ["AllDebrid", "Real-Debrid", "TorBox", "Premiumize"]

_DOWNLOAD_EXTS = (".mp4", ".mkv", ".avi", ".ts", ".mov", ".wmv", ".webm", ".m4v", ".mpg", ".mpeg")
_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
       "(KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36")


def _u(**kwargs):
    return core_settings.make_url(**kwargs)


def _h():
    return int(sys.argv[1])


def _log(msg, level=xbmc.LOGWARNING):
    xbmc.log("[TopZilla/Debrid] {0}".format(msg), level)


def _label(text):
    return core_settings.apply_label(
        text,
        bold=core_settings.get_acc_force_bold(),
        strip=core_settings.get_acc_strip_symbols(),
        color_mode=core_settings.get_acc_color_mode(),
    )


def _resolver():
    try:
        return debrid_resolver.get_resolver()
    except Exception as e:
        _log("get_resolver: {0}".format(e))
        return None


# --- Orden y filtro de Mi nube (por tamaño / calidad parseada del nombre) ---

_VIEW_FILE = "debrid_view.json"
_SORTS = [("default", "Por defecto"), ("size_desc", "Tamaño ↓"),
          ("size_asc", "Tamaño ↑"), ("name", "Nombre A-Z")]
_QUALITIES = ["Todas", "4K", "1080p", "720p"]


def _parse_quality(name):
    n = (name or "").lower()
    if "2160" in n or "4k" in n or "uhd" in n:
        return "4K"
    if "1080" in n:
        return "1080p"
    if "720" in n:
        return "720p"
    if "480" in n:
        return "480p"
    return "SD"


def _load_view():
    d = core_settings.load_json(_VIEW_FILE, default={})
    if not isinstance(d, dict):
        d = {}
    sort = d.get("sort", "default")
    quality = d.get("quality", "Todas")
    if sort not in [s[0] for s in _SORTS]:
        sort = "default"
    if quality not in _QUALITIES:
        quality = "Todas"
    return sort, quality


def _save_view(sort, quality):
    core_settings.save_json(_VIEW_FILE, {"sort": sort, "quality": quality})


def _apply_view(items, sort, quality):
    """Filtra por calidad y ordena. Pura: testeable sin Kodi."""
    out = [it for it in items if isinstance(it, dict)]
    if quality != "Todas":
        out = [it for it in out if _parse_quality(it.get("filename", "")) == quality]
    if sort == "size_desc":
        out.sort(key=lambda it: it.get("size", 0) or 0, reverse=True)
    elif sort == "size_asc":
        out.sort(key=lambda it: it.get("size", 0) or 0)
    elif sort == "name":
        out.sort(key=lambda it: (it.get("filename", "") or "").lower())
    return out


def set_view():
    sort, quality = _load_view()
    s_idx = xbmcgui.Dialog().select("Ordenar Mi nube por", [s[1] for s in _SORTS])
    if s_idx < 0:
        return
    q_idx = xbmcgui.Dialog().select("Filtrar por calidad", _QUALITIES)
    if q_idx < 0:
        return
    _save_view(_SORTS[s_idx][0], _QUALITIES[q_idx])
    xbmc.executebuiltin("Container.Refresh")


# --- Nube: listar / archivos / reproducir / borrar ---

def cloud_menu():
    """Lista el contenido de la nube del Debrid configurado. Si no hay cuenta
    vinculada, abre el setup en lugar de mostrar una lista vacía."""
    h = _h()
    r = _resolver()
    if r is None or not r.is_authorized():
        setup_menu()
        return

    try:
        items = r.list_library()
    except debrid_resolver.DebridAuthError as e:
        # Token caducado/revocado (típico en Real-Debrid). No borramos credenciales
        # por un fallo puntual: avisamos y abrimos el setup para re-vincular.
        _log("list_library auth: {0}".format(e))
        xbmcgui.Dialog().notification("TopZilla", "Tu cuenta Debrid necesita reconectarse",
                                      xbmcgui.NOTIFICATION_WARNING, 4000)
        setup_menu()
        return
    except Exception as e:
        _log("list_library: {0}".format(e))
        xbmcgui.Dialog().notification("TopZilla", "No se pudo cargar tu nube Debrid",
                                      xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return

    fanart = core_settings.addon_fanart()
    sort, quality = _load_view()

    # Acceso al setup siempre disponible con sesión activa (cambiar proveedor,
    # comprobar cuenta, desconectar): si no, al vincular ya no habría vuelta atrás.
    gear = xbmcgui.ListItem(label=_label("[COLOR deepskyblue]Ajustes de Debrid (cuenta, proveedor)[/COLOR]"))
    gear.setArt({"icon": "DefaultAddonService.png", "fanart": fanart})
    gear.setInfo("video", {"plot": "Cambiar de proveedor, comprobar la cuenta o desconectar."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="debrid_setup"), listitem=gear, isFolder=True)

    sort_label = dict(_SORTS).get(sort, "Por defecto")
    vw = xbmcgui.ListItem(label=_label(
        "[COLOR deepskyblue]Orden y filtro[/COLOR]  [COLOR grey]({0} · {1})[/COLOR]".format(sort_label, quality)))
    vw.setArt({"icon": "DefaultAddonService.png", "fanart": fanart})
    vw.setInfo("video", {"plot": "Ordena Mi nube por tamaño o nombre y filtra por calidad (4K/1080p/720p)."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="debrid_cloud_view"), listitem=vw, isFolder=False)

    if not items:
        li = xbmcgui.ListItem(label=_label("[COLOR grey]Tu nube está vacía[/COLOR]"))
        li.setArt({"icon": "DefaultPlaylist.png", "fanart": fanart})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    items = _apply_view(items, sort, quality)
    if not items:
        li = xbmcgui.ListItem(label=_label(
            "[COLOR grey]Ningún archivo con el filtro actual ({0})[/COLOR]".format(quality)))
        li.setArt({"icon": "DefaultPlaylist.png", "fanart": fanart})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    for it in items:
        size_gb = (it.get("size", 0) or 0) / 1e9
        name = it.get("filename", "?")
        ready = it.get("ready")
        if ready:
            label = "{0}  [COLOR grey]({1:.2f} GB)[/COLOR]".format(name, size_gb)
        else:
            label = "[COLOR grey]{0} ({1})[/COLOR]".format(name, it.get("status", "procesando"))
        li = xbmcgui.ListItem(label=_label(label))
        li.setArt({"icon": "DefaultVideo.png", "fanart": fanart})
        item_id = it.get("id")
        if ready:
            li.setProperty("IsPlayable", "true")
            li.setInfo("video", {"title": name})
            li.addContextMenuItems([
                ("Ver archivos", "Container.Update({0})".format(_u(action="debrid_cloud_files", id=item_id))),
                ("Descargar a disco", "RunPlugin({0})".format(_u(action="debrid_cloud_download", id=item_id, title=name))),
                ("Borrar de la nube", "RunPlugin({0})".format(_u(action="debrid_cloud_delete", id=item_id))),
            ])
            url = _u(action="debrid_cloud_play", id=item_id)
        else:
            url = ""
        xbmcplugin.addDirectoryItem(handle=h, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def cloud_files(item_id):
    """Lista los archivos de vídeo de un elemento concreto de la nube."""
    h = _h()
    r = _resolver()
    if r is None or not item_id:
        xbmcplugin.endOfDirectory(h)
        return
    try:
        files = r.library_files(item_id)
    except Exception as e:
        _log("library_files: {0}".format(e))
        files = []

    fanart = core_settings.addon_fanart()
    if not files:
        li = xbmcgui.ListItem(label=_label("[COLOR grey]Sin archivos de vídeo[/COLOR]"))
        li.setArt({"icon": "DefaultVideo.png", "fanart": fanart})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    for idx, f in enumerate(files):
        size_gb = (f.get("size", 0) or 0) / 1e9
        name = f.get("name", "?")
        li = xbmcgui.ListItem(label=_label("{0}  [COLOR grey]({1:.2f} GB)[/COLOR]".format(name, size_gb)))
        li.setArt({"icon": "DefaultVideo.png", "fanart": fanart})
        li.setProperty("IsPlayable", "true")
        li.setInfo("video", {"title": name})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="debrid_cloud_play", id=item_id, file=idx),
                                    listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def cloud_play(item_id, file_index=None):
    """Resuelve y reproduce un elemento de la nube vía setResolvedUrl.
    En cualquier fallo cierra el handle con False para no dejar el spinner colgado."""
    h = _h()
    r = _resolver()
    if r is None or not item_id:
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        return
    try:
        if file_index in (None, ""):
            stream = r.resolve_library_item(item_id)
        else:
            stream = r.resolve_library_file(item_id, int(file_index))
    except Exception as e:
        _log("resolve play: {0}".format(e))
        stream = None

    if not stream:
        xbmcgui.Dialog().notification("TopZilla", "No se pudo reproducir", xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        return

    li = xbmcgui.ListItem(path=stream)
    li.setContentLookup(False)
    xbmcplugin.setResolvedUrl(h, True, li)


def cloud_delete(item_id):
    if not item_id:
        return
    if not xbmcgui.Dialog().yesno("TopZilla", "¿Borrar este elemento de tu nube Debrid?"):
        return
    r = _resolver()
    if r is None:
        return
    try:
        r.delete_library_item(item_id)
    except Exception as e:
        _log("delete: {0}".format(e))
    xbmc.executebuiltin("Container.Refresh")


# --- Descargar a disco ---

def cloud_download(item_id, title=""):
    """Descarga a disco el enlace directo de un elemento de la nube."""
    r = _resolver()
    if r is None or not item_id:
        return
    try:
        stream = r.resolve_library_item(item_id)
    except Exception as e:
        _log("download resolve: {0}".format(e))
        stream = None
    if not stream:
        xbmcgui.Dialog().notification("TopZilla", "No se pudo resolver para descargar",
                                      xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    dest = _download_dest(title, stream)
    if not dest:
        return
    _download_to_disk(stream, dest, title or "vídeo")


def _download_dest(title, stream_url):
    """Elige carpeta destino (recordando la última, con cancelación fiable) y
    devuelve la ruta final del archivo, o '' si el usuario cancela."""
    addon = xbmcaddon.Addon()
    saved = addon.getSetting("debrid_download_path") or ""
    dest_dir = ""
    if saved and os.path.isdir(saved):
        sel = xbmcgui.Dialog().select("Descargar en…", [saved, "Elegir otra carpeta…"])
        if sel < 0:
            return ""
        if sel == 0:
            dest_dir = saved
    if not dest_dir:
        # Sin default: browse devuelve '' de forma fiable al cancelar. Con un default,
        # Kodi devuelve ese mismo default al cancelar y no se distingue de una elección.
        picked = xbmcgui.Dialog().browse(3, "Guardar la descarga en…", "files", "", False, False)
        if not picked:
            return ""
        dest_dir = picked
    addon.setSetting("debrid_download_path", dest_dir)
    ext = os.path.splitext(urllib.parse.urlparse(stream_url).path)[1].lower()
    if ext not in _DOWNLOAD_EXTS:
        ext = ".mp4"
    safe = "".join(c for c in (title or "") if c.isalnum() or c in " -_").strip()
    if not safe:
        safe = "topzilla_debrid"
    if len(safe) > 120:
        safe = safe[:120].rstrip()
    return os.path.join(dest_dir, "{0}{1}".format(safe, ext))


def _download_to_disk(url, dest, title):
    dp = xbmcgui.DialogProgress()
    dp.create("Descargando", "Conectando: {0}".format(title))
    tmp = dest + ".part"
    cancelled = False
    total = done = 0
    try:
        with requests.get(url, headers={"User-Agent": _UA}, stream=True, timeout=30) as r:
            if r.status_code >= 400:
                raise OSError("El servidor respondió {0}".format(r.status_code))
            total = int(r.headers.get("content-length", 0) or 0)
            with open(tmp, "wb") as f:
                for chunk in r.iter_content(chunk_size=256 * 1024):
                    if dp.iscanceled():
                        cancelled = True
                        break
                    if not chunk:
                        continue
                    f.write(chunk)
                    done += len(chunk)
                    if total > 0:
                        dp.update(int(done * 100 / total),
                                  "{0:.1f} MB / {1:.1f} MB".format(done / 1048576, total / 1048576))
                    else:
                        dp.update(0, "{0:.1f} MB".format(done / 1048576))
    except (OSError, requests.RequestException) as e:
        dp.close()
        _safe_remove(tmp)
        _log("download: {0}".format(e))
        xbmcgui.Dialog().ok("TopZilla", "Error en la descarga:\n{0}".format(str(e)[:200]))
        return
    dp.close()
    if cancelled:
        _safe_remove(tmp)
        return
    if total > 0 and done < total:
        # El servidor cerró la conexión antes de enviar todo: no lo damos por bueno.
        _safe_remove(tmp)
        _log("descarga incompleta: {0}/{1} bytes".format(done, total))
        xbmcgui.Dialog().ok("TopZilla", "La descarga se interrumpió antes de completarse.")
        return
    try:
        os.replace(tmp, dest)
    except OSError as e:
        _safe_remove(tmp)
        _log("download replace: {0}".format(e))
        xbmcgui.Dialog().ok("TopZilla", "No se pudo guardar el archivo:\n{0}".format(str(e)[:200]))
        return
    xbmcgui.Dialog().ok("TopZilla", "Descarga completada:\n{0}".format(dest))


def _safe_remove(path):
    try:
        if os.path.exists(path):
            os.remove(path)
    except OSError:
        pass


# --- Setup: estado, proveedor y vinculación ---

def _status():
    """(provider, authorized, user) sin red. Defensivo."""
    provider = xbmcaddon.Addon().getSetting("debrid_provider") or "AllDebrid"
    try:
        r = debrid_resolver.get_resolver()
        return provider, r.is_authorized(), r.stored_user()
    except Exception:
        return provider, False, ""


def setup_menu():
    h = _h()
    fanart = core_settings.addon_fanart()
    provider, authorized, user = _status()

    def _add(label, action, plot):
        li = xbmcgui.ListItem(label=_label(label))
        li.setArt({"icon": "DefaultAddonService.png", "fanart": fanart})
        li.setInfo("video", {"plot": plot})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action=action), listitem=li, isFolder=False)

    if authorized:
        estado = "[COLOR lime]{0} · {1}[/COLOR]".format(provider, user) if user else "[COLOR lime]{0}[/COLOR]".format(provider)
    else:
        estado = "[COLOR grey]Sin vincular[/COLOR]"
    li = xbmcgui.ListItem(label=_label("Estado: {0}".format(estado)))
    li.setArt({"icon": "DefaultAddonService.png", "fanart": fanart})
    li.setInfo("video", {"plot": "Proveedor activo y cuenta vinculada. Aquí solo se muestra tu nube; "
                                 "la resolución de enlaces del catálogo no forma parte de TopZilla."})
    xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)

    _add("Proveedor: [COLOR deepskyblue]{0}[/COLOR]".format(provider), "debrid_set_provider",
         "Servicio Debrid a usar: AllDebrid, Real-Debrid, TorBox o Premiumize.")

    if not authorized:
        supports_pin = True
        try:
            supports_pin = debrid_resolver.get_resolver().SUPPORTS_PIN
        except Exception:
            pass
        if supports_pin:
            _add("[COLOR limegreen]Vincular cuenta (código PIN)[/COLOR]", "debrid_authorize_pin",
                 "Muestra un código para introducir en la web del proveedor y vincula tu cuenta.")
        _add("[COLOR limegreen]Introducir API Key manualmente[/COLOR]", "debrid_authorize_key",
             "Pega la API key de tu cuenta (la encuentras en la web del proveedor).")
    else:
        _add("Comprobar cuenta", "debrid_account",
             "Consulta el estado de tu cuenta (premium, caducidad).")
        _add("[COLOR lightsalmon]Desconectar cuenta[/COLOR]", "debrid_deauthorize",
             "Elimina la cuenta vinculada de este addon.")

    xbmcplugin.endOfDirectory(h)


def _reset():
    try:
        debrid_resolver.reset_resolver()
    except Exception:
        pass


def setup_set_provider():
    cur = xbmcaddon.Addon().getSetting("debrid_provider") or "AllDebrid"
    pre = _PROVIDERS.index(cur) if cur in _PROVIDERS else 0
    sel = xbmcgui.Dialog().select("Proveedor Debrid", _PROVIDERS, preselect=pre)
    if sel < 0:
        return
    addon = xbmcaddon.Addon()
    addon.setSetting("debrid_provider", _PROVIDERS[sel])
    addon.setSetting("debrid_hosts_cache", "")  # invalida la cache de hosts del anterior
    _reset()
    xbmc.executebuiltin("Container.Refresh")


def setup_authorize_pin():
    try:
        ok = debrid_resolver.get_resolver().authorize_pin()
    except Exception as e:
        xbmcgui.Dialog().ok("Debrid", "Error al vincular:\n{0}".format(e))
        return
    if ok:
        xbmcgui.Dialog().notification("TopZilla", "Cuenta vinculada", xbmcgui.NOTIFICATION_INFO, 2500)
    _reset()
    xbmc.executebuiltin("Container.Refresh")


def setup_authorize_key():
    key = xbmcgui.Dialog().input("API Key del proveedor")
    if not key:
        return
    try:
        ok = debrid_resolver.get_resolver().authorize_apikey(key)
    except Exception as e:
        xbmcgui.Dialog().ok("Debrid", "Error:\n{0}".format(e))
        return
    if ok:
        xbmcgui.Dialog().notification("TopZilla", "Cuenta vinculada", xbmcgui.NOTIFICATION_INFO, 2500)
    _reset()
    xbmc.executebuiltin("Container.Refresh")


def setup_deauthorize():
    if not xbmcgui.Dialog().yesno("Debrid", "¿Desconectar la cuenta de este addon?"):
        return
    try:
        debrid_resolver.get_resolver().deauthorize()
    except Exception:
        pass
    _reset()
    xbmcgui.Dialog().notification("TopZilla", "Cuenta desconectada", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")


def setup_account():
    try:
        info = debrid_resolver.get_resolver().account_info()
    except Exception as e:
        xbmcgui.Dialog().ok("Debrid", "No se pudo consultar la cuenta:\n{0}".format(e))
        return
    estado = "Premium" if info.get("premium") else "No premium"
    expiry = info.get("expiry_text") or ""
    days = info.get("days")
    extra = info.get("extra") or ""
    lineas = ["Usuario: {0}".format(info.get("username", "?")), "Estado: {0}".format(estado)]
    if expiry:
        dtxt = " ({0} días)".format(days) if isinstance(days, int) else ""
        lineas.append("Válida hasta: {0}{1}".format(expiry, dtxt))
    if extra:
        lineas.append(extra)
    xbmcgui.Dialog().ok("Cuenta Debrid", "\n".join(lineas))
