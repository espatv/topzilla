# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""Internet Archive: cine de dominio público reproducible directamente.

Catálogo de películas y documentales de dominio público alojados en
archive.org. Cada resultado es un MP4/OGV/AVI servido directamente por
Internet Archive; se resuelve la URL del mejor archivo de vídeo del item
y se reproduce vía setResolvedUrl.
"""
import json
import os
import sys
import threading
import time
import urllib.parse

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import core_settings

_SEARCH_API   = "https://archive.org/advancedsearch.php"
_METADATA_API = "https://archive.org/metadata/{id}"
_THUMB_URL    = "https://archive.org/services/img/{id}"
_DOWNLOAD_URL = "https://archive.org/download/{id}/{file}"
_TTL          = 6 * 3600
_PAGE_SIZE    = 30
_LOG_TAG      = "[TopZilla-AO]"

_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/138.0.0.0 Safari/537.36"
)
_HEADERS = {
    "User-Agent": _UA,
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Referer": "https://archive.org/",
}

# Colecciones y temáticas de cine de dominio público. Todas restringidas a
# mediatype:movies para excluir audio. La búsqueda se ejecuta en directo contra
# Internet Archive; el catálogo y los resultados no están controlados por el addon.
_CATEGORIES = [
    ("Largometrajes de dominio público",
     "collection:feature_films AND mediatype:movies"),
    ("Ciencia ficción y terror",
     "collection:SciFi_Horror AND mediatype:movies"),
    ("Cine negro / film noir",
     'mediatype:movies AND subject:"film noir"'),
    ("Cine mudo",
     'mediatype:movies AND subject:"silent film"'),
    ("Clásicos (1920-1970)",
     "mediatype:movies AND year:[1920 TO 1970] AND subject:feature"),
    ("Dibujos animados clásicos",
     "collection:classic_cartoons AND mediatype:movies"),
    ("Blender Foundation (animación libre)",
     'creator:"Blender Foundation" AND mediatype:movies'),
    ("Documentales",
     "mediatype:movies AND subject:documentary"),
]

# Prioridad de formatos de vídeo de Archive.org (mejor calidad/compatibilidad primero).
_FORMAT_PRIORITY = [
    'h.264', 'MPEG4', '512Kb MPEG4', '256Kb MPEG4',
    'HiRes MPEG4', 'Ogg Video', 'DivX',
]


def _u(**kwargs):
    return core_settings.make_url(**kwargs)


def _handle():
    return int(sys.argv[1])


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"{_LOG_TAG} {msg}", level)


def _media_icon(name, fallback='DefaultMovies.png'):
    if not name:
        return fallback
    p = os.path.join(
        xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path')),
        'resources', 'media', name,
    )
    return p if os.path.exists(p) else fallback


def _cache_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(profile, 'topzilla_archive_cache.json')


def _load_cache():
    try:
        p = _cache_path()
        if not os.path.exists(p):
            return {}
        with open(p, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _save_cache(data):
    try:
        p = _cache_path()
        os.makedirs(os.path.dirname(p), exist_ok=True)
        # tmp por hilo: dos escrituras concurrentes con el mismo .tmp corromperían el JSON.
        tmp = f"{p}.{threading.get_ident()}.tmp"
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, p)
    except OSError as e:
        _log(f"cache save: {e}", xbmc.LOGWARNING)


def _search(query, page=1):
    cache = _load_cache()
    cache_key = f"{query}|{page}"
    entry = cache.get(cache_key, {})
    if entry.get('items') and (time.time() - entry.get('ts', 0)) < _TTL:
        return entry['items']

    try:
        r = requests.get(
            _SEARCH_API,
            params={
                'q': query,
                'fl[]': ['identifier', 'title', 'year', 'description', 'subject'],
                'sort[]': 'downloads desc',
                'rows': _PAGE_SIZE,
                'page': page,
                'output': 'json',
            },
            headers=_HEADERS,
            timeout=15,
        )
        _log(f"search '{query[:40]}' p{page} -> {r.status_code}")
        if r.status_code != 200:
            stale = entry.get('items')
            if stale:
                _log("búsqueda inaccesible, usando caché caducada", xbmc.LOGWARNING)
                return stale
            return []
        try:
            docs = r.json().get('response', {}).get('docs', [])
        except ValueError:
            return entry.get('items', [])
        items = []
        for d in docs:
            ident = d.get('identifier', '')
            if not ident:
                continue
            title = d.get('title', ident)
            if isinstance(title, list):
                title = title[0] if title else ident
            year = d.get('year', '')
            if isinstance(year, list):
                year = str(year[0]) if year else ''
            desc = d.get('description', '')
            if isinstance(desc, list):
                desc = ' '.join(str(x) for x in desc[:3])
            items.append({
                'id':    ident,
                'title': str(title).strip(),
                'year':  str(year)[:4],
                'plot':  str(desc)[:400],
                'thumb': _THUMB_URL.format(id=ident),
            })
        if items:  # no cachear vacíos (un fallo transitorio envenenaría la query durante el TTL)
            cache[cache_key] = {'ts': time.time(), 'items': items}
            _save_cache(cache)
        return items
    except (requests.RequestException, ValueError) as e:
        _log(f"search error: {e}", xbmc.LOGERROR)
        return entry.get('items', [])


def _best_video_url(identifier):
    """Devuelve URL directa al mejor archivo de vídeo del item, o ''."""
    try:
        r = requests.get(_METADATA_API.format(id=identifier), headers=_HEADERS, timeout=15)
        if r.status_code != 200:
            return ''
        try:
            files = r.json().get('files', [])
        except ValueError:
            return ''

        by_format = {}
        for f in files:
            fmt = f.get('format', '')
            name = f.get('name', '')
            if fmt and name:
                by_format.setdefault(fmt, name)

        for fmt in _FORMAT_PRIORITY:
            if fmt in by_format:
                return _DOWNLOAD_URL.format(
                    id=identifier,
                    file=urllib.parse.quote(by_format[fmt]),
                )

        for f in files:
            name = f.get('name', '')
            if name.lower().endswith(('.mp4', '.ogv', '.avi')):
                return _DOWNLOAD_URL.format(
                    id=identifier,
                    file=urllib.parse.quote(name),
                )
        return ''
    except (requests.RequestException, ValueError) as e:
        _log(f"metadata {identifier}: {e}", xbmc.LOGERROR)
        return ''


def _add_items(h, items, query, page):
    bold  = core_settings.get_acc_force_bold()
    strip = core_settings.get_acc_strip_symbols()
    color = core_settings.get_acc_color_mode()
    fanart = core_settings.addon_fanart()
    for item in items:
        title = item['title']
        label = f"{title} ({item['year']})" if item.get('year') else title
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            label, bold=bold, strip=strip, color_mode=color))
        li.setArt({'icon': 'DefaultMovies.png', 'thumb': item['thumb'],
                   'poster': item['thumb'], 'fanart': fanart})
        li.setInfo('video', {
            'title':     title,
            'year':      int(item['year']) if item.get('year', '').isdigit() else 0,
            'plot':      item['plot'] or "Película de dominio público — Internet Archive.",
            'mediatype': 'movie',
        })
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='archive_play', archive_id=item['id'], title=title),
            listitem=li,
            isFolder=False,
        )
    if len(items) == _PAGE_SIZE:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            "[COLOR limegreen]Página siguiente[/COLOR]", bold=bold, strip=strip, color_mode=color))
        li.setArt({'icon': 'DefaultFolder.png'})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='archive_category', q=query, page=int(page) + 1),
            listitem=li,
            isFolder=True,
        )


def show_menu():
    h = _handle()
    bold  = core_settings.get_acc_force_bold()
    strip = core_settings.get_acc_strip_symbols()
    color = core_settings.get_acc_color_mode()
    fanart = core_settings.addon_fanart()

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR yellow][B]Buscar película...[/B][/COLOR]", bold=bold, strip=strip, color_mode=color))
    li.setArt({'icon': _media_icon('busqueda.png', 'DefaultAddonSearch.png'),
               'fanart': fanart})
    li.setInfo('video', {'plot': "Busca por título en el catálogo de Internet Archive.\n\n[COLOR orange]La búsqueda se realiza al pulsar el botón. Los resultados provienen directamente de Internet Archive y no están controlados ni filtrados por este addon.[/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='archive_search_ui'), listitem=li, isFolder=True)

    disclaimer = "[COLOR orange]Los resultados provienen directamente de Internet Archive, filtrados por la temática de la categoría. El contenido específico de cada resultado no está controlado por este addon.[/COLOR]"
    for label, query in _CATEGORIES:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            label, bold=bold, strip=strip, color_mode=color))
        li.setArt({'icon': 'DefaultMovies.png', 'fanart': fanart})
        li.setInfo('video', {'plot': disclaimer})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='archive_category', q=query, page=1),
            listitem=li,
            isFolder=True,
        )
    xbmcplugin.endOfDirectory(h)


def show_category(query, page=1):
    h = _handle()
    if not query:
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    items = _search(query, page=int(page))
    if not items:
        xbmcgui.Dialog().notification("TopZilla", "Sin resultados en Internet Archive",
                                      xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(h)
        return
    _add_items(h, items, query, page)
    xbmcplugin.endOfDirectory(h)


def search_ui():
    h = _handle()
    import remote_input
    term = remote_input.get_text_input("Buscar en Internet Archive...").strip()
    if not term:
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    q = f'mediatype:movies AND title:({term})'
    items = _search(q)
    if not items:
        xbmcgui.Dialog().notification("TopZilla", "Sin resultados en Internet Archive",
                                      xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    _add_items(h, items, q, 1)
    xbmcplugin.endOfDirectory(h)


def play(archive_id, title=""):
    """Resuelve y reproduce un item de Archive.org vía setResolvedUrl.

    El router (default.py) la invoca para action='archive_play' pasando
    archive_id (identificador del item) y title. Lee su propio handle de
    sys.argv[1], por lo que el handler del router solo debe enrutar la acción
    a esta función; no necesita resolver la URL ni llamar a setResolvedUrl él mismo."""
    h = _handle()
    dp = xbmcgui.DialogProgress()
    dp.create("TopZilla", "Buscando enlace directo en Archive.org...")
    url = _best_video_url(archive_id)
    dp.close()

    if not url:
        xbmcgui.Dialog().notification(
            "TopZilla", "No se encontró vídeo reproducible",
            xbmcgui.NOTIFICATION_ERROR,
        )
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        return

    _log(f"play {archive_id} -> {url[:80]}")
    ext = url.split('?')[0].rsplit('.', 1)[-1].lower()
    mime = {'ogv': 'video/ogg', 'avi': 'video/x-msvideo'}.get(ext, 'video/mp4')
    li = xbmcgui.ListItem(label=title, path=url)
    li.setMimeType(mime)
    li.setContentLookup(False)
    xbmcplugin.setResolvedUrl(h, True, li)
