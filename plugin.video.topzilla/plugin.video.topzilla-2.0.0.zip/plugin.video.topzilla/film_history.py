# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""
Hoy en la historia del cine.

Dataset estático indexado por 'MM-DD'. Cada entrada: (año, texto).
`get_today()` y `get_nearest()` son puras (testeables sin xbmc). Como el dataset
no cubre los 365 días, si hoy no hay efeméride el panel muestra la más cercana del
calendario, para no salir nunca vacío. `show_today()` pinta el diálogo.
"""
import time

import xbmcgui

# Formato: 'MM-DD': [(año, descripción)]
# Fechas = estreno público original en el país de origen (estreno amplio en USA para
# Hollywood; estreno en país de origen para el resto), verificadas con Wikipedia/TMDB.
# Se puede ampliar sin tocar el código.
_EVENTS = {
    "02-26": [(1920, "Se estrena en Berlín 'El gabinete del doctor Caligari', obra fundacional del expresionismo alemán")],
    "03-15": [(1922, "Se estrena en Alemania 'Nosferatu', la primera gran adaptación de Drácula")],
    "03-19": [(1953, "Se televisan por primera vez los premios Óscar (NBC)")],
    "05-01": [(1941, "Orson Welles estrena 'Ciudadano Kane', considerada por muchos la mejor película de la historia")],
    "05-11": [(1988, "Se estrena en Francia 'El gran azul' de Luc Besson")],
    "05-21": [(1980, "Se estrena 'El Imperio Contraataca'")],
    "05-23": [(1980, "Se estrena 'El resplandor' de Stanley Kubrick")],
    "05-25": [(1977, "Se estrena 'La guerra de las galaxias' de George Lucas"),
               (1983, "Se estrena 'El retorno del Jedi'")],
    "06-08": [(1984, "Se estrena 'Los cazafantasmas'")],
    "06-11": [(1922, "Se estrena 'Nanook of the North', considerado el primer gran documental de la historia"),
               (1982, "Se estrena 'E.T. el extraterrestre' de Spielberg")],
    "06-20": [(1974, "Se estrena 'Chinatown' de Roman Polanski"),
               (1975, "Se estrena 'Tiburón' de Spielberg, que inventa el blockbuster de verano")],
    "06-23": [(1989, "Se estrena 'Batman' de Tim Burton")],
    "06-24": [(1994, "Se estrena 'El Rey León' de Disney, la película de animación tradicional más taquillera")],
    "06-29": [(1896, "Los hermanos Lumière dan su primera proyección pública en EE.UU.")],
    "07-03": [(1996, "Se estrena 'Independence Day'")],
    "07-06": [(1994, "Se estrena 'Forrest Gump'")],
    "07-18": [(1986, "Se estrena 'Aliens' de James Cameron")],
    "07-22": [(1988, "Se estrena 'Die Hard', que define el thriller de acción")],
    "07-27": [(2001, "Se estrena 'El planeta de los simios' de Tim Burton")],
    "07-29": [(1994, "Se estrena 'La máscara' con Jim Carrey")],
    "09-01": [(1954, "Se estrena 'La ventana indiscreta' de Alfred Hitchcock")],
    "10-14": [(1994, "Se estrena 'Pulp Fiction' de Quentin Tarantino en EE.UU.")],
    "10-25": [(1978, "Se estrena 'Halloween' de John Carpenter")],
    "10-26": [(1984, "Se estrena 'Terminator' de James Cameron")],
    "10-28": [(1994, "Se estrena 'Stargate'")],
    "11-22": [(1995, "Se estrena 'Toy Story', el primer largometraje 100% de animación por ordenador")],
    "11-27": [(1985, "Se estrena 'Rocky IV'")],
    "12-11": [(1987, "Se estrena 'Wall Street' de Oliver Stone")],
    "12-15": [(1978, "Se estrena 'Superman' con Christopher Reeve"),
               (1993, "Se estrena 'La lista de Schindler' de Spielberg")],
    "12-16": [(1988, "Se estrena 'Rain Man'")],
    "12-18": [(2009, "Se estrena 'Avatar' de James Cameron, que rompe todos los récords de taquilla")],
    "12-19": [(1997, "Se estrena 'Titanic' de James Cameron"),
               (2001, "Se estrena 'El señor de los anillos: La comunidad del anillo' de Peter Jackson")],
    "12-20": [(1946, "Se estrena '¡Qué bello es vivir!' de Frank Capra"),
               (1974, "Se estrena 'El padrino, parte II'")],
    "12-25": [(1999, "Se estrena 'El talento de Mr. Ripley'")],
    "12-26": [(1973, "Se estrena 'El exorcista' de William Friedkin")],
}


def get_today(today_str=None):
    """Lista de (año, texto) para la fecha exacta dada o la de hoy ('MM-DD'). Pura."""
    if today_str is None:
        today_str = time.strftime("%m-%d")
    return _EVENTS.get(today_str, [])


def _ordinal(mmdd):
    # Posición aproximada en el año tratando todos los meses como de 31 días. No es
    # el día real (ignora bisiestos y meses cortos), pero preserva el orden, que es
    # lo único que necesita la búsqueda del más cercano.
    return (int(mmdd[:2]) - 1) * 31 + (int(mmdd[3:]) - 1)


def get_nearest(today_str=None):
    """
    Devuelve (fecha_str, eventos, es_hoy). Si hoy hay efeméride(s), es_hoy=True.
    Si no, busca la fecha más cercana del dataset (distancia circular en el
    calendario) para que el panel nunca salga vacío. Pura: testeable sin xbmc.
    """
    if today_str is None:
        today_str = time.strftime("%m-%d")
    if today_str in _EVENTS:
        return today_str, _EVENTS[today_str], True
    if not _EVENTS:
        return today_str, [], True
    t = _ordinal(today_str)
    cycle = 12 * 31

    def _dist(key):
        d = abs(_ordinal(key) - t)
        return min(d, cycle - d)

    nearest = min(_EVENTS, key=lambda k: (_dist(k), _ordinal(k)))
    return nearest, _EVENTS[nearest], False


def _fmt_date(mmdd):
    return "{0}/{1}".format(mmdd[3:], mmdd[:2])


def show_today():
    """Efemérides de hoy; si hoy no hay, la más cercana del calendario."""
    date_str, events, is_today = get_nearest()
    if not events:
        xbmcgui.Dialog().notification(
            "TopZilla", "No hay efemérides en la base de datos.",
            xbmcgui.NOTIFICATION_INFO, 3000)
        return
    if is_today:
        lines = ["[B]Un día como hoy[/B] — {0}\n".format(_fmt_date(date_str))]
    else:
        lines = ["[B]Hoy ({0}) no tiene efeméride registrada.[/B]".format(time.strftime("%d/%m")),
                 "Lo más cercano — {0}:\n".format(_fmt_date(date_str))]
    for year, text in sorted(events):
        lines.append("[B]{0}[/B]  {1}".format(year, text))
    xbmcgui.Dialog().textviewer("Hoy en la historia del cine", "\n".join(lines))
