# Licencia: Consulta el archivo LICENSE para mas detalles.
# Idea: RubénSDFA1laberot
"""Modo Televisión Vintage. Overlay CRT sobre el vídeo en reproducción.

Patrón: WindowXMLDialog + show() (no bloquea el reproductor) gobernado por una
subclase de xbmc.Player. La referencia viva la mantiene el bucle de service.py;
sin ella el GC recolectaría el Player y los callbacks dejarían de dispararse.

Visibilidad de cada capa: Window.Property + condición <visible> en el XML (igual
que ascii_signature.py). No se usa getControl/setVisible porque el control
multiimage del grano no se expone a Python ("Unknown control type").

Un WindowXMLDialog roba el input mientras está abierto; no hay forma nativa de
hacerlo "pasar a través". Por eso, al pulsar un control nos apartamos (cerramos)
y reenviamos la acción al reproductor, y el bucle del servicio reabre el filtro
cuando el usuario deja de tocar los mandos.

self._overlay lo tocan varios hilos (callbacks del Player, onAction y el bucle
del servicio), así que se protege con un lock.
"""
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui

_ADDON = xbmcaddon.Addon()
_ADDON_PATH = _ADDON.getAddonInfo("path")

# Cada efecto se gobierna por una property homónima leída en el <visible> del XML.
_EFFECTS = (
    "crt_sepia", "crt_scanlines", "crt_vignette", "crt_bezel",
    "crt_grain", "crt_rollbar", "crt_flicker",
)

# Acciones de control que apartan el filtro y se reenvían al reproductor. Whitelist
# (lo no listado -ratón, volumen, ruido- se ignora). Nombres tomados del
# ActionTranslator de Kodi, para el builtin Action(nombre, ventana).
_FORWARD = {
    1: "left", 2: "right", 3: "up", 4: "down",
    7: "select", 10: "back", 92: "back",
    11: "info", 12: "pause", 13: "stop",
    24: "osd", 117: "contextmenu",
}

# Los clicks de ratón también apartan el filtro (izq/medio/doble abren los controles;
# der/mantener, el menú contextual). El mover (107), la rueda (104/105) y el
# arrastre (106/109) NO: son ruido y no deben cerrar el filtro.
_MOUSE = {
    100: "osd", 102: "osd", 103: "osd",
    101: "contextmenu", 108: "contextmenu",
}

# Mientras el usuario está en estos diálogos del reproductor no reabrimos el filtro.
_PLAYER_UI = "Window.IsActive(videoosd) | Window.IsActive(seekbar)"
_REOPEN_COOLDOWN_S = 2.0


def _any_effect_enabled():
    return any(_ADDON.getSetting(k) == "true" for k in _EFFECTS)


def _crt_on():
    return _ADDON.getSetting("crt_enabled") == "true" and _any_effect_enabled()


class CrtOverlay(xbmcgui.WindowXMLDialog):
    def onInit(self):
        for key in _EFFECTS:
            self.setProperty(key, "true" if _ADDON.getSetting(key) == "true" else "false")

    def onAction(self, action):
        aid = action.getId()
        name = _FORWARD.get(aid) or _MOUSE.get(aid)
        if name is None:
            return  # ruido (mover ratón, rueda, arrastre, volumen…): no apartamos el filtro
        manager = getattr(self, "_manager", None)
        if manager is not None:
            manager.notify_dismissed()
        self.close()
        xbmc.executebuiltin(f"Action({name},fullscreenvideo)")


class CrtManager(xbmc.Player):
    def __init__(self):
        super().__init__()
        self._overlay = None
        self._lock = threading.Lock()
        self._dismissed_at = 0.0

    def onPlayBackStarted(self):
        # Cierra cualquier overlay residual ANTES de
        # que arranque la nueva reproducción (autoplay del siguiente episodio).
        self._close("onPlayBackStarted")

    def onAVStarted(self):
        # onAVStarted también salta con audio; el filtro solo aplica a vídeo.
        # Un fallo aquí nunca debe afectar al vídeo en curso.
        try:
            if self.isPlayingVideo() and _crt_on():
                self._open("onAVStarted")
        except Exception as e:
            xbmc.log(f"[TopZilla CRT] onAVStarted falló: {e}", xbmc.LOGERROR)

    def onPlayBackStopped(self):
        self._close("onPlayBackStopped")

    def onPlayBackEnded(self):
        self._close("onPlayBackEnded")

    def onPlayBackError(self):
        self._close("onPlayBackError")

    def tick(self):
        # Llamado por el bucle del servicio (~1 s). Cierra si ya no hay vídeo o si
        # el filtro se apagó en caliente; reabre si lo apartó una interacción y el
        # usuario ya no está usando los controles del reproductor.
        try:
            if not self.isPlayingVideo():
                self._close("tick-idle")
                return
            if self._overlay is not None:
                if not _crt_on():
                    self._close("tick-disabled")
                return
            if (_crt_on()
                    and time.monotonic() - self._dismissed_at >= _REOPEN_COOLDOWN_S
                    and not xbmc.getCondVisibility(_PLAYER_UI)):
                self._open("tick-reopen")
        except Exception as e:
            xbmc.log(f"[TopZilla CRT] tick falló: {e}", xbmc.LOGERROR)

    def notify_dismissed(self):
        # El overlay se cerró porque el usuario interactuó. Sellamos el momento
        # ANTES de soltar la referencia; así tick nunca ve el overlay libre con un
        # cooldown ya vencido y reabre justo al apartarlo.
        self._dismissed_at = time.monotonic()
        with self._lock:
            self._overlay = None

    def _open(self, reason):
        with self._lock:
            if self._overlay is not None:
                return
            overlay = CrtOverlay("crt_overlay.xml", _ADDON_PATH, "Default", "1080i")
            overlay._manager = self
            overlay.show()
            self._overlay = overlay  # solo tras un show() correcto
        xbmc.log(f"[TopZilla CRT] overlay ABIERTO ({reason})", xbmc.LOGDEBUG)

    def _close(self, reason=""):
        # Bajo lock, solo un hilo obtiene la referencia y la cierra;
        # cualquier otro ve None. close() se hace fuera del lock.
        with self._lock:
            overlay, self._overlay = self._overlay, None
        if overlay is None:
            return
        try:
            overlay.close()
            xbmc.log(f"[TopZilla CRT] overlay CERRADO ({reason})", xbmc.LOGDEBUG)
        except Exception as e:
            xbmc.log(f"[TopZilla CRT] cierre falló ({reason}): {e}", xbmc.LOGERROR)

    def cleanup(self):
        self._close("cleanup")
