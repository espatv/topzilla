# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""Visor, buscador y exportador del log de Kodi.

Filtra y destaca las líneas del addon (tag "[TopZilla]") y censura tokens/claves
antes de mostrarlas o exportarlas, para no filtrar credenciales en el log.
"""
import base64
import os
import re
import sys
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import core_settings

_LOG_PATH = "special://logpath/kodi.log"


def _u(**kwargs):
    return core_settings.make_url(**kwargs)


def _handle():
    return int(sys.argv[1])


def _is_topzilla_line(line_lower):
    return 'topzilla' in line_lower


# Secretos como parámetro de consulta (?api_key=xxx, &token=xxx, /?apikey=xxx...):
# oculta el valor y conserva el nombre. El \b evita falsos positivos tipo "errorkey=".
_SECRET_QS = re.compile(
    r'(?i)\b(access_token|api_?key|apikey|client_id|client_secret|token|bearer|hdnts|key|password|passwd|secret)=[^&\s"\']+')
# Los mismos campos en JSON ("api_key":"xxx").
_SECRET_JSON = re.compile(
    r'(?i)"(access_token|api_?key|apikey|client_id|client_secret|token|password|secret)"(\s*:\s*)"[^"]*"')
_SECRET_AUTH = re.compile(r'(?i)(Authorization:\s*Bearer\s+)\S+')
# JWT standalone (eyJ...) — tokens Trakt/OAuth que aparecen fuera de JSON o QS.
_SECRET_JWT = re.compile(r'\beyJ[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]*\b')

# Datos personales (rutas con el nombre de usuario, IPs). A diferencia de los
# secretos de arriba, solo se ocultan si el toggle 'log_redact_paths' está activo.
_HOME_DIR = os.path.expanduser('~')
_PATH_WIN = re.compile(r'(?i)([A-Z]:\\Users\\)[^\\\r\n"\'\s]+')
# El lookbehind evita matchear dentro de URLs o de 'special://home/...' (donde el
# segmento tras /home/ es 'addons'/'userdata', no un usuario): solo home reales.
_PATH_NIX = re.compile(r'(?<![:/\w])(/(?:home|Users)/)[^/\r\n"\'\s]+')
_IPV4 = re.compile(
    r'\b(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b')


def _redact_personal(line):
    """Oculta la carpeta del usuario y las IPs. Puede enmascarar algún número
    x.x.x.x que no sea una IP real; en un log es raro y de bajo impacto."""
    if len(_HOME_DIR) > 3:  # evita reemplazar '/' o 'C:\' si expanduser falla
        line = line.replace(_HOME_DIR, '<HOME>')
    line = _PATH_WIN.sub(r'\1***', line)
    line = _PATH_NIX.sub(r'\1***', line)
    line = _IPV4.sub('***.***.***.***', line)
    return line


def sanitize_line(line):
    """Oculta tokens/claves del log para que no se filtren al mostrarlo o exportarlo.
    Las rutas e IPs solo se ocultan si el usuario tiene activa la censura."""
    line = _SECRET_QS.sub(lambda m: m.group(1) + '=***', line)
    line = _SECRET_JSON.sub(lambda m: f'"{m.group(1)}"{m.group(2)}"***"', line)
    line = _SECRET_AUTH.sub(lambda m: m.group(1) + '***', line)
    line = _SECRET_JWT.sub('***', line)
    if core_settings.get_bool_setting('log_redact_paths', True):
        line = _redact_personal(line)
    return line


def _read_lines():
    """Devuelve (lines, log_path) o (None, log_path) si no existe el log."""
    log_path = xbmcvfs.translatePath(_LOG_PATH)
    if not os.path.exists(log_path):
        return None, log_path
    with open(log_path, 'r', encoding='utf-8', errors='replace') as f:
        return f.readlines(), log_path


def view_log():
    try:
        lines, _ = _read_lines()
        if lines is None:
            xbmcgui.Dialog().ok("TopZilla", "No se encontró el archivo de log de Kodi.")
            return
        last_lines = lines[-100:]
        tz_lines = [sanitize_line(l.rstrip()) for l in last_lines if _is_topzilla_line(l.lower())]
        if not tz_lines:
            tz_lines = [sanitize_line(l.rstrip()) for l in last_lines[-30:]]
        xbmcgui.Dialog().textviewer("Log de Kodi (TopZilla)", "\n".join(tz_lines[-50:]))
    except OSError as e:
        xbmcgui.Dialog().ok("Error", "No se pudo leer el log:\n{0}".format(e))


def view_full():
    try:
        lines, _ = _read_lines()
        if lines is None:
            xbmcgui.Dialog().ok("TopZilla", "No se encontró el archivo de log de Kodi.")
            return
        opts   = ["Últimas 50 líneas", "Últimas 100 líneas", "Últimas 200 líneas"]
        counts = [50, 100, 200]
        sel = xbmcgui.Dialog().select("¿Cuántas líneas?", opts)
        if sel < 0:
            return
        xbmcgui.Dialog().textviewer("Log de Kodi (completo)", "".join(sanitize_line(l) for l in lines[-counts[sel]:]))
    except OSError as e:
        xbmcgui.Dialog().ok("Error", "No se pudo leer el log:\n{0}".format(e))


def view_errors():
    try:
        lines, _ = _read_lines()
        if lines is None:
            xbmcgui.Dialog().ok("TopZilla", "No se encontró el archivo de log de Kodi.")
            return
        error_lines = [sanitize_line(l.rstrip()) for l in lines[-500:]
                       if ' error ' in l.lower() or 'warning' in l.lower()
                       or 'exception' in l.lower() or 'traceback' in l.lower()]
        if not error_lines:
            xbmcgui.Dialog().ok("TopZilla", "No se encontraron errores recientes en el log.")
            return
        xbmcgui.Dialog().textviewer("Errores del Log de Kodi", "\n".join(error_lines[-80:]))
    except OSError as e:
        xbmcgui.Dialog().ok("Error", "No se pudo leer el log:\n{0}".format(e))


def search():
    kb = xbmc.Keyboard('', 'Buscar en el log de Kodi')
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        return
    term     = kb.getText().strip().lower()
    term_raw = kb.getText().strip()
    try:
        lines, _ = _read_lines()
        if lines is None:
            xbmcgui.Dialog().ok("TopZilla", "No se encontró el archivo de log.")
            return
        matches = [sanitize_line(l.rstrip()) for l in lines if term in l.lower()]
        if not matches:
            xbmcgui.Dialog().ok("TopZilla", "No se encontró '{0}' en el log.".format(term_raw))
            return
        xbmcgui.Dialog().textviewer(
            "{0} resultados para '{1}'".format(len(matches), term_raw),
            "\n".join(matches[-80:]),
        )
    except OSError as e:
        xbmcgui.Dialog().ok("Error", str(e))


def info():
    try:
        log_path = xbmcvfs.translatePath(_LOG_PATH)
        msg = "[B]Log de Kodi[/B]\n"
        if os.path.exists(log_path):
            size = os.path.getsize(log_path)
            with open(log_path, 'r', encoding='utf-8', errors='replace') as f:
                total_lines = sum(1 for _ in f)
            msg += "Tamaño: {0:.1f} {1}\n".format(
                size / 1048576 if size > 1048576 else size / 1024,
                "MB" if size > 1048576 else "KB",
            )
            msg += "Líneas: {0:,}\n".format(total_lines)
            msg += "Ruta: {0}\n".format(log_path)
        else:
            msg += "No encontrado\n"
        msg += "\n[B]Registro de depuración de Kodi[/B]\n"
        kodi_dbg = xbmc.getCondVisibility("System.GetBool(debug.showloginfo)")
        msg += "Nivel DEBUG: {0}".format("ACTIVADO" if kodi_dbg else "DESACTIVADO")
        xbmcgui.Dialog().textviewer("Información de Logs", msg)
    except OSError as e:
        xbmcgui.Dialog().ok("Error", str(e))


def export():
    try:
        lines, _ = _read_lines()
        if lines is None:
            xbmcgui.Dialog().ok("TopZilla", "No se encontró el archivo de log de Kodi.")
            return
        opts = ["Solo entradas de TopZilla", "Log completo (últimas 500 líneas)", "Solo errores y warnings"]
        sel = xbmcgui.Dialog().select("¿Qué exportar?", opts)
        if sel < 0:
            return
        if sel == 0:
            filtered = [sanitize_line(l) for l in lines if _is_topzilla_line(l.lower())]
            suffix   = "TopZilla"
        elif sel == 1:
            filtered = [sanitize_line(l) for l in lines[-500:]]
            suffix   = "completo"
        else:
            filtered = [sanitize_line(l) for l in lines
                        if ' error ' in l.lower() or 'warning' in l.lower()
                        or 'exception' in l.lower() or 'traceback' in l.lower()]
            suffix = "errores"
        if not filtered:
            xbmcgui.Dialog().ok("TopZilla", "No hay entradas que exportar.")
            return
        d = xbmcgui.Dialog().browse(3, 'Guardar log exportado', 'files')
        if not d:
            return
        fname = "kodi_log_{0}_{1}.txt".format(suffix, time.strftime("%Y%m%d_%H%M%S"))
        dest  = os.path.join(d, fname) if os.path.isdir(d) else (d if d.lower().endswith('.txt') else d + '.txt')
        # browse(3) puede devolver una ruta special://; open() no la entiende.
        dest = xbmcvfs.translatePath(dest)
        with open(dest, 'w', encoding='utf-8') as f:
            f.write("Log exportado por TopZilla -- {0}\n".format(time.strftime('%d/%m/%Y %H:%M:%S')))
            f.write("Tipo: {0}\nLíneas: {1}\n{2}\n\n".format(opts[sel], len(filtered), "=" * 60))
            f.writelines(filtered)
        xbmcgui.Dialog().ok("Exportado", "Log guardado en:\n{0}\n\n{1} líneas exportadas.".format(dest, len(filtered)))
    except OSError as e:
        xbmcgui.Dialog().ok("Error", "No se pudo exportar:\n{0}".format(e))


def view_visual():
    log_path = xbmcvfs.translatePath(_LOG_PATH)
    if not os.path.exists(log_path):
        xbmcgui.Dialog().ok("TopZilla", "No se encontró el archivo de log de Kodi.")
        return
    opts = ["Últimas 50 líneas", "Últimas 100 líneas", "Últimas 200 líneas", "Solo TopZilla", "Solo errores"]
    sel = xbmcgui.Dialog().select("Modo de vista", opts)
    if sel < 0:
        return
    try:
        with open(log_path, 'r', encoding='utf-8', errors='replace') as f:
            all_lines = f.readlines()
    except OSError as e:
        xbmcgui.Dialog().ok("Error", str(e))
        return
    if sel == 0:
        lines = all_lines[-50:]
    elif sel == 1:
        lines = all_lines[-100:]
    elif sel == 2:
        lines = all_lines[-200:]
    elif sel == 3:
        lines = [l for l in all_lines if _is_topzilla_line(l.lower())][-100:]
    else:
        lines = [l for l in all_lines if ' error ' in l.lower() or 'exception' in l.lower() or 'traceback' in l.lower()][-100:]
    if not lines:
        xbmcgui.Dialog().ok("TopZilla", "No hay entradas que mostrar.")
        return
    h = _handle()
    for raw in lines:
        line = sanitize_line(raw.rstrip())
        ll   = line.lower()
        if ' error ' in ll or 'exception' in ll or 'traceback' in ll:
            sev = 'error'
        elif 'warning' in ll:
            sev = 'warning'
        elif _is_topzilla_line(ll):
            sev = 'topzilla'
        elif ' debug ' in ll:
            sev = 'debug'
        else:
            sev = 'info'
        ts_display = ""
        if len(line) > 23 and line[4] == '-' and line[10] == ' ':
            ts_display = line[11:19]
            body = line[23:].strip()
            if body.startswith("T:"):
                idx = body.find(' ')
                if idx > 0:
                    body = body[idx:].strip()
            for tag in ['info <general>:', 'error <general>:', 'warning <general>:', 'debug <general>:', 'notice <general>:']:
                if body.lower().startswith(tag):
                    body = body[len(tag):].strip()
                    break
        else:
            body = line
        label_text = body[:117] + "..." if len(body) > 120 else body
        if sev == 'error':
            label = "[COLOR red][B]X[/B][/COLOR] "
            if ts_display: label += "[COLOR grey]{0}[/COLOR] ".format(ts_display)
            label += "[COLOR red]{0}[/COLOR]".format(label_text)
            icon = 'DefaultIconError.png'
        elif sev == 'warning':
            label = "[COLOR yellow][B]![/B][/COLOR] "
            if ts_display: label += "[COLOR grey]{0}[/COLOR] ".format(ts_display)
            label += "[COLOR yellow]{0}[/COLOR]".format(label_text)
            icon = 'DefaultIconWarning.png'
        elif sev == 'topzilla':
            label = "[COLOR limegreen][B]*[/B][/COLOR] "
            if ts_display: label += "[COLOR grey]{0}[/COLOR] ".format(ts_display)
            label += "[COLOR limegreen]{0}[/COLOR]".format(label_text)
            icon = 'DefaultIconInfo.png'
        elif sev == 'debug':
            label = "[COLOR grey]-"
            if ts_display: label += " {0}".format(ts_display)
            label += " {0}[/COLOR]".format(label_text)
            icon = 'DefaultIconInfo.png'
        else:
            label = "[COLOR white]-[/COLOR] "
            if ts_display: label += "[COLOR grey]{0}[/COLOR] ".format(ts_display)
            label += label_text
            icon = 'DefaultIconInfo.png'
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': icon})
        li.setInfo('video', {'plot': line})
        encoded = base64.b64encode(line.encode('utf-8')).decode('ascii')
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="log_show_line", data=encoded), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)


def show_line(data):
    try:
        xbmcgui.Dialog().textviewer("Detalle del Log", base64.b64decode(data).decode('utf-8'))
    except (ValueError, UnicodeDecodeError):
        xbmcgui.Dialog().ok("Error", "No se pudo decodificar la entrada.")


def loiolog():
    """Abre LoioLog si está instalado; si no, ofrece instalarlo (delegado al instalador)."""
    import espakodi_installer
    espakodi_installer.launch_by_id("plugin.program.loiolog")


def menu():
    h = _handle()
    media_dir = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')

    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()
    _font  = core_settings.get_acc_font_size()
    af = core_settings.addon_fanart()

    def _ico(name, fallback='DefaultIconInfo.png'):
        p = os.path.join(media_dir, name)
        return p if os.path.isfile(p) else fallback

    def _add(label, plot, action, is_folder, icon):
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            label, bold=_bold, strip=_strip, color_mode=_color, font_size=_font))
        li.setArt({'icon': icon, 'fanart': af})
        li.setInfo('video', {'plot': plot})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action=action), listitem=li, isFolder=is_folder)

    _add("[COLOR limegreen]Log de TopZilla (filtrado)[/COLOR]",
         "Muestra las últimas entradas del log de Kodi que mencionan TopZilla.\nTokens y datos sensibles se censuran automáticamente.",
         "log_view_kodi", False, _ico('log_topzilla.png'))
    _add("[COLOR magenta][B]Visor del Log[/B][/COLOR]",
         "Muestra cada línea del log como un elemento visual individual.\nCodificado por colores según severidad:\n\n[COLOR red]X Error[/COLOR]\n[COLOR yellow]! Warning[/COLOR]\n[COLOR limegreen]* TopZilla[/COLOR]\n[COLOR white]- Info[/COLOR]\n[COLOR grey]- Debug[/COLOR]",
         "log_view_visual", True, _ico('log_visor.png'))
    _add("Log de Kodi (completo)",
         "Muestra las últimas líneas del log completo de Kodi, sin filtrar.\nPuedes elegir cuántas líneas ver.",
         "log_view_full", False, _ico('log_kodi.png'))
    _add("[COLOR red]Solo Errores y Warnings[/COLOR]",
         "Filtra el log para mostrar solo líneas de error, warning, exception y traceback.",
         "log_view_errors", False, _ico('log_errores.png'))
    _add("[COLOR cyan]Buscar en el Log[/COLOR]",
         "Escribe un texto para buscar en todo el log de Kodi.\nMuestra todas las líneas que coinciden.",
         "log_search", False, _ico('log_buscar.png'))
    _add("Exportar Log a archivo",
         "Guarda el log filtrado, completo o de errores en un archivo TXT.\nÚtil para compartir o enviar a soporte.",
         "log_export", False, _ico('log_exportar.png'))
    _add("Información del Log",
         "Muestra el tamaño, número de líneas y ruta del log de Kodi, y el estado del registro de depuración.",
         "log_info", False, _ico('log_info.png'))

    if xbmc.getCondVisibility("System.HasAddon(plugin.program.loiolog)"):
        ll_label = "LoioLog: [COLOR green]INSTALADO[/COLOR]"
    else:
        ll_label = "LoioLog: [COLOR grey]NO INSTALADO[/COLOR]"
    _add(ll_label,
         "LoioLog es un gestor avanzado de logs para Kodi.\nPermite ver, filtrar, buscar, analizar y exportar los logs del sistema.\n\nSi no está instalado, pulsa para descargarlo e instalarlo.",
         "log_loiolog", False, _ico('log_loiolog.png', 'DefaultAddonProgram.png'))

    xbmcplugin.endOfDirectory(h)
