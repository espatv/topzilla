# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""Fila "Continuar viendo" del Modo Cine/Grid.

TopZilla no reproduce el catálogo, así que no hay progreso de reproducción propio.
La fila se compone de dos fuentes, deduplicadas por ref_key:
  1. Trakt sync/playback (lo que dejaste a medias en cualquier dispositivo), si la
     cuenta está vinculada. Es la fuente más fiel; va primero.
  2. Reciente local: lo que has marcado como visto en TopZilla.

Mismo formato de salida que movie_favorites.get_movie_favorites: dicts con los campos
que consume el grid, enriquecidos desde la caché de metadatos (sin red).
"""
import movie_ref

_MAX = 30


def _enrich_rec(title, year, tmdb_id, imdb_id, poster, plot, media_type):
    """Construye el dict que consume el grid, completándolo desde la caché TMDB."""
    import metadata_enricher as me

    rec = {
        'title':      title or '',
        'year':       year or '',
        'poster':     poster or '',
        'fanart':     '',
        'rating':     0,
        'genre':      '',
        'director':   '',
        'cast_str':   '',
        'plot':       plot or '',
        'runtime':    0,
        'imdb_id':    imdb_id or '',
        'tmdb_id':    str(tmdb_id or ''),
        'media_type': media_type,
    }
    meta = me.enrich(
        tmdb_id=tmdb_id, imdb_id=imdb_id, title=title,
        year=year or None, media_type=media_type, use_cache_only=True,
    )
    if meta:
        genres = meta.get('genres') or []
        cast = meta.get('cast') or []
        rec['poster']   = meta.get('poster') or rec['poster']
        rec['fanart']   = meta.get('fanart') or ''
        rec['rating']   = meta.get('rating') or 0
        rec['genre']    = ' / '.join(genres[:2]) if genres else ''
        rec['director'] = meta.get('director') or ''
        rec['cast_str'] = ', '.join(
            c.get('name', '') if isinstance(c, dict) else str(c) for c in cast[:3])
        rec['plot']     = meta.get('overview') or rec['plot']
        rec['runtime']  = meta.get('runtime') or 0
        rec['tmdb_id']  = str((meta.get('ids') or {}).get('tmdb') or rec['tmdb_id'])
    return rec


def _trakt_playback(media_type):
    """Items de sync/playback de Trakt para el media_type pedido, o [] si no hay
    cuenta vinculada o la red falla. Best-effort: no propaga errores."""
    import trakt_auth

    if not trakt_auth.is_authorized():
        return []
    try:
        import trakt_personal
        items = trakt_personal._fetch(
            'sync/playback', {'extended': 'full'}, media_filter=media_type)
        return items or []
    except Exception as e:  # red/Trakt: la fila debe seguir con las fuentes locales
        import xbmc
        xbmc.log(f'[TopZilla-CW] trakt playback: {e}', xbmc.LOGWARNING)
        return []


def _local_recent(media_type):
    """Refs marcados como vistos del media_type, más nuevo primero. No se incluye el
    historial de navegación: clicar una ficha para leer su sinopsis no es "ver" algo,
    y mezclarlo desvirtuaría "Continuar viendo"."""
    import watch_history

    refs = sorted(watch_history._load(),
                  key=lambda r: r.get('watched_at') or r.get('added_at') or 0,
                  reverse=True)
    return [r for r in refs if r.get('media_type', 'movie') == media_type]


def has_sources(media_type='movie'):
    """Predicado barato (sin red ni enriquecido) para decidir si mostrar la fila:
    True si hay cuenta Trakt vinculada o algún reciente local del tipo pedido.
    Evita una request de red en build_rows al abrir el Modo Cine.

    Fail-closed: ante cualquier error (p.ej. JSON corrupto) devuelve False y oculta la
    fila, en vez de propagar y romper la apertura del Modo Cine (build_rows es crítico)."""
    try:
        import trakt_auth
        if trakt_auth.is_authorized():
            return True
        return bool(_local_recent(media_type))
    except Exception as e:
        import xbmc
        xbmc.log(f'[TopZilla-CW] has_sources: {e}', xbmc.LOGWARNING)
        return False


def get_continue_watching(media_type='movie'):
    out, seen = [], set()

    for it in _trakt_playback(media_type):
        ref = {'tmdb_id': it.get('tmdb_id'), 'imdb_id': it.get('imdb_id'),
               'media_type': media_type, 'title': it.get('title'), 'year': it.get('year')}
        key = movie_ref.ref_key(ref)
        if not key or key in seen:
            continue
        seen.add(key)
        out.append(_enrich_rec(it.get('title'), it.get('year'), it.get('tmdb_id'),
                               it.get('imdb_id'), '', it.get('overview'), media_type))

    for r in _local_recent(media_type):
        key = movie_ref.ref_key(r)
        if not key or key in seen:
            continue
        seen.add(key)
        out.append(_enrich_rec(r.get('title'), r.get('year'), r.get('tmdb_id'),
                               r.get('imdb_id'), r.get('poster'), r.get('plot'), media_type))
        if len(out) >= _MAX:
            break

    return out[:_MAX]
