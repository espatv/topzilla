# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
"""Arte de alta calidad desde Fanart.tv (opt-in, con la API key del usuario).

Aporta clearlogo y fondos HD que TMDB no siempre tiene. Diseño no-bloqueante: el
catálogo lee SOLO de la caché (instantáneo); lo que falta se pide en segundo plano
con un único worker y, al terminar, se refresca la vista una vez. Sin key/sin
activar, todo degrada a TMDB.

API verificada: webservice.fanart.tv/v3/movies/{tmdb_id} y /v3/tv/{tvdb_id}, con
api_key como query param (campos hdmovielogo/moviebackground/movieposter y
hdtvlogo/showbackground/tvposter). 404 = sin arte; 429 = rate limit.
"""
import queue
import threading
import time

import requests
import xbmc

import core_settings

_BASE = "https://webservice.fanart.tv/v3"
_CACHE_FILE = 'fanart_tv_cache.json'
_TTL = 7 * 24 * 3600       # arte encontrado: 7 días
_NEG_TTL = 24 * 3600       # sin arte (404): reintentar al día siguiente
_LOG = "[TopZilla-FTV]"

_FIELDS = {
    'movie': {'clearlogo': 'hdmovielogo', 'fanart': 'moviebackground', 'poster': 'movieposter'},
    'show':  {'clearlogo': 'hdtvlogo',    'fanart': 'showbackground',  'poster': 'tvposter'},
}

_q = queue.Queue()
_seen = set()           # ids ya encolados en esta ejecución (no re-encolar)
_seen_lock = threading.Lock()
_worker_started = False
_worker_lock = threading.Lock()
_cache_lock = threading.Lock()  # serializa el read-modify-write de la caché de disco
_SEEN_CAP = 5000        # techo del dedupe en memoria (se purga al superarlo)


def enabled():
    return (core_settings.get_bool_setting('fanart_tv_enabled', False)
            and bool(core_settings.get_text_setting('fanart_tv_api_key', '')))


def _canon_mt(mt):
    return 'show' if mt in ('show', 'tv') else 'movie'


def _ext_id(tmdb_id, tvdb_id, mt):
    return str(tvdb_id or '') if mt == 'show' else str(tmdb_id or '')


def _pick(images):
    """Mejor URL de una lista de imágenes Fanart.tv: prefiere es > en > otras, y a
    igualdad de idioma, más 'likes'."""
    best, best_score = '', None
    for img in images or []:
        if not isinstance(img, dict) or not img.get('url'):
            continue
        lang_rank = {'es': 2, 'en': 1}.get(img.get('lang') or '', 0)
        try:
            likes = int(img.get('likes') or 0)
        except (TypeError, ValueError):
            likes = 0
        score = (lang_rank, likes)
        if best_score is None or score > best_score:
            best, best_score = img['url'], score
    return best


def _extract_art(payload, mt):
    """Pura (testeable): saca clearlogo/fanart/poster del JSON de Fanart.tv."""
    fields = _FIELDS[_canon_mt(mt)]
    art = {}
    for kodi_key, ft_key in fields.items():
        url = _pick(payload.get(ft_key))
        if url:
            art[kodi_key] = url
    return art


def cached_art(tmdb_id=None, tvdb_id=None, media_type='movie'):
    """Arte de la caché de disco SOLO (no red). {} si no está o caducó. Instantáneo:
    apto para el hot path de pintado de listas."""
    if not enabled():
        return {}
    mt = _canon_mt(media_type)
    ext = _ext_id(tmdb_id, tvdb_id, mt)
    if not ext:
        return {}
    cache = core_settings.load_json(_CACHE_FILE, default={})
    entry = cache.get(f"{mt}:{ext}") if isinstance(cache, dict) else None
    if not isinstance(entry, dict):
        return {}
    ttl = _TTL if entry.get('art') else _NEG_TTL
    if (time.time() - entry.get('ts', 0)) < ttl:
        return entry.get('art') or {}
    return {}


def fetch_art(tmdb_id=None, tvdb_id=None, media_type='movie'):
    """Arte desde Fanart.tv (caché o red). Cachea el resultado (incl. negativo en
    404). Nunca lanza: ante fallo devuelve la caché previa o {}."""
    if not enabled():
        return {}
    mt = _canon_mt(media_type)
    ext = _ext_id(tmdb_id, tvdb_id, mt)
    if not ext:
        return {}
    key = f"{mt}:{ext}"
    cache = core_settings.load_json(_CACHE_FILE, default={})
    if not isinstance(cache, dict):
        cache = {}
    entry = cache.get(key)
    if isinstance(entry, dict):
        ttl = _TTL if entry.get('art') else _NEG_TTL
        if (time.time() - entry.get('ts', 0)) < ttl:
            return entry.get('art') or {}

    endpoint = 'tv' if mt == 'show' else 'movies'
    try:
        r = requests.get(f"{_BASE}/{endpoint}/{ext}",
                         params={'api_key': core_settings.get_text_setting('fanart_tv_api_key', '')},
                         timeout=8)
    except requests.RequestException as e:
        xbmc.log(f"{_LOG} {key}: {e}", xbmc.LOGWARNING)
        return (entry or {}).get('art') or {}
    if r.status_code == 404:
        _store(key, {})  # cachear negativo (sin arte) con NEG_TTL
        return {}
    if r.status_code != 200:  # 429/5xx: no cachear, conservar lo previo
        return (entry or {}).get('art') or {}
    try:
        payload = r.json()
    except ValueError:
        return (entry or {}).get('art') or {}
    if not isinstance(payload, dict):  # la API siempre devuelve objeto; defensa
        return {}
    art = _extract_art(payload, mt)
    _store(key, art)
    return art


def _store(key, art):
    """Escribe una entrada en la caché con read-modify-write serializado (evita
    lost-update si dos llamadas a fetch_art coinciden)."""
    with _cache_lock:
        cache = core_settings.load_json(_CACHE_FILE, default={})
        if not isinstance(cache, dict):
            cache = {}
        cache[key] = {'ts': int(time.time()), 'art': art}
        core_settings.save_json(_CACHE_FILE, cache)


def request_async(tmdb_id=None, tvdb_id=None, media_type='movie'):
    """Encola un título para prefetch en segundo plano (un solo worker). No bloquea
    el pintado. Al vaciar la cola, refresca el contenedor una vez para mostrar el
    arte recién cacheado."""
    if not enabled():
        return
    mt = _canon_mt(media_type)
    ext = _ext_id(tmdb_id, tvdb_id, mt)
    if not ext:
        return
    marker = f"{mt}:{ext}"
    with _seen_lock:
        if marker in _seen:
            return
        if len(_seen) >= _SEEN_CAP:  # techo: re-permitir (re-fetch sale de caché, barato)
            _seen.clear()
        _seen.add(marker)
    _q.put((tmdb_id, tvdb_id, mt))
    _ensure_worker()


def _ensure_worker():
    global _worker_started
    with _worker_lock:
        if _worker_started:
            return
        _worker_started = True
    threading.Thread(target=_worker, daemon=True).start()


def _worker():
    global _worker_started
    fetched = 0
    while True:
        try:
            tmdb_id, tvdb_id, mt = _q.get(timeout=2)
        except queue.Empty:
            # Cierre del worker bajo el MISMO lock que _ensure_worker, con un último
            # intento de drenar la cola: así un item encolado en la ventana entre el
            # timeout y el reset del flag no queda huérfano (lo coge este worker, o
            # _ensure_worker arranca uno nuevo porque ve _worker_started=False).
            with _worker_lock:
                try:
                    tmdb_id, tvdb_id, mt = _q.get_nowait()
                except queue.Empty:
                    _worker_started = False
                    break
        try:
            if fetch_art(tmdb_id=tmdb_id, tvdb_id=tvdb_id, media_type=mt):
                fetched += 1
        except Exception as e:  # worker daemon: solo loguear
            xbmc.log(f"{_LOG} worker: {e}", xbmc.LOGWARNING)
        finally:
            _q.task_done()
    if fetched:
        xbmc.executebuiltin("Container.Refresh")
