# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
#
# Búsqueda en Odysee (LBRY) sin API key:
#   1) Lighthouse devuelve claim_ids ordenados por relevancia.
#   2) claim_search los hidrata con metadatos (título, miniatura, duración, canal).
#   3) Al reproducir, la API proxy devuelve streaming_url real (igual que yt-dlp).
import hashlib
import json
import os
import sys
import time
import urllib.parse
import urllib.request
import urllib.error

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

_LHSE_URL  = "https://lighthouse.odysee.tv/search?s={0}&size={1}&claimType=file&nsfw=false&free_only=true"
_PROXY_CS  = "https://api.na-backend.odysee.com/api/v1/proxy?m=claim_search"
_PROXY_GET = "https://api.na-backend.odysee.com/api/v1/proxy?m=get"

_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
    "Accept": "application/json",
    "Accept-Language": "es-ES,es;q=0.9,en;q=0.8",
}

_MIME_EXT = {
    "video/mp4": ".mp4", "video/webm": ".webm", "video/ogg": ".ogv",
    "audio/mpeg": ".mp3", "audio/mp4": ".m4a", "audio/ogg": ".ogg",
    "audio/flac": ".flac", "audio/wav": ".wav",
}
_CDN_STREAM = "https://player.odycdn.com/v6/streams/{claim_id}/{sd6}{ext}"
_CDN_HDRS   = urllib.parse.urlencode({"Referer": "https://odysee.com/",
                                       "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                                                     "AppleWebKit/537.36 (KHTML, like Gecko) "
                                                     "Chrome/123.0.0.0 Safari/537.36"})

_CACHE_DIR = xbmcvfs.translatePath(
    "special://userdata/addon_data/plugin.video.topzilla/search_cache/")
_CACHE_TTL = 3600  # segundos


def _cache_get(key):
    path = os.path.join(_CACHE_DIR, key + ".json")
    try:
        if time.time() - os.path.getmtime(path) > _CACHE_TTL:
            return None
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except OSError:
        return None


def _cache_set(key, data):
    try:
        os.makedirs(_CACHE_DIR, exist_ok=True)
        tmp = os.path.join(_CACHE_DIR, key + ".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(tmp, os.path.join(_CACHE_DIR, key + ".json"))
    except OSError:
        pass


def _get_json(url, timeout=15):
    req = urllib.request.Request(url, headers=_HEADERS)
    resp = urllib.request.urlopen(req, timeout=timeout)
    return json.loads(resp.read().decode("utf-8", errors="replace"))


def _post_json(url, payload, timeout=20):
    body = json.dumps(payload).encode("utf-8")
    headers = dict(_HEADERS, **{"Content-Type": "application/json"})
    req = urllib.request.Request(url, data=body, headers=headers, method="POST")
    resp = urllib.request.urlopen(req, timeout=timeout)
    return json.loads(resp.read().decode("utf-8", errors="replace"))


def _lighthouse_ids(query, size=30):
    """Devuelve claim_ids ordenados por relevancia (Lighthouse solo da claimId/name)."""
    data = _get_json(_LHSE_URL.format(urllib.parse.quote_plus(query), size))
    arr = data if isinstance(data, list) else data.get("results", [])
    return [it["claimId"] for it in (arr or [])
            if isinstance(it, dict) and it.get("claimId")]


def _claim_search(claim_ids):
    """Hidrata los claim_ids con metadatos completos en una sola llamada."""
    payload = {
        "jsonrpc": "2.0", "method": "claim_search", "id": 1,
        "params": {"claim_ids": claim_ids, "page": 1,
                   "page_size": len(claim_ids), "no_totals": True},
    }
    data = _post_json(_PROXY_CS, payload)
    return ((data.get("result") or {}).get("items")) or []


def _fmt_duration(secs):
    if not isinstance(secs, int) or secs <= 0:
        return ""
    h, rem = divmod(secs, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


def _parse_claim(c):
    """Extrae campos del claim (metadatos anidados bajo value.*)."""
    if not isinstance(c, dict):
        return None
    name = c.get("name", "")
    claim_id = c.get("claim_id", "")
    if not name or not claim_id:
        return None
    val = c.get("value") or {}
    if val.get("stream_type") not in ("video", "audio"):
        return None  # descartar PDFs, imágenes y otros ficheros no reproducibles
    video = val.get("video") or {}
    source = val.get("source") or {}
    sign = c.get("signing_channel") or {}
    channel = (sign.get("value") or {}).get("title") or sign.get("name", "")
    return {
        "name":        name,
        "claim_id":    claim_id,
        "title":       val.get("title") or name,
        "channel":     channel,
        "thumb":       (val.get("thumbnail") or {}).get("url", ""),
        "duration":    video.get("duration", 0),
        "description": val.get("description", ""),
        "sd_hash":     source.get("sd_hash", ""),
        "media_type":  source.get("media_type", ""),
    }


def search(query):
    query = (query or "").strip()
    if not query:
        return []
    key = "odysee_" + hashlib.md5(query.lower().encode()).hexdigest()[:16]
    cached = _cache_get(key)
    if cached is not None:
        return cached
    ids = _lighthouse_ids(query)
    if not ids:
        return []
    by_id = {}
    for c in _claim_search(ids):
        p = _parse_claim(c)
        if p:
            by_id[p["claim_id"]] = p
    results = [by_id[i] for i in ids if i in by_id]
    _cache_set(key, results)
    return results


def resolve_stream(name, claim_id):
    """Obtiene la streaming_url real via API proxy (mismo método que usa yt-dlp)."""
    uri = f"lbry://{name}#{claim_id}"
    payload = {"jsonrpc": "2.0", "method": "get", "id": 1, "params": {"uri": uri}}
    try:
        data = _post_json(_PROXY_GET, payload)
        url = (data.get("result") or {}).get("streaming_url", "")
        if url:
            return url
    except Exception as e:
        xbmc.log(f"[TopZilla] Odysee get failed: {e}", xbmc.LOGWARNING)
    return ""


def play_item(handle, name, claim_id):
    """Resuelve y reproduce un vídeo de Odysee. Llamado por default.py action=odysee_play."""
    dp = xbmcgui.DialogProgress()
    dp.create("Megabuscador", "Resolviendo stream de Odysee...")
    try:
        streaming_url = resolve_stream(name, claim_id)
        dp.close()
    except Exception as e:
        dp.close()
        xbmc.log(f"[TopZilla] Error resolviendo Odysee: {e}", xbmc.LOGERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        xbmcgui.Dialog().ok("Megabuscador", f"Error al resolver el stream:\n{e}")
        return

    if not streaming_url:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        xbmcgui.Dialog().ok("Megabuscador", "No se pudo obtener la URL de reproducción de Odysee.")
        return

    # El CDN devuelve 401 sin Referer; se adjunta vía sintaxis de cabeceras de Kodi.
    headers = urllib.parse.urlencode({"Referer": "https://odysee.com/",
                                      "User-Agent": _HEADERS["User-Agent"]})
    play_url = f"{streaming_url}|{headers}"
    xbmc.log(f"[TopZilla] Odysee stream: {streaming_url}", xbmc.LOGINFO)
    li = xbmcgui.ListItem(path=play_url)
    xbmcplugin.setResolvedUrl(handle, True, li)


def render_results(handle, query):
    query = (query or "").strip()
    if not query:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    dp = xbmcgui.DialogProgress()
    dp.create("Megabuscador", f"Buscando en Odysee: {query}...")
    try:
        results = search(query)
        dp.close()
    except (urllib.error.URLError, OSError, ValueError) as e:
        dp.close()
        xbmc.log(f"[TopZilla] Error buscando en Odysee: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Megabuscador", f"Error al buscar en Odysee:\n{e}")
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if not results:
        xbmcgui.Dialog().ok("Megabuscador", f"No se encontraron resultados para:\n{query}")
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    addon_url = sys.argv[0]
    xbmcplugin.setContent(handle, 'videos')
    for r in results:
        sd_hash = r.get("sd_hash", "")
        if sd_hash:
            # URL directa al CDN; Kodi no llama al addon al volver, el directorio queda cacheado.
            ext = _MIME_EXT.get(r.get("media_type", ""), "")
            raw_url = _CDN_STREAM.format(claim_id=r["claim_id"], sd6=sd_hash[:6], ext=ext)
            play_url = f"{raw_url}|{_CDN_HDRS}"
        else:
            play_url = addon_url + '?' + urllib.parse.urlencode(
                {'action': 'odysee_play', 'name': r['name'], 'claim_id': r['claim_id']})

        title = r["title"]
        thumb = r["thumb"] or "DefaultMusicVideos.png"

        li = xbmcgui.ListItem(label=title)
        li.setArt({'icon': 'DefaultMusicVideos.png', 'thumb': thumb,
                   'poster': thumb, 'fanart': thumb})
        plot_lines = []
        if r.get("channel"):     plot_lines.append(f"Canal: {r['channel']}")
        dur = _fmt_duration(r.get("duration", 0))
        if dur:                  plot_lines.append(f"Duración: {dur}")
        if r.get("description"): plot_lines.append(r["description"][:200])
        li.setInfo('video', {'plot': "\n".join(plot_lines) or title,
                             'title': title, 'duration': r.get("duration", 0),
                             'mediatype': 'video'})
        li.setProperty('IsPlayable', 'true')
        if sd_hash:
            li.setContentLookup(False)  # URL directa, sin que Kodi intente resolverla como plugin

        xbmcplugin.addDirectoryItem(handle=handle, url=play_url,
                                    listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(handle)
