# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
#
# Ganadores transcritos de Wikipedia (tablas oficiales de cada premio).
# Fuentes y rango de años: ver REPORTE de la integración.
# Emmy: 'year' = año de la CEREMONIA (un título puede repetir, son hechos
# distintos). Globes/BAFTA: 'year' = año de ESTRENO de la película (para que
# TMDB la identifique, igual que en oscar_movies).
import json
import os
import sys

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import core_settings

_PER_PAGE = 50

# Títulos en idioma original: TMDB resuelve la localización es-ES al enriquecer.
# media_type 'show' para series (Emmy), 'movie' para películas (Globes/BAFTA).
_AWARDS = {
    'emmy_drama': {
        'label': "Emmy — Mejor Serie Dramática",
        'icon': 'oscar.png',
        'media_type': 'show',
        'winners': [
            ("Lost", 2005),
            ("24", 2006),
            ("The Sopranos", 2007),
            ("Mad Men", 2008),
            ("Mad Men", 2009),
            ("Mad Men", 2010),
            ("Mad Men", 2011),
            ("Homeland", 2012),
            ("Breaking Bad", 2013),
            ("Breaking Bad", 2014),
            ("Game of Thrones", 2015),
            ("Game of Thrones", 2016),
            ("The Handmaid's Tale", 2017),
            ("Game of Thrones", 2018),
            ("Game of Thrones", 2019),
            ("Succession", 2020),
            ("The Crown", 2021),
            ("Succession", 2022),
            ("Succession", 2023),
            ("Shōgun", 2024),
            ("The Pitt", 2025),
        ],
    },
    'emmy_comedy': {
        'label': "Emmy — Mejor Serie de Comedia",
        'icon': 'oscar.png',
        'media_type': 'show',
        'winners': [
            ("Everybody Loves Raymond", 2005),
            ("The Office", 2006),
            ("30 Rock", 2007),
            ("30 Rock", 2008),
            ("30 Rock", 2009),
            ("Modern Family", 2010),
            ("Modern Family", 2011),
            ("Modern Family", 2012),
            ("Modern Family", 2013),
            ("Modern Family", 2014),
            ("Veep", 2015),
            ("Veep", 2016),
            ("Veep", 2017),
            ("The Marvelous Mrs. Maisel", 2018),
            ("Fleabag", 2019),
            ("Schitt's Creek", 2020),
            ("Ted Lasso", 2021),
            ("Ted Lasso", 2022),
            ("The Bear", 2023),
            ("Hacks", 2024),
            ("The Studio", 2025),
        ],
    },
    'globe_drama': {
        'label': "Globo de Oro — Mejor Película Dramática",
        'icon': 'oscar.png',
        'media_type': 'movie',
        'winners': [
            ("Brokeback Mountain", 2005),
            ("Babel", 2006),
            ("Atonement", 2007),
            ("Slumdog Millionaire", 2008),
            ("Avatar", 2009),
            ("The Social Network", 2010),
            ("The Descendants", 2011),
            ("Argo", 2012),
            ("12 Years a Slave", 2013),
            ("Boyhood", 2014),
            ("The Revenant", 2015),
            ("Moonlight", 2016),
            ("Three Billboards Outside Ebbing, Missouri", 2017),
            ("Bohemian Rhapsody", 2018),
            ("1917", 2019),
            ("Nomadland", 2020),
            ("The Power of the Dog", 2021),
            ("The Fabelmans", 2022),
            ("Oppenheimer", 2023),
            ("The Brutalist", 2024),
        ],
    },
    'globe_comedy': {
        'label': "Globo de Oro — Mejor Película de Comedia o Musical",
        'icon': 'oscar.png',
        'media_type': 'movie',
        'winners': [
            ("Walk the Line", 2005),
            ("Dreamgirls", 2006),
            ("Sweeney Todd: The Demon Barber of Fleet Street", 2007),
            ("Vicky Cristina Barcelona", 2008),
            ("The Hangover", 2009),
            ("The Kids Are All Right", 2010),
            ("The Artist", 2011),
            ("Les Misérables", 2012),
            ("American Hustle", 2013),
            ("The Grand Budapest Hotel", 2014),
            ("The Martian", 2015),
            ("La La Land", 2016),
            ("Lady Bird", 2017),
            ("Green Book", 2018),
            ("Once Upon a Time in Hollywood", 2019),
            ("Borat Subsequent Moviefilm", 2020),
            ("West Side Story", 2021),
            ("The Banshees of Inisherin", 2022),
            ("Poor Things", 2023),
            ("Emilia Pérez", 2024),
        ],
    },
    'bafta_film': {
        'label': "BAFTA — Mejor Película",
        'icon': 'oscar.png',
        'media_type': 'movie',
        'winners': [
            ("The Aviator", 2004),
            ("Brokeback Mountain", 2005),
            ("The Queen", 2006),
            ("Atonement", 2007),
            ("Slumdog Millionaire", 2008),
            # The Hurt Locker: TMDB la fecha en 2008 (estreno Venecia 2008,
            # estreno EE.UU. 2009); usamos 2008 para que TMDB la identifique.
            ("The Hurt Locker", 2008),
            ("The King's Speech", 2010),
            ("The Artist", 2011),
            ("Argo", 2012),
            ("12 Years a Slave", 2013),
            ("Boyhood", 2014),
            ("The Revenant", 2015),
            ("La La Land", 2016),
            ("Three Billboards Outside Ebbing, Missouri", 2017),
            ("Roma", 2018),
            ("1917", 2019),
            ("Nomadland", 2020),
            ("The Power of the Dog", 2021),
            ("All Quiet on the Western Front", 2022),
            ("Oppenheimer", 2023),
            ("Conclave", 2024),
        ],
    },
}

_ORDER = ['emmy_drama', 'emmy_comedy', 'globe_drama', 'globe_comedy', 'bafta_film']


def _u(**kwargs):
    return core_settings.make_url(**kwargs)


def _handle():
    return int(sys.argv[1])


def _cache_path(key):
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    os.makedirs(profile, exist_ok=True)
    return os.path.join(profile, f'topzilla_awards_{key}_thumbs.json')


def _load_cache(key):
    path = _cache_path(key)
    if os.path.exists(path):
        try:
            with open(path, 'r', encoding='utf-8') as fh:
                return json.load(fh)
        except (OSError, ValueError):
            pass
    return {}


def _save_cache(key, data):
    try:
        path = _cache_path(key)
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, path)
    except OSError as e:
        xbmc.log(f"[TopZilla-Awards] cache save: {e}", xbmc.LOGWARNING)


def show_menu():
    h = _handle()
    addon = xbmcaddon.Addon()
    media_dir = os.path.join(addon.getAddonInfo('path'), 'resources', 'media')
    af = core_settings.addon_fanart()

    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()

    for key in _ORDER:
        award = _AWARDS[key]
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            f"[B]{award['label']}[/B]", bold=_bold, strip=_strip, color_mode=_color))
        icon = os.path.join(media_dir, award['icon'])
        li.setArt({'icon': icon, 'thumb': icon, 'fanart': af})
        li.setInfo('video', {'plot': f"Ganadores: {award['label']}. {len(award['winners'])} entradas."})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='awards_category', key=key, page=1),
            listitem=li,
            isFolder=True,
        )

    xbmcplugin.endOfDirectory(h)


def show_award(key, page=1):
    award = _AWARDS.get(key)
    if not award:
        xbmcplugin.endOfDirectory(_handle())
        return

    try:
        page = int(page)
    except (ValueError, TypeError):
        page = 1

    h = _handle()
    media_type = award['media_type']
    winners = award['winners']

    addon = xbmcaddon.Addon()
    ai = addon.getAddonInfo('icon')
    af = core_settings.addon_fanart()

    total = len(winners)
    start = (page - 1) * _PER_PAGE
    end = start + _PER_PAGE
    page_items = winners[start:end]

    cache = _load_cache(key)

    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()

    import metadata_enricher as me
    import context_menu, movie_ref

    if page_items:
        first_title, first_year = page_items[0]
        has_meta = bool(me.enrich(title=first_title, year=first_year,
                                  media_type=media_type, use_cache_only=True))
    else:
        has_meta = False

    if not has_meta:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            "[COLOR yellow][B]Descargar carátulas y reparto desde TMDB[/B][/COLOR]",
            bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': os.path.join(addon.getAddonInfo('path'), 'resources', 'media', 'adv_refrescar.png'), 'fanart': af})
        li.setInfo('video', {'plot': f"Descarga carátulas en alta calidad y reparto en español de todos los ganadores ({award['label']}).\n\nSe guarda durante 30 días en caché local.\nProceso paralelo (~5-10 segundos)."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="cache_awards_covers", key=key), listitem=li, isFolder=False)
    else:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            "[COLOR red][B]Borrar carátulas y reparto descargados[/B][/COLOR]",
            bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': 'DefaultIconError.png', 'fanart': af})
        li.setInfo('video', {'plot': "Elimina los metadatos descargados de TMDB. La sección volverá a usar solo los datos locales (sin carátulas en alta calidad ni reparto)."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="clear_awards_cache", key=key), listitem=li, isFolder=False)

    for title, year in page_items:
        meta = me.enrich(title=title, year=year, media_type=media_type,
                         use_cache_only=True)

        thumb = (meta.get('poster') if meta else None) or cache.get(title, ai)

        label_text = f"[B]{title}  ·  {year}[/B]"
        li = xbmcgui.ListItem(label=core_settings.apply_label(label_text, bold=_bold, strip=_strip, color_mode=_color))

        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
        else:
            li.setArt({'thumb': thumb, 'icon': thumb, 'poster': thumb, 'fanart': af})
            li.setInfo('video', {
                'title': title,
                'plot': f"{award['label']}\nAño: {year}",
                'year': year,
                'mediatype': 'tvshow' if media_type == 'show' else 'movie',
            })

        tmdb_id = (meta or {}).get('ids', {}).get('tmdb') if meta else None
        plot_ref = meta.get('overview', '') if meta else ''
        ref = movie_ref.make_ref(
            title=title, year=year,
            tmdb_id=tmdb_id, poster=thumb,
            media_type=media_type, source='awards', plot=plot_ref,
        )
        context_menu.attach(li, ref)
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(handle=h, url=context_menu.build_play_url(ref), listitem=li, isFolder=False)

    if end < total:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            f"[B]Siguiente Página ({page + 1}) >>[/B]",
            bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': 'DefaultFolder.png', 'fanart': af})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='awards_category', key=key, page=page + 1),
            listitem=li,
            isFolder=True,
        )

    xbmcplugin.endOfDirectory(h)


def _items_for(key):
    award = _AWARDS[key]
    mt = award['media_type']
    # Deduplica por (título, año) porque Emmy repite títulos en años distintos;
    # para descargar metadatos basta una vez por película/serie.
    seen = set()
    items = []
    for title, year in award['winners']:
        ck = (title, year)
        if ck in seen:
            continue
        seen.add(ck)
        items.append({'title': title, 'year': year, 'media_type': mt})
    return items


def cache_covers(key):
    if key not in _AWARDS:
        return
    if not xbmcgui.Dialog().yesno(
        "TopZilla",
        "¿Descargar carátulas en alta calidad y reparto desde TMDB?\n\n"
        "Tarda ~5-10s. Se guarda durante 30 días.",
    ):
        return

    import metadata_enricher as me

    items = _items_for(key)

    pDialog = xbmcgui.DialogProgress()
    pDialog.create("TopZilla", "Descargando metadatos desde TMDB...")
    try:
        count = me.batch_fetch_with_progress(items, pDialog)
    finally:
        pDialog.close()

    xbmcgui.Dialog().notification(
        "TopZilla",
        f"Metadatos descargados: {count}/{len(items)}",
        xbmcgui.NOTIFICATION_INFO,
    )
    xbmc.executebuiltin("Container.Refresh")


def clear_cache(key):
    if key not in _AWARDS:
        return
    try:
        _save_cache(key, {})

        import metadata_enricher as me
        me.delete_items(_items_for(key))

        xbmcgui.Dialog().notification(
            "TopZilla",
            "Metadatos eliminados.",
            xbmcgui.NOTIFICATION_INFO,
            4000,
        )
        xbmc.executebuiltin("Container.Refresh")
    except OSError as e:
        xbmc.log(f"[TopZilla-Awards] error borrando caché: {e}", xbmc.LOGWARNING)
