# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""Entrada de texto remota (movil/PC) por servidor local LAN o relay ntfy."""
import json
import secrets
import socket
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.error import URLError
from urllib.parse import parse_qs, urlparse
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcgui

_PORT_DEFAULT = 8089
_PORT_RANGE = 10
_TIMEOUT_SECONDS = 300          # 5 minutos

_NTFY_DEFAULT_SERVER = "https://ntfy.sh"
_NTFY_TOPIC_PREFIX = "topzilla-"
_NTFY_READ_TIMEOUT = 45         # 1.5x el keepalive de ntfy.sh (~30s): detecta conexion muerta
_NTFY_RECONNECT_DELAY = 3       # backoff entre reconexiones si cae el stream


def _get_mode():
    try:
        return "internet" if xbmcaddon.Addon().getSetting('webremote_mode') == 'Internet' else "lan"
    except (AttributeError, RuntimeError):
        return "lan"


def _get_port_start():
    try:
        val = xbmcaddon.Addon().getSetting('remote_port')
        if val:
            port = int(val)
            if 1024 <= port <= 65535:
                return port
    except (ValueError, RuntimeError):
        pass
    return _PORT_DEFAULT


def _get_secure():
    try:
        return xbmcaddon.Addon().getSetting('remote_secure') == 'true'
    except (AttributeError, RuntimeError):
        return False


def _get_server():
    try:
        val = (xbmcaddon.Addon().getSetting('webremote_server') or '').strip().rstrip('/')
        if val.startswith(("http://", "https://")):
            return val
    except (AttributeError, RuntimeError):
        pass
    return _NTFY_DEFAULT_SERVER


def _get_or_create_topic():
    # El topic actua como secreto: solo quien lo conozca puede enviar a este Kodi.
    try:
        addon = xbmcaddon.Addon()
        topic = addon.getSetting('webremote_topic').strip()
        if not topic:
            topic = _NTFY_TOPIC_PREFIX + secrets.token_hex(8)
            addon.setSetting('webremote_topic', topic)
        return topic
    except (AttributeError, RuntimeError):
        return _NTFY_TOPIC_PREFIX + secrets.token_hex(8)


def _get_local_ip():
    try:
        ip = xbmc.getIPAddress()
        if ip and ip != "127.0.0.1" and not ip.startswith("0."):
            return ip
    except (AttributeError, RuntimeError):
        pass

    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.settimeout(0)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            if ip and ip != "127.0.0.1":
                return ip
        finally:
            s.close()
    except OSError:
        pass

    return None


class _RemoteHandler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        xbmc.log(f"[TopZilla/remote] {fmt % args}", xbmc.LOGDEBUG)

    def _check_token(self):
        if not self.server.secure:
            return True
        t = self.headers.get('X-Remote-Token', '').strip()
        if not t:
            t = parse_qs(urlparse(self.path).query).get('t', [''])[0]
        if not t:
            return False
        return secrets.compare_digest(t, self.server.token)

    def _reject_unauthorized(self):
        body = b'{"error":"No autorizado"}'
        self.send_response(403)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _json_response(self, code, obj):
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.end_headers()
        self.wfile.write(json.dumps(obj, ensure_ascii=False).encode("utf-8"))

    def do_GET(self):
        if not self._check_token():
            self._reject_unauthorized()
            return
        if urlparse(self.path).path in ("/", ""):
            self._serve_html()
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        if not self._check_token():
            self._reject_unauthorized()
            return
        if urlparse(self.path).path == "/send":
            self._handle_send()
        else:
            self.send_response(404)
            self.end_headers()

    def _serve_html(self):
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        if self.server.secure:
            token_script = (
                '<script>'
                'window.__RT__={t};'  # json.dumps -> literal JS seguro (token_urlsafe ya es seguro; defensa en profundidad)
                '(function(){{var _f=window.fetch;window.fetch=function(u,o){{'
                'o=o||{{}};o.headers=Object.assign({{}},o.headers,{{"X-Remote-Token":window.__RT__}});'
                'return _f(u,o);}};}})()'
                '</script>'
            ).format(t=json.dumps(self.server.token))
            page = _HTML_TEXT.replace('</head>', token_script + '</head>', 1)
        else:
            page = _HTML_TEXT
        self.wfile.write(page.encode("utf-8"))

    def _handle_send(self):
        try:
            content_length = int(self.headers.get("Content-Length", 0))
        except (ValueError, TypeError):
            self._json_response(400, {"error": "Content-Length no valido"})
            return
        if content_length == 0 or content_length > 4096:
            self._json_response(400, {"error": "Datos no validos"})
            return

        body = self.rfile.read(content_length)
        try:
            data = json.loads(body.decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError):
            self._json_response(400, {"error": "JSON no valido"})
            return

        text = str(data.get("text") or "").strip()  # str(): tolera JSON con text no-string
        if not text:
            self._json_response(400, {"error": "Campo vacio"})
            return

        self.server.received_text = text
        self.server.text_event.set()
        self._json_response(200, {"ok": True, "message": "Texto recibido."})


class _RemoteServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address, handler_class, secure=False):
        self.received_text = None
        self.text_event = threading.Event()
        self.secure = secure
        self.token = secrets.token_urlsafe(16) if secure else None
        super().__init__(address, handler_class)


def _try_start_server(secure=False):
    port_start = _get_port_start()
    for port in range(port_start, port_start + _PORT_RANGE + 1):
        try:
            return _RemoteServer(("", port), _RemoteHandler, secure=secure), port
        except OSError:
            continue
    return None, 0


def _run_server(title):
    """Levanta el servidor LAN, muestra el QR y espera texto. Devuelve el texto o None."""
    ip = _get_local_ip()
    if not ip:
        xbmcgui.Dialog().ok(
            "TopZilla",
            "No se pudo detectar la IP local.\n\n"
            "Asegurate de estar conectado a una red WiFi o Ethernet."
        )
        return None

    secure = _get_secure()
    server, port = _try_start_server(secure=secure)
    if not server:
        port_start = _get_port_start()
        xbmcgui.Dialog().ok(
            "TopZilla",
            "No se pudo iniciar el servidor.\n\n"
            f"Los puertos {port_start}-{port_start + _PORT_RANGE} estan ocupados."
        )
        return None

    if secure:
        addr = f"http://{ip}:{port}/?t={server.token}"
    else:
        addr = f"http://{ip}:{port}/"
    xbmc.log(f"[TopZilla/remote] Servidor LAN iniciado en {addr}", xbmc.LOGINFO)

    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()

    received = None
    try:
        import qr_dialog
        if qr_dialog.show_and_wait(title, addr, server.text_event, timeout=_TIMEOUT_SECONDS):
            received = server.received_text
    except Exception as e:
        xbmc.log(f"[TopZilla/remote] QR: {e}", xbmc.LOGWARNING)
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=3)

    return received


def _ntfy_stream_thread(server, topic, done_event, holder, stop_event, lock):
    # Conexion de streaming persistente: ntfy mantiene el GET abierto y empuja
    # los mensajes al instante. Un poll repetido agotaria el rate limit anonimo.
    url = f"{server}/{topic}/json"
    while not stop_event.is_set():
        try:
            req = Request(url, headers={"User-Agent": "Kodi/TopZilla"})
            resp = urlopen(req, timeout=_NTFY_READ_TIMEOUT)
            with lock:
                # stop() pudo dispararse mientras open() bloqueaba: cerramos aqui
                # en vez de entrar al loop y bloquear hasta el timeout de lectura.
                if stop_event.is_set():
                    resp.close()
                    return
                holder["resp"] = resp
            try:
                for raw in resp:
                    if stop_event.is_set():
                        return
                    line = raw.decode("utf-8", errors="ignore").strip()
                    if not line:
                        continue
                    try:
                        obj = json.loads(line)
                    except ValueError:
                        continue
                    if not isinstance(obj, dict):
                        continue   # ntfy siempre manda objetos; defensa ante self-hosted anomalo
                    if obj.get("event") != "message":
                        continue
                    msg = (obj.get("message") or "").strip()
                    if msg:
                        holder["result"] = msg
                        done_event.set()
                        return
            finally:
                with lock:
                    holder["resp"] = None
                resp.close()
        except (URLError, OSError) as exc:
            if stop_event.is_set():
                return
            xbmc.log(f"[TopZilla/remote] ntfy stream caido, reintentando: {exc}", xbmc.LOGDEBUG)
        if not stop_event.is_set():
            stop_event.wait(timeout=_NTFY_RECONNECT_DELAY)


def _run_ntfy(title):
    server = _get_server()
    topic = _get_or_create_topic()
    sub_url = f"{server}/{topic}"

    holder = {"resp": None, "result": None}
    done_event = threading.Event()
    stop_event = threading.Event()
    lock = threading.Lock()
    thread = threading.Thread(
        target=_ntfy_stream_thread,
        args=(server, topic, done_event, holder, stop_event, lock),
        daemon=True,
    )
    thread.start()

    xbmc.log(f"[TopZilla/remote] Modo internet escuchando en {sub_url}", xbmc.LOGINFO)

    received = None
    try:
        import qr_dialog
        if qr_dialog.show_and_wait(title, sub_url, done_event, timeout=_TIMEOUT_SECONDS):
            received = holder["result"]
    except Exception as e:
        xbmc.log(f"[TopZilla/remote] QR: {e}", xbmc.LOGWARNING)
    finally:
        stop_event.set()
        with lock:
            resp = holder["resp"]
            holder["resp"] = None
        if resp is not None:
            try:
                resp.close()
            except OSError:
                pass
        thread.join(timeout=5)

    return received


def receive_text(title, mode=None):
    """Pide texto desde movil/PC. mode: 'lan' | 'internet' | None (lee el ajuste).

    Devuelve el texto introducido o None (cancelado o timeout).
    """
    if mode is None:
        mode = _get_mode()
    if mode == "internet":
        received = _run_ntfy(title)
    else:
        received = _run_server(title)
    if received:
        xbmcgui.Dialog().notification(
            "TopZilla", "Texto recibido",
            xbmcgui.NOTIFICATION_INFO, 1500
        )
    return received


def _keyboard(title, default=''):
    # None si se cancela; el texto (posible '') si se confirma.
    kb = xbmc.Keyboard(default or '', title)
    kb.doModal()
    return kb.getText().strip() if kb.isConfirmed() else None


def _resolve_text(title, default):
    """Obtiene texto según el método elegido. Devuelve None si se cancela, o el
    texto (posiblemente '') si se confirma/recibe."""
    try:
        pref = (xbmcaddon.Addon().getSetting('search_input_default') or '').strip()
    except (AttributeError, RuntimeError):
        pref = ''

    if pref in ('Teclado', 'Teclado (mando)', 'Mando'):
        return _keyboard(title, default)
    if pref == 'Servidor local':
        return receive_text(title, mode='lan')
    if pref == 'Servidor online':
        return receive_text(title, mode='internet')

    # 'Preguntar siempre' (o ajuste sin definir): selector cada vez.
    idx = xbmcgui.Dialog().select(title, [
        "Teclado (mando)",
        "Servidor local (móvil/PC en la misma red)",
        "Servidor online (móvil/PC por internet)",
    ])
    if idx < 0:
        return None
    if idx == 0:
        return _keyboard(title, default)
    return receive_text(title, mode='lan' if idx == 1 else 'internet')


def get_text_input(title, default='', allow_clear=False):
    """Punto único para pedir texto (teclado / servidor local / online, según el
    ajuste 'search_input_default'; 'Preguntar siempre' muestra un selector).

    - allow_clear=False (por defecto, búsquedas/nombres): devuelve siempre str;
      '' equivale a cancelado o vacío (el caller hace `if not val`).
    - allow_clear=True (claves API, campos editables): devuelve None si se cancela
      y str (posiblemente '') si se confirma, para poder distinguir "no tocar"
      de "borrar el valor". El caller hace `if val is None: return` y trata '' como borrar."""
    raw = _resolve_text(title, default)
    if allow_clear:
        return raw
    return raw or ''


_HTML_TEXT = """<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<title>TopZilla Remote</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{
  font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
  background:#0d1117;color:#c9d1d9;
  min-height:100vh;display:flex;align-items:flex-start;justify-content:center;
  padding:16px;
}
.card{
  background:#161b22;border:1px solid #30363d;border-radius:12px;
  padding:32px 24px;max-width:480px;width:100%;
  box-shadow:0 8px 32px rgba(0,0,0,.4);
}
h1{
  font-size:1.4em;text-align:center;margin-bottom:6px;
  color:#e6edf3;font-weight:600;
}
.sub{
  text-align:center;color:#8b949e;font-size:.85em;margin-bottom:24px;
}
textarea{
  width:100%;min-height:96px;padding:14px 12px;
  background:#0d1117;color:#c9d1d9;
  border:1px solid #30363d;border-radius:8px;
  font-size:16px;font-family:inherit;outline:none;resize:vertical;
  transition:border-color .2s;
}
textarea:focus{border-color:#58a6ff}
textarea::placeholder{color:#484f58}
.btn{
  display:block;width:100%;padding:14px;margin-top:16px;
  background:#1f6feb;color:#fff;
  border:none;border-radius:8px;
  font-size:1em;font-weight:600;cursor:pointer;
  transition:background .2s;
}
.btn:hover{background:#388bfd}
.btn:active{background:#1f6feb;transform:scale(.98)}
.btn:disabled{background:#21262d;color:#484f58;cursor:not-allowed}
.msg{
  margin-top:14px;padding:10px 14px;border-radius:8px;
  font-size:.9em;text-align:center;display:none;
}
.msg.ok{display:flex;align-items:center;justify-content:center;gap:8px;background:#0d2818;color:#3fb950;border:1px solid #238636}
.msg.err{display:block;background:#2d1117;color:#f85149;border:1px solid #da3633}
.check-svg{width:20px;height:20px;flex-shrink:0}
.check-svg circle{stroke:#3fb950;stroke-width:2;fill:none;stroke-dasharray:52;stroke-dashoffset:52;animation:circ .4s ease forwards}
.check-svg path{stroke:#3fb950;stroke-width:2;fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:20;stroke-dashoffset:20;animation:tick .3s .35s ease forwards}
@keyframes circ{to{stroke-dashoffset:0}}
@keyframes tick{to{stroke-dashoffset:0}}
.footer{
  text-align:center;color:#484f58;font-size:.75em;margin-top:20px;
}
</style>
</head>
<body>
<div class="card">
  <h1>TopZilla Remote</h1>
  <p class="sub">Escribe texto para enviarlo a Kodi</p>
  <textarea id="txt" placeholder="Escribe aqui..." autofocus></textarea>
  <button class="btn" id="send" onclick="enviar()">Enviar a Kodi</button>
  <div class="msg" id="msg"></div>
  <p class="footer">El servidor se cerrara automaticamente tras recibir el texto.</p>
  <p style="text-align:center;color:#484f58;font-size:.7em;margin-top:8px">Concepto: RubenSDFA1laberot</p>
</div>
<script>
function checkSVG(){
  return '<svg class="check-svg" viewBox="0 0 24 24">'
    +'<circle cx="12" cy="12" r="10"/>'
    +'<path d="M7 12.5l3 3 7-7"/></svg>';
}
function enviar(){
  var txt=document.getElementById('txt').value.trim();
  var msg=document.getElementById('msg');
  var btn=document.getElementById('send');
  msg.className='msg';msg.style.display='none';
  if(!txt){
    msg.className='msg err';msg.textContent='Escribe algo';msg.style.display='block';
    return;
  }
  btn.disabled=true;btn.textContent='Enviando...';
  fetch('/send',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({text:txt})
  })
  .then(function(r){return r.json()})
  .then(function(d){
    if(d.ok){
      msg.className='msg ok';
      msg.innerHTML=checkSVG()+'<span>Texto enviado a Kodi</span>';
      btn.textContent='Enviado';
    }else{
      msg.className='msg err';
      msg.textContent=d.error||'Error desconocido';
      btn.disabled=false;btn.textContent='Enviar a Kodi';
    }
    msg.style.display='';
  })
  .catch(function(){
    msg.className='msg err';
    msg.textContent='Error de conexion con Kodi';
    msg.style.display='block';
    btn.disabled=false;btn.textContent='Enviar a Kodi';
  });
}
document.getElementById('txt').addEventListener('keydown',function(e){
  if(e.key==='Enter'&&(e.ctrlKey||e.metaKey)){e.preventDefault();enviar()}
});
</script>
</body>
</html>"""
