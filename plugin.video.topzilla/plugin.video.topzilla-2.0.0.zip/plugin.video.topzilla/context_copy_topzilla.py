# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""
Item de menu contextual: copia el label del item enfocado al portapapeles de
TopZilla (que tambien sincroniza al portapapeles del SO si esta activado).

Flujo inverso al de context_paste_topzilla.py: en vez de PEGAR el portapapeles
en el item enfocado, COPIA el texto visible del item.
"""
import re
import sys

import xbmc
import xbmcgui

import clipboard

_LOG_PREFIX = '[TopZilla.context_copy]'

# Whitelist cerrada de tags BBCode de Kodi (https://kodi.wiki/view/Label_formatting).
# Cerrada para NO comerse texto literal entre corchetes que NO es BBCode, como
# '[REC]' (titulo de peli) o '[Director's Cut]'.
_BBCODE_RE = re.compile(
    r'\[/?(?:B|I|LIGHT|UPPERCASE|LOWERCASE|CAPITALIZE|CR|COLOR|TABS|FONT)'
    r'(?:[ =][^\]]*)?\]',
    re.IGNORECASE,
)

# Placeholders de navegacion que no aportan nada copiar.
_USELESS_LABELS = frozenset(('..', '.', '/'))


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log(f'{_LOG_PREFIX} {msg}', level)


def _strip_bbcode(text):
    return _BBCODE_RE.sub('', text).strip()


def _read_focused_label():
    """Lee el texto del item sobre el que se abrio el menu contextual.

    Prioridad: sys.listitem (snapshot oficial que Kodi pasa al handler) sobre
    InfoLabel del foco actual. sys.listitem es el item canonico; InfoLabel
    puede haber driftado si el cursor se movio tras abrir el menu.
    """
    label = ''
    if hasattr(sys, 'listitem') and sys.listitem:
        try:
            label = sys.listitem.getLabel() or ''
        except (AttributeError, RuntimeError) as e:
            _log(f'sys.listitem.getLabel error: {e}', xbmc.LOGDEBUG)
    if not label:
        label = xbmc.getInfoLabel('ListItem.Label') or ''
    label = _strip_bbcode(label)
    if label in _USELESS_LABELS:
        return ''
    return label


def _run():
    label = _read_focused_label()
    if not label:
        xbmcgui.Dialog().notification(
            'TopZilla', 'Nada que copiar',
            xbmcgui.NOTIFICATION_WARNING, 2000,
        )
        _log('label vacio o inutil, abortando', xbmc.LOGDEBUG)
        return

    clipboard.set(label)
    xbmcgui.Dialog().notification(
        'TopZilla', f'Copiado: {label[:80]}',
        xbmcgui.NOTIFICATION_INFO, 2000,
    )
    _log(f'copiado, len={len(label)}, preview={label[:40]!r}')


if __name__ == '__main__':
    # Red de seguridad: si algo falla en runtime, notificamos al usuario en vez
    # de dejarlo sin feedback con solo un traceback en kodi.log.
    try:
        _run()
    except Exception as e:
        xbmc.log(f'{_LOG_PREFIX} error inesperado: {e}', xbmc.LOGERROR)
        xbmcgui.Dialog().notification(
            'TopZilla', 'Error al copiar',
            xbmcgui.NOTIFICATION_ERROR, 2000,
        )
