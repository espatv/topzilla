# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
"""Sagas y colecciones de cine: las películas de una saga juntas, vía TMDB
collection/{id}. IDs de colección verificados contra themoviedb.org (jun 2026)."""
import json
import os
import sys
import threading
import time

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import context_menu
import core_settings
import movie_ref

_TMDB_BASE = "https://api.themoviedb.org/3"
_IMG_W342  = "https://image.tmdb.org/t/p/w342"
_IMG_ORIG  = "https://image.tmdb.org/t/p/original"
_TTL       = 7 * 24 * 3600  # las sagas cambian poco
_LOG_TAG   = "[TopZilla-COL]"

# (label, collection_id, icon). IDs verificados en themoviedb.org/collection/{id}.
_COLLECTIONS = [
    ("Star Wars",               10,     "saga_starwars.png"),
    ("El Señor de los Anillos", 119,    "saga_lotr.png"),
    ("El Hobbit",               121938, "saga_hobbit.png"),
    ("Harry Potter",            1241,   "saga_harrypotter.png"),
    ("James Bond 007",          645,    "saga_jamesbond.png"),
    ("Fast & Furious",          9485,   "saga_fastfurious.png"),
    ("Misión Imposible",        87359,  "saga_misionimposible.png"),
    ("John Wick",               404609, "saga_johnwick.png"),
    ("Los Vengadores",          86311,  "saga_vengadores.png"),
    ("Los Juegos del Hambre",   131635, "saga_hungergames.png"),
    ("Indiana Jones",           84,     "saga_indianajones.png"),
    ("Jurassic Park",           328,    "saga_jurassicpark.png"),
    ("Toy Story",               10194,  "saga_toystory.png"),
    ("Matrix",                  2344,   "saga_matrix.png"),
    ("Piratas del Caribe",      295,    "saga_piratas.png"),
]


def _u(**kwargs):
    return core_settings.make_url(**kwargs)


def _handle():
    return int(sys.argv[1])


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"{_LOG_TAG} {msg}", level)


def _cache_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(profile, 'topzilla_collections_cache.json')


def _load_cache():
    try:
        p = _cache_path()
        if not os.path.exists(p):
            return {}
        with open(p, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _save_cache(data):
    try:
        p = _cache_path()
        os.makedirs(os.path.dirname(p), exist_ok=True)
        tmp = f"{p}.{threading.get_ident()}.tmp"
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, p)
    except OSError as e:
        _log(f"cache save: {e}", xbmc.LOGWARNING)


def _tmdb_get(path, params):
    api_key = core_settings.get_tmdb_api_key()
    if not api_key:
        return None
    try:
        r = requests.get(f"{_TMDB_BASE}/{path}", params=dict(params, api_key=api_key), timeout=10)
        if r.status_code != 200:
            return None
        return r.json()
    except (requests.RequestException, ValueError) as e:
        _log(f"error {path}: {e}", xbmc.LOGERROR)
        return None


def _fetch_parts(collection_id):
    """Películas de una colección, ordenadas por fecha. Lista de dicts. [] si falla."""
    cache = _load_cache()
    key = str(collection_id)
    entry = cache.get(key, {})
    if entry.get('items') and (time.time() - entry.get('ts', 0)) < _TTL:
        return entry['items']

    data = _tmdb_get(f'collection/{collection_id}', {'language': 'es-ES'})
    if not data:
        return entry.get('items') or []

    parts = data.get('parts') or []
    parts.sort(key=lambda p: (p.get('release_date') or '9999'))
    items = []
    for r in parts:
        title = r.get('title') or r.get('original_title', '')
        if not title:
            continue
        pp, bp = r.get('poster_path') or '', r.get('backdrop_path') or ''
        items.append({
            'tmdb_id': str(r.get('id', '')), 'title': title,
            'year': (r.get('release_date') or '')[:4], 'overview': r.get('overview', ''),
            'rating': r.get('vote_average', 0),
            'poster': f"{_IMG_W342}{pp}" if pp else '',
            'fanart': f"{_IMG_ORIG}{bp}" if bp else '',
        })

    if items:
        cache[key] = {'ts': time.time(), 'items': items}
        _save_cache(cache)
    return items


def show_menu():
    h = _handle()
    bold, strip, color = (core_settings.get_acc_force_bold(),
                          core_settings.get_acc_strip_symbols(), core_settings.get_acc_color_mode())
    af = core_settings.addon_fanart()
    for label, cid, icon in _COLLECTIONS:
        li = xbmcgui.ListItem(label=core_settings.apply_label(label, bold=bold, strip=strip, color_mode=color))
        li.setArt({'icon': core_settings.addon_media(icon), 'fanart': af})
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action='collection_list', collection_id=cid),
            listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def _trigger_bg_enrich(items):
    import metadata_enricher as me

    def _fetch():
        try:
            if any(me.batch_enrich(items, max_workers=2)):
                xbmc.executebuiltin("Container.Refresh")
        except Exception as e:
            _log(f"bg enrich: {e}", xbmc.LOGWARNING)

    threading.Thread(target=_fetch, daemon=True).start()


def show_list(collection_id):
    import pelis_grid as _pg
    if _pg.apply_grid_mode(_handle(), 'collection', 'Saga', collection_id=collection_id):
        return

    import metadata_enricher as me
    h = _handle()
    items = _fetch_parts(collection_id)
    if not items:
        xbmcgui.Dialog().notification("TopZilla", "No se pudo cargar la saga", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(h)
        return

    af = core_settings.addon_fanart()
    bold, strip, color = (core_settings.get_acc_force_bold(),
                          core_settings.get_acc_strip_symbols(), core_settings.get_acc_color_mode())
    missing = []

    for item in items:
        year_int = int(item['year']) if item.get('year', '').isdigit() else 0
        label = f"{item['title']} ({year_int})" if year_int else item['title']
        li = xbmcgui.ListItem(label=core_settings.apply_label(label, bold=bold, strip=strip, color_mode=color))

        meta = me.enrich(tmdb_id=item['tmdb_id'], title=item['title'],
                         year=year_int or None, media_type='movie', use_cache_only=True)
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
        else:
            art = {'icon': 'DefaultVideo.png', 'fanart': item.get('fanart') or af}
            if item['poster']:
                art.update({'thumb': item['poster'], 'poster': item['poster']})
            li.setArt(art)
            info = {'title': item['title'], 'plot': item.get('overview', ''), 'mediatype': 'movie'}
            if year_int:
                info['year'] = year_int
            if item.get('rating'):
                info['rating'] = item['rating']
            li.setInfo('video', info)
            missing.append({'tmdb_id': item.get('tmdb_id'), 'imdb_id': '', 'title': item['title'],
                            'year': year_int or None, 'media_type': 'movie'})

        ref = movie_ref.make_ref(title=item['title'], year=year_int or None,
                                 tmdb_id=item['tmdb_id'], poster=item['poster'],
                                 media_type='movie', source='collection', plot=item.get('overview', ''))
        context_menu.attach(li, ref)
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(handle=h, url=context_menu.build_play_url(ref), listitem=li, isFolder=False)

    if missing:
        _trigger_bg_enrich(missing)
    xbmcplugin.endOfDirectory(h, cacheToDisc=core_settings.remember_list_position())
