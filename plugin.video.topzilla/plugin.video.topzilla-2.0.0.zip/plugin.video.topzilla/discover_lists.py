# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
"""Listas de descubrimiento por década y por género (películas), vía TMDB discover.
No requiere IDs curados: usa rangos de año y los géneros estándar de TMDB."""
import sys
from datetime import datetime

import xbmcgui
import xbmcplugin

import context_menu
import core_settings
import movie_ref

_LIMIT = 40


def _build_decades():
    """Décadas desde la actual hasta los 70, sin huecos. Etiqueta de 2 dígitos para
    el s.XX ('Años 90') y de 4 para el s.XXI ('Años 2020'). Año local basta: solo es
    una etiqueta de década, no un timestamp."""
    current = (datetime.now().year // 10) * 10
    decades = []
    for d in range(current, 1969, -10):
        label = f"Años {d}" if d >= 2000 else f"Años {d % 100:02d}"
        decades.append((label, d, d + 9))
    return decades


# (label, año_inicio, año_fin)
_DECADES = _build_decades()

# Géneros de PELÍCULA de TMDB (ids oficiales y estables).
_MOVIE_GENRES = [
    ("Acción",        28,     "top_accion.png"),
    ("Aventura",      12,     "top_aventura.png"),
    ("Animación",     16,     "top_animacion.png"),
    ("Comedia",       35,     "top_comedia.png"),
    ("Crimen",        80,     "top_thriller.png"),
    ("Documental",    99,     "top_discovery.png"),
    ("Drama",         18,     "top_drama.png"),
    ("Familia",       10751,  "top_animacion.png"),
    ("Fantasía",      14,     "top_fantasia.png"),
    ("Historia",      36,     "top_peliculas_hist.png"),
    ("Terror",        27,     "top_terror.png"),
    ("Música",        10402,  "top_drama.png"),
    ("Misterio",      9648,   "top_thriller.png"),
    ("Romance",       10749,  "top_drama.png"),
    ("Ciencia ficción", 878,  "top_scifi.png"),
    ("Suspense",      53,     "top_thriller.png"),
    ("Bélica",        10752,  "top_belica.png"),
    ("Western",       37,     "top_western.png"),
]


def _u(**kwargs):
    return core_settings.make_url(**kwargs)


def _handle():
    return int(sys.argv[1])


def _acc():
    return (core_settings.get_acc_force_bold(),
            core_settings.get_acc_strip_symbols(),
            core_settings.get_acc_color_mode())


def show_decades_menu():
    h = _handle()
    bold, strip, color = _acc()
    af = core_settings.addon_fanart()
    for label, start, end in _DECADES:
        li = xbmcgui.ListItem(label=core_settings.apply_label(label, bold=bold, strip=strip, color_mode=color))
        li.setArt({'icon': core_settings.addon_media('top_decada.png'), 'fanart': af})
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action='decade_list', start=start, end=end, page=1),
            listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def show_genres_menu():
    h = _handle()
    bold, strip, color = _acc()
    af = core_settings.addon_fanart()
    for label, gid, icon in _MOVIE_GENRES:
        li = xbmcgui.ListItem(label=core_settings.apply_label(label, bold=bold, strip=strip, color_mode=color))
        li.setArt({'icon': core_settings.addon_media(icon), 'fanart': af})
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action='genre_list', genre_id=gid, page=1),
            listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def show_decade_list(start, end, page=1):
    params = {
        'primary_release_date.gte': f'{int(start)}-01-01',
        'primary_release_date.lte': f'{int(end)}-12-31',
        'vote_count.gte': 200, 'page': int(page),
    }
    _discover_and_render(params, 'decade_list', dict(start=start, end=end), int(page))


def show_genre_list(genre_id, page=1):
    params = {'with_genres': str(genre_id), 'vote_count.gte': 150, 'page': int(page)}
    _discover_and_render(params, 'genre_list', dict(genre_id=genre_id), int(page))


def _discover_and_render(params, action, action_kw, page):
    import metadata_enricher as me

    h = _handle()
    items, total_pages = me.discover('movie', params, limit=_LIMIT, with_pages=True)
    if not items:
        if page == 1:
            xbmcgui.Dialog().notification("TopZilla", "Sin resultados", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(h)
        return

    af = core_settings.addon_fanart()
    bold, strip, color = _acc()
    missing = []
    for item in items:
        year_int = int(item['year']) if item.get('year', '').isdigit() else 0
        label = f"{item['title']} ({year_int})" if year_int else item['title']
        li = xbmcgui.ListItem(label=core_settings.apply_label(label, bold=bold, strip=strip, color_mode=color))

        meta = me.enrich(tmdb_id=item['tmdb_id'], title=item['title'],
                         year=year_int or None, media_type='movie', use_cache_only=True)
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
        else:
            poster = item.get('poster') or ''
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': poster, 'poster': poster, 'fanart': af})
            info = {'title': item['title'], 'plot': item.get('overview', ''), 'mediatype': 'movie'}
            if year_int:
                info['year'] = year_int
            li.setInfo('video', info)
            missing.append({'tmdb_id': item['tmdb_id'], 'imdb_id': '', 'title': item['title'],
                            'year': year_int or None, 'media_type': 'movie'})

        ref = movie_ref.make_ref(title=item['title'], year=year_int or None,
                                 tmdb_id=item['tmdb_id'], poster=item.get('poster', ''),
                                 media_type='movie', source='discover', plot=item.get('overview', ''))
        context_menu.attach(li, ref)
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(handle=h, url=context_menu.build_play_url(ref), listitem=li, isFolder=False)

    if missing:
        import threading

        def _bg():
            try:
                if any(me.batch_enrich(missing, max_workers=2)):
                    import xbmc
                    xbmc.executebuiltin("Container.Refresh")
            except Exception:
                pass

        threading.Thread(target=_bg, daemon=True).start()

    # "Página siguiente" según total_pages de TMDB (cap 10 páginas, como network_tops).
    last_page = min(total_pages, 10)
    if page < last_page:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            f"[COLOR limegreen]Página siguiente ({page + 1}/{last_page})[/COLOR]", bold=bold, strip=strip, color_mode=color))
        li.setArt({'icon': 'DefaultFolder.png', 'fanart': af})
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action=action, page=page + 1, **action_kw), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h, cacheToDisc=core_settings.remember_list_position())
