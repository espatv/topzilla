# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""Tops de películas y series por plataforma de streaming en España vía TMDB."""
import json
import os
import sys
import threading
import time

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import context_menu
import core_settings
import movie_ref

_TMDB_BASE = "https://api.themoviedb.org/3"
_IMG_W342  = "https://image.tmdb.org/t/p/w342"
_IMG_ORIG  = "https://image.tmdb.org/t/p/original"
_TTL       = 24 * 3600
_LOG_TAG   = "[TopZilla-ST]"

# IDs de proveedores TMDB verificados para España (watch/providers, watch_region=ES)
_PROVIDERS = [
    # (label, provider_id, media_type)
    ("Netflix — Películas",         8,    "movie"),
    ("Netflix — Series",            8,    "show"),
    ("Amazon Prime — Películas",    119,  "movie"),
    ("Amazon Prime — Series",       119,  "show"),
    ("Disney+ — Películas",         337,  "movie"),
    ("Disney+ — Series",            337,  "show"),
    ("Max — Películas",             1899, "movie"),
    ("Max — Series",                1899, "show"),
    ("Movistar Plus+ — Películas",  149,  "movie"),
    ("Movistar Plus+ — Series",     149,  "show"),
    ("Apple TV+ — Películas",       350,  "movie"),
    ("Apple TV+ — Series",          350,  "show"),
]

_GENRE_NAMES = {
    28: 'Acción', 12: 'Aventura', 16: 'Animación', 35: 'Comedia',
    80: 'Crimen', 99: 'Documental', 18: 'Drama', 10751: 'Familia',
    14: 'Fantasía', 36: 'Historia', 27: 'Terror', 10402: 'Música',
    9648: 'Misterio', 10749: 'Romance', 878: 'Ciencia ficción',
    53: 'Suspense', 10752: 'Bélica', 37: 'Western',
    10759: 'Acción y aventura', 10765: 'Ciencia ficción y fantasía',
}

_PROVIDER_ICON_FILES = {
    8:    'top_netflix.png',
    119:  'top_amazon.png',
    337:  'top_disney.png',
    1899: 'top_max.png',
    149:  'top_movistar.png',
    350:  'top_appletv.png',
}


def _u(**kwargs):
    return core_settings.make_url(**kwargs)


def _handle():
    return int(sys.argv[1])


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"{_LOG_TAG} {msg}", level)


def _cache_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(profile, 'topzilla_streaming_tops_cache.json')


def _load_cache():
    try:
        p = _cache_path()
        if not os.path.exists(p):
            return {}
        with open(p, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _save_cache(data):
    try:
        p = _cache_path()
        os.makedirs(os.path.dirname(p), exist_ok=True)
        # tmp por hilo: dos escrituras concurrentes con el mismo .tmp corromperían el JSON.
        tmp = f"{p}.{threading.get_ident()}.tmp"
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, p)
    except OSError as e:
        _log(f"cache save: {e}", xbmc.LOGWARNING)


def _genres_from_ids(ids):
    names = [_GENRE_NAMES[i] for i in (ids or []) if i in _GENRE_NAMES]
    return ' / '.join(names[:3])


def _tmdb_get(path, params):
    api_key = core_settings.get_tmdb_api_key()
    if not api_key:
        return None
    try:
        r = requests.get(f"{_TMDB_BASE}/{path}",
                         params=dict(params, api_key=api_key), timeout=10)
        _log(f"{path} -> {r.status_code}")
        if r.status_code != 200:
            return None
        return r.json()
    except (requests.RequestException, ValueError) as e:
        _log(f"error {path}: {e}", xbmc.LOGERROR)
        return None


def _fetch_provider_list(provider_id, media_type, page):
    cache = _load_cache()
    cache_key = f"{provider_id}|{media_type}|{page}"
    entry = cache.get(cache_key, {})
    if entry.get('items') and (time.time() - entry.get('ts', 0)) < _TTL:
        return entry['items'], entry.get('total_pages', 1)

    endpoint = 'discover/tv' if media_type == 'show' else 'discover/movie'
    min_votes = 50 if media_type == 'show' else 100
    params = {
        'language': 'es-ES',
        'watch_region': 'ES',
        'with_watch_providers': str(provider_id),
        'sort_by': 'vote_average.desc',
        'vote_count.gte': min_votes,
        'page': page,
    }
    data = _tmdb_get(endpoint, params)
    if not data:
        stale = entry.get('items')
        if stale:
            _log(f"provider {provider_id} inaccesible, usando caché caducada", xbmc.LOGWARNING)
            return stale, entry.get('total_pages', 1)
        return [], 1

    results = data.get('results') or []
    total_pages = min(data.get('total_pages', 1), 10)  # cap a 10 páginas
    items = []
    for r in results:
        if media_type == 'show':
            title = r.get('name') or r.get('original_name', '')
            year  = (r.get('first_air_date') or '')[:4]
        else:
            title = r.get('title') or r.get('original_title', '')
            year  = (r.get('release_date') or '')[:4]
        if not title:
            continue
        poster_path = r.get('poster_path') or ''
        backdrop_path = r.get('backdrop_path') or ''
        items.append({
            'tmdb_id':    str(r.get('id', '')),
            'title':      title,
            'year':       year,
            'overview':   r.get('overview', ''),
            'rating':     r.get('vote_average', 0),
            'genre':      _genres_from_ids(r.get('genre_ids') or []),
            'poster':     f"{_IMG_W342}{poster_path}" if poster_path else '',
            'fanart':     f"{_IMG_ORIG}{backdrop_path}" if backdrop_path else '',
            'media_type': media_type,
        })

    if items:  # no cachear vacíos (fallo transitorio envenenaría la fila durante el TTL)
        cache[cache_key] = {'ts': time.time(), 'items': items, 'total_pages': total_pages}
        _save_cache(cache)
    return items, total_pages


def _media_icon(name, fallback='DefaultVideoPlaylists.png'):
    p = os.path.join(
        xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path')),
        'resources', 'media', name,
    )
    return p if os.path.exists(p) else fallback


def show_menu():
    h = _handle()
    bold  = core_settings.get_acc_force_bold()
    strip = core_settings.get_acc_strip_symbols()
    color = core_settings.get_acc_color_mode()
    for label, provider_id, media_type in _PROVIDERS:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            label, bold=bold, strip=strip, color_mode=color))
        icon = _media_icon(_PROVIDER_ICON_FILES.get(provider_id, ''))
        li.setArt({'icon': icon, 'thumb': icon, 'fanart': core_settings.addon_fanart()})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='streaming_tops_list', provider_id=provider_id,
                   media_type=media_type, page=1),
            listitem=li,
            isFolder=True,
        )
    xbmcplugin.endOfDirectory(h)


def _trigger_bg_enrich(items):
    import metadata_enricher as me

    def _fetch():
        try:
            results = me.batch_enrich(items, max_workers=2)
            if any(results):
                xbmc.executebuiltin("Container.Refresh")
        except Exception as e:  # hilo daemon: un fallo solo debe loguearse, no propagar
            _log(f"bg enrich: {e}", xbmc.LOGWARNING)

    threading.Thread(target=_fetch, daemon=True).start()


def show_provider_list(provider_id, media_type, page=1):
    import pelis_grid as _pg
    tipo = 'Series' if media_type in ('tv', 'show') else 'Películas'
    if _pg.apply_grid_mode(_handle(), 'streaming', f'Streaming · {tipo}',
                           provider_id=provider_id, media_type=media_type):
        return

    import metadata_enricher as me

    h    = _handle()
    page = int(page)
    try:
        provider_id = int(provider_id)
    except (ValueError, TypeError):
        xbmcplugin.endOfDirectory(h)
        return

    canon_mt = 'show' if media_type in ('tv', 'show') else 'movie'
    items, total_pages = _fetch_provider_list(provider_id, canon_mt, page)

    if not items:
        xbmcgui.Dialog().notification(
            "TopZilla", "No se pudo cargar el catálogo", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(h)
        return

    af    = core_settings.addon_fanart()
    bold  = core_settings.get_acc_force_bold()
    strip = core_settings.get_acc_strip_symbols()
    color = core_settings.get_acc_color_mode()
    kodi_mt = 'tvshow' if canon_mt == 'show' else 'movie'
    missing_meta = []

    for item in items:
        year_int = int(item['year']) if item.get('year', '').isdigit() else 0
        label    = f"{item['title']} ({year_int})" if year_int else item['title']
        li       = xbmcgui.ListItem(label=core_settings.apply_label(
            label, bold=bold, strip=strip, color_mode=color))

        meta = me.enrich(
            tmdb_id=item['tmdb_id'], title=item['title'],
            year=year_int or None, media_type=canon_mt, use_cache_only=True,
        )
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or item['poster']
        else:
            art = {'icon': 'DefaultVideo.png', 'fanart': af}
            if item['poster']:
                art.update({'thumb': item['poster'], 'poster': item['poster']})
            if item['fanart']:
                art['fanart'] = item['fanart']
            li.setArt(art)
            genre  = item.get('genre', '')
            header = me.build_plot_header(item.get('rating'), genre)
            info   = {
                'title':     item['title'],
                'plot':      header + item.get('overview', ''),
                'mediatype': kodi_mt,
            }
            if year_int:
                info['year'] = year_int
            if item.get('rating'):
                info['rating'] = item['rating']
            if genre:
                info['genre'] = genre
            li.setInfo('video', info)
            poster = item['poster']
            missing_meta.append({
                'tmdb_id':    item.get('tmdb_id'),
                'imdb_id':    '',
                'title':      item['title'],
                'year':       year_int or None,
                'media_type': canon_mt,
            })

        tmdb_id = (meta.get('ids') or {}).get('tmdb', item['tmdb_id']) if meta else item['tmdb_id']
        ref = movie_ref.make_ref(
            title=item['title'], year=year_int or None,
            tmdb_id=tmdb_id, imdb_id=item.get('imdb_id', ''),
            poster=poster, media_type=canon_mt, source='streaming', plot=item.get('overview', ''),
        )
        context_menu.attach(li, ref)
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(
            handle=h, url=context_menu.build_play_url(ref), listitem=li, isFolder=False)

    if missing_meta:
        _trigger_bg_enrich(missing_meta)

    if page < total_pages:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            f"[COLOR limegreen]Página siguiente ({page + 1}/{total_pages})[/COLOR]",
            bold=bold, strip=strip, color_mode=color))
        li.setArt({'icon': 'DefaultFolder.png', 'fanart': af})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='streaming_tops_list', provider_id=provider_id,
                   media_type=media_type, page=page + 1),
            listitem=li,
            isFolder=True,
        )
    xbmcplugin.endOfDirectory(h, cacheToDisc=core_settings.remember_list_position())
