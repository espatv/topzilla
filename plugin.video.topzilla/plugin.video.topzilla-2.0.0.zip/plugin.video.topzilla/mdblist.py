# TopZilla — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""Listas curadas de MDbList (agrega IMDb, Letterboxd, Metacritic, RT, etc.)."""
import json
import os
import sys
import threading
import time

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import context_menu
import core_settings
import movie_ref

_MDB_BASE      = "https://mdblist.com/api"
_TTL_LISTS     = 24 * 3600
_TTL_ITEMS     = 6  * 3600
_TTL_CATEGORY  = 12 * 3600
_PAGE_SIZE     = 20
_LOG_TAG       = "[TopZilla-MDB]"

# (label, query_búsqueda, icono, descripción)
_CATEGORIES = [
    ("Tendencias",          "trending",          "top_trending.png",      "Películas y series que están arrasando ahora mismo."),
    ("Lo más visto",        "most watched",      "top_watched.png",       "Las más vistas de la semana según Trakt y otras fuentes."),
    ("Nuevos lanzamientos", "new release",       "top_anticipated.png",   "Últimas películas lanzadas en digital y plataformas."),
    ("IMDb Top y Premios",  "imdb top",          "top_mejores.png",       "IMDb Top 250, ganadores de Oscar y otros galardones."),
    ("Netflix",             "netflix top 10",    "top_netflix.png",       "Lo más popular en Netflix ahora mismo."),
    ("HBO / Max",           "hbo max",           "top_max.png",           "Series y películas destacadas de HBO y Max."),
    ("Disney+",             "disney plus",       "top_disney.png",        "Lo mejor de Disney, Marvel, Pixar y Star Wars."),
    ("Amazon Prime",        "amazon prime",      "top_amazon.png",        "Catálogo destacado de Amazon Prime Video."),
    ("Terror",              "horror",            "top_terror.png",        "Las mejores listas de terror, suspense y gore."),
    ("Ciencia Ficción",     "sci-fi",            "top_scifi.png",         "Sci-fi, distopías y fantasía especulativa."),
    ("Animación",           "animation",         "top_animacion.png",     "Animación para todos los gustos y edades."),
    ("Crimen y Thriller",   "crime thriller",    "top_thriller.png",      "Thrillers, noir y las mejores series de crimen."),
    ("Documentales",        "documentary",       "cat_documentales.png",  "Documentales recomendados de todas las temáticas."),
]


def _u(**kwargs):
    return core_settings.make_url(**kwargs)


def _handle():
    return int(sys.argv[1])


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"{_LOG_TAG} {msg}", level)


def _icon(name, fallback='DefaultVideoPlaylists.png'):
    p = os.path.join(
        xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path')),
        'resources', 'media', name,
    )
    return p if os.path.exists(p) else fallback


def _cache_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(profile, 'topzilla_mdblist_cache.json')


def _load_cache():
    try:
        p = _cache_path()
        if not os.path.exists(p):
            return {}
        with open(p, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _save_cache(data):
    try:
        p = _cache_path()
        os.makedirs(os.path.dirname(p), exist_ok=True)
        # tmp por hilo: dos escrituras concurrentes con el mismo .tmp corromperían el JSON.
        tmp = f"{p}.{threading.get_ident()}.tmp"
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, p)
    except OSError as e:
        _log(f"cache save: {e}", xbmc.LOGWARNING)


def _mdb_get(path, params=None):
    api_key = core_settings.get_mdblist_api_key()
    if not api_key:
        return None
    url = f"{_MDB_BASE}/{path}"
    full = dict(params or {}, apikey=api_key)
    try:
        r = requests.get(url, params=full, timeout=12)
        _log(f"{path} -> {r.status_code}")
        if r.status_code == 429:
            _log("rate limit hit", xbmc.LOGWARNING)
        if r.status_code != 200:
            return None
        data = r.json()
        if isinstance(data, dict) and data.get('error'):
            _log(f"API error: {data['error']}", xbmc.LOGWARNING)
            return None
        return data
    except (requests.RequestException, ValueError) as e:
        _log(f"fetch error {path}: {e}", xbmc.LOGERROR)
        return None


# Gestión de la clave API

def _add_api_key():
    import remote_input
    key = remote_input.get_text_input('Introduce tu API key de MDbList (gratis en mdblist.com)').strip()
    if not key:
        return
    core_settings.set_mdblist_api_key(key)
    xbmcgui.Dialog().notification(
        "TopZilla", "API key de MDbList guardada", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


def _setup_api_key():
    _add_api_key()


# Pantalla de bienvenida (sin clave configurada): muestra contenido gratuito

def _sep(h, text=''):
    lbl = core_settings.apply_label(f"[COLOR gray]{text}[/COLOR]") if text else ''
    li = xbmcgui.ListItem(label=lbl)
    li.setArt({'icon': _icon('transparent.png')})
    li.setInfo('video', {'plot': ''})
    xbmcplugin.addDirectoryItem(handle=h, url='', listitem=li, isFolder=False)


def _show_onboarding():
    h = _handle()
    bold  = core_settings.get_acc_force_bold()
    strip = core_settings.get_acc_strip_symbols()
    color = core_settings.get_acc_color_mode()

    # --- Bloque MDbList ---
    tip = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR gold][B]Activa MDbList para más listas curadas[/B][/COLOR]",
        bold=bold, strip=strip, color_mode=color))
    tip.setArt({'icon': _icon('top_mdblist.png'), 'fanart': core_settings.addon_fanart()})
    tip.setInfo('video', {'plot': (
        "MDbList combina listas de IMDb, Letterboxd, Metacritic, Rotten Tomatoes y Trakt "
        "en un solo lugar.\n\n"
        "Con una clave gratuita (sin tarjeta) desbloqueas 13 categorías adicionales:\n"
        "Tendencias, Lo más visto, Nuevos lanzamientos, IMDb Top 250, Netflix, HBO/Max, "
        "Disney+, Amazon, Terror, Sci-Fi, Animación, Crimen y Documentales.\n\n"
        "Para activarla: crea cuenta en mdblist.com → perfil → API → copia la clave "
        "→ pulsa en 'Introducir clave API' aquí abajo.\n"
        "Límite gratuito: 1.000 peticiones al día."
    )})
    xbmcplugin.addDirectoryItem(handle=h, url='', listitem=tip, isFolder=False)

    add = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR limegreen][B]  Introducir clave API gratuita de MDbList[/B][/COLOR]",
        bold=bold, strip=strip, color_mode=color))
    add.setArt({'icon': _icon('adv_busqueda.png'), 'fanart': core_settings.addon_fanart()})
    add.setInfo('video', {'plot': "Pulsa aquí para introducir tu clave API de MDbList y desbloquear todas las categorías."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='mdblist_add_key'), listitem=add, isFolder=False)

    _sep(h, '─────  Tendencias gratis (Trakt · TMDB)  ─────')

    # --- Trakt sin login ---
    trakt_free = [
        ("Películas en tendencia",    "movies/trending",       "movie", "1", "top_trending.png",
         "Lo que más se está viendo ahora mismo en todo el mundo según Trakt."),
        ("Series en tendencia",       "shows/trending",        "show",  "1", "top_trending.png",
         "Las series más vistas en tiempo real según Trakt."),
        ("Taquilla USA",              "movies/boxoffice",      "movie", "1", "top_boxoffice.png",
         "Las películas que más recaudan en los cines de Estados Unidos esta semana."),
        ("Más vistas hoy — Películas","movies/watched/daily",  "movie", "1", "top_watched.png",
         "Las películas con más reproducciones hoy en Trakt."),
        ("Más vistas hoy — Series",   "shows/watched/daily",   "show",  "1", "top_watched.png",
         "Las series con más reproducciones hoy en Trakt."),
        ("Más esperadas — Películas", "movies/anticipated",    "movie", "1", "top_anticipated.png",
         "Las películas más anticipadas por la comunidad de Trakt."),
        ("Más esperadas — Series",    "shows/anticipated",     "show",  "1", "top_anticipated.png",
         "Las series más anticipadas por la comunidad de Trakt."),
    ]
    for label, path, media_type, wrapped, icon_name, desc in trakt_free:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            label, bold=bold, strip=strip, color_mode=color))
        li.setArt({'icon': _icon(icon_name), 'fanart': core_settings.addon_fanart()})
        li.setInfo('video', {'plot': desc})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='trakt_tops_list', path=path, media_type=media_type,
                   wrapped=wrapped, page=1),
            listitem=li,
            isFolder=True,
        )

    # --- TMDB sin login (pool de clave embebida) ---
    tmdb_free = [
        ("Películas mejor valoradas",  "movie/top_rated",       "movie", "top_mejores.png",
         "Las películas con mejor valoración media de todos los tiempos en TMDB."),
        ("Series mejor valoradas",     "tv/top_rated",          "tv",    "top_mejores.png",
         "Las series con mejor valoración media de todos los tiempos en TMDB."),
        ("En cartelera ahora",         "movie/now_playing",     "movie", "top_encines.png",
         "Películas que se están proyectando actualmente en cines."),
        ("Próximos estrenos",          "movie/upcoming",        "movie", "top_encines_tv.png",
         "Películas que estrenarán próximamente en cines."),
    ]
    for label, endpoint, media_type, icon_name, desc in tmdb_free:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            label, bold=bold, strip=strip, color_mode=color))
        li.setArt({'icon': _icon(icon_name), 'fanart': core_settings.addon_fanart()})
        li.setInfo('video', {'plot': desc})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='tmdb_lists_show', endpoint=endpoint, media_type=media_type, page=1),
            listitem=li,
            isFolder=True,
        )

    _sep(h, '─────  Por plataforma (España)  ─────')

    # provider_ids de JustWatch para España
    platforms = [
        ("Netflix",       8,    "movie", "top_netflix.png",   "Lo más popular en Netflix España."),
        ("Amazon Prime",  9,    "movie", "top_amazon.png",    "Lo más popular en Amazon Prime Video España."),
        ("Disney+",       337,  "movie", "top_disney.png",    "Lo más popular en Disney+ España."),
        ("HBO / Max",     1899, "movie", "top_max.png",       "Lo más popular en Max España."),
        ("Apple TV+",     350,  "movie", "top_appletv.png",   "Lo más popular en Apple TV+ España."),
        ("Movistar+",     149,  "movie", "top_movistar.png",  "Lo más popular en Movistar+ España."),
    ]
    for label, provider_id, media_type, icon_name, desc in platforms:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            label, bold=bold, strip=strip, color_mode=color))
        li.setArt({'icon': _icon(icon_name), 'fanart': core_settings.addon_fanart()})
        li.setInfo('video', {'plot': desc})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='streaming_tops_list', provider_id=provider_id,
                   media_type=media_type, page=1),
            listitem=li,
            isFolder=True,
        )

    xbmcplugin.endOfDirectory(h)


# Menú principal

def show_menu():
    if not core_settings.get_mdblist_api_key():
        _show_onboarding()
        return

    h = _handle()
    bold  = core_settings.get_acc_force_bold()
    strip = core_settings.get_acc_strip_symbols()
    color = core_settings.get_acc_color_mode()

    # Categorías predefinidas
    for label, query, icon_name, desc in _CATEGORIES:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            label, bold=bold, strip=strip, color_mode=color))
        li.setArt({'icon': _icon(icon_name), 'fanart': core_settings.addon_fanart()})
        li.setInfo('video', {'plot': desc})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='mdblist_category', query=query, label=label),
            listitem=li,
            isFolder=True,
        )

    # Separador visual
    sep = xbmcgui.ListItem(label=core_settings.apply_label("[COLOR gray]─────────────────────────────[/COLOR]", bold=bold, strip=strip, color_mode=color))
    sep.setArt({'icon': _icon('transparent.png')})
    sep.setInfo('video', {'plot': ''})
    xbmcplugin.addDirectoryItem(handle=h, url='', listitem=sep, isFolder=False)

    # Secciones clásicas
    extras = [
        ("Top Listas Públicas",  'mdblist_top',          'top_mdblist.png',
         "Las listas más populares y valoradas de MDbList en este momento."),
        ("Buscar listas...",     'mdblist_search',        'adv_busqueda.png',
         "Busca entre miles de listas por nombre o temática."),
        ("Mis listas",           'mdblist_user',          'top_trakt_listas.png',
         "Tus listas personales guardadas en MDbList."),
    ]
    for label, action, icon_name, desc in extras:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            label, bold=bold, strip=strip, color_mode=color))
        li.setArt({'icon': _icon(icon_name), 'fanart': core_settings.addon_fanart()})
        li.setInfo('video', {'plot': desc})
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action=action), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(h)


# Listas por categoría (búsqueda predefinida)

def show_category_lists(query, label=''):
    cache = _load_cache()
    cache_key = f"cat:{query}"
    entry = cache.get(cache_key, {})
    if entry and (time.time() - entry.get('ts', 0)) < _TTL_CATEGORY:
        lists = entry['lists']
    else:
        data = _mdb_get('lists/search', {'s': query})
        lists = []
        for lst in (data if isinstance(data, list) else []):
            lid  = lst.get('id')
            name = (lst.get('name') or '').strip()
            if not lid or not name:
                continue
            lists.append({
                'id':   lid,
                'name': name,
                'desc': (lst.get('description') or '').strip(),
                'user': (lst.get('user_name') or '').strip(),
            })
        if lists:
            cache[cache_key] = {'ts': time.time(), 'lists': lists}
            _save_cache(cache)
        elif entry.get('lists'):
            _log(f"category '{query}' inaccesible, usando caché caducada", xbmc.LOGWARNING)
            lists = entry['lists']

    _show_list_of_lists(lists, empty_msg=f"No se encontraron listas para '{label or query}'")


# Helpers para mostrar listas de listas e items

def _fetch_list_of_lists(path, cache_key, ttl):
    cache = _load_cache()
    entry = cache.get(cache_key, {})
    if entry and (time.time() - entry.get('ts', 0)) < ttl:
        return entry['lists']

    data = _mdb_get(path)
    if data is None:
        stale = entry.get('lists')
        if stale:
            _log(f"{path} inaccesible, usando caché caducada", xbmc.LOGWARNING)
            return stale
        return []

    lists = []
    for lst in (data if isinstance(data, list) else []):
        lid  = lst.get('id')
        name = (lst.get('name') or '').strip()
        if not lid or not name:
            continue
        lists.append({
            'id':   lid,
            'name': name,
            'desc': (lst.get('description') or '').strip(),
            'user': (lst.get('user_name') or '').strip(),
        })

    if lists:
        cache[cache_key] = {'ts': time.time(), 'lists': lists}
        _save_cache(cache)
    return lists


def _show_list_of_lists(lists, empty_msg="No se encontraron listas"):
    h = _handle()
    if not lists:
        xbmcgui.Dialog().notification("TopZilla", empty_msg, xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(h)
        return
    bold  = core_settings.get_acc_force_bold()
    strip = core_settings.get_acc_strip_symbols()
    color = core_settings.get_acc_color_mode()
    for lst in lists:
        lines = [lst['name']]
        if lst['desc']:
            lines.append(lst['desc'])
        if lst['user']:
            lines.append(f"por {lst['user']}")
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            lst['name'], bold=bold, strip=strip, color_mode=color))
        li.setArt({'icon': _icon('top_mdblist.png'), 'fanart': core_settings.addon_fanart()})
        li.setInfo('video', {'plot': '\n'.join(lines)})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='mdblist_list', list_id=lst['id'], list_name=lst['name'], page=1),
            listitem=li,
            isFolder=True,
        )
    xbmcplugin.endOfDirectory(h)


def show_top_lists():
    lists = _fetch_list_of_lists('lists/top', 'top', _TTL_LISTS)
    _show_list_of_lists(lists)


def show_user_lists():
    lists = _fetch_list_of_lists('lists/user', 'user', _TTL_LISTS)
    _show_list_of_lists(lists, empty_msg="No tienes listas en MDbList o la clave no es válida.")


def search_lists():
    import remote_input
    query = remote_input.get_text_input('Buscar listas en MDbList').strip()
    if not query:
        xbmcplugin.endOfDirectory(_handle())
        return
    data = _mdb_get('lists/search', {'s': query})
    lists = []
    for lst in (data if isinstance(data, list) else []):
        lid  = lst.get('id')
        name = (lst.get('name') or '').strip()
        if not lid or not name:
            continue
        lists.append({
            'id':   lid,
            'name': name,
            'desc': (lst.get('description') or '').strip(),
            'user': (lst.get('user_name') or '').strip(),
        })
    _show_list_of_lists(lists, empty_msg=f"Sin resultados para '{query}'")


# Items de una lista

def _fetch_list_items(list_id):
    cache = _load_cache()
    cache_key = f"items:{list_id}"
    entry = cache.get(cache_key, {})
    if entry and (time.time() - entry.get('ts', 0)) < _TTL_ITEMS:
        return entry['items']

    data = _mdb_get(f"lists/{list_id}/items")
    if data is None:
        stale = entry.get('items')
        if stale:
            _log(f"items/{list_id} inaccesible, usando caché caducada", xbmc.LOGWARNING)
            return stale
        return []

    items = []
    for it in (data if isinstance(data, list) else []):
        mt = it.get('mediatype', '')
        if mt not in ('movie', 'show'):
            continue
        tmdb_id = it.get('id')
        imdb_id = it.get('imdb_id') or ''
        title   = (it.get('title') or '').strip()
        if not title:
            continue
        items.append({
            'tmdb_id':    tmdb_id,
            'imdb_id':    imdb_id,
            'title':      title,
            'year':       it.get('release_year') or 0,
            'media_type': mt,
        })

    if items:
        cache[cache_key] = {'ts': time.time(), 'items': items}
        _save_cache(cache)
    return items


def _trigger_bg_enrich_mdb(items):
    import metadata_enricher as me

    def _fetch():
        try:
            results = me.batch_enrich(items, max_workers=2)
            if any(results):
                xbmc.executebuiltin("Container.Refresh")
        except Exception as e:  # hilo daemon: un fallo solo debe loguearse, no propagar
            _log(f"bg enrich: {e}", xbmc.LOGWARNING)

    threading.Thread(target=_fetch, daemon=True).start()


def show_list_items(list_id, list_name, page=1):
    import pelis_grid as _pg
    if _pg.apply_grid_mode(_handle(), 'mdblist', list_name or 'MDBList', list_id=list_id):
        return

    import metadata_enricher as me

    h    = _handle()
    page = int(page)
    all_items = _fetch_list_items(list_id)

    if not all_items:
        xbmcgui.Dialog().notification(
            "TopZilla", "Lista vacía o no disponible", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(h)
        return

    start       = (page - 1) * _PAGE_SIZE
    end         = start + _PAGE_SIZE
    page_items  = all_items[start:end]
    total_pages = (len(all_items) + _PAGE_SIZE - 1) // _PAGE_SIZE

    af    = core_settings.addon_fanart()
    bold  = core_settings.get_acc_force_bold()
    strip = core_settings.get_acc_strip_symbols()
    color = core_settings.get_acc_color_mode()
    missing_meta = []

    for item in page_items:
        media_type = item['media_type']
        year_int   = item['year'] or 0
        label      = f"{item['title']} ({year_int})" if year_int else item['title']
        li         = xbmcgui.ListItem(label=core_settings.apply_label(
            label, bold=bold, strip=strip, color_mode=color))

        meta = me.enrich(
            tmdb_id=item['tmdb_id'], imdb_id=item['imdb_id'],
            title=item['title'], year=year_int or None,
            media_type=media_type, use_cache_only=True,
        )
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or ''
        else:
            li.setArt({'icon': 'DefaultVideo.png', 'fanart': af})
            li.setInfo('video', {
                'title':    item['title'],
                'year':     year_int,
                'mediatype': 'tvshow' if media_type == 'show' else 'movie',
            })
            poster = ''
            missing_meta.append({
                'tmdb_id':    item['tmdb_id'],
                'imdb_id':    item['imdb_id'],
                'title':      item['title'],
                'year':       year_int or None,
                'media_type': media_type,
            })

        tmdb_id = (meta.get('ids') or {}).get('tmdb', item['tmdb_id']) if meta else item['tmdb_id']
        canon_mt = 'show' if media_type in ('tv', 'show') else 'movie'
        ref = movie_ref.make_ref(
            title=item['title'], year=year_int or None,
            tmdb_id=tmdb_id, imdb_id=item['imdb_id'],
            poster=poster, media_type=canon_mt, source='mdblist', plot='',
        )
        context_menu.attach(li, ref)
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(
            handle=h, url=context_menu.build_play_url(ref), listitem=li, isFolder=False)

    if page < total_pages:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            f"[COLOR limegreen]Página siguiente ({page + 1}/{total_pages})[/COLOR]",
            bold=bold, strip=strip, color_mode=color))
        li.setArt({'icon': 'DefaultFolder.png', 'fanart': af})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='mdblist_list', list_id=list_id, list_name=list_name, page=page + 1),
            listitem=li,
            isFolder=True,
        )

    if missing_meta:
        _trigger_bg_enrich_mdb(missing_meta)

    xbmcplugin.endOfDirectory(h, cacheToDisc=core_settings.remember_list_position())
