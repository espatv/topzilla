# -*- coding: utf-8 -*-
# TopZilla — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""
Categorías personalizadas: el usuario crea colecciones (p.ej. "Cine 80s",
"Pendientes") y añade películas/series desde el menú contextual.

Adaptado de plugin.video.espadaily/category_manager.py: aquí los items
son MovieRef (no strings genéricos).

Modelo: dict {nombre_categoria: [MovieRef, ...]} en `custom_categories.json`.
"""
import json
import os
import sys
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

import core_settings
import movie_ref


_FILE = 'custom_categories.json'


def _u(**kwargs):
    return core_settings.make_url(**kwargs)


def _handle():
    return int(sys.argv[1])


def _media(filename):
    return os.path.join(xbmcaddon.Addon().getAddonInfo('path'),
                        'resources', 'media', filename)


def load_cats():
    data = core_settings.load_json(_FILE, default={})
    return data if isinstance(data, dict) else {}


def save_cats(data):
    core_settings.save_json(_FILE, data)


def main_menu():
    cats = load_cats()
    h = _handle()

    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR limegreen][B]CREAR NUEVA CATEGORÍA[/B][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultAddSource.png', 'fanart': core_settings.addon_fanart()})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="cat_create"), listitem=li, isFolder=False)

    if not cats:
        li = xbmcgui.ListItem(label="[COLOR gray]No tienes categorías. Crea una y añade películas desde el clic derecho.[/COLOR]")
        li.setArt({'icon': 'DefaultIconInfo.png', 'fanart': core_settings.addon_fanart()})
        xbmcplugin.addDirectoryItem(handle=h, url='', listitem=li, isFolder=False)
    else:
        for name in sorted(cats.keys()):
            n = len(cats[name])
            li = xbmcgui.ListItem(label=core_settings.apply_label(
                "[B]{0}[/B] [COLOR gray]({1})[/COLOR]".format(name, n),
                bold=_bold, strip=_strip, color_mode=_color))
            li.setArt({'icon': 'DefaultFolder.png', 'fanart': core_settings.addon_fanart()})
            cm = [
                ("Renombrar Categoría",
                 "RunPlugin({0})".format(_u(action='cat_rename', name=name))),
                ("Borrar Categoría",
                 "RunPlugin({0})".format(_u(action='cat_delete', name=name))),
            ]
            li.addContextMenuItems(cm)
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="cat_view", name=name),
                                         listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Backup y restauración[/B]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _media('adv_backup.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Exporta tus categorías a un archivo JSON o impórtalas desde uno previamente guardado."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="cat_backup_menu"), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def backup_menu():
    h = _handle()

    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Exportar Categorías[/B]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _media('descargas.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Guarda tus categorías en un archivo JSON para compartirlas o respaldarlas."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="cat_export"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Importar Categorías[/B]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _media('backup_favs.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Carga categorías desde un JSON. Puedes fusionarlas con las existentes o reemplazarlas."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="cat_import"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def create_category():
    kb = xbmc.Keyboard('', 'Nombre de la nueva categoría')
    kb.doModal()
    if not kb.isConfirmed():
        return None
    name = kb.getText().strip()
    if not name:
        return None
    cats = load_cats()
    if name in cats:
        xbmcgui.Dialog().notification("TopZilla", "La categoría ya existe", xbmcgui.NOTIFICATION_ERROR)
        return None
    cats[name] = []
    save_cats(cats)
    xbmc.executebuiltin("Container.Refresh")
    return name


def delete_category(name):
    if not name:
        return
    if not xbmcgui.Dialog().yesno("Borrar Categoría",
                                    "¿Borrar la categoría '{0}'?\nSe perderán los elementos que contiene.".format(name)):
        return
    cats = load_cats()
    if name in cats:
        del cats[name]
        save_cats(cats)
        xbmc.executebuiltin("Container.Refresh")


def rename_category(name):
    if not name:
        return
    kb = xbmc.Keyboard(name, 'Renombrar categoría')
    kb.doModal()
    if not kb.isConfirmed():
        return
    new_name = kb.getText().strip()
    if not new_name or new_name == name:
        return
    cats = load_cats()
    if new_name in cats:
        xbmcgui.Dialog().notification("TopZilla", "Ya existe una categoría con ese nombre",
                                       xbmcgui.NOTIFICATION_ERROR)
        return
    items = cats.get(name, [])
    del cats[name]
    cats[new_name] = items
    save_cats(cats)
    xbmc.executebuiltin("Container.Refresh")


def view_category(name):
    if not name:
        return
    import metadata_enricher as me
    import context_menu

    cats = load_cats()
    items = cats.get(name, [])
    h = _handle()
    af = core_settings.addon_fanart()

    if not items:
        li = xbmcgui.ListItem(label="[COLOR gray]Categoría vacía. Añade películas desde el clic derecho.[/COLOR]")
        li.setArt({'icon': 'DefaultIconInfo.png', 'fanart': core_settings.addon_fanart()})
        xbmcplugin.addDirectoryItem(handle=h, url='', listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
        return

    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()

    for ref in items:
        title = ref.get('title') or ''
        year = ref.get('year') or 0
        media = ref.get('media_type', 'movie')
        label = "[B]{0}[/B]".format(movie_ref.display_label(ref))
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            label, bold=_bold, strip=_strip, color_mode=_color))

        meta = me.enrich(
            tmdb_id=ref.get('tmdb_id'),
            imdb_id=ref.get('imdb_id'),
            title=title,
            year=year or None,
            media_type=media,
            use_cache_only=True,
        )
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
        else:
            poster = ref.get('poster') or ''
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': poster, 'poster': poster, 'fanart': af})
            li.setInfo('video', {
                'title': title,
                'year': year,
                'plot': ref.get('plot') or '',
                'mediatype': 'tvshow' if media == 'show' else 'movie',
            })

        cm_extra = [
            ("Quitar de esta categoría",
             "RunPlugin({0})".format(_u(action='cat_remove_item',
                                         cat=name, key=movie_ref.ref_key(ref)))),
            ("Mover a otra categoría...",
             "RunPlugin({0})".format(_u(action='cat_move_item',
                                         from_cat=name, key=movie_ref.ref_key(ref)))),
        ]
        context_menu.attach(li, ref, extra=cm_extra)
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=context_menu.build_play_url(ref),
            listitem=li,
            isFolder=False,
        )

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def add_item_dialog(ref):
    if not ref or not ref.get('title'):
        return False
    cats = load_cats()

    cat_names = sorted(cats.keys())
    options = ["[COLOR limegreen]+ Crear nueva categoría...[/COLOR]"] + cat_names

    sel = xbmcgui.Dialog().select(
        "Añadir '{0}' a...".format(ref.get('title')), options)
    if sel < 0:
        return False

    if sel == 0:
        new_name = create_category()
        if not new_name:
            return False
        target = new_name
        cats = load_cats()
    else:
        target = cat_names[sel - 1]

    items = cats.get(target, [])
    key = movie_ref.ref_key(ref)
    if any(movie_ref.ref_key(r) == key for r in items):
        xbmcgui.Dialog().notification("TopZilla", "Ya estaba en '{0}'".format(target),
                                       xbmcgui.NOTIFICATION_INFO, 2500)
        return False
    new_ref = dict(ref)
    new_ref['added_at'] = int(time.time())
    items.insert(0, new_ref)
    cats[target] = items
    save_cats(cats)
    xbmcgui.Dialog().notification("TopZilla", "Añadido a '{0}'".format(target),
                                   xbmcgui.NOTIFICATION_INFO, 2500)
    return True


def remove_item(cat, key):
    if not cat or not key:
        return
    cats = load_cats()
    if cat not in cats:
        return
    cats[cat] = movie_ref.remove_by_key(cats[cat], key)
    save_cats(cats)
    xbmc.executebuiltin("Container.Refresh")


def move_item(from_cat, key):
    if not from_cat or not key:
        return
    cats = load_cats()
    other_cats = [c for c in sorted(cats.keys()) if c != from_cat]
    if not other_cats:
        xbmcgui.Dialog().notification("TopZilla", "No hay otras categorías",
                                       xbmcgui.NOTIFICATION_INFO)
        return
    sel = xbmcgui.Dialog().select("Mover a...", other_cats)
    if sel < 0:
        return
    target = other_cats[sel]
    ref = movie_ref.find_ref(cats.get(from_cat, []), key)
    if not ref:
        return
    cats[from_cat] = movie_ref.remove_by_key(cats[from_cat], key)
    target_items = cats.get(target, [])
    if not any(movie_ref.ref_key(r) == key for r in target_items):
        target_items.insert(0, ref)
    cats[target] = target_items
    save_cats(cats)
    xbmcgui.Dialog().notification("TopZilla", "Movido a '{0}'".format(target),
                                   xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


def export_categories():
    cats = load_cats()
    if not cats:
        xbmcgui.Dialog().notification("TopZilla", "No hay categorías para exportar",
                                       xbmcgui.NOTIFICATION_INFO)
        return
    ts = time.strftime("%Y%m%d_%H%M")
    default_name = "topzilla_categorias_{0}.json".format(ts)
    d = xbmcgui.Dialog().browse(3, 'Guardar Categorías', 'files', '', False, False, default_name)
    if not d:
        return
    if os.path.isdir(d):
        d = os.path.join(d, default_name)
    elif not d.lower().endswith('.json'):
        d += '.json'
    try:
        with open(d, 'w', encoding='utf-8') as f:
            json.dump(cats, f, ensure_ascii=False, indent=2)
        total = sum(len(v) for v in cats.values())
        xbmcgui.Dialog().ok("Exportar Categorías",
                             "Guardado:\n{0}\n\nCategorías: {1}\nElementos: {2}".format(
                                 os.path.basename(d), len(cats), total))
    except OSError as e:
        xbmcgui.Dialog().ok("Error", str(e))


def import_categories():
    f = xbmcgui.Dialog().browse(1, 'Seleccionar archivo de categorías',
                                  'files', '.json', False, False, '')
    if not f:
        return
    try:
        with open(f, 'r', encoding='utf-8') as fp:
            new_cats = json.load(fp)
    except (OSError, ValueError) as e:
        xbmcgui.Dialog().ok("Error", str(e))
        return

    if not isinstance(new_cats, dict):
        xbmcgui.Dialog().ok("Error", "El archivo no tiene el formato correcto.")
        return

    sel = xbmcgui.Dialog().select("¿Cómo importar?",
                                    ["Fusionar con las existentes", "Reemplazar todas"])
    if sel < 0:
        return

    if sel == 0:
        existing = load_cats()
        for name, refs in new_cats.items():
            if not isinstance(refs, list):
                continue
            target = existing.get(name, [])
            for r in refs:
                if isinstance(r, dict):
                    k = movie_ref.ref_key(r)
                    if k and not any(movie_ref.ref_key(x) == k for x in target):
                        target.append(r)
            existing[name] = target
        save_cats(existing)
        xbmcgui.Dialog().notification("TopZilla", "Categorías fusionadas",
                                       xbmcgui.NOTIFICATION_INFO)
    else:
        save_cats(new_cats)
        xbmcgui.Dialog().notification("TopZilla", "Categorías reemplazadas",
                                       xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")
