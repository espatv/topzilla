# -*- coding: utf-8 -*-
# TopZilla — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""
Integración Trakt.tv: importar listas públicas por ID y mostrar sus items
con metadatos TMDB en español.
"""
import json
import os
import sys
import time

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

import core_settings
import movie_ref

_trakt_session = requests.Session()


def _trakt_get(url, headers, timeout=15):
    try:
        r = _trakt_session.get(url, headers=headers, timeout=timeout)
    except requests.RequestException as e:
        xbmc.log("[TopZilla] trakt request error: {0}".format(e), xbmc.LOGWARNING)
        return None
    if r.status_code == 429:
        try:
            wait = int(r.headers.get('Retry-After', '2'))
        except (TypeError, ValueError):
            wait = 2
        time.sleep(min(max(wait, 1), 5))
        try:
            r = _trakt_session.get(url, headers=headers, timeout=timeout)
        except requests.RequestException as e:
            xbmc.log("[TopZilla] trakt retry error: {0}".format(e), xbmc.LOGWARNING)
            return None
    return r


def _u(**kwargs):
    return core_settings.make_url(**kwargs)


def _handle():
    return int(sys.argv[1])


def _media(filename):
    return os.path.join(xbmcaddon.Addon().getAddonInfo('path'),
                        'resources', 'media', filename)


def _get_thumb_cache_path(list_id):
    return core_settings.profile_file("trakt_thumbs_{0}.json".format(list_id))


def _load_thumb_cache(list_id):
    path = _get_thumb_cache_path(list_id)
    if os.path.exists(path):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (OSError, ValueError):
            pass
    return {}


def _meta_flag_path():
    return core_settings.profile_file('trakt_meta_downloaded.flag')


def _meta_items_path():
    return core_settings.profile_file('trakt_meta_items.json')


def _has_trakt_meta():
    return os.path.exists(_meta_flag_path())


def _get_tmdb_thumb(tmdb_id, fallback):
    if not tmdb_id:
        return fallback
    try:
        import metadata_enricher as me
        data = me.tmdb_get("movie/{0}".format(tmdb_id))
        if data and data.get("poster_path"):
            return "https://image.tmdb.org/t/p/w342{0}".format(data["poster_path"])
    except Exception:
        pass
    return fallback


def menu_trakt_root():
    core_settings.seed_default_trakt_lists(core_settings.get_trakt_api_key())

    h = _handle()

    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR yellow][B]Actualizar nombres y datos[/B][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _media('adv_refrescar.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Obtiene el nombre real y el número de ítems de todas las listas desde Trakt."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="trakt_refresh_defaults"),
                                 listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR blue][B]Opciones / Importar[/B][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _media('opciones.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Importa una lista de Trakt por su ID o gestiona las listas guardadas."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="trakt_options"),
                                 listitem=li, isFolder=True)

    lists = core_settings.get_trakt_lists()
    order = core_settings.load_trakt_lists_order()
    if order:
        index = {lid: i for i, lid in enumerate(order)}
        lists = sorted(lists, key=lambda l: index.get(l.get("id", ""), 10**6))
    for l in lists:
        count = l.get('item_count', 0)
        label = "[B]{0}[/B] [COLOR gray]({1} ítems)[/COLOR]".format(l['name'], count)
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            label, bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': 'DefaultFolder.png', 'fanart': core_settings.addon_fanart()})
        li.setInfo('video', {'plot': "ID: {0}\nUsuario: {1}\nTotal: {2} elementos.".format(
            l['id'], l.get('user', ''), count)})
        cm = [("Eliminar lista",
               "RunPlugin({0})".format(_u(action='trakt_delete_list', list_id=l['id'])))]
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(handle=h,
                                     url=_u(action="trakt_view_list", list_id=l['id']),
                                     listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(h)


def menu_options():
    h = _handle()

    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR yellow][B]Guía: Cómo obtener tu API Key (paso a paso)[/B][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultIconInfo.png', 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Instrucciones detalladas para registrarte en Trakt.tv y obtener tu Client ID."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="trakt_help_guide"),
                                 listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Si el addon deja de funcionar, configura un Client ID[/B]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultIconInfo.png', 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot':
        "[B]ℹ Información[/B]\n\n"
        "Si en algún momento el contenido de Trakt no carga o ves errores, "
        "puedes configurar un Client ID gratuito de Trakt.tv para un funcionamiento independiente.\n\n"
        "Sigue la guía de arriba para obtenerlo e introdúcelo en «Configurar API Key»."})
    xbmcplugin.addDirectoryItem(handle=h, url='', listitem=li, isFolder=False)

    key = core_settings.get_trakt_settings().get('api_key', '')
    status = "[COLOR green]CONFIGURADA[/COLOR]" if key else "[COLOR red]NO CONFIGURADA[/COLOR]"

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Configurar API Key[/B] {0}".format(status),
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultAddonService.png', 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Pulsa para introducir tu Client ID personal."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="trakt_set_key"),
                                 listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]↕ Reordenar listas[/B]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultAddonService.png', 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Cambia el orden en el que se muestran las listas Trakt en el menú principal."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="trakt_lists_reorder"),
                                 listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Importar lista por ID[/B]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultAddonService.png', 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Introduce el ID numérico de una lista pública (ej: 21583416)."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="trakt_import"),
                                 listitem=li, isFolder=False)

    if _has_trakt_meta():
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            "[COLOR red][B]Borrar metadatos TMDB de Trakt[/B][/COLOR]",
            bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': 'DefaultIconError.png', 'fanart': core_settings.addon_fanart()})
        li.setInfo('video', {'plot': "Elimina los metadatos TMDB descargados para todas las listas."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="trakt_clear_all_meta"),
                                     listitem=li, isFolder=False)
    else:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            "[B]Descargar metadatos TMDB en español[/B]",
            bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': 'DefaultAddonService.png', 'fanart': core_settings.addon_fanart()})
        li.setInfo('video', {'plot': "Descarga sinopsis, director y reparto de TMDB para todas las listas Trakt."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="trakt_cache_all_meta"),
                                     listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def help_guide():
    text = (
        "[B]PASO 1: REGISTRO[/B]\n"
        "Entra en tu navegador (PC o móvil) a:\n"
        "[COLOR cyan]https://trakt.tv/oauth/applications[/COLOR]\n"
        "Identifícate con tu cuenta de usuario.\n\n"
        "[B]PASO 2: CREAR APLICACIÓN[/B]\n"
        "Pulsa el botón verde [B]NEW APPLICATION[/B].\n\n"
        "[B]PASO 3: RELLENAR DATOS[/B]\n"
        " • [B]Name:[/B] TopZilla\n"
        " • [B]Description:[/B] Addon de Kodi\n"
        " • [B]Redirect uri:[/B] urn:ietf:wg:oauth:2.0:oob\n"
        " • [B]Permissions:[/B] (no marques nada)\n\n"
        "Pulsa [B]SAVE APP[/B].\n\n"
        "[B]PASO 4: OBTENER EL CLIENT ID[/B]\n"
        "Tras guardar, copia el [B]Client ID[/B] y pégalo en 'Configurar API Key'.\n\n"
        "[I]La API Key es personal y gratuita. Solo permite leer listas públicas.[/I]"
    )
    xbmcgui.Dialog().textviewer("[COLOR yellow]Configurar Trakt.tv[/COLOR]", text)


def set_api_key():
    kb = xbmc.Keyboard(core_settings.get_trakt_user_key(),
                        'Introduce Trakt Client ID (API Key)')
    kb.doModal()
    if kb.isConfirmed():
        core_settings.set_trakt_api_key(kb.getText().strip())
        xbmcgui.Dialog().notification("TopZilla", "API Key guardada",
                                       xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin("Container.Refresh")


def import_list():
    key = core_settings.get_trakt_api_key()
    if not key:
        xbmcgui.Dialog().notification("Error", "Configura primero la API Key",
                                       xbmcgui.NOTIFICATION_ERROR)
        return

    kb = xbmc.Keyboard('', 'Introduce ID numérico de la lista')
    kb.doModal()
    if not kb.isConfirmed():
        return
    list_id = kb.getText().strip()
    if not list_id:
        return

    headers = {'Content-Type': 'application/json',
               'trakt-api-version': '2',
               'trakt-api-key': key}

    pDialog = xbmcgui.DialogProgress()
    pDialog.create("TopZilla", "Importando lista de Trakt...")
    try:
        r = _trakt_get("https://api.trakt.tv/lists/{0}".format(list_id),
                        headers, timeout=10)
        if r is None:
            pDialog.close()
            xbmcgui.Dialog().notification("Error Trakt", "No se pudo conectar",
                                           xbmcgui.NOTIFICATION_ERROR)
            return
        if r.status_code != 200:
            pDialog.close()
            xbmcgui.Dialog().notification("Error Trakt",
                                           "No se pudo leer la lista (HTTP {0})".format(r.status_code),
                                           xbmcgui.NOTIFICATION_ERROR)
            return
        try:
            data = r.json()
        except ValueError:
            pDialog.close()
            xbmcgui.Dialog().notification("Error Trakt", "Respuesta no válida",
                                           xbmcgui.NOTIFICATION_ERROR)
            return
        name = data.get('name', "Lista {0}".format(list_id))
        user = data.get('user', {}).get('username', 'Unknown') if isinstance(data.get('user'), dict) else 'Unknown'
        item_count = data.get('item_count', 0)
        core_settings.add_trakt_list(list_id, name, user, item_count)
    finally:
        pDialog.close()

    if xbmcgui.Dialog().yesno("TopZilla",
                                "Lista '{0}' importada.\n\n¿Abrirla ahora?".format(name)):
        xbmc.executebuiltin("Container.Update({0})".format(
            _u(action='trakt_view_list', list_id=list_id)))
    else:
        xbmc.executebuiltin("Container.Update({0})".format(_u(action='trakt_root')))


def delete_list(list_id):
    if not list_id:
        return
    if xbmcgui.Dialog().yesno("Eliminar lista",
                                "¿Borrar esta lista de tu colección?"):
        core_settings.remove_trakt_list(list_id)
        xbmc.executebuiltin("Container.Refresh")


def refresh_all_lists():
    api_key = core_settings.get_trakt_api_key()
    if not api_key:
        xbmcgui.Dialog().notification("Error", "Configura la API Key",
                                       xbmcgui.NOTIFICATION_ERROR)
        return
    lists = core_settings.get_trakt_lists()
    if not lists:
        xbmcgui.Dialog().notification("Trakt", "No hay listas para actualizar",
                                       xbmcgui.NOTIFICATION_INFO)
        return
    headers = {'Content-Type': 'application/json',
               'trakt-api-version': '2',
               'trakt-api-key': api_key}
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("TopZilla", "Actualizando listas de Trakt...")
    total = len(lists)
    for i, l in enumerate(lists):
        if pDialog.iscanceled():
            break
        pDialog.update(int((i / total) * 100), "({0}/{1}) {2}".format(i + 1, total, l['name']))
        r = _trakt_get("https://api.trakt.tv/lists/{0}".format(l['id']),
                        headers, timeout=5)
        if r is not None and r.status_code == 200:
            try:
                d = r.json()
                l['name'] = d.get('name', l['name'])
                if isinstance(d.get('user'), dict):
                    l['user'] = d['user'].get('username', l.get('user', 'official'))
                l['item_count'] = d.get('item_count', l.get('item_count', 0))
            except ValueError:
                pass
    pDialog.close()
    settings = core_settings.get_trakt_settings()
    existing = {l['id']: l for l in settings.get('lists', [])}
    for l in lists:
        if l['id'] in existing:
            existing[l['id']].update(l)
    settings['lists'] = list(existing.values())
    core_settings.save_trakt_settings(settings)
    xbmcgui.Dialog().notification("TopZilla", "Listas actualizadas",
                                   xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


# Listado de items y carátulas

def view_list(list_id):
    if not list_id:
        return
    import metadata_enricher as me
    import context_menu

    h = _handle()
    key = core_settings.get_trakt_api_key()
    if not key:
        xbmcgui.Dialog().notification("Error", "Falta API Key",
                                       xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(h)
        return

    headers = {'Content-Type': 'application/json',
               'trakt-api-version': '2',
               'trakt-api-key': key}

    r = _trakt_get("https://api.trakt.tv/lists/{0}/items?extended=full".format(list_id),
                    headers)
    if r is None:
        xbmcgui.Dialog().notification("Trakt", "No se pudo conectar",
                                       xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(h)
        return
    try:
        items = r.json()
    except ValueError as e:
        xbmc.log("[TopZilla] trakt view_list: {0}".format(e), xbmc.LOGWARNING)
        xbmcgui.Dialog().notification("Trakt", "No se pudo conectar",
                                       xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(h)
        return

    if not isinstance(items, list):
        msg = items.get('message', 'Error desconocido') if isinstance(items, dict) else 'Respuesta no válida'
        xbmcgui.Dialog().ok("Error Trakt", "No se pudieron cargar los elementos:\n{0}".format(msg))
        xbmcplugin.endOfDirectory(h)
        return

    addon = xbmcaddon.Addon()
    ai = addon.getAddonInfo('icon')
    af = core_settings.addon_fanart()

    cache = _load_thumb_cache(list_id)
    has_cache = bool(cache)

    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()

    if has_cache:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            "[COLOR red][B]Borrar carátulas guardadas (volver a carga rápida)[/B][/COLOR]",
            bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': 'DefaultIconError.png', 'fanart': core_settings.addon_fanart()})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action='trakt_clear_cache', list_id=list_id),
                                     listitem=li, isFolder=False)
    else:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            "[COLOR cyan][B]Descargar y guardar carátulas[/B][/COLOR]",
            bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': 'DefaultAddonService.png', 'fanart': core_settings.addon_fanart()})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action='trakt_cache_covers', list_id=list_id),
                                     listitem=li, isFolder=False)

    for it in items:
        if not isinstance(it, dict):
            continue
        t = it.get('type')
        if t not in ('movie', 'show'):
            continue
        data = it.get(t)
        if not data:
            continue

        title = data.get('title') or ''
        year = data.get('year') or 0
        overview = data.get('overview') or ''
        tagline = data.get('tagline') or ''
        tmdb_id = (data.get('ids') or {}).get('tmdb')
        media = 'show' if t == 'show' else 'movie'
        item_key = "{0}_{1}".format(title, year)

        label = "[B]{0}[/B]".format("{0} ({1})".format(title, year) if year else title)
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            label, bold=_bold, strip=_strip, color_mode=_color))

        meta = me.enrich(tmdb_id=tmdb_id, title=title, year=year or None,
                          media_type=media, use_cache_only=True)
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or cache.get(item_key) or ai
        else:
            poster = cache.get(item_key) or ai
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': poster, 'poster': poster, 'fanart': af})
            li.setInfo('video', {
                'title': title, 'year': year,
                'plot': "[B]{0}[/B]\n\n{1}".format(tagline, overview) if tagline else overview,
                'mediatype': 'tvshow' if media == 'show' else 'movie',
            })

        plot = meta.get('overview', '') if meta else ("[B]{0}[/B]\n\n{1}".format(tagline, overview) if tagline else overview)
        ref = movie_ref.make_ref(
            title=title, year=year,
            tmdb_id=tmdb_id, poster=poster,
            media_type=media, source='trakt', plot=plot,
        )
        context_menu.attach(li, ref)
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(handle=h,
                                     url=context_menu.build_play_url(ref),
                                     listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def cache_covers(list_id):
    if not list_id:
        return
    if not xbmcgui.Dialog().yesno("TopZilla",
        "[B]AVISO:[/B] al guardar las carátulas la lista tardará algo más en cargar.\n\n¿Continuar?"):
        return

    key = core_settings.get_trakt_api_key()
    headers = {'Content-Type': 'application/json',
               'trakt-api-version': '2',
               'trakt-api-key': key}
    r = _trakt_get("https://api.trakt.tv/lists/{0}/items?extended=full".format(list_id),
                    headers)
    if r is None:
        xbmcgui.Dialog().notification("Error", "No se pudo conectar con Trakt",
                                       xbmcgui.NOTIFICATION_ERROR)
        return
    try:
        items = r.json()
    except ValueError:
        xbmcgui.Dialog().notification("Error", "No se pudo conectar con Trakt",
                                       xbmcgui.NOTIFICATION_ERROR)
        return

    if not isinstance(items, list):
        return

    cache = {}
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("TopZilla", "Descargando carátulas...")
    total = len(items)
    if total == 0:
        pDialog.close()
        return

    for i, item in enumerate(items):
        if pDialog.iscanceled():
            break
        if not isinstance(item, dict):
            continue
        t = item.get('type')
        if t not in ('movie', 'show'):
            continue
        data = item.get(t)
        if not data:
            continue
        title = data.get('title')
        year = data.get('year')
        tmdb_id = (data.get('ids') or {}).get('tmdb')
        item_key = "{0}_{1}".format(title, year)
        pDialog.update(int(float(i) / total * 100),
                        "({0}/{1}) {2}".format(i, total, title))
        thumb = _get_tmdb_thumb(tmdb_id, None)
        if thumb:
            cache[item_key] = thumb
    pDialog.close()

    if cache:
        try:
            with open(_get_thumb_cache_path(list_id), 'w', encoding='utf-8') as f:
                json.dump(cache, f)
            xbmcgui.Dialog().notification("TopZilla", "Carátulas guardadas",
                                           xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
        except OSError as e:
            xbmcgui.Dialog().ok("Error", str(e))


def clear_cache(list_id):
    if not list_id:
        return
    path = _get_thumb_cache_path(list_id)
    if os.path.exists(path):
        try:
            os.remove(path)
            xbmcgui.Dialog().notification("TopZilla", "Caché borrada",
                                           xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
        except OSError as e:
            xbmcgui.Dialog().notification("Error", str(e),
                                           xbmcgui.NOTIFICATION_ERROR)


# Metadatos TMDB en español para todas las listas

def _collect_all_items(api_key, pDialog=None):
    headers = {'Content-Type': 'application/json',
               'trakt-api-version': '2',
               'trakt-api-key': api_key}
    lists = core_settings.get_trakt_lists()
    all_items = []
    seen = set()
    total = len(lists)
    for i, lst in enumerate(lists):
        if pDialog and pDialog.iscanceled():
            break
        if pDialog:
            pDialog.update(int((i / max(total, 1)) * 100),
                            "Lista ({0}/{1}): {2}".format(i + 1, total, lst.get('name', lst['id'])))
        r = _trakt_get("https://api.trakt.tv/lists/{0}/items?extended=full".format(lst['id']),
                        headers)
        if r is None or r.status_code != 200:
            continue
        try:
            raw = r.json()
        except ValueError as e:
            xbmc.log("[TopZilla] trakt collect: {0}".format(e), xbmc.LOGWARNING)
            continue
        for item in raw:
            if not isinstance(item, dict):
                continue
            t = item.get('type')
            if t not in ('movie', 'show'):
                continue
            d = item.get(t)
            if not d:
                continue
            tmdb_id = (d.get('ids') or {}).get('tmdb')
            title = d.get('title')
            year = d.get('year')
            media = 'show' if t == 'show' else 'movie'
            k = (tmdb_id or title, year, media)
            if k in seen:
                continue
            seen.add(k)
            all_items.append({'tmdb_id': tmdb_id, 'title': title,
                                'year': year, 'media_type': media})
    return all_items


def cache_all_meta():
    import metadata_enricher as me

    key = core_settings.get_trakt_api_key()
    if not key:
        xbmcgui.Dialog().ok("Error", "No hay API Key configurada para Trakt.")
        return
    if not core_settings.get_trakt_lists():
        xbmcgui.Dialog().ok("Trakt", "No hay listas configuradas.")
        return

    pDialog = xbmcgui.DialogProgress()
    pDialog.create("TopZilla", "Recopilando elementos de Trakt...")
    try:
        all_items = _collect_all_items(key, pDialog)
    except Exception as e:
        pDialog.close()
        xbmcgui.Dialog().notification("Error", str(e), xbmcgui.NOTIFICATION_ERROR)
        return

    if pDialog.iscanceled() or not all_items:
        pDialog.close()
        if not all_items:
            xbmcgui.Dialog().ok("Trakt", "No se encontraron elementos en las listas.")
        return

    pDialog.update(0, "Descargando metadatos TMDB en español...")
    try:
        count = me.batch_fetch_with_progress(all_items, pDialog)
    finally:
        pDialog.close()

    try:
        with open(_meta_items_path(), 'w', encoding='utf-8') as fh:
            json.dump(all_items, fh, ensure_ascii=False)
        open(_meta_flag_path(), 'w').close()
    except OSError as e:
        xbmc.log("[TopZilla] trakt meta save: {0}".format(e), xbmc.LOGWARNING)

    xbmcgui.Dialog().notification("TopZilla",
                                   "Metadatos guardados: {0}/{1}".format(count, len(all_items)),
                                   xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


def clear_all_meta():
    import metadata_enricher as me

    items_path = _meta_items_path()
    flag_path = _meta_flag_path()

    saved_items = []
    if os.path.exists(items_path):
        try:
            with open(items_path, 'r', encoding='utf-8') as fh:
                saved_items = json.load(fh)
        except (OSError, ValueError):
            pass

    deleted = 0
    if saved_items:
        me.delete_items(saved_items)
        deleted = len(saved_items)
    else:
        key = core_settings.get_trakt_api_key()
        if key:
            items = _collect_all_items(key)
            if items:
                me.delete_items(items)
                deleted = len(items)

    for path in (items_path, flag_path):
        try:
            if os.path.exists(path):
                os.remove(path)
        except OSError:
            pass

    if deleted:
        xbmcgui.Dialog().notification("TopZilla",
                                       "Metadatos TMDB eliminados ({0})".format(deleted),
                                       xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification("TopZilla", "No había metadatos que borrar",
                                       xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")
