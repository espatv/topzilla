# -*- coding: utf-8 -*-
# TopZilla — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
import base64
import hashlib
import json
import os
import re

_TMDB_KEY_POOL_B64 = (
    "MjczZmZkMmY0MjhkZjNlMGVmNDc5ZWViOGQ2MzI1NDE=",
    "MjVjZGJiY2I0ZDk0ZTBkZWNlYTQxNzhhMjdjMzE1MmM=",
    "MjJjMTNmNWNlYzA3NDZkNDRlMjRiOWU4ZmVmZTRlNDU=",
    "YjY0YmRlYTM2OWQ4ODZlNWI3MzkyYmZiYjA5ZDRmOTU=",
)

_OMDB_KEY_POOL_B64 = (
    "NjVmMTVmM2Y=",
    "NDU4ODI0YWU=",
    "ZjVhNTM5NzI=",
)

_dead_pool_keys = set()
_dead_omdb_pool_keys = set()
_uid_cache = None
_decoded_pool = None
_decoded_omdb_pool = None


def _decode_one(b64):
    try:
        return base64.b64decode(b64).decode()
    except Exception:
        return ""


def _decoded():
    global _decoded_pool
    if _decoded_pool is None:
        _decoded_pool = tuple(_decode_one(b) for b in _TMDB_KEY_POOL_B64)
    return _decoded_pool


def _uid():
    global _uid_cache
    if _uid_cache is None:
        try:
            import stats
            _uid_cache = stats._get_uuid() or "x"
        except Exception:
            _uid_cache = "x"
    return _uid_cache


def _pool_index():
    h = hashlib.sha1(_uid().encode("utf-8")).hexdigest()
    return int(h[:8], 16) % len(_TMDB_KEY_POOL_B64)


def _pool_key():
    pool = _decoded()
    n = len(pool)
    start = _pool_index()
    for i in range(n):
        idx = (start + i) % n
        if idx in _dead_pool_keys:
            continue
        if pool[idx]:
            return pool[idx]
    _dead_pool_keys.clear()
    return pool[start]


def mark_tmdb_pool_key_dead(key):
    if not key:
        return
    pool = _decoded()
    for idx, k in enumerate(pool):
        if k == key:
            _dead_pool_keys.add(idx)
            return


def _decoded_omdb():
    global _decoded_omdb_pool
    if _decoded_omdb_pool is None:
        _decoded_omdb_pool = tuple(_decode_one(b) for b in _OMDB_KEY_POOL_B64)
    return _decoded_omdb_pool


def _omdb_pool_index():
    h = hashlib.sha1(_uid().encode("utf-8")).hexdigest()
    return int(h[8:16], 16) % len(_OMDB_KEY_POOL_B64)


def _omdb_pool_key():
    pool = _decoded_omdb()
    n = len(pool)
    if n == 0:
        return ""
    start = _omdb_pool_index()
    for i in range(n):
        idx = (start + i) % n
        if idx in _dead_omdb_pool_keys:
            continue
        if pool[idx]:
            return pool[idx]
    _dead_omdb_pool_keys.clear()
    return pool[start]


def mark_omdb_pool_key_dead(key):
    if not key:
        return
    pool = _decoded_omdb()
    for idx, k in enumerate(pool):
        if k == key:
            _dead_omdb_pool_keys.add(idx)
            return


def _auto_fetch_enabled():
    try:
        import xbmcaddon
        return xbmcaddon.Addon().getSetting('auto_fetch') == 'true'
    except Exception:
        return False


def set_auto_fetch_enabled(state):
    try:
        import xbmcaddon
        xbmcaddon.Addon().setSetting('auto_fetch', 'true' if state else 'false')
        return True
    except Exception:
        return False


def _show_context_menu_enabled():
    # Default true; userdata vacía o ausente cae al default.
    try:
        import xbmcaddon
        return xbmcaddon.Addon().getSetting('show_context_menu') != 'false'
    except Exception:
        return True


def _espadaily_integration_enabled():
    try:
        import xbmcaddon
        return xbmcaddon.Addon().getSetting('espadaily_integration_enabled') == 'true'
    except Exception:
        return False


def set_espadaily_integration_enabled(state):
    try:
        import xbmcaddon
        xbmcaddon.Addon().setSetting('espadaily_integration_enabled', 'true' if state else 'false')
        return True
    except Exception:
        return False


def set_show_context_menu_enabled(state):
    try:
        import xbmcaddon
        xbmcaddon.Addon().setSetting('show_context_menu', 'true' if state else 'false')
        return True
    except Exception:
        return False


def _show_context_menu_view_card_enabled():
    # Default true; userdata vacía o ausente cae al default.
    try:
        import xbmcaddon
        return xbmcaddon.Addon().getSetting('show_context_menu_view_card') != 'false'
    except Exception:
        return True


def set_show_context_menu_view_card_enabled(state):
    try:
        import xbmcaddon
        xbmcaddon.Addon().setSetting('show_context_menu_view_card', 'true' if state else 'false')
        return True
    except Exception:
        return False


def show_soundtrack_button_enabled():
    try:
        import xbmcaddon
        return xbmcaddon.Addon().getSetting('show_soundtrack_button') == 'true'
    except Exception:
        return False


def set_show_soundtrack_button_enabled(state):
    try:
        import xbmcaddon
        xbmcaddon.Addon().setSetting('show_soundtrack_button', 'true' if state else 'false')
        return True
    except Exception:
        return False


def show_omdb_button_enabled():
    try:
        import xbmcaddon
        return xbmcaddon.Addon().getSetting('show_omdb_button') == 'true'
    except Exception:
        return False


def set_show_omdb_button_enabled(state):
    try:
        import xbmcaddon
        xbmcaddon.Addon().setSetting('show_omdb_button', 'true' if state else 'false')
        return True
    except Exception:
        return False


def show_share_button_enabled():
    try:
        import xbmcaddon
        return xbmcaddon.Addon().getSetting('show_share_button') == 'true'
    except Exception:
        return False


def set_show_share_button_enabled(state):
    try:
        import xbmcaddon
        xbmcaddon.Addon().setSetting('show_share_button', 'true' if state else 'false')
        return True
    except Exception:
        return False


# Mantener sincronizada con resources/settings.xml.
_ALL_SETTING_IDS = (
    'auto_fetch', 'show_context_menu', 'show_context_menu_view_card',
    'show_soundtrack_button', 'show_omdb_button', 'show_share_button',
    'tmdb_api_key', 'trakt_api_key', 'omdb_api_key',
    'acc_color_mode', 'acc_force_bold', 'acc_strip_symbols', 'acc_font_size',
)


def reset_all_settings():
    try:
        import xbmcaddon
        addon = xbmcaddon.Addon()
        for sid in _ALL_SETTING_IDS:
            addon.setSetting(sid, '')
        return True
    except Exception:
        return False


# --- Helpers genéricos de perfil/JSON (usados por favorites, watch_history,
#     navigation_history, search_history, category_manager, trakt_manager,
#     backup_manager) ---

def profile_dir():
    """Devuelve la ruta del perfil del addon, creándolo si no existe."""
    import xbmcaddon
    import xbmcvfs
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p):
        os.makedirs(p)
    return p


def profile_file(name):
    return os.path.join(profile_dir(), name)


def load_json(name, default=None):
    """Devuelve `default` si el archivo no existe o está corrupto."""
    if default is None:
        default = {}
    path = profile_file(name)
    if not os.path.exists(path):
        return default
    try:
        with open(path, 'r', encoding='utf-8') as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return default


def save_json(name, data):
    path = profile_file(name)
    try:
        with open(path, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        return True
    except (OSError, TypeError, ValueError):
        return False


def make_url(**kwargs):
    """Construye la URL del plugin con los parámetros pasados.
    Helper único usado por los módulos del addon (sustituye al `_u` duplicado)."""
    import sys
    import urllib.parse
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)


# --- Accesibilidad (lee/escribe en settings.xml de Kodi) ---

_ACC_COLOR_MODES = ['none', 'white', 'daltonic_rg', 'daltonic_by', 'hc_dark', 'hc_light']


def _addon():
    import xbmcaddon
    return xbmcaddon.Addon()


def get_acc_color_mode():
    try:
        idx = int(_addon().getSetting('acc_color_mode') or '0')
        return _ACC_COLOR_MODES[idx] if 0 <= idx < len(_ACC_COLOR_MODES) else 'none'
    except Exception:
        return 'none'


def set_acc_color_mode(mode):
    try:
        idx = _ACC_COLOR_MODES.index(mode) if mode in _ACC_COLOR_MODES else 0
        _addon().setSetting('acc_color_mode', str(idx))
    except Exception:
        pass


def get_acc_force_bold():
    try:
        return _addon().getSetting('acc_force_bold') == 'true'
    except Exception:
        return False


def set_acc_force_bold(state):
    try:
        _addon().setSetting('acc_force_bold', 'true' if state else 'false')
    except Exception:
        pass


def get_acc_strip_symbols():
    try:
        return _addon().getSetting('acc_strip_symbols') == 'true'
    except Exception:
        return False


def set_acc_strip_symbols(state):
    try:
        _addon().setSetting('acc_strip_symbols', 'true' if state else 'false')
    except Exception:
        pass


def get_acc_font_size():
    try:
        return _addon().getSetting('acc_font_size') == 'true'
    except Exception:
        return False


def set_acc_font_size(state):
    try:
        _addon().setSetting('acc_font_size', 'true' if state else 'false')
    except Exception:
        pass


_SYMBOL_MAP = {
    '★': '*', '☆': '*', '●': '·', '•': '-',
    '▲': '^', '▼': 'v', '►': '>', '◄': '<',
    '➤': '>', '✓': 'OK', '✗': 'X', '✘': 'X',
    '→': '->', '←': '<-', '↑': '^', '↓': 'v',
    '…': '...', '«': '<<', '»': '>>',
}


_COLOR_TRANSFORM = {
    'white': {
        '__default__': 'white',
    },
    'daltonic_rg': {
        'red': 'darkorange', 'crimson': 'darkorange', 'darkred': 'darkorange',
        'tomato': 'darkorange', 'firebrick': 'darkorange',
        'green': 'deepskyblue', 'limegreen': 'deepskyblue', 'lime': 'deepskyblue',
        'darkgreen': 'deepskyblue', 'chartreuse': 'deepskyblue',
    },
    'daltonic_by': {
        'yellow': 'fuchsia', 'gold': 'fuchsia', 'orange': 'fuchsia',
        'darkorange': 'fuchsia', 'lightyellow': 'fuchsia',
        'blue': 'orangered', 'deepskyblue': 'orangered', 'cyan': 'orangered',
        'cornflowerblue': 'orangered', 'royalblue': 'orangered', 'aqua': 'orangered',
    },
    'hc_dark': {
        '__default__': 'yellow',
        'red': 'red',
    },
    'hc_light': {
        '__default__': 'black',
        'red': 'red',
    },
}

_COLOR_WRAP = {
    'white':    'white',
    'hc_dark':  'yellow',
    'hc_light': 'black',
}

_COLOR_TAG_RE = re.compile(r'\[COLOR ([^\]]+)\](.*?)\[/COLOR\]', re.DOTALL)


def _apply_color_transform(text, mode):
    transform = _COLOR_TRANSFORM.get(mode)
    if not transform:
        return text
    default = transform.get('__default__')

    def _replace(m):
        color = m.group(1).lower().strip()
        new = transform.get(color, default)
        if new is None:
            return m.group(0)
        return '[COLOR {0}]{1}[/COLOR]'.format(new, m.group(2))

    result = _COLOR_TAG_RE.sub(_replace, text)

    wrap = _COLOR_WRAP.get(mode)
    if wrap:
        result = '[COLOR {0}]{1}[/COLOR]'.format(wrap, result)
    return result


def apply_label(text, bold=None, strip=None, color_mode=None, font_size=None):
    """Devuelve el texto con todas las transformaciones de accesibilidad aplicadas.
    Recibe bold/strip/color_mode/font_size pre-leídos para evitar llamadas extra a getSetting() por ítem."""
    if not text:
        return text
    if strip is None:
        strip = get_acc_strip_symbols()
    if bold is None:
        bold = get_acc_force_bold()
    if color_mode is None:
        color_mode = get_acc_color_mode()
    if font_size is None:
        font_size = get_acc_font_size()
    if strip:
        for sym, rep in _SYMBOL_MAP.items():
            text = text.replace(sym, rep)
    if color_mode and color_mode != 'none':
        text = _apply_color_transform(text, color_mode)
    if not bold:
        text = text.replace('[B]', '').replace('[/B]', '')
    if font_size:
        text = '[UPPERCASE]' + text + '[/UPPERCASE]'
    return text


def state_tag(enabled):
    """Etiqueta BBCode de estado (ACTIVADA / DESACTIVADA) para toggles del menú."""
    if enabled:
        return "[COLOR green]ACTIVADA[/COLOR]"
    return "[COLOR red]DESACTIVADA[/COLOR]"


# --- Trakt.tv ---

_TRAKT_SETTINGS_FILE = 'trakt_settings.json'
_TOPZILLA_TRAKT_CLIENT_ID = base64.b64decode("ZGY1MDZjZjQ4ZDY1ZGVlZDAyOTczOWY2Zjk3ZjcxYjA2NzE0YmI4ZGExZTgyMGRmMjVkOTMyYzk4M2EyYjNhZQ==").decode()

_DEFAULT_TRAKT_LIST_IDS = [
    "805405", "1282987", "2748259", "797798", "832943",
    "4737076", "4834057", "9429302", "851495", "1558961",
    "6544049", "3785062", "20579314", "11512456", "2142753",
    "2143363", "1211468", "11416887", "801239", "6652041",
    "20770365", "1326415", "1076107", "20492899", "20770267",
    "20772087", "21583416",
]


def get_trakt_settings():
    data = load_json(_TRAKT_SETTINGS_FILE, default={"api_key": "", "lists": []})
    if not isinstance(data, dict):
        return {"api_key": "", "lists": []}
    data.setdefault("api_key", "")
    data.setdefault("lists", [])
    return data


def save_trakt_settings(data):
    save_json(_TRAKT_SETTINGS_FILE, data)


def get_tmdb_user_key():
    try:
        return (_addon().getSetting('tmdb_api_key') or '').strip()
    except Exception:
        return ''


def get_tmdb_api_key():
    return get_tmdb_user_key() or _pool_key()


def set_tmdb_api_key(key):
    key = (key or '').strip() if isinstance(key, str) else ''
    try:
        _addon().setSetting('tmdb_api_key', key)
        return True
    except Exception:
        return False


def validate_tmdb_key(key, timeout=6):
    """Devuelve True si TMDB acepta la clave, False si la rechaza, None si no se pudo verificar."""
    if not isinstance(key, str) or not key.strip():
        return False
    try:
        import requests
        r = requests.get('https://api.themoviedb.org/3/configuration',
                         params={'api_key': key.strip()}, timeout=timeout)
        if 200 <= r.status_code < 300:
            return True
        if r.status_code in (401, 403):
            return False
    except Exception:
        pass
    return None


def validate_trakt_key(key, timeout=6):
    """Devuelve True si Trakt acepta el Client ID, False si lo rechaza, None si no se pudo verificar."""
    if not isinstance(key, str) or not key.strip():
        return False
    try:
        import requests
        r = requests.get('https://api.trakt.tv/movies/popular',
                         headers={'trakt-api-key': key.strip(),
                                  'trakt-api-version': '2'},
                         params={'limit': 1}, timeout=timeout)
        if 200 <= r.status_code < 300:
            return True
        if r.status_code in (401, 403):
            return False
    except Exception:
        pass
    return None


def get_trakt_user_key():
    try:
        addon = _addon()
        kodi_key = (addon.getSetting('trakt_api_key') or '').strip()
        if kodi_key:
            return kodi_key
        # Migra la key de trakt_settings.json (formato previo) al Kodi setting.
        # Solo ocurre una vez: tras migrar, limpia el campo JSON para que
        # borrar el Kodi setting no reactive la key antigua.
        settings = get_trakt_settings()
        json_key = settings.get('api_key', '')
        json_key = json_key.strip() if isinstance(json_key, str) else ''
        if json_key:
            try:
                addon.setSetting('trakt_api_key', json_key)
                settings['api_key'] = ''
                save_trakt_settings(settings)
            except Exception:
                pass
            return json_key
    except Exception:
        pass
    return ''


def get_trakt_api_key():
    return get_trakt_user_key() or _TOPZILLA_TRAKT_CLIENT_ID


def get_omdb_user_key():
    try:
        return (_addon().getSetting('omdb_api_key') or '').strip()
    except Exception:
        return ''


def get_omdb_api_key():
    """User key first, fallback to hardcoded pool."""
    return get_omdb_user_key() or _omdb_pool_key()


def set_omdb_api_key(key):
    key = (key or '').strip() if isinstance(key, str) else ''
    try:
        _addon().setSetting('omdb_api_key', key)
        return True
    except Exception:
        return False


def set_trakt_api_key(key):
    key = (key or '').strip() if isinstance(key, str) else ''
    try:
        _addon().setSetting('trakt_api_key', key)
        return True
    except Exception:
        pass
    # setSetting falló (Kodi no disponible): guarda en JSON como fallback.
    try:
        data = get_trakt_settings()
        data['api_key'] = key
        save_trakt_settings(data)
        return True
    except Exception:
        return False


def get_trakt_lists():
    return get_trakt_settings().get("lists", [])


def add_trakt_list(list_id, name, user, item_count=0):
    data = get_trakt_settings()
    lists = data.get("lists", [])
    for l in lists:
        if l['id'] == list_id:
            l['name'] = name
            l['user'] = user
            l['item_count'] = item_count
            save_trakt_settings(data)
            return
    lists.append({"id": list_id, "name": name, "user": user, "item_count": item_count})
    data["lists"] = lists
    save_trakt_settings(data)
    order = load_trakt_lists_order()
    if order:
        new_order = [list_id] + [x for x in order if x != list_id]
        save_trakt_lists_order(new_order)


def seed_default_trakt_lists(api_key=''):
    """Añade las listas por defecto que aún no estén ni hayan sido eliminadas."""
    data = get_trakt_settings()
    lists = data.get("lists", [])
    removed_defaults = set(data.get("removed_defaults", []))
    existing_ids = {l['id'] for l in lists}
    new_ids = [lid for lid in _DEFAULT_TRAKT_LIST_IDS
               if lid not in existing_ids and lid not in removed_defaults]
    if not new_ids:
        return
    names = {lid: "Lista Trakt #{0}".format(lid) for lid in new_ids}
    if api_key:
        try:
            import requests
            from concurrent.futures import ThreadPoolExecutor
            headers = {'trakt-api-key': api_key, 'trakt-api-version': '2',
                       'Content-Type': 'application/json'}

            def fetch_name(lid):
                try:
                    r = requests.get("https://api.trakt.tv/lists/{0}".format(lid),
                                      headers=headers, timeout=5)
                    if r.status_code == 200:
                        return lid, r.json().get('name', names[lid])
                except Exception:
                    pass
                return lid, names[lid]

            with ThreadPoolExecutor(max_workers=8) as ex:
                for lid, name in ex.map(fetch_name, new_ids):
                    names[lid] = name
        except Exception:
            pass
    for lid in new_ids:
        lists.append({"id": lid, "name": names[lid], "user": "official", "item_count": 0})
    data["lists"] = lists
    save_trakt_settings(data)


def remove_trakt_list(list_id):
    data = get_trakt_settings()
    lists = data.get("lists", [])
    if list_id in _DEFAULT_TRAKT_LIST_IDS:
        removed = data.get("removed_defaults", [])
        if list_id not in removed:
            removed.append(list_id)
        data["removed_defaults"] = removed
    data["lists"] = [l for l in lists if l['id'] != list_id]
    save_trakt_settings(data)


def get_fanart_mode():
    try:
        return _addon().getSetting('fanart_mode') or 'addon'
    except Exception:
        return 'addon'


def set_fanart_mode(mode):
    try:
        _addon().setSetting('fanart_mode', mode)
    except Exception:
        pass


def get_custom_fanart_path():
    try:
        return _addon().getSetting('fanart_custom_path') or ''
    except Exception:
        return ''


def set_custom_fanart_path(path):
    try:
        _addon().setSetting('fanart_custom_path', path)
    except Exception:
        pass


def addon_media(filename):
    return os.path.join(_addon().getAddonInfo('path'), 'resources', 'media', filename)


def addon_fanart():
    try:
        mode = get_fanart_mode()
        if mode == 'disabled':
            return ''
        if mode == 'custom':
            path = get_custom_fanart_path()
            if path and os.path.exists(path):
                return path
        return os.path.join(_addon().getAddonInfo('path'), 'fanart.jpg')
    except Exception:
        return ''


# --- Atajos personalizados en "¿Dónde buscar?" ---

_SEARCH_SHORTCUTS_FILE = 'search_shortcuts.json'

# Tags BBCode admitidos por Kodi que no queremos en nombres de atajos
# (evita que un nombre rompa el [COLOR gold]...[/COLOR] del menú "¿Dónde buscar?").
_BBCODE_RE = re.compile(
    r'\[/?(?:B|I|UPPERCASE|LOWERCASE|CAPITALIZE|LIGHT|COLOR(?:\s+[^\]]*)?)\]',
    re.IGNORECASE,
)


def sanitize_shortcut_name(text):
    if not text:
        return ''
    return _BBCODE_RE.sub('', str(text)).strip()


def load_search_shortcuts():
    data = load_json(_SEARCH_SHORTCUTS_FILE, default=[])
    if not isinstance(data, list):
        return []
    out = []
    for item in data:
        if not isinstance(item, dict):
            continue
        cmd = item.get('command')
        if not isinstance(cmd, str) or not cmd.strip():
            continue
        out.append({
            'name':    sanitize_shortcut_name(item.get('name')) or cmd[:40],
            'icon':    item.get('icon') if isinstance(item.get('icon'), str) else '',
            'command': cmd.strip(),
            'type':    item.get('type') if item.get('type') in ('addon', 'manual') else 'manual',
            'addon_id': item.get('addon_id') if isinstance(item.get('addon_id'), str) else '',
        })
    return out


def save_search_shortcuts(shortcuts):
    return save_json(_SEARCH_SHORTCUTS_FILE, shortcuts)


# --- Orden personalizado de la ventana "¿Dónde buscar?" ---

_SEARCH_MENU_ORDER_FILE = 'search_menu_order.json'


def load_search_menu_order():
    data = load_json(_SEARCH_MENU_ORDER_FILE, default=[])
    if not isinstance(data, list):
        return []
    return [x for x in data if isinstance(x, str)]


def save_search_menu_order(order):
    return save_json(_SEARCH_MENU_ORDER_FILE, list(order))


def reset_search_menu_order():
    return save_json(_SEARCH_MENU_ORDER_FILE, [])


# --- Orden personalizado de las listas Trakt ---

_TRAKT_LISTS_ORDER_FILE = 'trakt_lists_order.json'


def load_trakt_lists_order():
    data = load_json(_TRAKT_LISTS_ORDER_FILE, default=[])
    if not isinstance(data, list):
        return []
    return [x for x in data if isinstance(x, str)]


def save_trakt_lists_order(order):
    return save_json(_TRAKT_LISTS_ORDER_FILE, list(order))


def reset_trakt_lists_order():
    return save_json(_TRAKT_LISTS_ORDER_FILE, [])


def shortcut_stable_id(sc):
    """ID estable para un atajo. Sobrevive a renombrados."""
    if not isinstance(sc, dict):
        return ''
    aid = sc.get('addon_id') or ''
    if aid:
        return 'custom:addon:{0}'.format(aid)
    cmd = (sc.get('command') or '').strip()
    if not cmd:
        return ''
    return 'custom:cmd:{0}'.format(hashlib.sha1(cmd.encode('utf-8')).hexdigest()[:8])
