# -*- coding: utf-8 -*-
# TopZilla — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""
Favoritos: lista persistente de películas/series marcadas por el usuario.

Modelo de datos: lista de MovieRef (movie_ref.py) en `favorites.json`.
Deduplicación por `ref_key`.
"""
import sys
import time

import xbmc
import xbmcgui
import xbmcplugin

import core_settings
import movie_ref


_FILE = 'favorites.json'


def _u(**kwargs):
    return core_settings.make_url(**kwargs)


def _handle():
    return int(sys.argv[1])


def _load():
    data = core_settings.load_json(_FILE, default=[])
    return data if isinstance(data, list) else []


def _save(refs):
    core_settings.save_json(_FILE, refs)


def is_favorite(key):
    if not key:
        return False
    return any(movie_ref.ref_key(r) == key for r in _load())


def add(ref):
    if not ref or not ref.get('title'):
        return False
    refs = _load()
    key = movie_ref.ref_key(ref)
    if any(movie_ref.ref_key(r) == key for r in refs):
        xbmcgui.Dialog().notification("TopZilla", "Ya estaba en favoritos",
                                       xbmcgui.NOTIFICATION_INFO, 2500)
        return False
    ref = dict(ref)
    ref['added_at'] = int(time.time())
    refs.insert(0, ref)
    _save(refs)
    xbmcgui.Dialog().notification("TopZilla",
                                   "Añadido a favoritos: {0}".format(ref.get('title', '')),
                                   xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin("Container.Refresh")
    return True


def remove(key):
    if not key:
        return False
    refs = _load()
    new_refs = movie_ref.remove_by_key(refs, key)
    if len(new_refs) == len(refs):
        return False
    _save(new_refs)
    xbmcgui.Dialog().notification("TopZilla", "Quitado de favoritos",
                                   xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin("Container.Refresh")
    return True


def clear_all():
    if not xbmcgui.Dialog().yesno("TopZilla - Favoritos",
                                   "¿Borrar TODOS los favoritos? Esta acción no se puede deshacer."):
        return
    _save([])
    xbmcgui.Dialog().notification("TopZilla", "Favoritos borrados",
                                   xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin("Container.Refresh")


_FIELD_LABELS = (
    ('title',      'Título'),
    ('year',       'Año'),
    ('media_type', 'Tipo'),
    ('tmdb_id',    'TMDB ID'),
    ('imdb_id',    'IMDb ID'),
    ('plot',       'Sinopsis'),
    ('poster',     'Cartel (URL)'),
)


def _label_for(field):
    for f, lbl in _FIELD_LABELS:
        if f == field:
            return lbl
    return field


def _format_value(field, value):
    if field == 'media_type':
        return 'Serie' if value == 'show' else 'Película'
    if value in (None, '', 0):
        return '(vacío)'
    s = str(value)
    return s if len(s) <= 60 else s[:57] + '...'


def _edit_field(ref, field):
    current = ref.get(field)
    if field == 'media_type':
        idx = xbmcgui.Dialog().select('Tipo', ['Película', 'Serie'],
                                       preselect=1 if current == 'show' else 0)
        if idx < 0:
            return False
        ref['media_type'] = 'show' if idx == 1 else 'movie'
        return True

    if field in ('year', 'tmdb_id'):
        default = '' if current in (None, 0, '') else str(current)
        kb = xbmc.Keyboard(default, _label_for(field))
        kb.doModal()
        if not kb.isConfirmed():
            return False
        text = kb.getText().strip()
        if not text:
            ref[field] = 0 if field == 'year' else None
            return True
        try:
            ref[field] = int(text)
        except ValueError:
            xbmcgui.Dialog().notification('TopZilla',
                'Valor numérico no válido', xbmcgui.NOTIFICATION_WARNING, 2000)
            return False
        return True

    default = '' if current is None else str(current)
    kb = xbmc.Keyboard(default, _label_for(field))
    kb.doModal()
    if not kb.isConfirmed():
        return False
    text = kb.getText().strip()
    if field == 'title' and not text:
        xbmcgui.Dialog().notification('TopZilla',
            'El título no puede estar vacío', xbmcgui.NOTIFICATION_WARNING, 2000)
        return False
    ref[field] = text or (None if field == 'imdb_id' else '')
    return True


def edit(key):
    if not key:
        return
    refs = _load()
    ref = movie_ref.find_ref(refs, key)
    if not ref:
        xbmcgui.Dialog().notification('TopZilla',
            'Favorito no encontrado', xbmcgui.NOTIFICATION_WARNING, 2500)
        return

    changed = False
    while True:
        opciones = ['{0}: {1}'.format(lbl, _format_value(f, ref.get(f)))
                    for f, lbl in _FIELD_LABELS]
        idx = xbmcgui.Dialog().select(
            'Editar: {0}'.format(ref.get('title', '')), opciones)
        if idx < 0:
            break
        field = _FIELD_LABELS[idx][0]
        if _edit_field(ref, field):
            changed = True

    if not changed:
        return

    new_key = movie_ref.ref_key(ref)
    if new_key != key:
        collision = next(
            (r for r in refs if r is not ref and movie_ref.ref_key(r) == new_key),
            None)
        if collision:
            if not xbmcgui.Dialog().yesno('TopZilla',
                'Ya existe otro favorito con esos datos. ¿Sobrescribirlo?'):
                xbmcgui.Dialog().notification('TopZilla',
                    'Cambios descartados', xbmcgui.NOTIFICATION_INFO, 2500)
                return
            refs = [r for r in refs if r is ref or movie_ref.ref_key(r) != new_key]

    _save(refs)
    xbmcgui.Dialog().notification('TopZilla', 'Favorito actualizado',
                                   xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin('Container.Refresh')


def pick_action(key):
    if not key:
        return
    while True:
        ref = movie_ref.find_ref(_load(), key)
        if not ref:
            xbmcgui.Dialog().notification('TopZilla',
                'Favorito no encontrado', xbmcgui.NOTIFICATION_WARNING, 2500)
            return
        idx = xbmcgui.Dialog().select(
            'Acciones — {0}'.format(movie_ref.display_label(ref)),
            ['[COLOR cyan]Editar campos…[/COLOR]',
             '[COLOR red]Borrar este favorito[/COLOR]',
             'Ver datos guardados'])
        if idx < 0:
            return
        if idx == 0:
            edit(key)
            return
        if idx == 1:
            _remove_one(key, ref)
            return
        if idx == 2:
            _view_info(ref)


def _remove_one(key, ref):
    if not xbmcgui.Dialog().yesno('TopZilla',
        '¿Quitar de favoritos?\n\n{0}'.format(movie_ref.display_label(ref))):
        return
    if not remove(key):
        xbmcgui.Dialog().notification('TopZilla',
            'No se pudo quitar (ya no existía)',
            xbmcgui.NOTIFICATION_WARNING, 2500)


def _view_info(ref):
    media = 'Serie' if ref.get('media_type') == 'show' else 'Película'
    year = ref.get('year') or 0
    added = ref.get('added_at')
    try:
        added_str = time.strftime('%d/%m/%Y %H:%M',
                                    time.localtime(int(added))) if added else '(desconocido)'
    except (ValueError, TypeError):
        added_str = '(desconocido)'

    text = (
        "[B]Título:[/B] {0}\n"
        "[B]Año:[/B] {1}\n"
        "[B]Tipo:[/B] {2}\n"
        "[B]TMDB ID:[/B] {3}\n"
        "[B]IMDb ID:[/B] {4}\n\n"
        "[B]Sinopsis:[/B]\n{5}\n\n"
        "[B]Cartel:[/B] {6}\n\n"
        "[B]Fuente:[/B] {7}\n"
        "[B]Añadido:[/B] {8}"
    ).format(
        ref.get('title') or '(sin título)',
        year if year else '(vacío)',
        media,
        ref.get('tmdb_id') or '(vacío)',
        ref.get('imdb_id') or '(vacío)',
        ref.get('plot') or '(vacía)',
        ref.get('poster') or '(vacío)',
        ref.get('source') or '(desconocida)',
        added_str,
    )
    xbmcgui.Dialog().textviewer('Datos guardados', text)


def show_edit_menu():
    import metadata_enricher as me

    h = _handle()
    refs = _load()
    af = core_settings.addon_fanart()

    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()

    if not refs:
        li = xbmcgui.ListItem(label="[COLOR gray]No tienes favoritos guardados[/COLOR]")
        li.setArt({'icon': 'DefaultIconInfo.png', 'fanart': af})
        xbmcplugin.addDirectoryItem(handle=h, url='', listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
        return

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR yellow][I]Pulsa cualquier favorito para editarlo, borrarlo o ver sus datos.[/I][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultIconInfo.png', 'fanart': af})
    li.setInfo('video', {'plot':
        "Pulsa cualquier favorito para abrir el menú de acciones (editar, borrar, ver datos)."})
    li.setProperty('IsPlayable', 'false')
    xbmcplugin.addDirectoryItem(handle=h, url='', listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR red][B]Borrar todos los favoritos[/B][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultIconError.png', 'fanart': af})
    li.setProperty('IsPlayable', 'false')
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='favorites_clear_all'),
                                 listitem=li, isFolder=False)

    for ref in refs:
        title = ref.get('title') or ''
        year = ref.get('year') or 0
        media = ref.get('media_type', 'movie')
        label = "[B]{0}[/B]".format(movie_ref.display_label(ref))
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            label, bold=_bold, strip=_strip, color_mode=_color))

        meta = me.enrich(
            tmdb_id=ref.get('tmdb_id'),
            imdb_id=ref.get('imdb_id'),
            title=title,
            year=year or None,
            media_type=media,
            use_cache_only=True,
        )
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
        else:
            poster = ref.get('poster') or ''
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': poster, 'poster': poster, 'fanart': af})
            li.setInfo('video', {
                'title': title,
                'year': year,
                'plot': ref.get('plot') or '',
                'mediatype': 'tvshow' if media == 'show' else 'movie',
            })

        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='favorite_pick_action', key=movie_ref.ref_key(ref)),
            listitem=li,
            isFolder=False,
        )

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def show_menu():
    import metadata_enricher as me
    import context_menu

    h = _handle()
    refs = _load()
    af = core_settings.addon_fanart()

    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()

    try:
        import espakodi_installer as _eki
        _FLOWFAV_ID = "plugin.program.flowfavmanager"
        if _eki._ek_addon_is_installed(_FLOWFAV_ID):
            _ff_label = "[COLOR violet][B]Flow FavManager[/B][/COLOR]"
            _ff_plot  = ("Abre el editor y organizador avanzado de favoritos para Kodi.\n"
                         "Personaliza colores, iconos, formatos, crea secciones, "
                         "perfiles, copias de seguridad y más.")
        else:
            _ff_label = "[COLOR gray]Flow FavManager (No instalado)[/COLOR]"
            _ff_plot  = ("Editor y organizador avanzado de favoritos para Kodi.\n"
                         "Personaliza colores, iconos, formatos, crea secciones, "
                         "perfiles, copias de seguridad y más.\n\n"
                         "Pulsa para instalarlo o ver instrucciones.")
        li_ff = xbmcgui.ListItem(label=core_settings.apply_label(
            _ff_label, bold=_bold, strip=_strip, color_mode=_color))
        li_ff.setArt({'icon': _eki._ek_addon_icon(
            _FLOWFAV_ID, fallback=core_settings.addon_media('favoritos.png')), 'fanart': af})
        li_ff.setInfo('video', {'plot': _ff_plot})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action='flowfav_launch'),
                                    listitem=li_ff, isFolder=False)
    except Exception as _ff_err:
        xbmc.log("[TopZilla] Flow FavManager item omitido: {0}".format(_ff_err), xbmc.LOGWARNING)

    if not refs:
        li = xbmcgui.ListItem(label="[COLOR gray]No tienes favoritos guardados[/COLOR]")
        li.setArt({'icon': 'DefaultIconInfo.png', 'fanart': core_settings.addon_fanart()})
        li.setInfo('video', {'plot': "Añade películas a favoritos desde el menú contextual (clic derecho)\n"
                                       "en cualquier sección del addon."})
        xbmcplugin.addDirectoryItem(handle=h, url='', listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
        return

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR cyan][B]Editar favoritos…[/B][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': core_settings.addon_media('adv_editar.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot':
        "Vista simplificada para editar datos, borrar o ver información de cada favorito guardado."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='favorites_edit_menu'),
                                 listitem=li, isFolder=True)

    for ref in refs:
        title = ref.get('title') or ''
        year = ref.get('year') or 0
        media = ref.get('media_type', 'movie')
        label = "[B]{0}[/B]".format(movie_ref.display_label(ref))
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            label, bold=_bold, strip=_strip, color_mode=_color))

        meta = me.enrich(
            tmdb_id=ref.get('tmdb_id'),
            imdb_id=ref.get('imdb_id'),
            title=title,
            year=year or None,
            media_type=media,
            use_cache_only=True,
        )
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
        else:
            poster = ref.get('poster') or ''
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': poster, 'poster': poster, 'fanart': af})
            li.setInfo('video', {
                'title': title,
                'year': year,
                'plot': ref.get('plot') or '',
                'mediatype': 'tvshow' if media == 'show' else 'movie',
            })

        context_menu.attach(li, ref)
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=context_menu.build_play_url(ref),
            listitem=li,
            isFolder=False,
        )

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)
