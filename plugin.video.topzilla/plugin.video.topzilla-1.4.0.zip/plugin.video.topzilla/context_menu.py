# -*- coding: utf-8 -*-
# TopZilla — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""
Helper centralizado para el menú contextual de cada película/serie.

Lo usan: filmaffinity, sensacine, cinemeta, tmdb_lists, top_movies,
search_movies, trakt_manager y category_manager (al ver una categoría).

`attach(li, ref)` añade el menú contextual estándar al ListItem `li`.
`build_play_url(ref)` devuelve la URL de click izquierdo, que pasa por
`record_navigation` (registra la peli en el historial) y delega en el
diálogo de búsqueda de alternativas existente.
"""
import xbmcaddon

import core_settings
import movie_ref


def _u(**kwargs):
    return core_settings.make_url(**kwargs)


def has_embuary():
    """True si script.embuary.info está instalado y es instanciable."""
    try:
        xbmcaddon.Addon('script.embuary.info')
        return True
    except RuntimeError:
        return False


def _embuary_script(ref):
    """Devuelve la cadena RunScript para Embuary Info, o None si no procede.

    API verificada en sualfred/script.embuary.info (rama matrix):
      call=movie|tv      tipo de contenido (no 'info=')
      tmdb_id=N          identificador TMDB (preferido)
      external_id=ttN    identificador IMDb (con prefijo 'tt')
      query=texto        búsqueda libre (sin comas: RunScript las usa de separador)
      year=YYYY          opcional, mejora la precisión del query
    """
    if not has_embuary():
        return None
    media     = ref.get('media_type', 'movie')
    call_type = 'tv' if media == 'show' else 'movie'
    tmdb_id   = ref.get('tmdb_id')
    imdb_id   = ref.get('imdb_id')
    title     = (ref.get('title') or '').strip()
    year      = ref.get('year') or 0

    args = []
    args.append("call={0}".format(call_type))
    if tmdb_id:
        try:
            args.append("tmdb_id={0}".format(int(tmdb_id)))
        except (ValueError, TypeError):
            return None
    elif isinstance(imdb_id, str) and imdb_id.startswith('tt'):
        args.append("external_id={0}".format(imdb_id))
    elif title:
        safe = title.replace('"', ' ').replace(',', ' ').strip()
        if len(safe) < 2:
            return None
        args.append("query={0}".format(safe))
    else:
        return None

    if year:
        try:
            args.append("year={0}".format(int(year)))
        except (ValueError, TypeError):
            pass

    return "RunScript(script.embuary.info,{0})".format(",".join(args))


def attach(li, ref, extra=None):
    """Añade el menú contextual estándar al ListItem `li` para la peli `ref`.

    `extra`: lista opcional de tuplas (label, action) que se añaden al final.
    """
    import favorites
    import watch_history

    cm = []
    ref_json = movie_ref.dumps_ref(ref)
    key = movie_ref.ref_key(ref)
    title = ref.get('title', '')
    media = ref.get('media_type', 'movie')

    if favorites.is_favorite(key):
        cm.append(("[COLOR red]Quitar de Favoritos[/COLOR]",
                   "RunPlugin({0})".format(_u(action='remove_favorite', key=key))))
        cm.append(("Editar favorito…",
                   "RunPlugin({0})".format(_u(action='edit_favorite', key=key))))
    else:
        cm.append(("[COLOR gold]Añadir a Favoritos[/COLOR]",
                   "RunPlugin({0})".format(_u(action='add_favorite', ref=ref_json))))

    if watch_history.is_watched(key):
        cm.append(("Desmarcar como vista",
                   "RunPlugin({0})".format(_u(action='unmark_watched', key=key))))
    else:
        cm.append(("Marcar como vista",
                   "RunPlugin({0})".format(_u(action='mark_watched', ref=ref_json))))

    cm.append(("Añadir a Categoría...",
               "RunPlugin({0})".format(_u(action='cat_add_item', ref=ref_json))))

    cm.append(("Buscar alternativas",
               "RunPlugin({0})".format(_u(
                   action='search_alt_prompt',
                   q=title,
                   ot=ref.get('poster', ''),
                   mode=media,
                   ref=ref_json,
               ))))

    embuary = _embuary_script(ref)
    if embuary:
        cm.append(("Ficha completa", embuary))

    if extra:
        cm.extend(extra)

    li.addContextMenuItems(cm)


def build_play_url(ref):
    """URL del click izquierdo: pasa por record_navigation y delega en el flujo existente."""
    return _u(action='record_navigation', ref=movie_ref.dumps_ref(ref))
