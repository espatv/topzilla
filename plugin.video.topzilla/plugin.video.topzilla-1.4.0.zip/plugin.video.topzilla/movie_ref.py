# -*- coding: utf-8 -*-
# TopZilla — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""
Estructura común de referencia a una película/serie (`MovieRef`).

Usada por: favorites, watch_history, navigation_history, search_movies,
category_manager, trakt_manager y por context_menu para construir las URLs
de las acciones del menú contextual.

La clave canónica (`ref_key`) es estable entre módulos: una misma película
añadida desde FilmAffinity y desde TMDB Lists se deduplica si ambos refs
acaban con el mismo `tmdb_id`.
"""
import json
import re
import time
import urllib.parse


_VALID_MEDIA = ('movie', 'show')


def _to_int(v):
    if v is None or v == '' or isinstance(v, bool):
        return None
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def _slug(s):
    s = (s or '').lower().strip()
    s = re.sub(r'[^a-z0-9]+', '-', s)
    return s.strip('-')


def make_ref(title, year=None, tmdb_id=None, imdb_id=None,
             media_type='movie', poster='', source='', added_at=None, plot=''):
    mt = media_type if media_type in _VALID_MEDIA else 'movie'
    return {
        'tmdb_id':    _to_int(tmdb_id),
        'imdb_id':    imdb_id or None,
        'title':      title or '',
        'year':       _to_int(year) or 0,
        'media_type': mt,
        'poster':     poster or '',
        'plot':       plot or '',
        'source':     source or '',
        'added_at':   int(added_at) if added_at is not None else int(time.time()),
    }


def ref_key(ref):
    """Clave única para deduplicación.

    Preferencia: tmdb > imdb > title+year. Incluye media_type para
    permitir que una peli y una serie con el mismo título coexistan.
    """
    if not ref:
        return ''
    mt = ref.get('media_type', 'movie')
    tmdb_id = _to_int(ref.get('tmdb_id'))
    if tmdb_id:
        return "tmdb:{0}:{1}".format(mt, tmdb_id)
    imdb_id = ref.get('imdb_id')
    if imdb_id:
        return "imdb:{0}:{1}".format(mt, imdb_id)
    title = ref.get('title') or ''
    year = ref.get('year') or 0
    slug = _slug(title)
    return "title:{0}:{1}:{2}".format(mt, slug, year)


def keys_match(ref_a, ref_b):
    return ref_key(ref_a) == ref_key(ref_b)


def find_ref(refs, key):
    for r in refs:
        if ref_key(r) == key:
            return r
    return None


def remove_by_key(refs, key):
    return [r for r in refs if ref_key(r) != key]


def dedupe(refs):
    """Elimina duplicados (por `ref_key`) preservando el orden, conservando el primero."""
    seen = set()
    out = []
    for r in refs:
        k = ref_key(r)
        if k and k not in seen:
            seen.add(k)
            out.append(r)
    return out


def dumps_ref(ref):
    """Serializa un ref para pasarlo en una URL del plugin (urlencode-safe)."""
    return urllib.parse.quote(json.dumps(ref, ensure_ascii=False), safe='')


def loads_ref(s):
    """Deserializa un ref recibido por URL. Devuelve {} si falla."""
    if not s:
        return {}
    try:
        return json.loads(urllib.parse.unquote(s))
    except (ValueError, TypeError):
        return {}


def display_label(ref):
    """Etiqueta legible para listados: 'Título (Año)' o 'Título'."""
    title = ref.get('title') or ''
    year = ref.get('year') or 0
    return "{0} ({1})".format(title, year) if year else title
