# -*- coding: utf-8 -*-
# TopZilla — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""
Historial de Navegación: registro automático de las películas/series sobre
las que el usuario hace click. Máximo 50 entradas (FIFO con LRU al revisitar).

Modelo: lista de MovieRef en `navigation_history.json`. Cada entrada lleva
`visited_at`. Si el usuario vuelve a hacer click, la entrada existente
sube al principio y actualiza el timestamp.
"""
import sys
import time

import xbmc
import xbmcgui
import xbmcplugin

import core_settings
import movie_ref


_FILE = 'navigation_history.json'
_MAX = 50


def _u(**kwargs):
    return core_settings.make_url(**kwargs)


def _handle():
    return int(sys.argv[1])


def _load():
    data = core_settings.load_json(_FILE, default=[])
    return data if isinstance(data, list) else []


def _save(refs):
    core_settings.save_json(_FILE, refs)


def record(ref):
    """LRU: si el ref ya existe, sube al inicio y actualiza visited_at."""
    if not ref or not ref.get('title'):
        return
    refs = _load()
    key = movie_ref.ref_key(ref)
    refs = [r for r in refs if movie_ref.ref_key(r) != key]
    new_ref = dict(ref)
    new_ref['visited_at'] = int(time.time())
    refs.insert(0, new_ref)
    if len(refs) > _MAX:
        refs = refs[:_MAX]
    _save(refs)


def delete(key):
    if not key:
        return False
    refs = _load()
    new_refs = movie_ref.remove_by_key(refs, key)
    if len(new_refs) == len(refs):
        return False
    _save(new_refs)
    xbmc.executebuiltin("Container.Refresh")
    return True


def clear_all():
    if not xbmcgui.Dialog().yesno("TopZilla - Historial de Navegación",
                                   "¿Borrar TODO el historial de navegación?\nEsta acción no se puede deshacer."):
        return
    _save([])
    xbmcgui.Dialog().notification("TopZilla", "Historial de navegación borrado",
                                   xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin("Container.Refresh")


def show_menu():
    import metadata_enricher as me
    import context_menu

    h = _handle()
    refs = _load()
    af = core_settings.addon_fanart()

    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()

    if not refs:
        li = xbmcgui.ListItem(label="[COLOR gray]No hay historial de navegación[/COLOR]")
        li.setArt({'icon': 'DefaultIconInfo.png', 'fanart': core_settings.addon_fanart()})
        li.setInfo('video', {'plot': "Las películas que abras aparecerán aquí automáticamente.\n"
                                       "Se conservan las últimas 50."})
        xbmcplugin.addDirectoryItem(handle=h, url='', listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
        return

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR red][B]Borrar todo el historial de navegación[/B][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultIconError.png', 'fanart': core_settings.addon_fanart()})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='navigation_history_clear_all'),
                                 listitem=li, isFolder=False)

    for ref in refs:
        title = ref.get('title') or ''
        year = ref.get('year') or 0
        media = ref.get('media_type', 'movie')
        visited_at = ref.get('visited_at') or 0
        date_str = time.strftime("%d/%m %H:%M", time.localtime(visited_at)) if visited_at else ""

        base_label = "[B]{0}[/B]".format(movie_ref.display_label(ref))
        label = "{0} [COLOR gray]({1})[/COLOR]".format(base_label, date_str) if date_str else base_label
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            label, bold=_bold, strip=_strip, color_mode=_color))

        meta = me.enrich(
            tmdb_id=ref.get('tmdb_id'),
            imdb_id=ref.get('imdb_id'),
            title=title,
            year=year or None,
            media_type=media,
            use_cache_only=True,
        )
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
        else:
            poster = ref.get('poster') or ''
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': poster, 'poster': poster, 'fanart': af})
            li.setInfo('video', {
                'title': title,
                'year': year,
                'mediatype': 'tvshow' if media == 'show' else 'movie',
            })

        cm_extra = [
            ("Borrar de este historial",
             "RunPlugin({0})".format(_u(action='navigation_history_delete', key=movie_ref.ref_key(ref)))),
        ]
        context_menu.attach(li, ref, extra=cm_extra)
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=context_menu.build_play_url(ref),
            listitem=li,
            isFolder=False,
        )

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)
