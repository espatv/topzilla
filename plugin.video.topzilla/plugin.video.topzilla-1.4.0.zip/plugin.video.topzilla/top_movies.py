# -*- coding: utf-8 -*-
# TopZilla — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
import json
import os
import sys

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import core_settings
import movie_data

_PER_PAGE = 50


def _u(**kwargs):
    return core_settings.make_url(**kwargs)

def _handle():
    return int(sys.argv[1])


def _cache_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    p = profile
    if not os.path.exists(p):
        os.makedirs(p)
    return os.path.join(p, 'topzilla_top_movies_thumbs.json')


def _load_cache():
    path = _cache_path()
    if os.path.exists(path):
        try:
            with open(path, 'r', encoding='utf-8') as fh:
                return json.load(fh)
        except Exception:
            pass
    return {}


def _save_cache(data):
    try:
        path = _cache_path()
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, path)
    except Exception as e:
        xbmc.log("[TopZilla-TM] cache save: {0}".format(e), xbmc.LOGWARNING)


def show_top(page=1):
    try:
        page = int(page)
    except (ValueError, TypeError):
        page = 1

    h = _handle()
    addon = xbmcaddon.Addon()
    ai = addon.getAddonInfo('icon')
    af = core_settings.addon_fanart()

    movies = movie_data._get_movies_list()
    total = len(movies)
    start = (page - 1) * _PER_PAGE
    end = start + _PER_PAGE
    page_items = movies[start:end]

    cache = _load_cache()

    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()

    import metadata_enricher as me
    import context_menu, movie_ref

    items_meta = []
    for m in page_items:
        details  = movie_data._get_movie_details(m)
        year_int = int(details[0]) if str(details[0]).isdigit() else 0
        items_meta.append((m, year_int, details))

    if items_meta:
        first_title, first_year = items_meta[0][0], items_meta[0][1]
        has_meta = bool(me.enrich(title=first_title, year=first_year or None,
                                   media_type='movie', use_cache_only=True))
    else:
        has_meta = False
    if not has_meta:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            "[COLOR yellow][B]Descargar carátulas y reparto desde TMDB[/B][/COLOR]",
            bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': 'DefaultAddonService.png', 'fanart': core_settings.addon_fanart()})
        li.setInfo('video', {'plot': "Descarga carátulas en alta calidad y reparto en español de las 130+ películas top.\n\nSe guarda durante 30 días en caché local.\nProceso paralelo (~5-10 segundos)."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="cache_top_movies_covers"), listitem=li, isFolder=False)
    else:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            "[COLOR red][B]Borrar carátulas y reparto descargados[/B][/COLOR]",
            bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': 'DefaultIconError.png', 'fanart': core_settings.addon_fanart()})
        li.setInfo('video', {'plot': "Elimina los metadatos descargados de TMDB. La sección volverá a usar solo los datos locales (sin carátulas en alta calidad ni reparto)."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="clear_top_movies_cache"), listitem=li, isFolder=False)

    for m, year_int, details in items_meta:
        genre = movie_data._get_movie_genre(m)

        # Tras el pre-fetch paralelo, enrich con use_cache_only=True es instantáneo
        meta = me.enrich(title=m, year=year_int or None, media_type='movie',
                         use_cache_only=True)

        thumb = (meta.get('poster') if meta else None) or cache.get(m, ai)
        li = xbmcgui.ListItem(label=core_settings.apply_label("[B]{0}[/B]".format(m), bold=_bold, strip=_strip, color_mode=_color))

        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
        else:
            plot = (
                "[COLOR gold][B]Género:[/B][/COLOR] [COLOR deepskyblue]{0}[/COLOR]  |  "
                "[COLOR gold][B]Año:[/B][/COLOR] [COLOR deepskyblue]{1}[/COLOR]  |  "
                "[COLOR gold][B]Nota IMDb:[/B][/COLOR] [COLOR deepskyblue]{2}[/COLOR]\n"
                "[COLOR gold][B]Director:[/B][/COLOR] [COLOR deepskyblue]{3}[/COLOR]\n\n"
                "{4}"
            ).format(genre, details[0], details[1], details[2], movie_data._get_movie_plot(m))
            li.setArt({'thumb': thumb, 'icon': thumb, 'poster': thumb, 'fanart': af})
            li.setInfo('video', {
                'title':    m,
                'plot':     plot,
                'genre':    genre,
                'year':     year_int,
                'rating':   float(details[1]) if str(details[1]).replace('.', '', 1).isdigit() else 0.0,
                'director': details[2],
                'mediatype': 'movie',
            })

        tmdb_id = (meta or {}).get('ids', {}).get('tmdb') if meta else None
        plot = meta.get('overview', '') if meta else ''
        ref = movie_ref.make_ref(
            title=m, year=year_int,
            tmdb_id=tmdb_id, poster=thumb,
            media_type='movie', source='top_movies', plot=plot,
        )
        context_menu.attach(li, ref)
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(handle=h, url=context_menu.build_play_url(ref), listitem=li, isFolder=False)

    if end < total:
        li = xbmcgui.ListItem(label=core_settings.apply_label("[B]Siguiente Página ({0}) >>[/B]".format(page + 1), bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': 'DefaultFolder.png', 'fanart': core_settings.addon_fanart()})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='top_movies', page=page + 1),
            listitem=li,
            isFolder=True,
        )

    xbmcplugin.endOfDirectory(h)


def cache_covers():
    if not xbmcgui.Dialog().yesno(
        "TopZilla",
        "¿Descargar carátulas en alta calidad y reparto desde TMDB?\n\n"
        "Tarda ~5-10s. Se guarda durante 30 días.",
    ):
        return

    import metadata_enricher as me

    movies = movie_data._get_movies_list()
    items = []
    for m in movies:
        details  = movie_data._get_movie_details(m)
        year_int = int(details[0]) if str(details[0]).isdigit() else None
        items.append({'title': m, 'year': year_int, 'media_type': 'movie'})

    pDialog = xbmcgui.DialogProgress()
    pDialog.create("TopZilla", "Descargando metadatos desde TMDB...")
    try:
        count = me.batch_fetch_with_progress(items, pDialog)
    finally:
        pDialog.close()

    xbmcgui.Dialog().notification(
        "TopZilla",
        "Metadatos descargados: {0}/{1}".format(count, len(items)),
        xbmcgui.NOTIFICATION_INFO,
    )
    xbmc.executebuiltin("Container.Refresh")


def clear_cache():
    try:
        # Borra el JSON de posters (legacy)
        _save_cache({})

        import metadata_enricher as me
        items = []
        for m in movie_data._get_movies_list():
            details  = movie_data._get_movie_details(m)
            year_int = int(details[0]) if str(details[0]).isdigit() else None
            items.append({'title': m, 'year': year_int, 'media_type': 'movie'})
        me.delete_items(items)

        xbmcgui.Dialog().notification(
            "TopZilla",
            "Metadatos del Top eliminados.",
            xbmcgui.NOTIFICATION_INFO,
            4000,
        )
        xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        xbmc.log("[TopZilla-TM] error borrando caché: {0}".format(e), xbmc.LOGWARNING)
