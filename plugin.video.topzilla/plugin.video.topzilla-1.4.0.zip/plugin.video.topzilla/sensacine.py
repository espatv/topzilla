# -*- coding: utf-8 -*-
# TopZilla — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
import sys
import re
import html
import json
import os
import time
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
import requests
import core_settings

_CARTELERA_URL = "https://www.sensacine.com/peliculas/en-cartelera/cines/"
_ESTRENOS_URL  = "https://www.sensacine.com/peliculas/estrenos/"
_MEJORES_URL   = "https://www.sensacine.com/peliculas/mejores/"
_TAQUILLA_URL  = "https://www.sensacine.com/peliculas/taquilla/"
_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Accept-Language": "es-ES,es;q=0.9",
    "Referer": "https://www.sensacine.com/",
}
_SC_TTL = 6 * 3600
_SC_TTL_LONG = 7 * 24 * 3600
_SC_MIN_FILMS = 3
_MEJORES_PAGES = 5


def _u(**kwargs):
    return core_settings.make_url(**kwargs)

def _handle():
    return int(sys.argv[1])


def _cache_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(profile, 'topzilla_sc_cache.json')


def _load_cache():
    empty = {"cartelera": {}, "estrenos": {}, "mejores": {}, "taquilla": {}}
    try:
        path = _cache_path()
        if not os.path.exists(path):
            return empty
        with open(path, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        for key in empty:
            if not isinstance(data.get(key), dict):
                data[key] = {}
        return data
    except Exception as e:
        xbmc.log(f"[TopZilla] sensacine cache load error: {e}", xbmc.LOGWARNING)
        return empty


def _save_cache(data):
    try:
        path = _cache_path()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, path)
    except Exception as e:
        xbmc.log(f"[TopZilla] sensacine cache save error: {e}", xbmc.LOGWARNING)


def _cache_fresh(cache):
    c = cache.get("cartelera", {})
    return bool(c.get("films")) and (time.time() - c.get("fetched_at", 0)) < _SC_TTL


def _scrape_url(url, label, seen=None):
    try:
        r = requests.get(url, headers=_HEADERS, timeout=12)
        xbmc.log(f"[TopZilla] sensacine {label} -> {r.status_code}", xbmc.LOGINFO)
        if r.status_code != 200:
            return None
        films = []
        if seen is None:
            seen = set()
        for block in re.split(r'(?=<div[^>]+class="[^"]*(?:entity-card|movie-card-bo)[^"]*")', r.text):
            id_m = re.search(r'/peliculas/pelicula-(\d+)/', block)
            if not id_m:
                continue
            fid = id_m.group(1)
            if fid in seen:
                continue
            title_m = re.search(r'class="meta-title-link"[^>]*>([^<]+)</a>', block)
            if not title_m:
                continue
            seen.add(fid)
            title = html.unescape(title_m.group(1).strip())
            img_m = re.search(r'data-src="(https://[^"]+acsta\.net[^"]*)"', block)
            if not img_m:
                img_m = re.search(r'\bsrc="(https://[^"]+acsta\.net[^"]*)"', block)
            poster = img_m.group(1) if img_m else ''
            films.append({'id': fid, 'title': title, 'poster': poster})
        return films
    except Exception as e:
        xbmc.log(f"[TopZilla] sensacine {label} error: {e}", xbmc.LOGERROR)
        return None


def _scrape_cartelera():
    films = _scrape_url(_CARTELERA_URL, "cartelera")
    if films is None:
        return None
    if len(films) < _SC_MIN_FILMS:
        xbmc.log(f"[TopZilla] sensacine cartelera sospechosa ({len(films)} films), ignorando", xbmc.LOGWARNING)
        return None
    xbmc.log(f"[TopZilla] sensacine scrapeadas {len(films)} películas", xbmc.LOGINFO)
    return films


def _fetch_cartelera():
    cache = _load_cache()

    if _cache_fresh(cache):
        films = cache["cartelera"]["films"]
        xbmc.log(f"[TopZilla] sensacine cartelera desde caché ({len(films)} títulos)", xbmc.LOGINFO)
        return films

    scraped = _scrape_cartelera()
    if scraped is not None:
        films = scraped
        cache["cartelera"] = {"fetched_at": time.time(), "films": films}
    elif cache.get("cartelera", {}).get("films"):
        films = cache["cartelera"]["films"]
        xbmc.log("[TopZilla] sensacine inaccesible, usando caché caducada", xbmc.LOGWARNING)
    else:
        return []

    _save_cache(cache)
    return films


def show_cartelera():
    import metadata_enricher as me

    films = _fetch_cartelera()
    if not films:
        xbmcgui.Dialog().notification("TopZilla", "No se pudo cargar SensaCine", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle())
        return

    af = core_settings.addon_fanart()
    auto_fetch = core_settings._auto_fetch_enabled()
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()

    if not auto_fetch:
        first_title = films[0]['title'] if films else None
        has_meta = bool(me.enrich(title=first_title, media_type='movie', use_cache_only=True)) if first_title else False
        if not has_meta:
            li = xbmcgui.ListItem(label=core_settings.apply_label("[COLOR yellow][B]Descargar metadatos completos[/B][/COLOR]", bold=_bold, strip=_strip, color_mode=_color))
            li.setArt({'icon': 'DefaultAddonService.png', 'fanart': core_settings.addon_fanart()})
            li.setInfo('video', {'plot': "Descarga sinopsis en español, actores y director de las películas en cartelera."})
            xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="sensacine_cache_cartelera_meta"), listitem=li, isFolder=False)
        else:
            li = xbmcgui.ListItem(label=core_settings.apply_label("[COLOR red][B]Borrar metadatos de cartelera[/B][/COLOR]", bold=_bold, strip=_strip, color_mode=_color))
            li.setArt({'icon': 'DefaultIconError.png', 'fanart': core_settings.addon_fanart()})
            li.setInfo('video', {'plot': "Elimina los metadatos guardados de la cartelera actual."})
            xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="sensacine_clear_cartelera_meta"), listitem=li, isFolder=False)

    import context_menu, movie_ref
    for f in films:
        li = xbmcgui.ListItem(label=core_settings.apply_label("[B]{0}[/B]".format(f['title']), bold=_bold, strip=_strip, color_mode=_color))
        meta = me.enrich(title=f['title'], media_type='movie', use_cache_only=not auto_fetch)
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or f['poster']
        else:
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': f['poster'], 'poster': f['poster'], 'fanart': af})
            li.setInfo('video', {'title': f['title'], 'mediatype': 'movie'})
            poster = f['poster']
        tmdb_id = (meta or {}).get('ids', {}).get('tmdb') if meta else None
        plot = meta.get('overview', '') if meta else ''
        ref = movie_ref.make_ref(
            title=f['title'], year=(meta or {}).get('year') if meta else None,
            tmdb_id=tmdb_id, poster=poster,
            media_type='movie', source='sensacine', plot=plot,
        )
        context_menu.attach(li, ref)
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(handle=_handle(), url=context_menu.build_play_url(ref), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(_handle())


def _estrenos_fresh(cache):
    c = cache.get("estrenos", {})
    return bool(c.get("films")) and (time.time() - c.get("fetched_at", 0)) < _SC_TTL


def _scrape_estrenos():
    films = _scrape_url(_ESTRENOS_URL, "estrenos")
    if films is None:
        return None
    if len(films) < _SC_MIN_FILMS:
        xbmc.log(f"[TopZilla] sensacine estrenos sospechoso ({len(films)} films), ignorando", xbmc.LOGWARNING)
        return None
    xbmc.log(f"[TopZilla] sensacine estrenos: {len(films)} películas", xbmc.LOGINFO)
    return films


def _scrape_mejores():
    seen = set()
    films = []
    for page in range(1, _MEJORES_PAGES + 1):
        url = _MEJORES_URL if page == 1 else f"{_MEJORES_URL}?page={page}"
        page_films = _scrape_url(url, f"mejores p{page}", seen=seen)
        if page_films is None:
            break
        films.extend(page_films)
        if len(page_films) == 0:
            break
    if len(films) < _SC_MIN_FILMS:
        xbmc.log(f"[TopZilla] sensacine mejores sospechoso ({len(films)} films), ignorando", xbmc.LOGWARNING)
        return None
    xbmc.log(f"[TopZilla] sensacine mejores: {len(films)} películas", xbmc.LOGINFO)
    return films


def _scrape_taquilla():
    films = _scrape_url(_TAQUILLA_URL, "taquilla")
    if films is None:
        return None
    if len(films) < _SC_MIN_FILMS:
        xbmc.log(f"[TopZilla] sensacine taquilla sospechosa ({len(films)} films), ignorando", xbmc.LOGWARNING)
        return None
    xbmc.log(f"[TopZilla] sensacine taquilla: {len(films)} películas", xbmc.LOGINFO)
    return films


def _fetch_estrenos():
    cache = _load_cache()

    if _estrenos_fresh(cache):
        films = cache["estrenos"]["films"]
        xbmc.log(f"[TopZilla] sensacine estrenos desde caché ({len(films)} títulos)", xbmc.LOGINFO)
        return films

    scraped = _scrape_estrenos()
    if scraped is not None:
        films = scraped
        cache["estrenos"] = {"fetched_at": time.time(), "films": films}
    elif cache.get("estrenos", {}).get("films"):
        films = cache["estrenos"]["films"]
        xbmc.log("[TopZilla] sensacine estrenos inaccesible, usando caché caducada", xbmc.LOGWARNING)
    else:
        return []

    _save_cache(cache)
    return films


def show_estrenos():
    import metadata_enricher as me

    films = _fetch_estrenos()
    if not films:
        xbmcgui.Dialog().notification("TopZilla", "No se pudo cargar SensaCine Estrenos", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle())
        return

    af = core_settings.addon_fanart()
    auto_fetch = core_settings._auto_fetch_enabled()
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()

    if not auto_fetch:
        first_title = films[0]['title'] if films else None
        has_meta = bool(me.enrich(title=first_title, media_type='movie', use_cache_only=True)) if first_title else False
        if not has_meta:
            li = xbmcgui.ListItem(label=core_settings.apply_label("[COLOR yellow][B]Descargar metadatos completos[/B][/COLOR]", bold=_bold, strip=_strip, color_mode=_color))
            li.setArt({'icon': 'DefaultAddonService.png', 'fanart': core_settings.addon_fanart()})
            li.setInfo('video', {'plot': "Descarga sinopsis en español, actores y director de los próximos estrenos."})
            xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="sensacine_cache_estrenos_meta"), listitem=li, isFolder=False)
        else:
            li = xbmcgui.ListItem(label=core_settings.apply_label("[COLOR red][B]Borrar metadatos de estrenos[/B][/COLOR]", bold=_bold, strip=_strip, color_mode=_color))
            li.setArt({'icon': 'DefaultIconError.png', 'fanart': core_settings.addon_fanart()})
            li.setInfo('video', {'plot': "Elimina los metadatos guardados de los próximos estrenos."})
            xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="sensacine_clear_estrenos_meta"), listitem=li, isFolder=False)

    import context_menu, movie_ref
    for f in films:
        li = xbmcgui.ListItem(label=core_settings.apply_label("[B]{0}[/B]".format(f['title']), bold=_bold, strip=_strip, color_mode=_color))
        meta = me.enrich(title=f['title'], media_type='movie', use_cache_only=not auto_fetch)
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or f['poster']
        else:
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': f['poster'], 'poster': f['poster'], 'fanart': af})
            li.setInfo('video', {'title': f['title'], 'mediatype': 'movie'})
            poster = f['poster']
        tmdb_id = (meta or {}).get('ids', {}).get('tmdb') if meta else None
        plot = meta.get('overview', '') if meta else ''
        ref = movie_ref.make_ref(
            title=f['title'], year=(meta or {}).get('year') if meta else None,
            tmdb_id=tmdb_id, poster=poster,
            media_type='movie', source='sensacine', plot=plot,
        )
        context_menu.attach(li, ref)
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(handle=_handle(), url=context_menu.build_play_url(ref), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(_handle())


def cache_cartelera_meta():
    import metadata_enricher as me

    films = _fetch_cartelera()
    if not films:
        xbmcgui.Dialog().notification("TopZilla", "No hay películas en cartelera", xbmcgui.NOTIFICATION_ERROR)
        return

    items = [{'title': f['title'], 'media_type': 'movie'} for f in films]
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("TopZilla", "Descargando metadatos cartelera...")
    try:
        count = me.batch_fetch_with_progress(items, pDialog)
    finally:
        pDialog.close()

    xbmcgui.Dialog().notification(
        "TopZilla",
        "Metadatos guardados: {0}/{1}".format(count, len(items)),
        xbmcgui.NOTIFICATION_INFO,
    )
    xbmc.executebuiltin("Container.Refresh")


def clear_cartelera_meta():
    import metadata_enricher as me

    films = _fetch_cartelera()
    items = [{'title': f['title'], 'media_type': 'movie'} for f in films]
    me.delete_items(items)
    xbmcgui.Dialog().notification("TopZilla", "Metadatos de cartelera eliminados", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


def cache_estrenos_meta():
    import metadata_enricher as me

    films = _fetch_estrenos()
    if not films:
        xbmcgui.Dialog().notification("TopZilla", "No hay estrenos disponibles", xbmcgui.NOTIFICATION_ERROR)
        return

    items = [{'title': f['title'], 'media_type': 'movie'} for f in films]
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("TopZilla", "Descargando metadatos estrenos...")
    try:
        count = me.batch_fetch_with_progress(items, pDialog)
    finally:
        pDialog.close()

    xbmcgui.Dialog().notification(
        "TopZilla",
        "Metadatos guardados: {0}/{1}".format(count, len(items)),
        xbmcgui.NOTIFICATION_INFO,
    )
    xbmc.executebuiltin("Container.Refresh")


def clear_estrenos_meta():
    import metadata_enricher as me

    films = _fetch_estrenos()
    items = [{'title': f['title'], 'media_type': 'movie'} for f in films]
    me.delete_items(items)
    xbmcgui.Dialog().notification("TopZilla", "Metadatos de estrenos eliminados", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


_SECTION_TTLS = {"mejores": _SC_TTL_LONG}


def _section_fresh(cache, key):
    c = cache.get(key, {})
    ttl = _SECTION_TTLS.get(key, _SC_TTL)
    return bool(c.get("films")) and (time.time() - c.get("fetched_at", 0)) < ttl


def _fetch_section(key, scraper, label):
    cache = _load_cache()
    if _section_fresh(cache, key):
        films = cache[key]["films"]
        xbmc.log(f"[TopZilla] sensacine {label} desde caché ({len(films)} títulos)", xbmc.LOGINFO)
        return films
    scraped = scraper()
    if scraped is not None:
        films = scraped
        cache[key] = {"fetched_at": time.time(), "films": films}
    elif cache.get(key, {}).get("films"):
        films = cache[key]["films"]
        xbmc.log(f"[TopZilla] sensacine {label} inaccesible, usando caché caducada", xbmc.LOGWARNING)
    else:
        return []
    _save_cache(cache)
    return films


def _fetch_mejores():
    return _fetch_section("mejores", _scrape_mejores, "mejores")


def _fetch_taquilla():
    return _fetch_section("taquilla", _scrape_taquilla, "taquilla")


def _show_section(films, action_prefix, plot_label, error_label):
    import metadata_enricher as me

    if not films:
        xbmcgui.Dialog().notification("TopZilla", f"No se pudo cargar {error_label}", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle())
        return

    af = core_settings.addon_fanart()
    auto_fetch = core_settings._auto_fetch_enabled()
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()

    if not auto_fetch:
        first_title = films[0]['title'] if films else None
        has_meta = bool(me.enrich(title=first_title, media_type='movie', use_cache_only=True)) if first_title else False
        if not has_meta:
            li = xbmcgui.ListItem(label=core_settings.apply_label("[COLOR yellow][B]Descargar metadatos completos[/B][/COLOR]", bold=_bold, strip=_strip, color_mode=_color))
            li.setArt({'icon': 'DefaultAddonService.png', 'fanart': af})
            li.setInfo('video', {'plot': f"Descarga sinopsis en español, actores y director de {plot_label}."})
            xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action=f"sensacine_cache_{action_prefix}_meta"), listitem=li, isFolder=False)
        else:
            li = xbmcgui.ListItem(label=core_settings.apply_label(f"[COLOR red][B]Borrar metadatos de {action_prefix}[/B][/COLOR]", bold=_bold, strip=_strip, color_mode=_color))
            li.setArt({'icon': 'DefaultIconError.png', 'fanart': af})
            li.setInfo('video', {'plot': f"Elimina los metadatos guardados de {plot_label}."})
            xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action=f"sensacine_clear_{action_prefix}_meta"), listitem=li, isFolder=False)

    import context_menu, movie_ref
    for f in films:
        li = xbmcgui.ListItem(label=core_settings.apply_label("[B]{0}[/B]".format(f['title']), bold=_bold, strip=_strip, color_mode=_color))
        meta = me.enrich(title=f['title'], media_type='movie', use_cache_only=not auto_fetch)
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or f['poster']
        else:
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': f['poster'], 'poster': f['poster'], 'fanart': af})
            li.setInfo('video', {'title': f['title'], 'mediatype': 'movie'})
            poster = f['poster']
        tmdb_id = (meta or {}).get('ids', {}).get('tmdb') if meta else None
        plot = meta.get('overview', '') if meta else ''
        ref = movie_ref.make_ref(
            title=f['title'], year=(meta or {}).get('year') if meta else None,
            tmdb_id=tmdb_id, poster=poster,
            media_type='movie', source='sensacine', plot=plot,
        )
        context_menu.attach(li, ref)
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(handle=_handle(), url=context_menu.build_play_url(ref), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(_handle())


def show_mejores():
    _show_section(_fetch_mejores(), "mejores",
                  "las mejores películas según SensaCine",
                  "SensaCine Mejores")


def show_taquilla():
    _show_section(_fetch_taquilla(), "taquilla",
                  "las películas más vistas en taquilla",
                  "SensaCine Taquilla")


def _batch_meta(films, label_progress):
    import metadata_enricher as me
    items = [{'title': f['title'], 'media_type': 'movie'} for f in films]
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("TopZilla", label_progress)
    try:
        count = me.batch_fetch_with_progress(items, pDialog)
    finally:
        pDialog.close()
    xbmcgui.Dialog().notification(
        "TopZilla",
        "Metadatos guardados: {0}/{1}".format(count, len(items)),
        xbmcgui.NOTIFICATION_INFO,
    )
    xbmc.executebuiltin("Container.Refresh")


def cache_mejores_meta():
    films = _fetch_mejores()
    if not films:
        xbmcgui.Dialog().notification("TopZilla", "No hay mejores películas", xbmcgui.NOTIFICATION_ERROR)
        return
    _batch_meta(films, "Descargando metadatos mejores...")


def clear_mejores_meta():
    import metadata_enricher as me
    films = _fetch_mejores()
    items = [{'title': f['title'], 'media_type': 'movie'} for f in films]
    me.delete_items(items)
    xbmcgui.Dialog().notification("TopZilla", "Metadatos de mejores eliminados", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


def cache_taquilla_meta():
    films = _fetch_taquilla()
    if not films:
        xbmcgui.Dialog().notification("TopZilla", "No hay datos de taquilla", xbmcgui.NOTIFICATION_ERROR)
        return
    _batch_meta(films, "Descargando metadatos taquilla...")


def clear_taquilla_meta():
    import metadata_enricher as me
    films = _fetch_taquilla()
    items = [{'title': f['title'], 'media_type': 'movie'} for f in films]
    me.delete_items(items)
    xbmcgui.Dialog().notification("TopZilla", "Metadatos de taquilla eliminados", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")
