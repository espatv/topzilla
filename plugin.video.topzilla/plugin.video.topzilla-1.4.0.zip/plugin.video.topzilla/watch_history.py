# -*- coding: utf-8 -*-
# TopZilla — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""
Historial de Visionado: películas marcadas como vistas por el usuario
desde el menú contextual ("Marcar como vista" / "Desmarcar como vista").

Modelo: lista de MovieRef en `watch_history.json`. Cada entrada lleva
`watched_at` además de `added_at`.
"""
import sys
import time

import xbmc
import xbmcgui
import xbmcplugin

import core_settings
import movie_ref


_FILE = 'watch_history.json'


def _u(**kwargs):
    return core_settings.make_url(**kwargs)


def _handle():
    return int(sys.argv[1])


def _load():
    data = core_settings.load_json(_FILE, default=[])
    return data if isinstance(data, list) else []


def _save(refs):
    core_settings.save_json(_FILE, refs)


def is_watched(key):
    if not key:
        return False
    return any(movie_ref.ref_key(r) == key for r in _load())


def mark(ref):
    if not ref or not ref.get('title'):
        return False
    refs = _load()
    key = movie_ref.ref_key(ref)
    if any(movie_ref.ref_key(r) == key for r in refs):
        xbmcgui.Dialog().notification("TopZilla", "Ya estaba marcada como vista",
                                       xbmcgui.NOTIFICATION_INFO, 2500)
        return False
    ref = dict(ref)
    ref['watched_at'] = int(time.time())
    refs.insert(0, ref)
    _save(refs)
    xbmcgui.Dialog().notification("TopZilla",
                                   "Marcada como vista: {0}".format(ref.get('title', '')),
                                   xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin("Container.Refresh")
    return True


def unmark(key):
    if not key:
        return False
    refs = _load()
    new_refs = movie_ref.remove_by_key(refs, key)
    if len(new_refs) == len(refs):
        return False
    _save(new_refs)
    xbmcgui.Dialog().notification("TopZilla", "Desmarcada como vista",
                                   xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin("Container.Refresh")
    return True


def clear_all():
    if not xbmcgui.Dialog().yesno("TopZilla - Historial de Visionado",
                                   "¿Borrar TODO el historial de visionado?\nEsta acción no se puede deshacer."):
        return
    _save([])
    xbmcgui.Dialog().notification("TopZilla", "Historial borrado",
                                   xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin("Container.Refresh")


_DEFAULT_MOVIE_MIN = 100


def _format_time(minutes):
    minutes = max(0, int(minutes))
    if minutes < 60:
        return "{0} min".format(minutes)
    h = minutes // 60
    m = minutes % 60
    if h < 24:
        return "{0}h {1}m".format(h, m) if m else "{0}h".format(h)
    days = h // 24
    rh = h % 24
    parts = ["{0}d".format(days)]
    if rh:
        parts.append("{0}h".format(rh))
    if m:
        parts.append("{0}m".format(m))
    return " ".join(parts)


def _prefetch_meta(refs, me):
    """Consulta el caché de metadatos una vez por ref_key. Devuelve dict ref_key→meta ({} si falla o no hay datos)."""
    out = {}
    for ref in refs:
        key = movie_ref.ref_key(ref)
        if not key or key in out:
            continue
        try:
            out[key] = me.enrich(
                tmdb_id=ref.get('tmdb_id'),
                imdb_id=ref.get('imdb_id'),
                title=ref.get('title', ''),
                year=ref.get('year') or None,
                media_type=ref.get('media_type', 'movie'),
                use_cache_only=True,
            ) or {}
        except Exception:
            out[key] = {}
    return out


def _compute_stats(refs, metas):
    movies = 0
    shows = 0
    movie_min = 0
    movies_with_runtime = 0
    for ref in refs:
        if ref.get('media_type', 'movie') == 'show':
            shows += 1
            continue
        movies += 1
        meta = metas.get(movie_ref.ref_key(ref)) or {}
        try:
            rt = int(meta.get('runtime') or 0)
        except (TypeError, ValueError):
            rt = 0
        if rt > 0:
            movie_min += rt
            movies_with_runtime += 1
        else:
            movie_min += _DEFAULT_MOVIE_MIN
    return {
        'total': len(refs),
        'movies': movies,
        'shows': shows,
        'movie_min': movie_min,
        'movies_with_runtime': movies_with_runtime,
    }


def _stats_banner(refs, metas, af, h, bold, strip, color):
    try:
        s = _compute_stats(refs, metas)
    except Exception:
        return

    parts = []
    if s['movies']:
        parts.append("{0} pelis".format(s['movies']))
    if s['shows']:
        parts.append("{0} series".format(s['shows']))
    summary = " · ".join(parts) if parts else "0 títulos"

    if s['movies']:
        time_str = "~{0}".format(_format_time(s['movie_min']))
        label = ("[COLOR cyan][B]Estadísticas[/B][/COLOR]  [COLOR gray]|[/COLOR]  "
                 "{0}  [COLOR gray]·[/COLOR]  {1} en pelis").format(summary, time_str)
    else:
        label = "[COLOR cyan][B]Estadísticas[/B][/COLOR]  [COLOR gray]|[/COLOR]  {0}".format(summary)

    plot_lines = ["Total: {0} títulos".format(s['total'])]
    if s['movies']:
        unknown = s['movies'] - s['movies_with_runtime']
        plot_lines.append("Películas: {0}  →  ~{1}".format(s['movies'], _format_time(s['movie_min'])))
        if unknown:
            plot_lines.append("  ({0} sin duración en caché, estimadas en {1} min)".format(unknown, _DEFAULT_MOVIE_MIN))
    if s['shows']:
        plot_lines.append("Series: {0} (no se suma tiempo: depende de los episodios vistos)".format(s['shows']))

    li = xbmcgui.ListItem(label=core_settings.apply_label(label, bold=bold, strip=strip, color_mode=color))
    li.setArt({'icon': 'DefaultIconInfo.png', 'fanart': af})
    li.setInfo('video', {'plot': "\n".join(plot_lines)})
    li.setProperty('IsPlayable', 'false')
    xbmcplugin.addDirectoryItem(handle=h, url='', listitem=li, isFolder=False)


def show_menu():
    import metadata_enricher as me
    import context_menu

    h = _handle()
    refs = _load()
    af = core_settings.addon_fanart()

    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()

    if not refs:
        li = xbmcgui.ListItem(label="[COLOR gray]Aún no has marcado ninguna película como vista[/COLOR]")
        li.setArt({'icon': 'DefaultIconInfo.png', 'fanart': core_settings.addon_fanart()})
        li.setInfo('video', {'plot': "Marca películas como vistas desde el menú contextual (clic derecho)\n"
                                       "para que aparezcan aquí."})
        xbmcplugin.addDirectoryItem(handle=h, url='', listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
        return

    metas = _prefetch_meta(refs, me)
    _stats_banner(refs, metas, af, h, _bold, _strip, _color)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR red][B]Borrar todo el historial de visionado[/B][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultIconError.png', 'fanart': core_settings.addon_fanart()})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='watch_history_clear_all'),
                                 listitem=li, isFolder=False)

    for ref in refs:
        title = ref.get('title') or ''
        year = ref.get('year') or 0
        media = ref.get('media_type', 'movie')
        watched_at = ref.get('watched_at') or ref.get('added_at') or 0
        date_str = time.strftime("%d/%m/%Y", time.localtime(watched_at)) if watched_at else ""

        base_label = "[B]{0}[/B]".format(movie_ref.display_label(ref))
        label = "{0} [COLOR gray]({1})[/COLOR]".format(base_label, date_str) if date_str else base_label
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            label, bold=_bold, strip=_strip, color_mode=_color))

        meta = metas.get(movie_ref.ref_key(ref))
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
        else:
            poster = ref.get('poster') or ''
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': poster, 'poster': poster, 'fanart': af})
            li.setInfo('video', {
                'title': title,
                'year': year,
                'plot': ref.get('plot') or '',
                'mediatype': 'tvshow' if media == 'show' else 'movie',
            })

        context_menu.attach(li, ref)
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=context_menu.build_play_url(ref),
            listitem=li,
            isFolder=False,
        )

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)
